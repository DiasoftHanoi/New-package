/*DSMETA version = "5.11.01-HF009-24112802" hash = "e2b483e82f2b61723ff4ec3f68d000f351ff8fd9"*/
/* global form, service */

function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
service = registerMethod(service);

form.isFormEditMode = form.inputParams.EDITMODE || false;
var inputParams = form.inputParams;
var outputParams = form.outputParams || {};
form.formParams = inputParams.formParams || {};
form.firstSupplementatyCard=form.formParams.firstSupplementatyCard || {};
form.secondSupplementatyCard=form.formParams.secondSupplementatyCard || {};
form.mainKNDLMember=form.formParams.mainKNDLMember || {};

outputParams.formParams = form.formParams;
form.isFormEditModeMain = form.inputParams.EDITMODE;
form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);

var gRB = service.gRB;
var lgr = service.lgr;
var nvl = service.nvl;

form.settings = {
    cmbSendCardAndPIN : {
        ReferenceSysName: 'sendCardAndPINLOS',
        ReferenceGroupName: 'Credit Card'
    },
    cmbIssueType : {
        ReferenceSysName: 'ccTypeIssue',
        ReferenceGroupName: 'Credit Card'
    },
    cmbOnlineLimit : {
        ReferenceSysName: 'ccOnlineLimit',
        ReferenceGroupName: 'Credit Card',
        ReferenceItemCode:form.formParams.bankProductName
    },
    cmbPaymentMethodCard : {
        ReferenceSysName: 'paymentMethodLOS',
        ReferenceGroupName: 'Credit Card'
    },
    cmbMethodReceivingMonthlyStatement : {
        ReferenceSysName: 'methodReceivingMonthlyStatementLOS',
        ReferenceGroupName: 'Credit Card'
    },
    cmbpasswordType : {
        ReferenceSysName: 'passwordType',
        ReferenceGroupName: 'General'
    }
};
form.notEmtyValues = function(params) {
   params = params || [];
   if(form.inputParams.APPLICATIONID)  return false;
   var i =0; while (i<params.length) {
   var curVal = params[i];
      if (curVal != '' && curVal != undefined && curVal != null)  {
          return false;
      }
   i++;
   }
   return true;
};

form.firstSupplementaryCollaps=form.notEmtyValues(form.firstSupplementatyCard) ;
form.secondtSupplementaryCollaps=form.notEmtyValues(form.secondSupplementatyCard);

form.onShow = function () {
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });
    if (form.isFormEditMode) {
        form.getBPparamValues();
        form.getSecondBPparamValues();
        form.secondCardTypeName(true);
    }
};

form.requiredElements = [
    "cbCardType",
    "cbPrincipalRepaymentMethod",
    "cbInterestRepaymentMethod",
    "edCreditLimit",
    "cbCreditLimitCurrency",
    "edRequestedLimit",
    "cbOnlineLimit",
    "edTerm",
    "interestRate",
    "overdueInterestRate",
    "maxFreeInterestPeriod",
    "cbSendCardAndPIN",
    "cbPasswordType",
    "edPasswordCreditCard",
    "cbIssueType",
    "cbPaymentMethodCard",
    "cbMethodReceivingMonthlyStatement",
    "edExceptionConditionsCard"
];

form.isExistValueItem = function(list, item, obj) {
    for (var i = 0, count = list.length; i < count; i++) {
        if (list[i].VALUE1 == item) {
            return true;
        }
    }
    if (obj) {
        form[obj].setValue("");
    }
    return false;
};

form.getBPparamValues = function(){

    var PARAMTYPELIST = [
        "currencyLOS",
        "principalRepaymentMethodLOS",
        "interestRepaymentMethodLOS",
        "minTerm",
        "maxTerm",
        "minCreditLimit",
        "maxCreditLimit",
        "classCustomer",
        "interestRateLOS",
        "interestRateOverdueLOS",
        "maxFreeInterestPeriod"
    ];
    var PRODUCTID = form.formParams.bankProductId;
    if (!PRODUCTID) return;
    var dsCallparams = {
        PRODUCTID: PRODUCTID,
        PARAMTYPELIST: PARAMTYPELIST,
        RETURN_ABSOLUTE_PARAM:true

    };

    return form.dsCall('[frontws2]', 'bankProductParamGetListByProductId', dsCallparams).then(function (response){

        service.lgr(response);
        for (var i=0; i<response.data.Result.length;i++){
            var items = response.data.Result[i];
            switch (items["PARAMTYPE"]){
                case "currencyLOS":
                    inputParams.currency_ITEMS = items["VALUES"];
                    break;
                case "principalRepaymentMethodLOS":
                    inputParams.principalRepaymentMethod_ITEMS = items["VALUES"];
                    break;
                case "interestRepaymentMethodLOS":
                    inputParams.interestRepaymentMethod_ITEMS = items["VALUES"];
                    break;
                case "minTerm":
                    inputParams.minTerm_ITEMS = items["VALUES"];
                    break;
                case "maxTerm":
                    inputParams.maxTerm_ITEMS = items["VALUES"];
                    break;
                case "minCreditLimit":
                    inputParams.minCreditLimit_ITEMS = items["VALUES"];
                    break;
                case "maxCreditLimit":
                    inputParams.maxCreditLimit_ITEMS = items["VALUES"];
                    break;
                case "interestRateLOS":
                    inputParams.interestRate_ITEMS = items["VALUES"];
                    break;
                case "interestRateOverdueLOS":
                    inputParams.interestRateOverdue_ITEMS = items["VALUES"];
                    break;
                case "maxFreeInterestPeriod":
                    inputParams.maxFreeInterestPeriod_ITEMS = items["VALUES"];
                    break;
            }
        }
        if (form.isFormEditModeMain) {
            form.isExistValueItem(inputParams.currency_ITEMS, form.formParams.creditCurrencySysName, "cbCreditLimitCurrency");
            form.isExistValueItem(inputParams.principalRepaymentMethod_ITEMS, form.formParams.principalRepaymentMethodSysName, "cbPrincipalRepaymentMethod");
            form.isExistValueItem(inputParams.interestRepaymentMethod_ITEMS, form.formParams.interestRepaymentMethodSysName, "cbInterestRepaymentMethod");
        }
        if(form.cbCardType){
            form.formParams.bankProductName=form.cbCardType.getText();
            if (form.formParams.bankProductName == 'VISA MobiFone') {
                delete form.mainKNDLMember.tier;
                delete form.mainKNDLMember.number;
                delete form.mainKNDLMember.validFrom;
                delete form.mainKNDLMember.validTo;
            }
        }
        if(form.cbOnlineLimit){
            form.settings.cmbOnlineLimit.ReferenceItemCode=form.cbCardType.getText();
            form.cbOnlineLimit.refresh();
        }
    }).catch(function (e){
        form.showErrorDialog('error', function(){}, [{caption: 'OK'}]);
    });
};

form.getSecondBPparamValues = function(flag){

    var PARAMTYPELIST = [
        "currencyLOS"
    ];
    var PRODUCTID = form.secondSupplementatyCard.cardType;
    if (!PRODUCTID) return;
    var dsCallparams = {
        PRODUCTID: PRODUCTID,
        PARAMTYPELIST: PARAMTYPELIST,
        RETURN_ABSOLUTE_PARAM:true

    };

    return form.dsCall('[frontws2]', 'bankProductParamGetListByProductId', dsCallparams).then(function (response){

        service.lgr(response);
        for (var i=0; i<response.data.Result.length;i++){
            var items = response.data.Result[i];
            switch (items["PARAMTYPE"]){
                case "currencyLOS":
                    inputParams.secondCurrency_ITEMS = items["VALUES"];
                    break;
            }
        }
        if (form.isFormEditModeMain) {
            form.isExistValueItem(inputParams.secondCurrency_ITEMS, form.secondSupplementatyCard.limitCurrency, "cbLimitCurrency");
            if(flag) form.secondSupplementatyCard.limitCurrency='VND';
        }
    }).catch(function (e){
        form.showErrorDialog('error', function(){}, [{caption: 'OK'}]);
    });
};
form.executeCommand = function(msg){
    if (msg.event === 'FAB_NAVIGATOR_NAVIGATE'){
        outputParams.NEXTPAGE = msg.params.step;
        form.action('DIRECT');
    }
};

form.verifyForm = function (showFlag) {
    var verified = true;
    try {
        var btnNext = (form.isLastWizForm) ? "btnSave" : "btnNext";
        if (form.validateControlsByIds(form.requiredElements.join(','), showFlag === true ? btnNext : undefined).isShowFormErrors) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {lgr(e);
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    form.outputParams.VERIFIED = verified;
    return verified;
};

form.action = function (tagName) {
    outputParams.TRANSTYPE = tagName;
    if (form.isFormEditModeMain) {
        outputParams.formParams.PRODUCTBRIEFNAME = form.formParams.bankProductName = (form.cbCardType) ? form.cbCardType.getText(): undefined;
        outputParams.formParams.bankProductBrief = (form.formParams.bankProductId) ? inputParams.bankProdParamMap[form.formParams.bankProductId]["PRODUCTBRIEFNAME"] : undefined;
        outputParams.formParams.bankProductGroupName            = form.cbCardType.getText();
        outputParams.formParams.principalRepaymentMethod        = form.cbPrincipalRepaymentMethod.getText();
        outputParams.formParams.interestRepaymentMethod         = form.cbInterestRepaymentMethod.getText();
        outputParams.formParams.creditCurrency                  = form.cbCreditLimitCurrency.getText();
        outputParams.formParams.interestRate                    = form.interestRate.getText();
        outputParams.formParams.overdueInterestRate             = form.overdueInterestRate.getText();
        outputParams.formParams.maxFreeInterestPeriod           = form.maxFreeInterestPeriod.getText();
        outputParams.formParams.sendCardAndPIN                  = form.cbSendCardAndPIN.getText();
        outputParams.formParams.passwordType                    = form.cbPasswordType.getText();
        outputParams.formParams.onlineLimit                     = form.cbOnlineLimit.getText();
        outputParams.formParams.issueType                       = form.cbIssueType.getText();
        outputParams.formParams.paymentMethodCard               = form.cbPaymentMethodCard.getText();
        outputParams.formParams.methodReceivingMonthlyStatement = form.cbMethodReceivingMonthlyStatement.getText();
        outputParams.formParams.firstSupplementatyCard          = form.firstSupplementatyCard;
        outputParams.formParams.secondSupplementatyCard         = form.secondSupplementatyCard;
        outputParams.formParams.mainKNDLMember                  = form.mainKNDLMember;

        if( (form.secondSupplementatyCard.cardholderName != null && form.secondSupplementatyCard.cardholderName+"" !="") ||
            (form.secondSupplementatyCard.cardType != null && form.secondSupplementatyCard.cardType+"" !="") ||
            (form.secondSupplementatyCard.requestedLimit != null && form.secondSupplementatyCard.requestedLimit+"" !="") ||
            (form.secondSupplementatyCard.limitCurrency != null && form.secondSupplementatyCard.limitCurrency+"" !=""))
        {
                outputParams.formParams.hasSupplementaryCard = true;
        }
        else {
            outputParams.formParams.hasSupplementaryCard = false;
        }


    }
    if (tagName === 'CLOSE') {
        if(form.inputParams.EDITMODE === false) {
            form.sendForm('GO',false);
        } else {
            service.showDialogCancelConfirm(
                form,
                function (){
                    form.outputParams.TRANSTYPE = 'SAVEDRAFT';
                    form.verifyForm(false);
                    form.sendForm('GO', false);
                },
                function () {
                    form.outputParams.TRANSTYPE = 'CLOSE';
                    form.sendForm('GO',false);
                }
            )
        }
    } else {
        if (tagName === 'NEXT' && !form.verifyForm(true)) {
            return;
        } else {
            form.verifyForm(false);
        }
        form.sendForm('GO', false);
    }
};

form.secondCardTypeName = function(isOnShow){
  if(form.cbsCardType && form.secondSupplementatyCard) {
    form.secondSupplementatyCard.cardTypeName=form.cbsCardType.getText();
    if (form.secondSupplementatyCard.cardTypeName=='VISA MobiFone' && !isOnShow){
        delete form.secondSupplementatyCard.tier;
        delete form.secondSupplementatyCard.number;
        delete form.secondSupplementatyCard.validFrom;
        delete form.secondSupplementatyCard.validTo;
    }
  } 
};

form.setMinDateValidTo = function(){
    if(form.cldValidTo){
        form.cldValidTo.setMinDate(utils.convertDate(form.firstSupplementatyCard.validFrom));
    }
    if(form.cldMemberValidTo){
        form.cldMemberValidTo.setMinDate(utils.convertDate(form.mainKNDLMember.validFrom));
    } 
    if(form.cldSecondSupplementatyValidTo){
        form.cldSecondSupplementatyValidTo.setMinDate(utils.convertDate(form.secondSupplementatyCard.validFrom));
    }      
};