template.PostFix=template.data.PostFix || "";
var PostFix=template.data.PostFix || "";
template.templateParams=template.data.address || {};
template.templateKind=template.data.templateKind || "large";
template.templateParams.Country=template.templateParams.Country || "VIET NAM";
template.templateParams.CountryCode=template.templateParams.CountryCode || "VN";
template.RequiredFlag=template.data.addressRequiredFlag || "true";
template.addressEnabled = template.data.addressEnabled || "true";
if(template.data.addressType) template.templateParams.addressType=template.data.addressType;
var nvl=service.nvl;

template.settings={
    /*countryParams:{
        ParamKeyList: ["BRIEFNAME", "ALPHACODE3", "COUNTRYNAME"],
        ParamValue: "VIET NAM"
    },*/
    countryParams:{
            ParamKeyList: ["ALPHACODE3", "BRIEFNAME", "COUNTRYNAME"],
            ParamValue: "VNM"
        },
    levelOneParams:{
        LEVEL:1
    },
    levelTwoParams:{
        LEVEL:2
    }, 
    levelThreeParams:{
        LEVEL:3
    }
    
}
template.onShow = function(){

    if(template.templateParams.RegionId) {
        template.settings.levelTwoParams.PARENT_CODE= template.templateParams.RegionId;
        template["cmCity"+PostFix].refresh();
    }  
    if(template.templateParams.DistrictId) {
        template.settings.levelThreeParams.PARENT_CODE= template.templateParams.DistrictId;
        template["cmWards"+PostFix].refresh();
    } 
    template.setAddressText();
    template.setStreet();

};

template.onChangeProvince=function(item){
    console.log("onChangeProvince");
    if(template.templateParams.RegionId) {
        template.templateParams.Region=item.FULLNAME;
        template.templateParams.RegionType=item.SHORTNAME;
        template.settings.levelTwoParams.PARENT_CODE= template.templateParams.RegionId;
        template["cmCity"+PostFix].refresh();
    } 
    template.templateParams.DistrictId=null;
    template.templateParams.CityId=null; 
    template.setAddressText();
};

template.onChangeCity=function(item){
    console.log("onChangeCity");
    if(template.templateParams.DistrictId) {
        template.templateParams.District=item.FULLNAME;
        template.templateParams.DistrictType=item.SHORTNAME;    
        template.settings.levelThreeParams.PARENT_CODE= template.templateParams.DistrictId;
        template["cmWards"+PostFix].refresh();
    }
    template.templateParams.CityId=null;
    template.setAddressText();
};
template.onChangeWards=function(item){
    console.log("onChangeWards");
    if(template.templateParams.CityId) {
        template.templateParams.City=item.FULLNAME;
        template.templateParams.CityType=item.SHORTNAME;    

    } 
    else{
        template.templateParams.City=null;
        template.templateParams.CityType=null;         
    }
    template.setAddressText();
};
template.setAddressText=function(){
    var text = "";
    var address = template.templateParams;    

// Обратный адрес
    if(address.Street){
        text+=((text!="") ? ", " +address.Street : address.Street);
    }
    if(address.CityId){
        text+=((text!="") ? ", " + nvl(address.CityType,"") + " " +address.City : nvl(address.CityType,"") + " " +address.City);
    }  
    if(address.DistrictId){
        text+=((text!="") ? ", " + nvl(address.DistrictType,"") + " " +address.District : nvl(address.DistrictType,"") + " " +address.District);
    } 
    if(address.RegionId){
        text+=((text!="") ? ", " + nvl(address.RegionType,"") + " " +address.Region : nvl(address.RegionType,"") + " " +address.Region);
    }    
    if(address.Country){
        text+=((text!="") ? ", " +address.Country : address.Country);
    }
 
    template.templateParams.addressText=text;
    template.templateParams.AlterName=text;
};

template.setStreet=function(){// В адресдетаил складываем все, что выше 3 уровня(для старых заявок), для новых все должно лежать в Street
    var address = template.templateParams;
    var detailAddressStr="";

    if(address.Town){
        detailAddressStr+=((detailAddressStr!="") ? ", " + nvl(address.TownType,"") + " " +address.Town : nvl(address.TownType,"")+ " " +address.Town);
    }
    if(address.Street){
        detailAddressStr+=((detailAddressStr!="") ? ", " + nvl(address.StreetType,"")+ " " +address.Street : nvl(address.StreetType,"") + (nvl(address.StreetType,"")!="" ? " " +address.Street : address.Street));
    }  
    if(address.House){
        detailAddressStr+=((detailAddressStr!="") ? ", " + nvl(address.HouseType,"") + " " +address.House : nvl(address.HouseType,"") + " " +address.House);
    }
    if(address.Flat){
        detailAddressStr+=((detailAddressStr!="") ? ", " + address.Flat: address.Flat);
    } 
    template.templateParams.Street=detailAddressStr;
    
    var clearList = ["Flat","FlatId","FlatType","House","HouseId","HouseType","StreetId","StreetType","Town","TownId","TownType"];
    for(var i=0;i<clearList.length;i++){// Зачищаем, ненужные теперь параметры адреса
        var key = clearList[i];
        if(template.templateParams[key]){
            template.templateParams[key]="";
        }
    }

};
