template.formParams = template.data;
template.editingMode = template.formParams.editingMode;

template.tabAddConditionObj = (function (grId) {
    var gridId = grId;
    var options = {
        editingMode: template.editingMode,
        btnApplyCaption: '',
        AddConditionParams: {
            ReferenceSysName: (template.data.isAutoFlag === true ? 'AdditionalConditionListAuto' : 'additionalConditions'),
            ORDERBY: 'ReferenceItemID'
        },
        fieldsCaption: {},
        cancel: function () {
            template[gridId].hideEditor();
            if (template['addButtonAddCondition'])
                template.addButtonAddCondition.enable();
        },
        save: function () {
            var selectedRow = template.tabAddCondition.getSelectedRow()[0];
            var newRow = {
                AddCondition: options.AddCondition,
                AdditionalConditionComment: options.AdditionalConditionComment,
                KODInclude: options.KODInclude,
                AddConditionText: template.cmbAddCondition.getText(),
                AdditionalConditionCommentText: template.edAdditionalConditionComment.getValue(),
                AdditionalConditionValue: options.AdditionalConditionValue
            };
            if (selectedRow['id']) {
                newRow['id'] = selectedRow['id'];
                template[gridId].hideEditor();
                template[gridId].updateRow(obj.selectedId, newRow);
            } else {
                newRow['id'] = new Date().getTime();
                template[gridId].hideEditor();
                template[gridId].addRow(newRow);
            }
            template[gridId].refresh();
            if (template['addButtonAddCondition'])
                template.addButtonAddCondition.enable();
        },
        clearFields: function () {
            delete options.AddCondition;
            delete options.AdditionalConditionComment;
            delete options.KODInclude;
        },
        edit: function () {
            options.clearFields();
            options.btnApplyCaption = form.getResourceBundle('some.Edit');
            var selectedRow = template.tabAddCondition.getSelectedRow()[0];
            template[gridId].showEditor('edit');
            options.AddCondition = selectedRow['AddConditionText'];
            options.AdditionalConditionComment = selectedRow['AdditionalConditionComment'];
            options.KODInclude = selectedRow['KODInclude'];
            if (template['addButtonAddCondition'])
                template.addButtonAddCondition.disable();
        },
        delete: function () {
            if (template.tabAddCondition.getSelectedRow()[0]) {
                template.tabAddCondition.deleteRow(obj.selectedId);
                template[gridId].refresh();
            }
            if (template['addButtonAddCondition'])
                template.addButtonAddCondition.enable();
        }
    };

    var obj = {
        gridId: grId,
        refresh: function () {
            template[gridId].refresh();
        },
        onChangeItems: function () {

        },
        addNewAddConditionRow: function () {
            template[gridId].showEditor('add');
            options.clearFields();
            options.btnApplyCaption = form.getResourceBundle('some.AddNew');
            if (template['addButtonAddCondition'])
                template.addButtonAddCondition.disable();
        },
        setItems: function (items) {
            template[gridId].setItems(items);
        },
        getItems: function () {
            return template[gridId].getItems();
        },
        onSelectRow: function () {
            var selRow = template[gridId].getSelectedRow()[0] || {};
            options.items = [];
            if (!selRow.readOnly) {
                if (template.editingMode == 'changeOnlyConditionFulfilled'){
                    options.items = [
                        {caption: form.getResourceBundle('additionalConditions.btnEdit'), click: template.tabAddCondition.options.edit}
                    ];
                }else{
                    options.items = [
                        {caption: form.getResourceBundle('additionalConditions.btnEdit'), click: template.tabAddCondition.options.edit},
                        {caption: form.getResourceBundle('additionalConditions.btnDel'), click: template.tabAddCondition.options.delete}
                    ];
                }
            }

        }
    };

    obj.options = options;
    return obj;
})('tabAddCondition');