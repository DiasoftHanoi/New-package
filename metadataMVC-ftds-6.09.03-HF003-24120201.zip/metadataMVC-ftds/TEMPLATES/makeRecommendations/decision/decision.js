template.formParams = template.data.formParams;
template.parentForm = template.data;
template.isFormEditMode = template.data.isFormEditMode;

template.onChangeComment = function(){
    template.commentRequired = (typeof template.data.setCommentRequired === 'function') ? template.data.setCommentRequired() : false;
}