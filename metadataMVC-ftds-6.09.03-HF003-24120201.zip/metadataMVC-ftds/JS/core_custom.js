/*DSMETA version = "6.01.01" hash = "74581bcfea83aaf6f445829fd5660d46369c4f14"*/
////////////////////////////////////////////////////////////////////////////////
/*function initEI(){
	function getLastID(elID){
		var idxSL=elID.lastIndexOf("_");
	    var idxDot=elID.lastIndexOf(".");
	    if (idxDot==-1){idxDot=idxSL;  if (idxDot==-1) {idxDot=0;}else{idxDot++};}else{idxDot++}
		return [elID.substring(idxDot),idxDot];
	}
	EI=[];
	var eIds=getAllIds();
	for( var i=0;i<eIds.size();i++){
	   var elID=eIds.get(i)
	   var keyData = getLastID(elID);
	   var key=keyData[0];
	   var idx=keyData[1];
	   if (key=="parent"){
	      elID=elID.substring(0,idx-1);
		  key=getLastID(elID)[0];
         
	   }
	   EI[key]=elID;
	}
}*/

initEI = initElementIdsJS;
////////////////////////////////////////////////////////////////////////////////
function stringToNumericPFD(b){
   b+="";
   var c=parseFloat(b.replace(/[^\d,\.-]/g,"").replace(/,/g,"."))+"";
   c=c.replace("NaN","0");
   c=parseFloat(c);
   return c
}
////////////////////////////////////////////////////////////////////
function isPlatform8(){
   isPlatform8Flag = false;
   try {
      var gwtFrame = getGWTFrame();
      if (gwtFrame) {
         isPlatform8Flag = true; 
      }
   }
   finally {
      return isPlatform8Flag;
   }
}
/////////////////////////////////////////////////////////////////////////////
try{
if(isPlatform8()){
  getSCElementByID = function(id){
	id+="";
	if (window.parent[getContextID()+"$"+id.replace(/[.]/gi,"_")]){
		return window.parent[getContextID()+"$"+id.replace(/[.]/gi,"_")]
	}
	return null;
  }
////////////////////////////////////////////////////////////////////////////////
  getContextID = function(){
	return  getGWTFrame().contextId;
  }
////////////////////////////////////////////////////////////////////////////////
  getLikeElementsIn = function(el,tN,attrName,attrValue){
    return window.parent.document.getElementsByTagName(tN+(attrName&&attrValue?"["+attrName+"="+attrValue+"]":attrName?"["+attrName+"]":""),el)
  }
}
}catch(e){}
////////////////////////////////////////////////////////////////////
function gbiFlex(id){
    if(isPlatform8()){
	  var scEl=getSCElementByID(id);
	  if (scEl && scEl._clipDiv){
		return scEl._clipDiv
	  }
    }
	else return gbi(id);
}
