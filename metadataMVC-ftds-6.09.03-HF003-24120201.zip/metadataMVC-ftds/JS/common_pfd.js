/*DSMETA version = "6.01.01" hash = "e6ef91bcf015bb821615e0117bbe57a2d50ebe31"*/

var projectSysName = 'FTDSMVC';
var projectSysNameLOS = 'FTFLOINTMVC';

function nvl(val, def){
    if (typeof val == "undefined" || val == null || val === "") return def;
    return val;
}

function getAddressMapFromParamsMap(pfx, paramsMap){
    var resultMap = new java.util.HashMap();

    paramToMap('Building');
    paramToMap('City');
    paramToMap('CityId');
    paramToMap('CityType');
    paramToMap('Country');
    paramToMap('District');
    paramToMap('DistrictId');
    paramToMap('DistrictType');
    paramToMap('Flat');
    paramToMap('House');
    paramToMap('Housing');
    paramToMap('PostalCode');
    paramToMap('Region');
    paramToMap('RegionId');
    paramToMap('RegionType');
    paramToMap('Street');
    paramToMap('StreetId');
    paramToMap('StreetType');
    paramToMap('Town');
    paramToMap('TownId');
    paramToMap('TownType');
    paramToMap('USEKLADR');

    return resultMap;

    function paramToMap(paramName){
        if (paramsMap.get(pfx+paramName)!=null){
            resultMap.put(paramName, paramsMap.get(pfx+paramName));
        }
    }
}

function mapToExpand(pfx, map){
    var resultMap = new java.util.HashMap();
    if (map instanceof java.util.HashMap){
        var it = map.keySet().iterator();
        while (it.hasNext()){
            var key = it.next().toString();
            resultMap.put((pfx ? pfx : "")+key, map.get(key));
        }
    }
    return resultMap;
}

////////////////////////////////////////////////////////////////////////////////
function cleanUpMap(map,keys){
    var res=getNewMap();
    for (var j=0;j<keys.length;j++){
        if (map.get(keys[j])!=null){
            res.put(keys[j],map.get(keys[j]));
        }
    }
    return res;
}

////////////////////////////////////////////////////////////////////////////////
function cleanUpList(list,keys){
    var res=getNewList();
    for (var i=0;i<list.size();i++){
        res.add(cleanUpMap(list.get(i),keys));
    }
    return res;
}

////////////////////////////////////////////////////////////////////////////////
function getNewMap(jMap){
    jMap=nvl(jMap,{});
    var res=new java.util.HashMap();
    for (var ar in jMap){
        res.put(ar,jMap[ar])
    }
    return res;
}
////////////////////////////////////////////////////////////////////////////////
function getNewList(jList){
    jList=nvl(jList,[]);
    var res=new java.util.ArrayList();
    for (var i=0;i<jList.length;i++){
        res.add(jList[i])
    }
    return res;
}

function gip(paramName, defValue){
    return nvl(getInputParams(paramName), defValue == undefined ? null : defValue);
}

function sop(paramName, paramValue){
    setOutputParams(paramName, paramValue);
}

function strToNum(str){
    str+="";
    var n=parseFloat(str.replace(/[^\d,\.-]/g,"").replace(/,/g,"."))+"";
    n=n.replace("NaN","0");
    n=parseFloat(n);
    return n;
}

function gRB(key){
	return nvl(getResourceBundle(key),key);
}
function getBundle(alertName, alertText){
    var phrase = getResourceBundle(alertName);
    if (phrase == null || phrase == "") phrase = alertText;
    return phrase.toString();
}
function sdFormat(dateForFormat, formatDateText){
    if(formatDateText==null || formatDateText==""){
        formatDateText = "dd.MM.yyyy";
    }
    return new java.text.SimpleDateFormat(formatDateText).format(dateForFormat);
}

function newDate(){
    return new java.util.Date();
}