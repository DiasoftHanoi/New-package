/*DSMETA version = "6.01.01" hash = "298f448f3189c39c95ee1696563478fde717a047"*/
////////////////////////////////////////////
function gRB(key){
	var bundle=getResourceBundle(key);
	return bundle!=null ? bundle : "�"+key+"�";
}
////////////////////////////////////////////////////////////////////////////////
function gRBT(key){
    var str = getResourceBundle(key);
    if(str != null && arguments.length > 1){
        for (var i = 1; i < arguments.length; i++) {
            str = str.replace("%"+i+"$", String(arguments[i]));
        }
    }
    return str;
} 
////////////////////////////////////////////////////////////////////////////////
lgr=function(){
	var dd=arguments.length;
	for (var i=0;i<dd;i++){
		println(arguments[i]);
	}
}
////////////////////////////////////////////////////////////////////////////////
/*function nvl(source,value){
  if (source !=null && source !='' && source !=NaN) {
    return source; 
  }
  else
    return value;
}*/
function nvl(value,defValue){
   return (value != null) ? value : defValue;
}
////////////////////////////////////////////////////////////////////////////////
function convertMoney(amount, oldCurrency, newCurrency, exchanges){
    if (oldCurrency == null || oldCurrency == "" || newCurrency == null || newCurrency == "") return 0;  
    if (oldCurrency == newCurrency) return amount;

    var oldExchange =  exchanges.get(oldCurrency).get('COURSEVALUE');
    var newExchange = exchanges.get(newCurrency).get('COURSEVALUE');
	
    if (oldExchange == null || newExchange == null) return 0;

    var amountInBaseCurrency = amount * oldExchange;
    var newAmount = amountInBaseCurrency / newExchange;
    return newAmount;
}
////////////////////////////////////////////////////////////////////////////////
setFocusByPriority = function(list){
  var dd = list.length;
  for (var i = 0; i < dd; i++) {
    if (getValue(list[i]) == "") {
      setFocus(list[i]);
      break;
    }
  }
  setFocus(list[dd - 1]);
}
////////////////////////////////////////////////////////////////////////////////
