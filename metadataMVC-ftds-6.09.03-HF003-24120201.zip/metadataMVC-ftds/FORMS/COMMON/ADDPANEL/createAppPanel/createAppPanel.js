/*global form*/

form.onNewMiniApp = function () {
    form.startNewPageFlowProcess("Добавление участника",  form.getCurrentProjectSysname() + '/' + 'loanApp/mortgageMiniApp/inputApplication/inputApplication', {}, null, null, function(p){});
}