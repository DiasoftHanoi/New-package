/* global form, service */

var inputParams = form.inputParams || {};
form.formParams = inputParams.formParams;

var outputParams = form.outputParams || {}
outputParams.formParams = form.formParams;

var lgr = service.lgr;
var nvl = service.nvl;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);

form.onShow = function () {
     form.addDublicationCheckTable.setItems(form.inputParams.dublicationCheckList || []);
};

form.executeCommand = function(msg){
    if (msg.event === 'FAB_NAVIGATOR_NAVIGATE'){
        outputParams.NEXTPAGE = msg.params.step;
        form.action('DIRECT');
    }
};

form.tblLoanObj = (function (grId) {
    var gridId = grId;
    var options = {
    };

    var obj = {
        gridId: grId,
        refresh: function () {
        },
        onChangeItems: function () {
        }
    };
    obj.options = options;
    return obj;
})('addDublicationCheckTable');

form.action = function (tagName) {
    outputParams.TRANSTYPE = tagName;
    form.sendForm('GO');
}

form.onSelectApplication=function(item){
    lgr('onSelectApplication', arguments);
    var params = {
        APPLICATIONID : item.DOCUMENTID,
          application : {mode: 'view'}
    };
    form.tblLoanObj.options['ID' + item.DOCUMENTID] = undefined;

    form.startProcess(
        form.getCurrentProjectSysname()+'/COMMON/APPLICATION/getTransferList',
        params,
        function (p) {
            var transfersList = nvl(p['transfersList'],{});
            var resActions=[];
            if (transfersList && transfersList.length) {
              for (var i=0;i<transfersList.length;i++) {
                  if (transfersList[i]["SYSNAME"] == 'LOSAppView') // Требуется только просмотр заявки-дубликата
                      resActions.push({
                          caption:transfersList[i]["NAME"],
                          click:function(){form.onApplicationAction(this,item)},
                          TRANSITIONID:transfersList[i]["TRANSITIONID"]
                      })
              }
            }
            form.tblLoanObj.options['ID' + item.DOCUMENTID] = resActions;
        }
    );

}

form.onApplicationAction=function(data,item){
    form.addDublicationCheckTable.setSelectedRow(undefined);
    form.tblLoanObj.options['ID' + item.DOCUMENTID] = null;
    form.startNewPageFlowProcess(data.caption+'. Application',form.getCurrentProjectSysname()+'/COMMON/STATEMACHINE/callPageflowByTransfer',{
        APPLICATIONID:item.DOCUMENTID,
        TRANSITIONID:data.TRANSITIONID
    },true,null,function(p) {});
}
