var lgr = service.lgr;
var nvl = service.nvl;
var inputParams = form.inputParams;
var outputParams = form.outputParams || {};
form.formParams = inputParams.formParams || {};
outputParams.formParams = form.formParams;
form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);
form.isFormEditMode = form.inputParams.EDITMODE;

form.requiredElements = [
    "generalProductInfoUnsecuredTemplate",
    "decisionMakingGeneralTemplate"
];


form.generalProductInfoTemplateData = {
    parentForm: form,
    fabPageFlowService: fabPageFlowService,
    needDisableLoanPurpose: true
};


form.decisionTemplateData = {
    parentForm: form,
    fabPageFlowService: fabPageFlowService
};

form.onShow = function () {
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });
};


form.executeCommand = function(msg){
    if (msg.event === 'FAB_NAVIGATOR_NAVIGATE'){
        outputParams.NEXTPAGE = msg.params.step;
        form.action('DIRECT');
    }
    if (msg.event === 'GO_TO_PAGEFLOW'){
        form.startNewPageFlowProcess(msg.caption, msg.params.PAGEFLOW, {
            APPLICATIONID: msg.params.APPLICATIONID,
            EDITMODE: false
        });
    }
};

form.verifyForm = function (showFlag, tag) {
    var verified = true;
    var buttonNextSave = (form.isLastWizForm) ? "btnSave" : "btnNext";
    if (tag === 'CLOSE') {
        buttonNextSave = "btnCancel";
    }
    try {
        if ((form.validateControlsByIds(form.requiredElements.join(','), showFlag === true ? buttonNextSave : undefined).isShowFormErrors)) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    form.outputParams.VERIFIED = verified;
    return verified;
};

form.action = function (tagName) {
    outputParams.TRANSTYPE = tagName;
    if(form.isFormEditMode && form.generalProductInfoUnsecuredTemplate) {
        form.formParams.loanPurpose = "";
        form.generalProductInfoUnsecuredTemplate.cmbLoanPurpose ? form.generalProductInfoUnsecuredTemplate.cmbLoanPurpose.getSelectedItems().forEach(function (item, i, arr){
            form.formParams.loanPurpose += item.ReferenceItemBrief;
            if (i < arr.length - 1){
                form.formParams.loanPurpose += "; ";
            }
        }) : undefined;
        form.generalProductInfoUnsecuredTemplate.cmbCurrency ? form.formParams.creditCurrencyName = form.generalProductInfoUnsecuredTemplate.cmbCurrency.getText() : undefined;
        form.formParams.PRODUCTBRIEFNAME = form.formParams.bankProductName = (form.generalProductInfoUnsecuredTemplate.cmbProductName) ? form.generalProductInfoUnsecuredTemplate.cmbProductName.getText(): undefined;
        form.formParams.bankProductBrief = (form.formParams.bankProductId) ? inputParams.bankProdParamMap[form.formParams.bankProductId]["PRODUCTBRIEFNAME"] : undefined;
    }


    if (tagName === 'CLOSE') {
        if(form.inputParams.EDITMODE === false){
            form.sendForm('GO',false);
        }else {
            form.verifyForm(true, tagName);
            service.showDialogCancelConfirm(
                form,
                function () {
                    outputParams.TRANSTYPE = 'SAVEDRAFT';
                    form.sendForm('GO', false);
                }
            )
        }
    } else {

        if (tagName === 'NEXT' && !form.verifyForm(true)) {
            return;
        } else {
            form.verifyForm(false);
        }
        form.sendForm('GO', false);
    }
};