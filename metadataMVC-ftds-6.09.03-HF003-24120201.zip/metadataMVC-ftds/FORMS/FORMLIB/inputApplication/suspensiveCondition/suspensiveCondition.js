/* global form, service */

var inputParams = form.inputParams || {};
form.formParams = inputParams.formParams;

var outputParams = form.outputParams || {}
outputParams.formParams = form.formParams;

form.templateData = {
    SuspensiveConditionList: form.formParams.SuspensiveConditionList || [],
    AddConditionList: form.formParams.AddConditionList || []
};
form.templateData.formParams = form.formParams;
form.templateData.parentForm = form;
form.templateData.fabPageFlowService = fabPageFlowService;

var lgr = service.lgr;
var nvl = service.nvl;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);

form.onShow = function () {
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });
};

form.executeCommand = function(msg){
    if (msg.event === 'FAB_NAVIGATOR_NAVIGATE'){
        outputParams.NEXTPAGE = msg.params.step;
        form.action('DIRECT');
    }
};

form.checkedStatus = function() {
    var validate = true;
    //Add validate
    return validate;
};

form.verifyForm = function (showFlag) {
    var verified = form.checkedStatus();
    if (!verified) {
        return;
    }
    outputParams.VERIFIED = verified;
    return verified;
};

form.action = function (tagName) {
    outputParams.TRANSTYPE = tagName;
    outputParams.VERIFIED = true;
    outputParams.formParams.AddConditionList = form.additionalConditionsTemplates.tabAddCondition.getItems();
    outputParams.formParams.SuspensiveConditionList = form.suspensiveConditionTemplate.tabSuspensiveCondition.getItems();

    if (!form.verifyForm(tagName === 'NEXT' ? true : false) && tagName === 'NEXT') {
        return;
    }
    if (tagName === 'CLOSE') {
        service.showDialogCancelConfirm(form,form.yesFunc);
    } else {
        form.sendForm('GO', false);
    }
};

form.yesFunc = function() {
    form.outputParams.TRANSTYPE = 'SAVEDRAFT';
    form.outputParams.skipTransferState = true;
    form.verifyForm(false);
    form.sendForm('GO', false);
};
