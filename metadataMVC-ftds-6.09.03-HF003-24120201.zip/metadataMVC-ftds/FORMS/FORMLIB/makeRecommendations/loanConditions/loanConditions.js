/* global form, service */
function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
service = registerMethod(service);

var inputParams = form.inputParams || {};
form.formParams = inputParams.formParams;

var outputParams = form.outputParams || {}
outputParams.formParams = form.formParams;

var lgr = service.lgr;
var nvl = service.nvl;
var gRB = service.gRB;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);
form.isFormEditMode = form.inputParams.EDITMODE || false;
form.params = form.inputParams.formParams || {};
form.TYPESYSNAME = form.params.TYPESYSNAME || "";
form.params.subproductList = form.params.subproductList ? form.params.subproductList : [];
form.isSubproductsPanelInfoCollapsed = /*true;*/ form.params.subproductList.length <= 0;
form.params.feeList = form.params.feeList ? form.params.feeList : [];
form.isfeesPanelInfoCollapsed = /*true;*/ form.params.feeList.length <= 0;

form.requiredElements = [
    "cbLoanPurpose",
    "cbPrincipalRepaymentMethod",
    "cbPrincipalRepaymentMethod",
    "cbInterestRepaymentMethod",
    "edWithdrawalTerm",
    "edLoanTerm",
    "edPaymentDate",
    "edLoanAmount",
    "cbCreditCurrency",
    "cbDisbursmentMethod",
    "edDisbursmentMethodOther",
    "edInterestRate"
];

form.onShow = function () {
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });
    form.subproductsInfo.setItems(form.params.subproductList || []);
    form.feesInfo.setItems(form.params.feeList || []);
};

form.executeCommand = function (msg) {
    switch (msg.event) {
        case 'FAB_NAVIGATOR_NAVIGATE':
            outputParams.NEXTPAGE = msg.params.step;
            form.action('DIRECT');
        break;
        default:
            break;
    }
};
form.templateData = {
    inputParams: form.inputParams,
    parentForm: form
};
form.verifyForm = function (showFlag) {
    var verified = true;
    try {
        var save =  form['save'];

        if (form.validateControlsByIds('*', showFlag === true ? save : undefined).isShowFormErrors) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    form.outputParams.VERIFIED = verified;
    return verified;
};

form.yesFunc = function() {

    outputParams.TRANSTYPE = 'SAVEDRAFT';
    if (form.verifyForm()) {
        form.sendForm('GO', false);
    }
};
form.GetIncomeListText=function(value){
    var str="fieldCheck."+value;
    return form.getResourceBundle(str);
};
form.settings = {
    cbPrincipalRepaymentMethod:JSON.stringify( {
        ReferenceSysName: 'principalRepaymentMethodLOS',
        ORDERBY: 'ReferenceItemID'
    }),
    cbLoanPurpose:JSON.stringify({
        ReferenceSysName: 'loanPurpose',
        ReferenceItemName: form.formParams.TYPESYSNAME,
        ORDERBY: 'ReferenceItemID'
    }),
    cbInterestRepaymentMethod:JSON.stringify({
        ReferenceSysName: 'interestRepaymentMethodLOS',
        ORDERBY: 'ReferenceItemID'
    }),
    cbCreditCurrency:JSON.stringify({
        ReferenceSysName: 'currencyLOS',
        ORDERBY: 'ReferenceItemID'
    }), 
    cbDisbursmentMethod:JSON.stringify({
        ReferenceSysName: 'disbursementMethod',
        ORDERBY: 'ReferenceItemID'
    })
};
form.getBPConditionParamValues = function(){
    var PRODUCTID = form.formParams.bankProductGroupId;
    if (!PRODUCTID) return;
    var CONDITIONVALUES = {
        loanPurpose:form.cbLoanPurpose.getValue()
    };
    var dsCallparams = {
        PRODUCTID: PRODUCTID,
        ReturnAsHashMap:"TRUE",
        CONDITIONVALUES:CONDITIONVALUES
    }
    if(CONDITIONVALUES["loanPurpose"]===undefined){
        return;
    }
    return form.dsCall('[frontws2]', 'bankProductListGetParamByConditionSet', dsCallparams).then(function (response){
        if(response.data["requst"]==="Household"){
            form.formParams.requstFor="Household";
        }
        else{
            form.formParams.requstFor="Individual";
        }
        service.lgr(response);
    }).catch(function (e){
        form.showErrorDialog('error', function(){}, [{caption: 'OK'}]);
    });
}
form.action = function (tagName) {
    outputParams.TRANSTYPE = tagName;
    if(form.isFormEditMode==='true'){
        form.formParams.loanPurpose=form.cbLoanPurpose.getText();
        form.formParams.principalRepaymentMethod=form.cbPrincipalRepaymentMethod.getText();
        form.formParams.interestRepaymentMethod=form.cbInterestRepaymentMethod.getText();
        form.formParams.disbursmentMethod=form.cbDisbursmentMethod.getText();
        if(form.subproductsInfo) { form.formParams.subproductList=form.subproductsInfo.getItems(); }
        if(form.feesInfo) { form.formParams.feeList=form.feesInfo.getItems(); }
    }
    if (tagName === 'CLOSE') {
        if(form.isFormEditMode === 'false'){
            form.sendForm('GO',false);
        }else{
            service.showDialogCancelConfirm(
                form,
                form.yesFunc
            )
        }
    } else {
        if (tagName === 'NEXT' && !form.verifyForm(true)) {
            return;
        } else {
            form.verifyForm(false);
        }
        form.sendForm('GO', false);
    }
}


form.tblSubproductsInfo = (function (grId) {
    var gridId = grId;

    var options = {
        cancel: function () {
            form[gridId].hideEditor();
            form.btnDataWorkAddSub.enable();
        },
        save: function () {
            var selectedRow = form.subproductsInfo.getSelectedRow()[0];
            var newRow = {
                subproductSysName          : form.cbSubproductsInfo.getValue(),
                subproductName          : form.cbSubproductsInfo.getText(),
                subproductNameOther        : form.subproductNameOther ? form.subproductNameOther.getValue() : "",
                subproductDetail     : form.subproductDetail.getValue()
            };

            if (selectedRow['LinkID']) {
                newRow['LinkID'] = selectedRow['LinkID'];
                form[gridId].hideEditor();
                form[gridId].updateRow(obj.selectedId, newRow);

            } else {
                newRow['LinkID'] = new Date().getTime();
                form[gridId].hideEditor();
                form[gridId].addRow(newRow);
            }
            form.btnDataWorkAddSub.enable();
        },

        clearFields: function () {
            delete options.data.subproductSysName;
            delete options.data.subproductNameOther;
            delete options.data.subproductDetail;
        },

        getOptionsData: function () {
            var selectedRow = form.subproductsInfo.getSelectedRow()[0];

            form.tblSubproductsInfo.options.data = {
                subproductSysName           : selectedRow["subproductSysName"],
                subproductNameOther    : selectedRow["subproductNameOther"],
                subproductDetail   : selectedRow["subproductDetail"]
            };

        },

        edit: function () {
            options.clearFields();
            options.getOptionsData();
            form[gridId].showEditor('edit');
            form.btnDataWorkAddSub.disable();
        },
        view : function () {
            options.clearFields();
            options.getOptionsData();
            form[gridId].showEditor('edit');
        },

        delete: function () {
            if (form.subproductsInfo.getSelectedRow()[0]) {
                form.subproductsInfo.deleteRow(obj.selectedId);
                form[gridId].refresh();
            }
        },

        referenceLoanSubproducts: {ReferenceSysName:"loanSubproducts"},
        EDITMODE : form.isFormEditMode,
        data: {}

    };

    var obj = {
        addNewRow: function () {
            options.clearFields();
            form.subproductsPanel.isCollapsed = false;
            form[gridId].showEditor('add');
            form.btnDataWorkAddSub.disable();

        },
        onSelectRow: function () {
            var selRow = form[gridId].getSelectedRow()[0] || {};
            if (form.isFormEditMode) {
                options.items = [
                    {caption: gRB('edit'), click: form.tblSubproductsInfo.options.edit},
                    {caption: gRB('delete'), click: form.tblSubproductsInfo.options.delete}
                ];
            }
        },
    };
    obj.options = options;
    return obj;
})('subproductsInfo');

form.tblFeesInfo = (function (grId) {
    var gridId = grId;

    var options = {
        cancel: function () {
            form[gridId].hideEditor();
            form.btnDataWorkAdd.enable();
        },
        save: function () {
            var selectedRow = form.feesInfo.getSelectedRow()[0];
            var newRow = {
                feeSysName          : form.cbFeeInfo.getValue(),
                feeName             : form.cbFeeInfo.getText(),
                feeNameOther        : form.feeNameOther ? form.feeNameOther.getValue() : "",
                feeDetail           : form.feeDetail.getValue()
            };

            if (selectedRow['LinkID']) {
                newRow['LinkID'] = selectedRow['LinkID'];
                form[gridId].hideEditor();
                form[gridId].updateRow(obj.selectedId, newRow);

            } else {
                newRow['LinkID'] = new Date().getTime();
                form[gridId].hideEditor();
                form[gridId].addRow(newRow);
            }
            form.btnDataWorkAdd.enable();
        },

        clearFields: function () {
            delete options.data.feeSysName;
            delete options.data.feeNameOther;
            delete options.data.feeDetail;
        },

        getOptionsData: function () {
            var selectedRow = form.feesInfo.getSelectedRow()[0];

            form.tblFeesInfo.options.data = {
                feeSysName           : selectedRow["feeSysName"],
                feeNameOther    : selectedRow["feeNameOther"],
                feeDetail   : selectedRow["feeDetail"]
            };

        },

        edit: function () {
            options.clearFields();
            options.getOptionsData();
            form[gridId].showEditor('edit');
            form.btnDataWorkAdd.disable();
        },
        view : function () {
            options.clearFields();
            options.getOptionsData();
            form[gridId].showEditor('edit');
        },

        delete: function () {
            if (form.feesInfo.getSelectedRow()[0]) {
                form.feesInfo.deleteRow(obj.selectedId);
                form[gridId].refresh();
            }
        },

        referenceLoanFee: {ReferenceSysName:"loanFees"},
        EDITMODE : form.isFormEditMode,
        data: {}

    };

    var obj = {
        addNewRow: function () {
            options.clearFields();
            form.feesPanel.isCollapsed = false;
            form[gridId].showEditor('add');
            form.btnDataWorkAdd.disable();

        },
        onSelectRow: function () {
            var selRow = form[gridId].getSelectedRow()[0] || {};
            if (form.isFormEditMode) {
                options.items = [
                    {caption: gRB('edit'), click: form.tblFeesInfo.options.edit},
                    {caption: gRB('delete'), click: form.tblFeesInfo.options.delete}
                ];
            }
        },
    };
    obj.options = options;
    return obj;
})('feesInfo');

