/*DSMETA version = "5.10.01-24111402" hash = "bf1d66b15631953fccae98d0ba5397f8b4d87f55"*/
var projectSysNameLOS = 'FTFLOINTMVC';

function nvl(val, def){
    if (typeof val == "undefined" || val == null || val === "") return def;
    return val;
}

function getAddressMapFromParamsMap(pfx, paramsMap){
    var resultMap = new java.util.HashMap();

    paramToMap('Building');
    paramToMap('City');
    paramToMap('CityId');
    paramToMap('CityType');
    paramToMap('Country');
    paramToMap('District');
    paramToMap('DistrictId');
    paramToMap('DistrictType');
    paramToMap('Flat');
    paramToMap('House');
    paramToMap('Housing');
    paramToMap('PostalCode');
    paramToMap('Region');
    paramToMap('RegionId');
    paramToMap('RegionType');
    paramToMap('Street');
    paramToMap('StreetId');
    paramToMap('StreetType');
    paramToMap('Town');
    paramToMap('TownId');
    paramToMap('TownType');
    paramToMap('USEKLADR');

    return resultMap;

    function paramToMap(paramName){
        if (paramsMap.get(pfx+paramName)!=null){
            resultMap.put(paramName, paramsMap.get(pfx+paramName));
        }
    }
}

function mapToExpand(pfx, map){
    var resultMap = new java.util.HashMap();
    if (map instanceof java.util.HashMap){
        var it = map.keySet().iterator();
        while (it.hasNext()){
            var key = it.next().toString();
            resultMap.put((pfx ? pfx : "")+key, map.get(key));
        }
    }
    return resultMap;
}

////////////////////////////////////////////////////////////////////////////////
function cleanUpMap(map,keys){
    var res=getNewMap();
    for (var j=0;j<keys.length;j++){
        if (map.get(keys[j])!=null){
            res.put(keys[j],map.get(keys[j]));
        }
    }
    return res;
}

////////////////////////////////////////////////////////////////////////////////
function cleanUpList(list,keys){
    var res=getNewList();
    for (var i=0;i<list.size();i++){
        res.add(cleanUpMap(list.get(i),keys));
    }
    return res;
}

////////////////////////////////////////////////////////////////////////////////
function getNewMap(jMap){
    jMap=nvl(jMap,{});
    var res=new java.util.HashMap();
    for (var ar in jMap){
        res.put(ar,jMap[ar])
    }
    return res;
}
////////////////////////////////////////////////////////////////////////////////
function getNewList(jList){
    jList=nvl(jList,[]);
    var res=new java.util.ArrayList();
    for (var i=0;i<jList.length;i++){
        res.add(jList[i])
    }
    return res;
}

function gip(paramName, defValue){
    return nvl(getInputParams(paramName), defValue == undefined ? null : defValue);
}

function sop(paramName, paramValue){
    setOutputParams(paramName, paramValue);
}

function strToNum(str){
    str+="";
    var n=parseFloat(str.replace(/[^\d,\.-]/g,"").replace(/,/g,"."))+"";
    n=n.replace("NaN","0");
    n=parseFloat(n);
    return n;
}

function gRB(key){
	return nvl(getResourceBundle(key),key);
}

function sdFormat(dateForFormat, formatDateText){
    if(formatDateText==null || formatDateText==""){
        formatDateText = "dd.MM.yyyy";
    }
    return new java.text.SimpleDateFormat(formatDateText).format(dateForFormat);
}

function newDate(){
    return new java.util.Date();
}

function addFormParam(paramName){
    if (contains(wizardParamsRef.clientMap, paramName)){
        if (clientMap.get(paramName)!=null){
            formParams.put(paramName, clientMap.get(paramName));
            clientMap.remove(paramName);
        }
    } else
    if (contains(wizardParamsRef.appMap, paramName)){
        if (appMap.get(paramName)!=null){
            formParams.put(paramName, appMap.get(paramName));
            appMap.remove(paramName);
        }
    } else
    if (wizardParams.get(paramName)!=null){
        formParams.put(paramName, wizardParams.get(paramName));
        wizardParams.remove(paramName);
    }

    function contains(arr, obj){
        var i = arr.length;
        while (i--) {
            if (arr[i] === obj) {
                return true;
            }
        }
        return false;
    }
}
// refList - лист фильтруется по keyStr, значения которого лежат в paramWizard через ';'
function getFilterReferenceList(paramWizard, refList, keyStr){
    var newRefList = getNewList();
    if (paramWizard && (paramWizard instanceof java.lang.String) && paramWizard.length() && refList && (refList instanceof java.util.ArrayList) && refList.size()){
        var paramWizardList = java.util.Arrays.asList(paramWizard.split(";"));
        var paramWizardMap = getNewMap();

        for (var i = 0, countI = paramWizardList.size(); i < countI; i++) {  // собрали мапу с нужными ключами
            var paramWizardTempMap = paramWizardList.get(i);
            paramWizardMap.put(paramWizardTempMap, paramWizardTempMap);
        }

        for (var j = 0, countJ = refList.size(); j < countJ; j++) {
            var refMap = refList.get(j);
            if (paramWizardMap.get(refMap.get(keyStr))){
                newRefList.add(refMap);
            }
        }
    }
    return newRefList;
}

function buildNotificationList(NotificationList, ReturnCode, ReturnMsg, lastErrorCode, lastErrorMessage, lastErrorStack){
    var lastErrorCode = lastErrorCode || "";
    var lastErrorMessage = lastErrorMessage || "";
    var ReturnCode = ReturnCode || "";
    var ReturnMsg = ReturnMsg || "";
    var NotificationList = NotificationList || new java.util.ArrayList();
    var lastErrorStack = lastErrorStack || new java.util.HashMap();
    
    for (var i=0; i<NotificationList.size(); i++) {
        if (NotificationList.get(i).get("NTFID")==0) {
            NotificationList.remove(i);
            i--;
        }
    }
    
    if (lastErrorCode != "" && lastErrorCode != "0") {
        var Notification = new java.util.HashMap();
        Notification.put("NTFID",      lastErrorCode);
        Notification.put("NTFMessage", lastErrorMessage);
        NotificationList.add(Notification);
    }

    if (ReturnCode != "" && ReturnCode != "0") {
        var Notification = new java.util.HashMap();
        Notification.put("NTFID",      ReturnCode);
        Notification.put("NTFMessage", ReturnMsg);
        NotificationList.add(Notification);
    }

    var lastErrorList = lastErrorStack.get("Result") || new java.util.ArrayList();
    if (lastErrorList.size() > 0) {
        var item = lastErrorList.get(0);
        var params = item.get('PARAMS') || new java.util.HashMap();
        params.put("NTFID", params.get("NTFID") || "");
        params.put("NTFMessage", params.get("NTFMessage") || getResourceBundle("errorInfo"));
        NotificationList.add(params);
    }

    return NotificationList;
}


//Глубокое копирование объектов
function deepCopy(object){
    var byteArrayOutputStream = new java.io.ByteArrayOutputStream();
    var objectOutputStream = new java.io.ObjectOutputStream(byteArrayOutputStream);
    objectOutputStream.writeObject(object);
    var byteArrayInputStream = new java.io.ByteArrayInputStream(byteArrayOutputStream.toByteArray());
    var objectInputStream = new java.io.ObjectInputStream(byteArrayInputStream);
    var newObject = objectInputStream.readObject();

    byteArrayOutputStream.close();
    objectOutputStream.close();
    byteArrayInputStream.close();
    objectInputStream.close();

    return newObject;
}