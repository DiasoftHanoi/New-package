/*DSMETA version = "5.10.01-24111402" hash = "c360b9d181182f5042b71a47198dc7096d44955c"*/
/* global form, service */


function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
var service = registerMethod(service);

form.params = form.inputParams.formParams || {};
form.params.businessesList = form.params.businessesList ? form.params.businessesList : [];
var convertDate = service.convertDate;
var getTableContent = service.getTableContent;
var gRB = service.gRB;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);

form.isFormEditMode = form.inputParams.EDITMODE || false;
form.isFormEditModeMain = form.inputParams.EDITMODE;
form.pnlBusinessesInfoIsCollapsed = form.params.businessesList.length <= 0;
form.registrationDocumentCollapsed = !(form.params.householdBusinessRegistrationCertificate || 
                                       form.params.householdBusinessRegistrationCertificatPlaceOfIssue ||
                                       form.params.householdBusinessRegistrationCertificatDateOfIssueText);

var inputParams = form.inputParams;
var outputParams = form.outputParams;

form.formParams = inputParams.formParams || {};
outputParams.formParams = form.formParams;

form.templateData={
    address:form.params.householdAddress || {},
    addressText:form.params.householdAddressText || ""
};
form.templateDataBus={
    address:form.params.householdBusinessAddress || {},
    addressText:form.params.householdBusinessAddressText || ""
};

var lgr = service.lgr;
var nvl = service.nvl;
service.lgr(form.params);
form.onShow = function () {
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });

    form.tblBusinessesInfoObj.setItems(form.inputParams.formParams.businessesList || []);
};
form.requiredElements = [
    "edHouseholdName",
    "edAverageIncome",
    "edHouseholdAddress",
    "edBusinessLine",
    "edProducts",
    "edEmployeesNumber",
    "edQualifiedEmployees",
    //These are not required, but need to be verified:
    "edRegisteredCapital",
    "edTaxCode",
    "edBusinessRegistrationCertificate",
    "edPlaceOfIssue"
];


form.tblBusinessesInfoObj = (function(grId){
    var gridId = grId;
    var options = {
        templateData:form.templateDataBus,

        objectType_ITEMS : [{
                value: 'Own',
                text:  "${Own}"
            }, {
                value: 'Rent',
                text: "${Rent}"
            }
        ],
        requiredElements : [
            "householdBusinessType",
            "householdBusinessNumber",
            "householdBusinessName",
            "householdBusinessAddress",
            "householdBusinessYearsOfActivity"
        ],
        businessesList: form.inputParams.businessesList,
        data: {},
        clearFields: function () {
            delete options.data.householdBusinessNumber;
            delete options.data.householdBusinessYearsOfActivity;
            delete options.data.householdBusinessType;
            delete options.data.householdBusinessName;
            options.data.householdBusinessAddress = {};
            options.data.businessAddress = null;
        },
        cancelFields:function(){
            options.clearFields();
            form[gridId].hideEditor();
            form.btnDataWorkAdd.enable();
        },
        saveFields:function(){
            var selectedRow = form.businessesInfo.getSelectedRow()[0];
            var newRow ={
                businessType                : form.householdBusinessType.getValue(),
                businessNumber              : form.householdBusinessNumber.getValue(),
                businessYearsOfActivity     : form.householdBusinessYearsOfActivity.getValue(),
                businessYearsOfActivityText : form.householdBusinessYearsOfActivity.getText(),
                businessName                : form.householdBusinessName.getValue(),
                businessAddress             : form.householdBusinessAddress ? form.householdBusinessAddress.data.address : {},
                businessAddressText         : form.householdBusinessAddress ? form.householdBusinessAddress.data.address.addressText : ""
              /*  businessAddress             : form.householdBusinessAddress.getValue(),
                businessAddressText         : form.householdBusinessAddress.getText()*/
            };
            if (selectedRow['id']) {
                newRow['id'] = selectedRow['id'];
                form[gridId].hideEditor();
                form[gridId].updateRow(obj.selectedId, newRow);

            } else {
                newRow['id'] = new Date().getTime();
                form[gridId].hideEditor();
                form[gridId].addRow(newRow);
            }
            form.btnDataWorkAdd.enable();
        },
        edit: function () {
            options.clearFields();
            var selectedRow = form.businessesInfo.getSelectedRow()[0];
            form[gridId].showEditor('edit');
            form.tblBusinessesInfoObj.options.data = {
                householdBusinessType            : selectedRow["businessType"],
                householdBusinessNumber          : selectedRow["businessNumber"],
                householdBusinessYearsOfActivity : selectedRow["businessYearsOfActivity"],
                householdBusinessName            : selectedRow["businessName"]
                //householdBusinessAddress         : selectedRow["businessAddress"],
                //businessAddress                  : selectedRow["businessAddress"]
            };
            form.tblBusinessesInfoObj.options.templateData.address = selectedRow["businessAddress"],
            form.tblBusinessesInfoObj.options.templateData.addressText = selectedRow["businessAddress"]
            form.btnDataWorkAdd.disable();
        },
        delete: function () {
            if (form.businessesInfo.getSelectedRow()[0]) {
                form.businessesInfo.deleteRow(obj.selectedId);
                form[gridId].refresh();
            }
            form.btnDataWorkAdd.enable();
        }
    };

    var obj = {
        addNewRow: function () {
            form.pnlBusinessesInfo.isCollapsed = false;
            form[gridId].showEditor('add');
            options.clearFields();
            form.btnDataWorkAdd.disable();
        },
        refresh: function () {
            form[gridId].refresh();
        },
        onChangeItems: function () {
        },
        setItems: function (items) {
            form[gridId].setItems(items);
        },
        getItems: function () {
            return form[gridId].getItems();
        },
        onSelectRow: function () {
            options.items = [];
            if (form.isFormEditMode) {
                var selRow = form[gridId].getSelectedRow()[0] || {};
                options.items = [
                    {caption: gRB('edit'),   click: form.tblBusinessesInfoObj.options.edit},
                    {caption: gRB('delete'), click: form.tblBusinessesInfoObj.options.delete}
                ];
            }
        }
    };
    obj.options = options;
    return obj;
})('businessesInfo');

form.verifyForm = function (showFlag, tag) {

    var verified = true;
    var buttonNextSave = (form.isLastWizForm) ? "btnSave" : "btnNext";
    if (tag === 'CLOSE') {
        buttonNextSave = "btnCancel";
    }

    try {
        console.log('verifyForm');
        console.log('r ',form.requiredElements.join(','));
        if ((form.validateControlsByIds(form.requiredElements.join(','), showFlag === true ? buttonNextSave : undefined).isShowFormErrors)) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    outputParams.VERIFIED = verified;
    console.log('verified ',verified);
    return verified;
};

form.executeCommand = function (msg) {
    if (msg.event === 'FAB_NAVIGATOR_NAVIGATE') {
        outputParams.NEXTPAGE = msg.params.step;
        form.action('DIRECT');
    }
};

form.yesFunc = function() {
    outputParams.TRANSTYPE = 'SAVEDRAFT';
    form.sendForm('GO', false);
};

form.action = function (tag) {

    outputParams.TRANSTYPE = tag;

    if (form.isFormEditModeMain) {
        outputParams.formParams.householdName                = form.params.householdName;
        outputParams.formParams.taxCode                      = form.params.taxCode;
        outputParams.formParams.dateOfEstablishment          = form.params.dateOfEstablishment;
        outputParams.formParams.dateOfEstablishmentText      = form.clDateOfEstablishment.getText();
        outputParams.formParams.householdAddress             = form.edHouseholdAddress.data.address;
        outputParams.formParams.householdAddressText         = form.edHouseholdAddress.data.address.addressText;
        outputParams.formParams.householdBusinessLine        = form.params.householdBusinessLine;
        outputParams.formParams.householdProducts            = form.params.householdProducts;
        outputParams.formParams.householdStaffNumber         = form.params.householdStaffNumber;
        outputParams.formParams.householdQualifiedemployees  = form.params.householdQualifiedemployees;
        outputParams.formParams.householdRegisteredCapital   = form.params.householdRegisteredCapital;
        outputParams.formParams.householdAverageIncome       = form.params.householdAverageIncome;

        outputParams.formParams.householdBusinessRegistrationCertificate                  = form.params.householdBusinessRegistrationCertificate;
        outputParams.formParams.householdBusinessRegistrationCertificatPlaceOfIssue       = form.params.householdBusinessRegistrationCertificatPlaceOfIssue;
        outputParams.formParams.householdBusinessRegistrationCertificatDateOfIssue        = form.params.householdBusinessRegistrationCertificatDateOfIssue;
        outputParams.formParams.householdBusinessRegistrationCertificatDateOfIssueText    = form.clDateOfIssue.getText();

        outputParams.formParams.businessesList   =  form.tblBusinessesInfoObj.getItems();
    }
    if (tag === 'CLOSE') {
        if(form.inputParams.EDITMODE === false){
            form.sendForm('GO',false);
        }else{
            form.verifyForm(true, tag);
            service.showDialogCancelConfirm(
                form,
                form.yesFunc
            )
        }
    }
    else {
        if (tag === 'NEXT' && !form.verifyForm(true) ) {
            return;
        }else{
            form.verifyForm(false);
        }
        form.sendForm('GO', false);
    }
};