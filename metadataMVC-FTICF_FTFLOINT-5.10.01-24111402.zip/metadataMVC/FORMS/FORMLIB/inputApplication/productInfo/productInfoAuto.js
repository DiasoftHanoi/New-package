/*DSMETA version = "5.10.01-24111402" hash = "da4528e00a6217f7de07821f467156c3dd3fa564"*/
/* global form, service */

function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
service = registerMethod(service);

form.isFormEditMode = form.inputParams.EDITMODE || false;
var inputParams = form.inputParams;
var outputParams = form.outputParams || {};
form.params = form.inputParams.formParams || {};
outputParams.formParams = form.params;
form.isFormEditModeMain = form.inputParams.EDITMODE;
form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);
form.params.subproductList = form.params.subproductList ? form.params.subproductList : [];
form.isSubproductsPanelInfoCollapsed = /*true;*/ form.params.subproductList.length <= 0;
form.params.feeList = form.params.feeList ? form.params.feeList : [];
form.isfeesPanelInfoCollapsed = /*true;*/ form.params.feeList.length <= 0;
var gRB = service.gRB;
console.log(form.params);
var lgr = service.lgr;
var nvl = service.nvl;
service.lgr(form.params);

form.onShow = function () {
    form.setLoanRatio();
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });
    form.flagOfSizeInterestRate = form.checkFieldOnNumberCharacters(form.params.interestRate, 20);
    form.flagOfSizeCommissionFee = form.checkFieldOnNumberCharacters(form.params.commission, 20);
    form.flagOfSizeDisbursmentMethodOther = form.checkFieldOnNumberCharacters(form.params.disbursmentMethodOther, 20);
    if (form.isFormEditModeMain) {
        form.getBPparamValues();
    }
    form.subproductsInfo.setItems(form.params.subproductList || []);
    form.feesInfo.setItems(form.params.feeList || []);
};

form.checkFieldOnNumberCharacters = function(text, num) {
    if (text != undefined) {
        if (text.length <= num)
            return true;
        return false;
    }
    return true;
};

form.isExistValueItem = function(list, item, obj) {
    for (var i = 0, count = list.length; i < count; i++) {
        if (list[i].VALUE1 == item) {
            return true;
        }
    }
    if (obj) {
        form[obj].setValue("");
    }
    return false;
};

form.getBPparamValues = function() {

    var PARAMTYPELIST = ["loanPurpose","carClass","vehicleCondition","principalRepaymentMethodLOS","interestRepaymentMethodLOS","currencyLOS",
        "interestRateOption","disbursementMethodLOS","gracePeriod","creditExtensionMethodLOS"];
    var PRODUCTID = form.params.bankProductId;
    if (!PRODUCTID) return;
    var dsCallparams = {
        PRODUCTID: PRODUCTID,
        PARAMTYPELIST: PARAMTYPELIST,
        RETURN_ABSOLUTE_PARAM:true

    };
     
    return form.dsCall('[frontws2]', 'bankProductParamGetListByProductId', dsCallparams).then(function (response){
        inputParams.loanPurpose_ITEMS=[];
        inputParams.carClass_ITEMS=[];
        inputParams.vehicleCondition_ITEMS=[];
        inputParams.principalRepaymentMethod_ITEMS=[];
        inputParams.interestRepaymentMethod_ITEMS=[];
        inputParams.loanCurrency_ITEMS=[];
        inputParams.interestRateOption_ITEMS=[];
        inputParams.disbursementMethod_ITEMS=[];
        inputParams.gracePeriod_ITEMS=[];
        inputParams.creditExtensionMethod_ITEMS=[];
        service.lgr(response);
        for (var i=0; i<response.data.Result.length;i++){
            var items = response.data.Result[i];
            switch (items["PARAMTYPE"]){
                case "loanPurpose":
                    inputParams.loanPurpose_ITEMS=items["VALUES"];
                    break;
                case "carClass":
                    inputParams.carClass_ITEMS=items["VALUES"];
                    break;
                case "vehicleCondition":
                    inputParams.vehicleCondition_ITEMS=items["VALUES"];
                    break;
                case "principalRepaymentMethodLOS":
                    inputParams.principalRepaymentMethod_ITEMS =items["VALUES"];
                    break;
                case "interestRepaymentMethodLOS":
                    inputParams.interestRepaymentMethod_ITEMS=items["VALUES"];
                    break;
                case "currencyLOS":
                    inputParams.loanCurrency_ITEMS=items["VALUES"];
                    break;
                case "interestRateOption":
                    inputParams.interestRateOption_ITEMS=items["VALUES"];
                    break;
                case "disbursementMethodLOS":
                    inputParams.disbursementMethod_ITEMS=items["VALUES"];
                    break;
             /*  case "interestRateOptionSysName":
                    inputParams.interestRateOption_ITEMS=items["VALUES"];
                    break;*/

                case "gracePeriod":
                    inputParams.gracePeriod_ITEMS=items["VALUES"];
                    break;
                case "creditExtensionMethodLOS":
                    inputParams.creditExtensionMethod_ITEMS=items["VALUES"];
                    break;
            }
        }
        form.isExistValueItem(inputParams.loanPurpose_ITEMS, form.params.loanPurposeSysName, "cbLoanPurpose");
        form.isExistValueItem(inputParams.carClass_ITEMS, form.params.carClassSysName, "cbCarClass");
        form.isExistValueItem(inputParams.vehicleCondition_ITEMS, form.params.vehicleConditionSysName, "cbVehicleCondition");
        form.isExistValueItem(inputParams.principalRepaymentMethod_ITEMS, form.params.principalRepaymentMethodSysName, "cbPrincipalRepaymentMethod");
        form.isExistValueItem(inputParams.interestRepaymentMethod_ITEMS, form.params.interestRepaymentMethodSysName, "cbInterestRepaymentMethod");
        form.isExistValueItem(inputParams.loanCurrency_ITEMS, form.params.creditCurrencySysName, "cbCreditCurrency");
        form.isExistValueItem(inputParams.interestRateOption_ITEMS, form.params.interestRateOptionSysName, "cbInterestRateOption");
        form.isExistValueItem(inputParams.disbursementMethod_ITEMS, form.params.disbursmentMethodSysName, "cbDisbursmentMethod");
        form.isExistValueItem(inputParams.creditExtensionMethod_ITEMS, form.params.creditExtensionMethodSysName, "cbCreditExtensionMethod");
    }).catch(function (e){
        form.showErrorDialog('error', function(){}, [{caption: 'OK'}]);
    });
};

form.getBPConditionParamValues = function(){
 var PRODUCTID = form.params.bankProductId;
    if (!PRODUCTID) return;
    var CONDITIONVALUES = {
        loanPurpose:form.params.loanPurposeSysName
    };
    var dsCallparams = {
        PRODUCTID: PRODUCTID,
        ReturnAsHashMap:"TRUE",
        CONDITIONVALUES:CONDITIONVALUES
    };
   if(CONDITIONVALUES["loanPurpose"]===undefined){
       return;
   }
    return form.dsCall('[frontws2]', 'bankProductListGetParamByConditionSet', dsCallparams).then(function (response){
        if(response.data["requst"]==="Household"){
            form.params.requstFor="Household";
        }
        else{
            form.params.requstFor="Individual";
        }
        service.lgr(response);
    }).catch(function (e){
        form.showErrorDialog('error', function(){}, [{caption: 'OK'}]);
    });
};
form.setLoanRatio = function() {
    var ratio = Math.ceil((form.params.loanAmount/form.params.costOfObject*100)*100)/100; 
    ratio = isNaN(ratio) ? "" : ratio;
    outputParams.formParams.loanRatio=ratio;
    form.params.loanRatio=ratio;
};
form.notEmtyValues = function() {
   var params = [form.params.conditionsBeforeDisbursement,form.params.conditionsAfterDisbursement,form.params.otherConditions,
   form.params.checksConditionsAfterDisbursement,form.params.exceptions];
   var i =0; while (i<params.length) {
   var curVal = params[i];
      if (curVal != '' && curVal != undefined && curVal != null)  {
          return false;
          break;
      }
   i++;
   }
   
   return true;

};
form.isCollaps = form.notEmtyValues();

form.requiredElements = ["cbLoanProduct","cbLoanPurpose","cbCarClass","cbVehicleCondition","edCarYear","edWithdrawalTerm","edPaymentDate","cbPrincipalRepaymentMethod",
                         "cbInterestRepaymentMethod","edObjCost","edOwnedCapital","cbCreditCurrency","edLoanAmount","edLoanTerm","edInterestRate","cbDisbursmentMethod",
                         "edDisbursmentMethodOther"];
form.verifyForm = function (showFlag) {
    var verified = true;
    var buttonNextSave = (form.isLastWizForm) ? "btnSave" : "btnNext";
    try {
        console.log('verifyForm');
        console.log('r ',form.requiredElements.join(','));
        if ((form.validateControlsByIds('*', showFlag === true ? buttonNextSave : undefined).isShowFormErrors)) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    outputParams.VERIFIED = verified;
    console.log('verified ',verified);
    return verified;
};

form.executeCommand = function (msg) {
    if (msg.event === 'FAB_NAVIGATOR_NAVIGATE') {
        outputParams.NEXTPAGE = msg.params.step;
        form.action('DIRECT');
    }
};

form.yesFunc = function() {
    outputParams.TRANSTYPE = 'SAVEDRAFT';
    if(form.verifyForm(false)) {
        form.sendForm('GO', false);
    }
};
form.noFunc = function(){
    form.outputParams.TRANSTYPE = 'CLOSE';
    form.sendForm('GO',false);
};

form.action = function (tag) {
    outputParams.TRANSTYPE = tag;
    if (form.isFormEditModeMain) {
        outputParams.formParams.bankProductId                       = form.params.bankProductId;
        outputParams.formParams.PRODUCTBRIEFNAME                    = form.params.bankProductName = (form.cbLoanProduct) ? form.cbLoanProduct.getText() : undefined;
        outputParams.formParams.bankProductBrief                    = (form.params.bankProductId) ? inputParams.bankProdParamMap[form.params.bankProductId]["PRODUCTBRIEFNAME"] : undefined;
        outputParams.formParams.bankProductGroupName                = form.cbLoanProduct.getText();
        outputParams.formParams.loanPurposeSysName                  = form.params.loanPurposeSysName;
        outputParams.formParams.loanPurpose                         = form.cbLoanPurpose.getText();
        outputParams.formParams.loanPurposeDetail                   = form.params.loanPurposeDetail;
        outputParams.formParams.requstFor                           = form.params.requstFor;
        outputParams.formParams.carClassSysName                     = form.params.carClassSysName;
        outputParams.formParams.carClass                            = form.cbCarClass.getText();
        outputParams.formParams.vehicleConditionSysName             = form.params.vehicleConditionSysName;
        outputParams.formParams.vehicleCondition                    = form.cbVehicleCondition.getText();
        outputParams.formParams.carYear                             = form.params.carYear;
        outputParams.formParams.withdrawalTerm                      = form.params.withdrawalTerm;
        outputParams.formParams.paymentDate                         = form.params.paymentDate;
        outputParams.formParams.principalRepaymentMethodSysName     = form.params.principalRepaymentMethodSysName;
        outputParams.formParams.principalRepaymentMethod            = form.cbPrincipalRepaymentMethod.getText();
        outputParams.formParams.interestRepaymentMethodSysName      = form.params.interestRepaymentMethodSysName;
        outputParams.formParams.interestRepaymentMethod             = form.cbInterestRepaymentMethod.getText();
        outputParams.formParams.costOfObject                        = form.params.costOfObject;
        outputParams.formParams.firstPayment                        = form.params.firstPayment;
        outputParams.formParams.creditCurrencySysName               = form.params.creditCurrencySysName;
        outputParams.formParams.creditCurrencyName                  = form.cbCreditCurrency.getText();
        outputParams.formParams.loanAmount                          = form.params.loanAmount;
        outputParams.formParams.loanTerm                            = form.params.loanTerm;
        outputParams.formParams.interestRate                        = form.params.interestRate;
        outputParams.formParams.gracePeriod                         = form.params.gracePeriod;
        outputParams.formParams.interestRateOptionSysName           = form.params.interestRateOptionSysName;
        outputParams.formParams.interestRateOption                  = form.params.interestRateOptionSysName ? form.cbInterestRateOption.getText() : "";
        outputParams.formParams.disbursmentMethodSysName            = form.params.disbursmentMethodSysName;
        outputParams.formParams.disbursmentMethod                   = form.cbDisbursmentMethod.getText();
        outputParams.formParams.disbursmentMethodOther              = form.params.disbursmentMethodOther;
        outputParams.formParams.commission                          = form.params.commission;
        outputParams.formParams.subproductList                      = form.subproductsInfo.getItems();
        outputParams.formParams.feeList                             = form.feesInfo.getItems();
        //outputParams.formParams.loanRatio                           = form.params.loanRatio
        outputParams.formParams.creditExtensionMethodSysName        = form.params.creditExtensionMethodSysName;
        outputParams.formParams.creditExtensionMethod               = form.cbCreditExtensionMethod.getText();
    }
    service.lgr(outputParams);

    if (tag === 'CLOSE') {
        if(form.inputParams.EDITMODE === false){
            form.sendForm('GO',false);
        }
        else {
            service.showDialogCancelConfirm(
                form,
                form.yesFunc,
                form.noFunc
            )
        }
    }
    else {
        if (tag === 'NEXT' && !form.verifyForm(true)) {
            return;
        } else {
            form.verifyForm(false);
        }
        form.sendForm('GO', false);
    }    
};

form.tblSubproductsInfo = (function (grId) {
    var gridId = grId;

    var options = {
        cancel: function () {
            form[gridId].hideEditor();
            form.btnDataWorkAddSub.enable();
        },
        save: function () {
            var selectedRow = form.subproductsInfo.getSelectedRow()[0];
            var newRow = {
                subproductSysName          : form.cbSubproductsInfo.getValue(),
                subproductName          : form.cbSubproductsInfo.getText(),
                subproductNameOther        : form.subproductNameOther ? form.subproductNameOther.getValue() : "",
                subproductDetail     : form.subproductDetail.getValue()
            };

            if (selectedRow['LinkID']) {
                newRow['LinkID'] = selectedRow['LinkID'];
                form[gridId].hideEditor();
                form[gridId].updateRow(obj.selectedId, newRow);

            } else {
                newRow['LinkID'] = new Date().getTime();
                form[gridId].hideEditor();
                form[gridId].addRow(newRow);
            }
            form.btnDataWorkAddSub.enable();
        },

        clearFields: function () {
            delete options.data.subproductSysName;
            delete options.data.subproductNameOther;
            delete options.data.subproductDetail;
        },

        getOptionsData: function () {
            var selectedRow = form.subproductsInfo.getSelectedRow()[0];

            form.tblSubproductsInfo.options.data = {
                subproductSysName           : selectedRow["subproductSysName"],
                subproductNameOther    : selectedRow["subproductNameOther"],
                subproductDetail   : selectedRow["subproductDetail"]
            };

        },

        edit: function () {
            options.clearFields();
            options.getOptionsData();
            form[gridId].showEditor('edit');
            form.btnDataWorkAddSub.disable();
        },
        view : function () {
            options.clearFields();
            options.getOptionsData();
            form[gridId].showEditor('edit');
        },

        delete: function () {
            if (form.subproductsInfo.getSelectedRow()[0]) {
                form.subproductsInfo.deleteRow(obj.selectedId);
                form[gridId].refresh();
            }
        },

        referenceLoanSubproducts: {ReferenceSysName:"loanSubproducts", ReferenceItemName:"Auto Loan"},
        EDITMODE : form.isFormEditMode,
        data: {}

    };

    var obj = {
        addNewRow: function () {
            options.clearFields();
            form.subproductsPanel.isCollapsed = false;
            form[gridId].showEditor('add');
            form.btnDataWorkAddSub.disable();

        },
        onSelectRow: function () {
            var selRow = form[gridId].getSelectedRow()[0] || {};
            if (form.isFormEditMode) {
                options.items = [
                    {caption: gRB('edit'), click: form.tblSubproductsInfo.options.edit},
                    {caption: gRB('delete'), click: form.tblSubproductsInfo.options.delete}
                ];
            }
        },
    };
    obj.options = options;
    return obj;
})('subproductsInfo');

form.tblFeesInfo = (function (grId) {
    var gridId = grId;

    var options = {
        cancel: function () {
            form[gridId].hideEditor();
            form.btnDataWorkAdd.enable();
        },
        save: function () {
            var selectedRow = form.feesInfo.getSelectedRow()[0];
            var newRow = {
                feeSysName          : form.cbFeeInfo.getValue(),
                feeName             : form.cbFeeInfo.getText(),
                feeNameOther        : form.feeNameOther ? form.feeNameOther.getValue() : "",
                feeDetail           : form.feeDetail.getValue()
            };

            if (selectedRow['LinkID']) {
                newRow['LinkID'] = selectedRow['LinkID'];
                form[gridId].hideEditor();
                form[gridId].updateRow(obj.selectedId, newRow);

            } else {
                newRow['LinkID'] = new Date().getTime();
                form[gridId].hideEditor();
                form[gridId].addRow(newRow);
            }
            form.btnDataWorkAdd.enable();
        },

        clearFields: function () {
            delete options.data.feeSysName;
            delete options.data.feeNameOther;
            delete options.data.feeDetail;
        },

        getOptionsData: function () {
            var selectedRow = form.feesInfo.getSelectedRow()[0];

            form.tblFeesInfo.options.data = {
                feeSysName           : selectedRow["feeSysName"],
                feeNameOther    : selectedRow["feeNameOther"],
                feeDetail   : selectedRow["feeDetail"]
            };

        },

        edit: function () {
            options.clearFields();
            options.getOptionsData();
            form[gridId].showEditor('edit');
            form.btnDataWorkAdd.disable();
        },
        view : function () {
            options.clearFields();
            options.getOptionsData();
            form[gridId].showEditor('edit');
        },

        delete: function () {
            if (form.feesInfo.getSelectedRow()[0]) {
                form.feesInfo.deleteRow(obj.selectedId);
                form[gridId].refresh();
            }
        },

        referenceLoanFee: {ReferenceSysName:"loanFees"},
        EDITMODE : form.isFormEditMode,
        data: {}

    };

    var obj = {
        addNewRow: function () {
            options.clearFields();
            form.feesPanel.isCollapsed = false;
            form[gridId].showEditor('add');
            form.btnDataWorkAdd.disable();

        },
        onSelectRow: function () {
            var selRow = form[gridId].getSelectedRow()[0] || {};
            if (form.isFormEditMode) {
                options.items = [
                    {caption: gRB('edit'), click: form.tblFeesInfo.options.edit},
                    {caption: gRB('delete'), click: form.tblFeesInfo.options.delete}
                ];
            }
        },
    };
    obj.options = options;
    return obj;
})('feesInfo');



