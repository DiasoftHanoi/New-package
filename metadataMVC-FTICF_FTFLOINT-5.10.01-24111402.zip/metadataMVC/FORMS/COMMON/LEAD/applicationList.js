/*DSMETA version = "5.10.01-24111402" hash = "a3f1d349e241989ffc740862da3ae2622a1186b8"*/
var inputParams = form.inputParams;
form.ROLES = form.inputParams.ROLES || [];

var mrtgRoles = ['Mrtg_InternalLoanOfficer','Mrtg_SatelliteManager','Mrtg_MobileSalesManager','Mrtg_ManagerCSD','Mrtg_ExternalSalesManager'];
var autoRoles = ['Avto_ManagerCSD','Avto_InternalLoanOfficer','Avto_MobileSalesManager','Avto_ChiefInternalLoanOfficer','Avto_AccountManager','Avto_ExternalSalesManager','Avto_ExtSalesManagerOnContract'];

var ROLESOBJ = {};
var ROLES = form.inputParams.ROLES || [];
var MrtgRights = false;
var AutoRights = false;
for (var i=0;i<ROLES.length; i++){
	ROLESOBJ[ROLES[i]['ROLESYSNAME']] = ROLES[i]['ROLESYSNAME'];
	if (!MrtgRights && ~mrtgRoles.indexOf(ROLES[i]['ROLESYSNAME'])) MrtgRights = true;
	if (!AutoRights && ~autoRoles.indexOf(ROLES[i]['ROLESYSNAME'])) AutoRights = true;
}
form.ROLESOBJ = ROLESOBJ;
/**
Mrtg_InternalLoanOfficer	Кредитный инспектор (ТП Банка) (Ипотека)
Mrtg_SatelliteManager	Сотрудник Ипотечного спутника
Mrtg_MobileSalesManager	Мобильный агент (Ипотека)
Mrtg_ManagerCSD	Сотрудник ДКО (Ипотека)
Mrtg_ExternalSalesManager	Менеджер (Сотрудник Партнера) (Ипотека)
	
Avto_ManagerCSD	Сотрудник ДКО
Avto_InternalLoanOfficer	Сотрудник МАК
Avto_MobileSalesManager	Мобильный агент
Avto_ChiefInternalLoanOfficer	Руководитель МАК
Avto_AccountManager	Персональный менеджер
Avto_ExternalSalesManager	Сотрудник Партнера
Avto_ExtSalesManagerOnContract	Сотрудник Партнера оформлен по ДВОУ в Банк
*/

function registerMethod(initService){
	var service={};
	for (var ar in initService){
		if (initService.hasOwnProperty(ar)){
			if (ar.indexOf('Service')>-1 || typeof (initService[ar]) != 'function'){
				service[ar]=initService[ar];
			}else{
				var fn=initService[ar].toString();
				if (fn && fn.length) {
				var sIdx=fn.search(/\(/)+1;
				var eIdx=fn.search(/\)\s*\{/);
				var args=fn.substring(sIdx,eIdx)
				eval("service."+ar+"=function("+args+")"+fn.substring(eIdx+1,fn.length));
                }
			}
		}
	}
	return service;
}
service=registerMethod(service);

var lgr=service.lgr;
var getInputParams=service.getInputParams;
var nvl=service.nvl;
var gRB=form.getResourceBundle;
var getSelectedRow2=service.getSelectedRow2;
form.getShortClientName = service.getShortClientName;
lgr(form.inputParams);

form.CLIENTID = form.inputParams.documentSearchParams.CLIENTID;


var localizedValues = {
	filter_DOCTYPESYSNAME: '${documentList.DOCTYPE}',
	filter_DOCUMENTNUMBER: '${documentList.DOCUMENTNUMBER}',
	filter_STRING3: '${documentList.STRING3}',
	filter_STATE: '${documentList.STATE}',
	filter_CREATIONDATE: '${documentList.CREATIONDATE}',
	filter_DOCNUMBER: '${documentList.DOCNUMBER}',
	filter_PHONE: '${documentList.clientMobilePhone}',
	LBDOCNUMBER: '${documentList.clientDocNo}',
	LBPHONE: '${documentList.clientPhoneNo}',
	filter_FIOBankEmployee: '${documentList.FIOBankEmployee}',
	filter_DEPARTMENTNAME: '${documentList.DEPARTMENTNAME}'
};


var BANKCONTEXT = inputParams.implementationContext || 'vtb24';

var contextSettings = {
	vtb24: {
		initSP: {
			CREATEDBY: inputParams.EMPLOYEEID
		},
		documentSearchParams:{
			DOCATTRIBUTE1: '/root/FIOBankEmployee',
			DOCATTRIBUTE2: '/root/loansType'
		},
		cols: [
			{
				value: 'DOCUMENTNUMBER',
				type: 'text',
				caption: gRB('documentNumber'),
				width: 15
			},
			{
				value: 'STRING3',
				type: 'text',
				caption: gRB('Client'),
				width: 10
			},
			{
				value: 'STRING4',
				type: 'text',
				width: 10
			},
			{
				value: 'STRING5',
				type: 'text',
				width: 10
			},
			{
				value: 'STATE',
				type: 'text',
				caption: gRB('State'),
				width: 10
			},
			{
				value: 'CREATIONDATE',
				type: 'date',
				caption: gRB('creationDate'),
				width: 15
			},
			{
				value: 'STRING1',
				type: 'text',
				caption: gRB('ProductGroup'),
				width: 15
			},
			{
				value: 'item.FIOBankEmployee',
				type: 'expression',
				sortName: 'DDA1.ATTRVALUE',
				caption:gRB("employeeName"),
				width: 15
			}
		]
	},
	tpb: {
		initSP: function(){
			var sp = {STATE: form.getResourceBundle('DOCUMENT.STATE.Initiation')};
			if (!ROLESOBJ['LOSSalesPersonTL']){
				sp.CREATEDBY = inputParams.EMPLOYEEID;
			}
			return sp;
		}(),
		CREATENEW_locked: true,
		documentSearchParams:{
			DOCATTRIBUTE1: '/root/FIOBankEmployee',
			DOCATTRIBUTE2: '/root/clientMobilePhone',
			DOCATTRIBUTE3: '/root/clientDocNumber',
			DOCATTRIBUTE4: '/root/externalClientID'
		},
		cols: [
			{
				value: 'DOCUMENTNUMBER',
				type: 'text',
				caption: localizedValues['filter_DOCUMENTNUMBER'],
				width: 10
			},
			{
				value: 'STRING4',
				type: 'text',
				caption: localizedValues['filter_STRING3'],
				width: 15
			},
			{
				value: 'item.clientDocNumber',
				type: 'expression',
				sortName: 'DDA3.ATTRVALUE',
				caption: localizedValues['filter_DOCNUMBER'],
				width: 10
			},
			{
				value: 'item.clientMobilePhone',
				type: 'expression',
				sortName: 'DDA2.ATTRVALUE',
				caption: localizedValues['filter_PHONE'],
				width: 10
			},
			{
				value: 'STATE',
				type: 'text',
				caption: localizedValues['filter_STATE'],
				width: 10
			},
			{
				value: 'CREATIONDATE',
				type: 'date',
				caption: localizedValues['filter_CREATIONDATE'],
				width: 10
			},
			{
				value: 'item.FIOBankEmployee',
				type: 'expression',
				sortName: 'DDA1.ATTRVALUE',
				caption: localizedValues['filter_FIOBankEmployee'],
				width: 15
			},
			{
				value: 'STRING3',
				type: 'text',
				caption: localizedValues['filter_DEPARTMENTNAME'],
				width: 10
			},
			{
				value: 'item.externalClientID',
				type: 'expression',
				caption: "CIF",
				sortName: 'DDA4.ATTRVALUE',
				width: 10
			}
		]
	}
};
form.settings = angular.merge({
	gridTemplatePath: '/webmvc/resource/'+form.getCurrentProjectSysname()+'/TEMPLATES/application/grid/'+BANKCONTEXT+'/'
},contextSettings[BANKCONTEXT]);

var documentSearchParams=nvl(getInputParams('documentSearchParams'),{});


form.prepareFilterParams=function(params,defObj){
	var defObj = defObj || {};
	params = nvl(params,{});
	if (!params.DOCTYPESYSNAMES){
		params.DOCTYPESYSNAMES=[];
		var applicationTypeList=nvl(getInputParams("applicationTypeList"),[]);
		if (applicationTypeList && applicationTypeList.length) {
		    for (var i=0;i<applicationTypeList.length;i++){
			    params.DOCTYPESYSNAMES.push('lead');
		    }
		}
	}
	params = angular.merge({},params,form.settings['documentSearchParams'],defObj);
	return params;
};

form.executeCommand = function(message){
	switch (message.event) {
		case 'SEARCH':
			var params = form.prepareFilterParams(message.params);
			form.documentObj.remoteMethod.filterParams = params;
			console.log('SEARCH');
			console.log(params);
			form.documentObj.refresh();
			break;
		case 'DOCTYPES':
			service.sendMessage({
				event : "DOCTYPES",
				params : {
					applicationTypeList : nvl(getInputParams("applicationTypeList"),[])
				}
			});
			break;
		case 'TRANS_DIRECT':
			service.sendForm("REFRESH", false);
			break;
		case "LEAD_CHANGE":
		case "REFRESH_APP":
			form.documentList.clickRow();
			form.documentObj.refresh();
			//console.log('wheee! table refreshed!');
			break;
		case "CHANGE_PERSON":
        	form.inputParams.SearchParams = message.params;
        	break;
		default:
			break;
			
	}
};

form.onSelectApplication=function(item){
	lgr('onSelectApplication', arguments);
	if (!item) return false;
	var params = {
		APPLICATIONID : item.DOCUMENTID,
        application : {executeSource:'applicationList',loansType:item.loansType}
	};
	//var acts = form.documentObj.options['ID' + item.DOCUMENTID+item.STATE];
	form.documentObj.options['ID' + item.DOCUMENTID+item.STATE] = undefined;
	//if (!acts/* || !acts.length*/) {
		form.startProcess(
			form.getCurrentProjectSysname()+'/COMMON/APPLICATION/getTransferList',
			params,
			function (p) {
				lgr('fillTransfers', p);
				var transfersList = nvl(p['transfersList'],{});
				var resActions=[];
				if (transfersList && transfersList.length) {
				for (var i=0;i<transfersList.length;i++){
					    resActions.push({
						    caption:transfersList[i]["NAME"],
						    click:function(){form.onApplicationAction(this,item)},
						    TRANSITIONID:transfersList[i]["TRANSITIONID"],
							SYSNAME: transfersList[i]["SYSNAME"]
					    });
				    }
				}
				form.documentObj.options['ID' + item.DOCUMENTID+item.STATE] = resActions;
			});
	//}
};


form.onApplicationAction=function(data,item){
    if (data.SYSNAME.indexOf("modal") == 0) { //Name of the transition must be started with 'modal'
        form.startModalPageFlowProcess(form.getCurrentProjectSysname() + '/COMMON/STATEMACHINE/callPageflowByTransferLead', {
            APPLICATIONID: item.DOCUMENTID,
            TRANSITIONID:  data.TRANSITIONID,
			extraParams: {
				loansType: item.loansType
			}
        });
    } else {
		form.documentList.setSelectedRow(undefined);
		form.documentObj.options['ID' + item.DOCUMENTID+item.STATE] = null;
        form.startNewPageFlowProcess(data.caption+form.getResourceBundle('lead.caption')+item['DOCUMENTNUMBER'],  form.getCurrentProjectSysname() + '/' + 'COMMON/STATEMACHINE/callPageflowByTransferLead', {
			APPLICATIONID:item.DOCUMENTID,
			MAINAPPLICATIONID:item.DOCUMENTID,
			TRANSITIONID:data.TRANSITIONID,
			extraParams: {
				loansType: item.loansType
			}
		},true);
		/*service.setActiveTab(form.getCurrentProjectSysname(),'COMMON/STATEMACHINE/callPageflowByTransfer',{
			APPLICATIONID:item.DOCUMENTID,
			MAINAPPLICATIONID:item.DOCUMENTID,
			TRANSITIONID:data.TRANSITIONID,
			extraParams: {
				loansType: item.loansType
			}
		},true,data.caption+form.getResourceBundle('lead.caption')+item['DOCUMENTNUMBER']);*/
    }
};

form.documentObj = (function (grId){
    var gridId = grId;
    var obj = {
        gridId: grId,
        cols : form.settings['cols'],
        options : {
			getLoansTypeLng: function (item){
				var res = '';
				switch (item.loansType){
					case "mortgageLoan":
						res = ' '+String('${mortgage}').toLowerCase();
					break;
					case "autoLoan":
						res = ' '+String('${auto}').toLowerCase();
					break;
					default:
						res = '';
					break;
				}
				return res;
			},
			stateItems: function (){
				utils.dsCall('[frontws2]','smStateGetListByObjectType',{SYSNAME: 'lead'}).then(
					function (res){
						var list = !!res ? (res.data || {}).Result || [] : [];
						obj.options.stateItems = list;
						var colors = {};
						for (var i=0;i<list.length;i++){
							var item = list[i];
							var name = ['NAME'];
							var sysname = ['SYSNAME'];
							colors[name] = function (sn){
								var colorsSys = {
									Initiate: 8,
									Initiation: 8,
									Done: 9
								};
								return colorsSys[sn];
							}(sysname);
						}
						obj.options.stateColors = colors;
					}
				);
				return [];
			}(),
			localizedValues: localizedValues,
			gRB:service.gRB,
			stateColors: {},
			getResourceBundle: form.getResourceBundle,
			cacheStates:[],
			onLoadTemplate:function(){
				lgr('onLoadTemplate',this,arguments);
			},
			prepareTemplatePath:function(){
				return form.settings.gridTemplatePath+'lead.html';
			},
			prepareTemplateFilterPath:function(){
				return form.settings.gridTemplatePath+'lead_filter.html';
			},
			checkStateType:function(state){
				state+="";
				if (this.cacheStates[state]) return this.cacheStates[state]
				var res="process";
				if (state.search(/оформлен/gi)>-1){
					res="done";
				}else
				if (state.search(/annul/gi)>-1 ||
					state.search(/аннул/gi)>-1 ||
					state.search(/отказ/gi)>-1){
					res="error";
				}
				this.cacheStates[state]=res;
				return res;
			}
		},
        remoteMethod : {
            filterParams:  form.prepareFilterParams(getInputParams('documentSearchParams'),form.settings.initSP)
        },
		
        refresh : function (){ console.log('refresh')
            form[gridId].refresh();
        },
		getCurrentProjectSysname:form.getCurrentProjectSysname,
		onChangeItems: function () {
            obj.totalCount = form[gridId].getTotalCount();
        }
    };

    return obj;
})("documentList");

form.createMrtg = function () {
    var SearchParams = form.inputParams.SearchParams;    
	var CLIENTID = form.inputParams.documentSearchParams.CLIENTID;
    if (CLIENTID != null) {
        form.outputParams.curPage = 'APPLIST';
        form.outputParams.menuSysname = 'LIDAPP';
        form.outputParams.DOCTYPESYSNAME = 'lead';
        form.action('NEXT');
    } else {
        form.startNewPageFlowProcess("Создание лида (Ипотека)",  form.getCurrentProjectSysname() + '/' + 'LEAD/_createApplication', {
			menuSysname: 'inputLead',
			DOCTYPESYSNAME: 'lead',
			SearchParams: SearchParams,
			extraParams: {loansType:'mortgageLoan'}
        }, true, null, function(p){});
    }
};

form.createAuto = function () {
    var SearchParams = form.inputParams.SearchParams;    
	var CLIENTID = form.inputParams.documentSearchParams.CLIENTID;
    if (CLIENTID != null) {
        form.outputParams.curPage = 'APPLIST';
        form.outputParams.menuSysname = 'LIDAPP';
        form.outputParams.DOCTYPESYSNAME = 'lead';
        form.action('NEXT');
    } else {
        form.startNewPageFlowProcess("Создание лида (Авто)",  form.getCurrentProjectSysname() + '/' + 'LEAD/_createApplication', {
			menuSysname: 'inputLead',
			DOCTYPESYSNAME: 'lead',
			SearchParams: SearchParams,
			extraParams: {loansType:'autoLoan'}
        }, true, null, function(p){});
    }
};


form.menuItems = [{
	caption: "${applicationList.create}"
}];
var menuActions = [];
if (!!MrtgRights) menuActions.push({
	caption: "${mortgage}",
	click: form.createMrtg
});
if (!!AutoRights) menuActions.push({
	caption: "${auto}",
	click: form.createAuto
});
if (menuActions.length>1){
	form.menuItems[0].items = menuActions;
} else if (!!menuActions.length){
	form.menuItems[0].click = menuActions[0].click;
} else form.menuItems = undefined;


form.action = function(tag){
	form.outputParams.ACTION = tag;
	form.sendForm(tag);
};

