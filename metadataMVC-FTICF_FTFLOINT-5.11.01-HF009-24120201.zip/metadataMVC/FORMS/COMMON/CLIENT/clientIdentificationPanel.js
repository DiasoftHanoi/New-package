/*DSMETA version = "5.11.01-HF009-24120201" hash = "1853e838e2fd8ebf5df28bdcd964292b62736b55"*/
var inputParams = form.inputParams || {};
form.searchParams = inputParams.searchParams || {};

var outputParams = form.outputParams || {}
outputParams.searchParams = form.searchParams || {};

form.getCurrentDate =  function () {
    var now = new Date();
    return service.convertDate(now);
};

form.clearSearchParams = function() {
    form.customerName.setValue("");
    form.dateOfBirth.setValue(null);
    form.documentType.clearValue();
    form.documentNumber.setValue("");
    form.phoneNumber.setValue("");
};

form.updateSearchParams = function() {
    form.searchParams.CurrentName = form.searchParams.CurrentName;
    form.searchParams.BirthDay = form.searchParams.BirthDay;
    form.searchParams.IdentityCardNumber = form.documentNumber.getText();
    form.searchParams.IdentityCardTypeBrief = form.searchParams.IdentityCardTypeBrief;
    form.searchParams.ContactValue = form.phoneNumber.getText();
    var message = {};
    message.event = 'UPDATE_SEARCH_PARAMS';
    message.params = {};
    message.params["searchParams"] = {
        CurrentName: form.searchParams.CurrentName,
        BirthDay: form.searchParams.BirthDay,
        IdentityCardNumber: form.searchParams.IdentityCardNumber,
        IdentityCardTypeBrief:form.searchParams.IdentityCardTypeBrief,
        ContactValue:form.searchParams.ContactValue
    }
    form.command(message);
};

form.onClickSearch = function () {
        form.searchParams.CurrentName = form.searchParams.CurrentName;
        form.searchParams.BirthDay = form.searchParams.BirthDay;
        form.searchParams.IdentityCardNumber = form.documentNumber.getText();
        form.searchParams.IdentityCardTypeBrief = form.searchParams.IdentityCardTypeBrief;
        form.searchParams.ContactValue = form.phoneNumber.getText();
        var message = {};
        message.event = 'SEARCH';
        message.params = {};
        message.params["CurrentName"] = form.searchParams.CurrentName;
        message.params["BirthDay"] = form.searchParams.BirthDay;
        message.params["IdentityCardNumber"] = form.searchParams.IdentityCardNumber;
        message.params["IdentityCardTypeBrief"] = form.searchParams.IdentityCardTypeBrief;
        message.params["ContactValue"] = form.searchParams.ContactValue;
        form.command(message);
};