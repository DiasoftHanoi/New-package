/*DSMETA version = "5.11.01-HF009-24120201" hash = "4c74edd994c443409e3a3b71790e1fcf7afd6c26"*/
/* global form */

function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
service = registerMethod(service);

var convertDate = service.convertDate;
var getTableContent = service.getTableContent;
var gRB = service.gRB;

var EDITMODE = form.inputParams.EDITMODE || "";
form.isFormEditMode = (EDITMODE == 'view') ? false : true;

var inputParams = form.inputParams;
var outputParams = form.outputParams;

form.formParams = inputParams.newRow || {};
outputParams.newRow = form.formParams;

form.requiredElements = [
    "rgEmploymentType",
    "edCompanyName",
    "cmbLegalStructure",
    "adbWorkAddress",
    "cmbContractType",
    "cmbPosition",
    "edPeriodWorkingLengthYears",
    "edPeriodWorkingLengthMonths",
    "edJobName",
    "clPeriodWorkingStartDate",
    "clPeriodWorkingEndDate"
];

form.employmentType_ITEMS = [
    {value: "${mainPlaceOfWork}", text: "${mainPlaceOfWork}"},
    {value: "${partTimeWork}", text: "${partTimeWork}"},
    {value: "${previousOfWork}", text: "${previousOfWork}"}
];
form.LegalStructureComboBoxParams = {
    CRMRefBrief : "organizationalForm"
};
form.cmbPositionComboBoxParams = {
    ReferenceSysName: 'customerPositionsLOS',
    ORDERBY: 'ReferenceItemID'
};
form.cmbContractTypeComboBoxParams = {
    ReferenceSysName: 'contractTypeLOS',
    ORDERBY: 'ReferenceItemID'
};
form.templateData={
    templateKind:"small" ,    
    address:form.formParams.adbWorkAddress || {},
    addressText:form.formParams.adbWorkAddressText || ""
    
};

form.onShow = function () {
    if (EDITMODE == "add") {
        form.formParams.employmentType = "${mainPlaceOfWork}";
    }
};

form.curDate = service.convertDate(new Date());

form.action = function (tag) {                                  
    if (tag == 'save') {
        if (!form.verifyForm()) {
            return;
        }
        var newRowTemp = {
            "adbWorkAddress"        : form.adbWorkAddress.data.address,
            "adbWorkAddressText"    : form.adbWorkAddress.data.address.addressText,
            "legalStructureText"    : form.cmbLegalStructure.getText(),
            "contractTypeText"      : form.cmbContractType.getText(),
            "PositionBriefText"     : form.cmbPosition.getText(),
            "validFromText"         : form.clPeriodWorkingStartDate.getText(),
            "validTillText"         : (form.clPeriodWorkingEndDate != "" && form.clPeriodWorkingEndDate != undefined) ? form.clPeriodWorkingEndDate.getText() : undefined
        };
        if (form.formParams.employmentType == "${mainPlaceOfWork}") {
            newRowTemp["validTillText"] = undefined;
        }
        var empVal =form.rgEmploymentType.getValue();
        for (var i=0;i<form.employmentType_ITEMS.length;i++){
            var item = form.employmentType_ITEMS[i];
            if(item["value"]===empVal){
                newRowTemp["employmentTypeText"]=item["text"]
            }
        }
        angular.extend(form.formParams, newRowTemp);
    }
    else {
        outputParams.newRow = {};
    }
    form.sendForm('GO', false);
};

form.verifyForm = function () {
    var valid = form.validateControlsByIds(form.requiredElements.join(','));
    if (valid && valid.isShowFormErrors == false) {
        return true;
    }
    return false;
};

form.onChangePeriodWorkingDate = function() {
    if (((form.rgEmploymentType.value === "${mainPlaceOfWork}") && form.clPeriodWorkingStartDate.getText() != undefined) || (form.clPeriodWorkingStartDate.getText() != undefined && form.clPeriodWorkingEndDate && form.clPeriodWorkingEndDate.getText() != undefined)) {
        var dateEnd = (form.rgEmploymentType.value != "${mainPlaceOfWork}") ? form.clPeriodWorkingEndDate.getText() : form.curDate;
        var month = parseInt(utils.diffDate(form.clPeriodWorkingStartDate.getText(), dateEnd, 'month'));
        form.edPeriodWorkingLengthMonths.setValue(month % 12 != 0 ? month % 12 : '0');
        form.edPeriodWorkingLengthYears.setValue(Math.floor(month / 12) != 0 ? Math.floor(month / 12) : '0');
    }
    if (form.rgEmploymentType.value === "${mainPlaceOfWork}") {
        form.clPeriodWorkingStartDate.setMaxDate(form.curDate);
        form.formParams.validTill = null;
    } else if (form.rgEmploymentType.value) {
        form.clPeriodWorkingStartDate.setMaxDate(form.clPeriodWorkingEndDate.getText());
        form.clPeriodWorkingEndDate.setMaxDate(form.curDate);
        form.clPeriodWorkingEndDate.setMinDate(form.clPeriodWorkingStartDate.getText());
    }
    if (form.clPeriodWorkingStartDate.getText()) {
        if ((form.rgEmploymentType.value === "${mainPlaceOfWork}") || form.clPeriodWorkingEndDate.getText()) {
            form.edPeriodWorkingLengthYears.disable();
            form.edPeriodWorkingLengthMonths.disable();
        }
        else {
            form.edPeriodWorkingLengthYears.enable();
            form.edPeriodWorkingLengthMonths.enable();
        }
    }
};

form.clearFields = function () {
    for (var keyParam in form.formParams) {
        if (keyParam != 'LinkID') {
            form.formParams[keyParam] = null;
        }
    }
};