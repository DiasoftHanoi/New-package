/*DSMETA version = "5.11.01-HF009-24120201" hash = "50f27e748c3250ed12fce202d69f9d9244873ec2"*/

function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
service = registerMethod(service);

var inputParams = form.inputParams;
var outputParams = form.outputParams;
outputParams.formParams = {};
form.params = form.inputParams.formParams || {};
form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);
form.params.assetsList = form.params.assetsList ? form.params.assetsList : [];
form.pnlAssetsInfoIsCollapsed = form.params.assetsList.length <= 0; 
form.isFormEditMode = form.inputParams.EDITMODE || false;


service.lgr(form.params);

var log = service.lgr;
var gRB = service.gRB;

form.onShow = function () {
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });
};

form.executeCommand = function(msg){
    service.lgr(msg.event);
    if (msg.event === 'FAB_NAVIGATOR_NAVIGATE'){
        outputParams.NEXTPAGE = msg.params.step;
        form.action('DIRECT');
     service.lgr(msg.params.step);   
    }
};

form.verifyForm = function (showFlag) {
    var verified = true;
    try {
        var save =  form['save'];

        if (form.validateControlsByIds('*', showFlag === true ? save : undefined).isShowFormErrors) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    form.outputParams.VERIFIED = verified;
    return verified;
};

form.action = function (tagName) {
    form.outputParams.TRANSTYPE = tagName;  

    outputParams.VERIFIED = true;
    outputParams.formParams.typeAssets = form.params.typeAssets;
    outputParams.formParams.sysnameTypeAssets = "ValuablePaper";
    outputParams.formParams.estimatedValue = form.params.estimatedValue;
    outputParams.formParams.description = form.params.description;

    if (tagName === 'CLOSE') {
        if(form.isFormEditMode) {
            form.CancelValuableForm(form);
        } else {
            form.outputParams.TRANSTYPE = 'CLOSE';
            form.sendForm('GO',false);
        }
    } else {

        if (tagName === 'NEXT' && !form.verifyForm(true)) {
            return;
        } 
        form.sendForm('GO', false);
    }
}
form.CancelValuableForm = function (BaseIdentityCardFlag, gridId) {
    form.mainDocFlag = true;
    form.showInformationDialog(gRB("dialog.confirmCancelValuable"), function(response){
        switch (response.buttonIndex){
            case 0:
                form.outputParams.TRANSTYPE = 'CLOSE';
                form.sendForm('GO',false);
                break;
        }
    }, [{caption: gRB("dialog.yes"), kind:"info small"}, {caption: gRB("dialog.cancel"), kind:"info small"}]);
};