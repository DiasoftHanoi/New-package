/*DSMETA version = "5.11.01-HF008-24102901" hash = "0fe4bb8cecc32b414d8150bc36aa0f67a8c9766c"*/
var inputParams = form.inputParams || {};
form.formParams = inputParams.formParams || {};

var outputParams = form.outputParams || {};
outputParams.formParams = form.formParams || {};

var lgr = service.lgr;
var nvl = service.nvl;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);

form.onShow = function () {

};
form.formParams.cbChooseEmail = inputParams.cbChooseEmail || "";

form.serviceInfo=form.formParams.serviceInfo || {};
form.customerTypeComboBoxParams={ReferenceSysName: 'promotionCustomerType', ReferenceItemCode:inputParams.DOCTYPESYSNAME, ORDERBY: 'ReferenceItemID'};
form.promotionProgramComboBoxParams={ReferenceSysName: 'promotionProgramCode', ReferenceItemCode:form.serviceInfo.customerType, ORDERBY: 'ReferenceItemID'};
form.feeTypeComboBoxParams={ReferenceSysName: 'feesOfCreditCard', ORDERBY: 'ReferenceItemID'};

form.settings = {
    cmbPaymentMethodCard : {
        ReferenceSysName: 'paymentMethodLOS',
        ReferenceGroupName: 'Credit Card'
    },
    cmbpasswordType : {
        ReferenceSysName: 'passwordType',
        ReferenceGroupName: 'General'
    }
};

form.executeCommand = function(msg){
    if (msg.event === 'FAB_NAVIGATOR_NAVIGATE'){
        outputParams.NEXTPAGE = msg.params.step;
        form.action('DIRECT');
    }
};
form.onChangeCbChooseEmail = function () {
    if (form.formParams.cbChooseEmail == '' || form.formParams.cbChooseEmail == undefined) form.formParams.selectedAddress = '';
    else if (form.formParams.cbChooseEmail == 'PersonalEmail') form.formParams.selectedAddress = form.formParams.selectedAddressForPersonalEmail;
    else if (form.formParams.cbChooseEmail == 'Other') form.formParams.selectedAddress = form.formParams.selectedAddressForOther;
};

form.onChangeCbChoosePersonalEmail = function () {
    form.formParams.selectedAddressForPersonalEmail = form.formParams.selectedAddress;
};


form.changePromotionProgram = function(item){
  form.serviceInfo.promotionProgramCode='';
  if(item){
      form.serviceInfo.promotionProgramCode=item.ReferenceItemName;
      if(form.cmbpromotionProgram) form.serviceInfo.promotionProgramName=form.cmbpromotionProgram.getText();
  }
};

form.changeCustomerType = function(flag){
    if(form.cmbcustomerType) form.serviceInfo.customerTypeName=form.cmbcustomerType.getText();
    if(flag){
        delete form.serviceInfo.promotionProgram;
        delete form.serviceInfo.promotionProgramCode;
    }
    if(form.cmbpromotionProgram) {
      form.promotionProgramComboBoxParams.ReferenceItemCode=form.serviceInfo.customerType;
      form.cmbpromotionProgram.refresh();
    }
};

form.changeFeeType = function(item){
  form.serviceInfo.feeCode='';
  if(item){
      form.serviceInfo.feeCode=item.ReferenceItemCode;
      if(form.cmbfeeType) form.serviceInfo.feeTypeName=form.cmbfeeType.getText();
  }
};

form.saveNewSelectedContact = function(selectedContact, selectedName, selectedSysName, text, type) {
    if (selectedContact != '' && selectedContact != undefined) {
        outputParams.formParams[selectedName] = text;
        outputParams.formParams[selectedSysName] = type;
    } else {
        outputParams.formParams[selectedName] = '';
        outputParams.formParams[selectedSysName] = '';
    }
};

form.verifyForm = function (showFlag) {
    var verified = true;
    try {
        var btnNext =  form['btnNext'] ? 'btnNext' : 'btnSave';
        if (form.validateControlsByIds('*', showFlag === true ? btnNext : undefined).isShowFormErrors) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {lgr(e);
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    form.outputParams.VERIFIED = verified;
    return verified;
};

form.action = function (tagName) {
    outputParams.STAGEDETAILS = form.formParams.STAGEDETAILS;
    outputParams.paymentAccountNumber = form.formParams.paymentAccountNumber;
    outputParams.formParams.passwordType = form.cbPasswordType.getText();
    outputParams.formParams.paymentMethodCard = form.cbPaymentMethodCard.getText();
    outputParams.formParams.selectedAddress = form.formParams.selectedAddress;
    form.saveNewSelectedContact(form.formParams.selectedAddress, "emailInforming", "emailInformingSysName", form.cbChooseEmail.getText(), form.cbChooseEmail.getValue());
    outputParams.formParams.serviceInfo = form.serviceInfo;
    outputParams.TRANSTYPE = tagName;

    if (tagName === 'CLOSE' || tagName === 'PREV') {
        form.sendForm('CLOSE', false);
    } else {

        if (tagName === 'NEXT' && !form.verifyForm(true)) {
            return;
        } else {
            form.verifyForm(false);
        }
        form.sendForm('GO', false);
    }
};