/*DSMETA version = "5.11.01-HF008-24102901" hash = "6d9408138f9e8f80718a86f95993b38daf618c6e"*/
form.formParams = form.inputParams.formParams;
form.onClickPage = function (item) {
    var rightMessage = {};
    rightMessage.event = "GO_TO_PAGEFLOW";
    rightMessage.caption = item.NAME;
    rightMessage.params = {};
    rightMessage.params.APPLICATIONID = form.formParams.APPLICATIONID;
    rightMessage.params.PAGEFLOW = item.PAGEFLOW;
    if (item.SYSNAME) {
        form.command(rightMessage);
    }
};