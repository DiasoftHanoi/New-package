/*DSMETA version = "5.11.01-HF008-24102901" hash = "d22cc67458066b97b0545af72154fb54a946d687"*/
/* Author azavodchikov*/

var inputParams = form.inputParams || {};
form.searchParams = inputParams.searchParams || {};

var outputParams = form.outputParams || {};
outputParams.searchParams = form.searchParams || {};

form.onShow = function () {
    var identityCardTypeByDefault = "nationalID";
    if (inputParams.IdentityCardList) {
        for (var i = 0, count = inputParams.IdentityCardList.length; i < count; i++) {
            var identityCardType = inputParams.IdentityCardList[i].IdentityCardTypeBrief;
            if (identityCardType.toLowerCase() == "nationalid") {
                identityCardTypeByDefault = identityCardType;
                break;
            }
        }
    }
    if(form.searchingStrategy) {
        form.searchingStrategy.setValue("By document");
    }
    if(form.documentType) {
        form.documentType.setValue(identityCardTypeByDefault);
    }
    form.checkSearchingStrategy();
    setTimeout(function() {
        if(form.documentType) {
            form.documentType.setValue(identityCardTypeByDefault);
        }
    }, 5);
};

form.executeCommand = function(msg) {
    switch(msg.event){
        case 'GO_TO_PAGEFLOW':
            form.startNewPageFlowProcess(msg.caption, msg.params.PAGEFLOW, {
                APPLICATIONID: msg.params.APPLICATIONID,
                EDITMODE: false
            });
            break;
        default:
            break;
    }
};

form.settings = {
    searchingStrategy_items: [{
           value: 'By document',
           text:  "${search.byDocument}"
    },  {
           value: 'By full name',
           text:  "${search.byFullName}"
    },  {
           value: 'By phone number',
           text:  "${search.byPhoneNumber}"
        }
    ]
};


form.checkSearchingStrategy = function () {
    if(form.searchingStrategy && form.searchingStrategy.getValue() == "By document") {
         form.isByDocument = true;
         form.searchParams.CurrentName = undefined;
         form.searchParams.BirthDay = undefined;
         form.searchParams.ContactValue = undefined;
         form.documentNumberMask = undefined;

    }else{
         form.isByDocument = false;
    }

    if(form.searchingStrategy.getValue() == "By full name") {
         form.isFullName = true;
         form.searchParams.IdentityCardTypeBrief = undefined;
         form.searchParams.IdentityCardNumber = undefined;
         form.searchParams.ContactValue = undefined;
    }else{
         form.isFullName = false;
    }

    if(form.searchingStrategy.getValue() == "By phone number") {
         form.isPhoneNumber = true;
         form.searchParams.CurrentName = undefined;
         form.searchParams.BirthDay = undefined;
         form.searchParams.IdentityCardTypeBrief = undefined;
         form.searchParams.IdentityCardNumber = undefined;
    }else{
         form.isPhoneNumber = false;
    }
};

form.changeDocumentType = function () {
    for (var i = 0, count = inputParams.IdentityCardList.length; i < count; i++) {
        if (form.searchParams.IdentityCardTypeBrief == inputParams.IdentityCardList[i].IdentityCardTypeBrief) {
            form.documentNumberMask = inputParams.IdentityCardList[i].NumberMask;
            return;
        }
    }
    form.documentNumberMask = undefined;
};

form.getCurrentDate =  function () {
    var now = new Date();
    return service.convertDate(now);
};

form.action = function (tag) {
    form.outputParams.ACTION = tag;
    form.outputParams.searchParams = form.searchParams;
    form.sendForm(tag,false);
};