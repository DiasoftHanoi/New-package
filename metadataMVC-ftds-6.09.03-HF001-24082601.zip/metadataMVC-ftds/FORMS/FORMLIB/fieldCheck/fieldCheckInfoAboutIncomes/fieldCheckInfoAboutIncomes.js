/* global form, service */
function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
service = registerMethod(service);

var inputParams = form.inputParams || {};
form.formParams = inputParams.formParams;

var outputParams = form.outputParams || {}
outputParams.formParams = form.formParams;

var lgr = service.lgr;
var nvl = service.nvl;
var gRB = service.gRB;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);
form.isFormEditMode = form.inputParams.EDITMODE || false;

form.data = {incomeAmountTotal : 0};

form.onShow = function () {
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });

    // To avoid case when the row has been edited. We need to reset flag, to see it in the grid.
    for(var i = 1; i < form.inputParams.wizardParams.incomeList.length; i++) {
        var isEdit = nvl(form.inputParams.wizardParams.incomeList[i].isEdit, false);
        if (isEdit)
          form.inputParams.wizardParams.incomeList[i].isEdit = false;
    }

    form.checkIncomeInfo('show');

    form.tblIncomeObj.setItems(form.inputParams.wizardParams.incomeList || []);
    form.tblIncome.setSelectedRow(undefined);
};


form.executeCommand = function (msg) {
    switch (msg.event) {
        case 'FAB_NAVIGATOR_NAVIGATE':
            outputParams.NEXTPAGE = msg.params.step;
            form.action('DIRECT');
        break;
        default:
            break;
    }
};

form.verifyForm = function (showFlag) {
    var verified = true;
    try {
        var save =  form['save'];

        if (form.validateControlsByIds('*', showFlag === true ? save : undefined).isShowFormErrors) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    form.outputParams.VERIFIED = verified;
    return verified;
};

form.yesFunc = function() {
    form.outputParams.TRANSTYPE = 'SAVEDRAFT';
    if (form.verifyForm()) {
        form.sendForm('GO', false);
    }
};

form.action = function (tagName) {
    outputParams.TRANSTYPE = tagName;

    if (tagName === 'CLOSE' && form.isFormEditMode) {
        service.showDialogCancelConfirm(
            form,
            form.yesFunc
        )
    } else {
        if (tagName === 'NEXT' && !form.verifyForm(true)) {
            return;
        } else {
            form.verifyForm(false);
        }
        form.sendForm('GO', false);
    }
};

form.tblIncomeObj = (function (grId) {
    var gridId = grId;
    var processParams = {
        clientMap:     inputParams.wizardParams.clientMap,
        appMap:        inputParams.wizardParams.appMap,
        STAGESYSNAME:  inputParams.wizardParams.STAGESYSNAME,
        STAGEID:       inputParams.wizardParams.STAGEID,
        APPLICATIONID: inputParams.APPLICATIONID,
        EDITMODE:      form.isFormEditMode
    };

    var options = {
        fieldCheck: function () {
            var selectedRow = form.tblIncome.getSelectedRow()[0] || {};
            //For wizard conditions
            processParams['incomeType']    = selectedRow.incomeType ? selectedRow.incomeType : null;
            processParams['typeAssets']    = selectedRow.typeAssets ? selectedRow.typeAssets : null;
            processParams['selectedRowId'] = selectedRow.LinkID;

            form.startNewPageFlowProcess(inputParams.NEXTWIZARDNAME, form.getCurrentProjectSysname() + "/FORMLIB/fieldCheck/fieldCheckIncomesINT", {
                wizardParams : processParams
            },false,null, function (response) {});
        }
    };
    var obj = {
        gridId: grId,
        refresh: function () {
            form[gridId].refresh();
        },
        setItems: function (items) {
            form[gridId].setItems(items);
        },
        getItems: function () {
            return form[gridId].getItems();
        },
        onSelectRow: function () {
            options.items = [];
            options.items = [
                {caption: form.isFormEditMode ? gRB('fieldCheck') : gRB('fieldCheckView'), 
                 click: form.tblIncome.options.fieldCheck}
            ];
        }
    };
    obj.options = options;
    return obj;
})('tblIncome');

form.checkIncomeInfo = function(mode) {
    var incomeTableList = (mode == 'show') ? form.inputParams.wizardParams.incomeList || [] : getTableContent(form.tblIncome);
    var incomeAmountTotal = 0;
    if (incomeTableList instanceof Object && Object.keys(incomeTableList).length > 0) {
        for (var i = 0, count = incomeTableList.length; i < count; i++) {
            incomeAmountTotal += parseFloat(incomeTableList[i].incomeAmount);
        }
    }
    form.data.incomeAmountTotal = incomeAmountTotal ;
};