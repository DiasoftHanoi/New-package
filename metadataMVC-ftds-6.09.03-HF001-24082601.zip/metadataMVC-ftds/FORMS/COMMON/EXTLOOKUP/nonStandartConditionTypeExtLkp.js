var inputParams = form.inputParams || {};
form.formParams = inputParams.formParams || {};

var formParams=form.formParams;
form.outputParams = form.formParams;

var lgr = service.lgr;
lgr(inputParams);

form.selRowClick = function () {
    service.lgr("ON CLICK");
    var selRow = form.tbConditionTypeList.getSelectedRow()[0];
    if (selRow != null) {
        formParams.KEY = selRow.SYSNAME
        formParams.VALUE = selRow.NAME;
        formParams.NEEDCOMMENT = selRow.NEEDCOMMENT;
    }

    service.lgr(formParams);

    if (formParams.KEY) {
        formParams.LOOKUP_RESULT = "OK";
    } else {
        delete formParams.LOOKUP_RESULT;
    }
    form.sendForm('NEXT');
};

form.cancel = function () {
    delete formParams.KEY;
    delete formParams.VALUE;
    delete formParams.LOOKUP_RESULT;
    delete formParams.DESCRIPTION;
    delete formParams.NEEDCOMMENT;
    form.sendForm("CANCEL");
}