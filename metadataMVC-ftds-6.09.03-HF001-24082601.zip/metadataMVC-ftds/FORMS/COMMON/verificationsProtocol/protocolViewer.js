var inputParams = form.inputParams;
var outputParams = form.outputParams;

form.checkScriptExecuted = inputParams.checkScriptExecuted;
var appId = inputParams.APPLICATIONID;
var globalProtocolId = inputParams.GLOBALPROTOCOLID;
var item = form.item;

form.params = inputParams;
form.methodParams = inputParams.methodParams;

var globalInterval;

form.onShow = function () {
    form.getScriptStatus();
    globalInterval = setInterval(form.getScriptStatus, 2000);
    //form.fillProtocolTable();
}

form.fillProtocolTable = function (wsResponse) {
    if (form.checkScriptExecuted == true) {
        form['checkStatus'].caption = 'Выполняются';
        form['checkStatus'].kind = ('color6');
        form['verGrid'].refresh();
    } else {
        form['checkStatus'].caption = 'Выполнены';
        form['checkStatus'].kind = ('color1');
        clearInterval(globalInterval);
    }

}

form.getScriptStatus = function () {
    var params = {"DOCUMENTID": appId, "ReturnAsHashMap": "TRUE"};
    form.dsCall('[frontws2]', 'documentGetByIdOld', params).then(function (response) {
        console.log("getScriptStatus");
        console.log(response.data);
        form.checkScriptExecuted = response.data["checkScriptExecuted"];
        form.fillProtocolTable();
    });
}


form.repeatCheck = function () {

    var selRows = form.verGrid.getSelectedRow();
    var selRow = null;
    if (selRows.length > 0) {
        selRow = selRows[0];
    }
    if (selRow != null) {
        outputParams.CHECKPROTOCOLID = selRow["CHECKPROTOCOLID"];
    }
    form.sendForm("REPEATCHECK", false);
}

form.showDetails = function () {
    var selRows = form.verGrid.getSelectedRow();
    var selRow = null;
    if (selRows.length > 0) {
        selRow = selRows[0];
    }

    var chkDetails = selRow["CHECKDETAILS"];
    if (!chkDetails) {
        chkDetails = 'Отсутствуют детали для выбранной проверки';
    }
    form.showModalDialog("large", "Детали проверки:", chkDetails, null, [{caption: "OK"}], function () {
    });
}

form.Cols = {

    cols: [
        {
            value: 'CHECKNAME',
            type: 'text',
            caption: 'Проверка',
            width: 10
        },
        {
            value: 'CHECKNAME',
            type: 'text',
            caption: 'Проверка',
            width: 10
        }
    ],
}

form.checkObj = (function (grId) {
    var gridId = grId;

    var obj = {
        gridId: grId,

        cols: [
            {
                value: 'CHECKNAME',
                type: 'text',
                caption: 'Проверка',
                width: 15
            },
            {
                value: 'CHECKRESULT',
                type: 'text',
                caption: 'Состояние',
                width: 15
            }
        ],

        remoteMethod: {
            method: 'checkProtocolGetListByParams',
            service: '[dmsws]',
            filterParams: inputParams.methodParams
        },

        options: {
            'items': [
                {
                    caption: 'Повторить проверку',
                    click: form.repeatCheck
                },
                {
                    caption: 'Показать детали',
                    click: form.showDetails
                }
            ]
        },

        refresh: function () {
            form[gridId].refresh();
        },

        onChangeItems: function () {
            obj.totalCount = form[gridId].getTotalCount();
        },
    };


    return obj;
})("verGrid")