/* global form, service */

var inputParams = form.inputParams || {};
form.formParams = inputParams.formParams;

var outputParams = form.outputParams || {}
outputParams.formParams = form.formParams;

var lgr = service.lgr;
var nvl = service.nvl;
var gRB = form.getResourceBundle;

form.onShow = function () {
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });
};

form.executeCommand = function(msg){
    if (msg.event === 'FAB_NAVIGATOR_NAVIGATE'){
        outputParams.NEXTPAGE = msg.params.step;
        form.action('DIRECT');
    }
};

form.action = function (tagName) {
    outputParams.TRANSTYPE = tagName;
    outputParams.VERIFIED = true;
    form.sendForm('GO');
}

form.makeDecision = function (decisionRef) {
    form.mComment.required='false';
    if(nvl(decisionRef.commentRequired,'false')=='true'){
        form.mComment.required='true';
        if(!form.verifyForm(true,decisionRef.REFSYSNAME)) return;
    }
    form.formParams.REFSYSNAME = decisionRef.REFSYSNAME;
    form.formParams.DECISION = decisionRef.REFNAME;
    form.action('NEXT');
};

form.decisionRefItems = (function (decisionRefItems) {
    var items = [];
    for (var i = 0; i<decisionRefItems.length; i++){
        items.push({
            caption: decisionRefItems[i]['REFNAME'],
            refItem: decisionRefItems[i],
            click: function () {
                form.makeDecision(this.refItem);
            }
        })
    }
    return items;
})(nvl(inputParams.DecisionRefList, []));

form.requiredControls = 'mComment';

form.verifyForm = function (showFlag,id) {
    var verified = true;
    try {
        console.log('verifyForm');
        if (form.validateControlsByIds(form.requiredControls, showFlag ? id : undefined).isShowFormErrors) {
            throw  {type: 'fields', msg: ''};
        }

    } catch (e) {
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{caption: gRB('dialog.ok')}]);
        }
        verified = false;
    }
    outputParams.VERIFIED = verified;
    return verified;
};