/*DSMETA version = "6.01.01" hash = "456e06fad94f219f04ca8ca890f9cc68e34a17f0"*/
service.setGeometryByVisible = setGeometryByVisible;

// подцветка строчки в TWTable
function hasClass(ele, cls){
  return ele.className.match(new RegExp('(\\s|^)' + cls + '(\\s|$)'));
}
///////////////////////////////////////////////////////////////////////////////////////////////////
function setClass(ele, cls){
  
  var defaultStyle = "table[class*='x-grid3-row-table']";
  
  if(cls != "") {
    if(!this.hasClass(ele, cls)) {
      ele.className = cls;
    }
  }
  else {
    ele.className = defaultStyle;
  }
}
///////////////////////////////////////////////////////////////////////////////////////////////////
function setColorOnTableRow(extElement, setStyle){
  if(setStyle != null && setStyle != "") {
    setClass(extElement, setStyle);
  }
  else {
    setClass(extElement, "");
  }
}
////////////////////////////////////////////////////////////////////////////////////////////
function setGeometryByVisible(pnlList,mainEl,isRoot,startCoord,interBlock,mergeBlock){
   //println("setGeometryByVisible");
   interBlock= interBlock!=null ? interBlock : 4;
   mergeBlock = mergeBlock!=null ? mergeBlock : 0;
   var curY=startCoord;

   for (var i=0;i<pnlList.length;i++){
      if (gbiFlex(pnlList[i])!=null){
	     if (isVisible(pnlList[i])){
            setCoordY(pnlList[i],curY);
            if (gbiFlex(pnlList[i]+"Pnl")){}
            if (gbiFlex("pnl"+pnlList[i]+"")){
				setHeight("pnl"+pnlList[i],getHeight(pnlList[i])-14);
            }
            curY+=getHeight(pnlList[i])+mergeBlock;
         }
      }
   }  

   setHeight(mainEl,curY+interBlock);
   if (gbiFlex(mainEl+"pnl")){
      setHeight(mainEl+"pnl",curY+interBlock);
   } 
   if (gbiFlex("pnl"+mainEl)){
      setHeight("pnl"+mainEl,curY+interBlock);
   } 
   
  if (isRoot){
      setFormHeight(curY+interBlock);
   }
}