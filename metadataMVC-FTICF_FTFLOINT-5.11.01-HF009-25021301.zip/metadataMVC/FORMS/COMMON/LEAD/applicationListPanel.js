/*DSMETA version = "5.11.01-HF009-25021301" hash = "60e7304c327989c54b6520a01a81d355df928471"*/
var inputParams = form.inputParams;
function registerMethod(initService){
	var service={};
	for (var ar in initService){
		if (initService.hasOwnProperty(ar)){
			if (ar.indexOf('Service')>-1 || typeof (initService[ar]) != 'function'){
				service[ar]=initService[ar];
			}else{
				var fn=initService[ar].toString();
				var sIdx=fn.search(/\(/)+1;
				var eIdx=fn.search(/\)\s*\{/);
				var args=fn.substring(sIdx,eIdx)
				eval("service."+ar+"=function("+args+")"+fn.substring(eIdx+1,fn.length));
			}
		}
	}
	return service;
}
service=registerMethod(service);
var lgr=service.lgr;
var nvl=service.nvl;
var gRB=service.gRB;

form.searchParams = form.inputParams.documentSearchParams;
form.searchParams.DOCTYPESYSNAME = 'lead';  //2132635 для того чтобы комбо не заполнялся и не дизейблился
form.docTypeEnableFlag = !form.searchParams.DOCTYPESYSNAME;
form.applicationTypeList = form.inputParams.applicationTypeList;
form.ROLES = form.inputParams.ROLES || [];
form.applicationStatusParams = {
      SYSNAME :"lead"
};
var ROLESOBJ = {};
var ROLES = form.inputParams.ROLES || [];
for (var i=0;i<ROLES.length; i++){
	ROLESOBJ[ROLES[i]['ROLESYSNAME']] = ROLES[i]['ROLESYSNAME'];
}
form.ExternalSalesManagerExist = ('Mrtg_ExternalSalesManager' in ROLESOBJ) || ('Avto_ExternalSalesManager' in ROLESOBJ);

form.localizedValues = {
	clientParams: '${clientParams.caption}',
	PERSONLASTNAME: '${clientLastname.caption}',
	PERSONFIRSTNAME: '${clientFirstname.caption}',
	PERSONMIDDLENAME: '${clientMiddlename.caption}',
	PERSONBIRTHDAY: '${clientBirthDate.caption}',
	PERSONDOCSERIES: '${clientDocSeries.caption}',
	PERSONDOCNUMBER: '${clientDocNumber.caption}',
	PHONE: '${clientMobilePhone.caption}',
	CIF: '${clientCIF.caption}',
	OPF: '${clientOPF.caption}',
	CLIENTNAME: '${clientName.caption}',
	appParams: '${appParams.caption}',
	DOCTYPESYSNAME: '${cbDocType.caption}',
	DOCUMENTNUMBER: '${docNumber.caption}',
	STATE: '${state.caption}',
	PERIOD: '${period.caption}',
	MINDATE: '${startDate.caption}',
	MAXDATE: '${endDate.caption}',
	DATE: '${date.caption}',
	BRANCHID: '${cbOrgNode.caption}',
	CREATEDBY: '${cbCreatedBy.caption}',
	loansType: '${cmLoansType.caption}'
};
var stateItem1 = {NAME:form.getResourceBundle('DOCUMENT.STATE.All'),SYSNAME:'All'};
var stateItem2 = {NAME:form.getResourceBundle('DOCUMENT.STATETYPE_NOT_EQUAL'),SYSNAME:'All_but_final'};
var stateParams = {SYSNAME: 'lead'};

var BANKCONTEXT = inputParams.implementationContext || 'vtb24';

var contextSettings = {
	vtb24: {
		defaultState: form.getResourceBundle('DOCUMENT.STATE.All'),
		activate_STATETYPE_NOT_EQUAL: false,
		clearSearchParams: function (){
			delete form.searchParams.CREATEDBY;
			delete form.searchParams.clientDocNumber;
		},
		init: function (){
			form.searchParams.CREATEDBY = inputParams.EMPLOYEEID;
		},
		prepareSearchParams: function (params){
			if (!params['PERSONLASTNAME'] && !params['PERSONFIRSTNAME'] && !params['PERSONMIDDLENAME'] && !params['PERSONBIRTHDAY'] && !params['PERSONDOCSERIES'] && !params['PERSONDOCNUMBER']){
				delete params['PARTICIPANTTYPE'];
			} else {
				params['PARTICIPANTTYPE']=1;
			}
		},
		cbOrgNodeParams:{DepartmentTypeList:[{DepartmentType:52},{DepartmentType:51},{DepartmentType:50},{DepartmentType:40},{DepartmentType:30}]}
	},
	tpb: {
		defaultState: form.getResourceBundle('DOCUMENT.STATE.Initiation'),
		activate_STATETYPE_NOT_EQUAL: true,
		clearSearchParams: function (){
			//LOSSalesPerson
			//LOSSalesPersonTL
			if (!form.settings.CREATEDBY_locked) delete form.searchParams.CREATEDBY;
			delete form.searchParams.DAVALUE2;
			delete form.searchParams.DAVALUE3;
			delete form.searchParams.DAVALUE4;
			//console.log('cleared');
		},
		createdByChange: function (val){
			//console.log('createdByChange');
			//console.log(val);
		},
		init: function (){
			//if (!ROLESOBJ['LOSSalesPersonTL']){
			//	form.searchParams.CREATEDBY = inputParams.EMPLOYEEID;
			//}
		},
		CREATEDBY_locked: function (){
			//if (ROLESOBJ['LOSSalesPerson'] && !ROLESOBJ['LOSSalesPersonTL']) return true;
			return false;
		}(),
		BRANCHID_locked: function (){
			if ((ROLESOBJ['LOSAccountManager'] || ROLESOBJ['LOSSalesPerson']) && !ROLESOBJ['LOSSalesPersonTL']) return true;
			return false;
		}(),
		prepareSearchParams: function (params){
			if (!params['STRING4']) delete params['STRING4'];
			if (!params['DAVALUE3']) delete params['DAVALUE3'];
			if (!params['DAVALUE4']) delete params['DAVALUE4'];
			if (!params['DAVALUE2']) delete params['DAVALUE2'];
		}
	}
};
form.settings = angular.merge({
/*	gridTemplatePath: '/webmvc/resource/'+form.getCurrentProjectSysname()+'/TEMPLATES/application/grid/'+BANKCONTEXT+'/',
	prepareTemplateFilterPath:function(){ console.log(form.settings.gridTemplatePath);
		return form.settings.gridTemplatePath+'lead_params.html';
	},*/

	stateItems: function (){
		utils.dsCall('[frontws2]','smStateGetListByObjectType',stateParams).then(
			function (res){
				var list = !!res ? (res.data || {}).Result || [] : [];
				if (contextSettings[BANKCONTEXT]['activate_STATETYPE_NOT_EQUAL']) list.unshift(stateItem2);
				list.unshift(stateItem1);

				form.settings.stateItems = list;//stateItem1.concat(list);
				form.searchParams.STATE = contextSettings[BANKCONTEXT]['defaultState'];
			}
		);
		return [];
	}(),
	dateBirthdayMax: utils.jsDateToString(new Date())
},contextSettings[BANKCONTEXT]);

form.ROLESOBJ = ROLESOBJ;
if (typeof form.settings.init === 'function') form.settings.init();
form.bankProductGroupParams = {
	BankProductGroup_ITEMS: {},
	caption: form.getResourceBundle('DOCUMENT.BankProductGroup')
	//title:'Дерево групп банковских продуктов'
};

form.periodItems = [
    {value:"today", text:gRB("list.calendar.today")},
    {value:"today_yesterday", text:gRB("list.calendar.todayYesterday")},
    {value:"last_week", text:gRB("list.calendar.lastWeek")},
    {value:"last_month", text:gRB("list.calendar.lastMonth")},
    {value:"period", text:gRB("list.calendar.period")},
    {value:"date", text:gRB("list.calendar.date")}
];

form.onChangeApplicationStatusItems = function () {
        var isAll=false;
        var list = form.state.getItems()
                for (var i = 0, count = list.length; i < count; i++) {
                    if (list[i].SYSNAME =='All') {
                        isAll=true;
                        break;
                    }
        }
        console.log(isAll);
        if(!isAll) {
        form.state.setEmptyValue("All",form.getResourceBundle("exceptEndStates"));
        form.state.setValue('All');
        form.States = undefined;
        console.log(form.States);
        }
};

form.onChangeState = function () {  console.log('state ' + form.state.getValue());
     form.States = undefined;
     if(form.state.getValue() +"" != "" && form.state.getValue() != "All") {
          form.States = [];
           var prms = {
               SYSNAME: form.state.getValue(),
               TYPEID: 555,
               LOCALE : "en"
           };

           form.dsCall('[frontws2]', 'smStateGetListByParams', prms).then(function (p) {
               var res = nvl(p['data'], {});
               form.States.push(res.Result[0].NAME);

                var prms2 = {
                     SYSNAME: form.state.getValue(),
                     TYPEID: 555,
                     LOCALE : "vi"
                };

                form.dsCall('[frontws2]', 'smStateGetListByParams', prms2).then(function (p) {
                     var res = nvl(p['data'], {});
                     //form.States = form.States + "," + res.Result[0].NAME;
                     form.States.push(res.Result[0].NAME);
                     console.log(form.States);
                });

           });

     }
}

form.ACTION_SEARCH = function() {
	var params=angular.copy(form.searchParams);
		params.CREATIONMINDATE = service.convertToDate(nvl(form.startDate.getValue(),params.CREATIONMINDATE));
		params.CREATIONMAXDATE = service.convertToDate(nvl(form.endDate.getValue(),params.CREATIONMAXDATE));

	function replaceToMask(mask, value){
		if (value == undefined || value == null){
			return value;
		}
		var count = 0;
		if (mask){
			var tA = mask.split(" ");
			for (var i=0;i<tA.length; i++){
				tA[i] = value.substring(count, count+tA[i].length)
				count+=tA[i].length
			}
			return tA.join(" ").trim();
		}
		return value;
	}

	if (params.PERIOD === 'date'){
		params.CREATIONMAXDATE = params.CREATIONMINDATE;
	}
	if (params.BRANCHID){
		params.BRANCHIDS = [params.BRANCHID];
	} else {
		delete params.BRANCHIDS;
	}
	delete params['STATES'];
	if (params['STATE'] === form.getResourceBundle('DOCUMENT.STATETYPE_NOT_EQUAL')){
		if (form.settings.activate_STATETYPE_NOT_EQUAL) params['STATETYPE_NOT_EQUAL'] = 2;
		delete params['STATE'];
	} else {
		delete params['STATETYPE_NOT_EQUAL'];
		delete params['STATE'];
		params.STATES = form.States;
	}

	if (params['STATE'] === form.getResourceBundle('DOCUMENT.STATE.All')){
		delete params['STATE'];
		delete params['STATETYPE_NOT_EQUAL'];
	}
	console.log('подготовка');
    console.log(params);
	/*///
	if (params['bankProductGroupId']){
		params['DOCATTRIBUTE1']='/root/bankProductGroupId';
		params['DAVALUE1']=params['bankProductGroupId'];
	} else {
		delete params['DOCATTRIBUTE1'];
		delete params['DAVALUE1'];
	}*/
	form.settings.prepareSearchParams(params);
    form.command({
		event:'SEARCH',
		params: params
	});
};

form.onChangePeriod = function (item){
	var dateStart = utils.curDateJS();
    var dateEnd = utils.curDateJS();
	
    lgr(item);
    switch (item.value){
        case "today":
            dateEnd.setDate(dateEnd.getDate()+1);
            break;
        case "today_yesterday":
			dateStart.setDate(dateStart.getDate() - 1);
			dateEnd.setDate(dateEnd.getDate() + 1);
			break;
        case "last_week":
			dateStart.setDate(dateStart.getDate() - 7);
			dateEnd.setDate(dateEnd.getDate() + 1);
			break;
        case "last_month":
			dateStart.setMonth(dateStart.getMonth() - 1);
			dateEnd.setDate(dateEnd.getDate() + 1);
			break;
        case "period":
            break;
        case "date":
            break;
        default:
            form.searchParams.PERIOD="last_week";
            break;

    }
   /* form.searchParams.MINDATE=service.convertDate(dateStart,'DD.MM.YYYY');
	form.searchParams.MAXDATE=service.convertDate(dateEnd,'DD.MM.YYYY');*/

	form.searchParams.MINDATE=utils.jsDateToJsonDate(dateStart);
	form.searchParams.MAXDATE=utils.jsDateToJsonDate(dateEnd);

    form.searchParams.CREATIONMINDATE = dateStart;
    form.searchParams.CREATIONMAXDATE = dateEnd;

    lgr(form.searchParams);
};

form.clearSearchParams = function(){
    lgr("clearSearchParams...");
	delete form.searchParams.STRING3;
	delete form.searchParams.STRING4;
	delete form.searchParams.STRING5;
    delete form.searchParams.PERSONLASTNAME;
    delete form.searchParams.PERSONFIRSTNAME;
    delete form.searchParams.PERSONMIDDLENAME;
	delete form.searchParams.PERSONBIRTHDAY;
	delete form.searchParams.PERSONDOCSERIES;
	delete form.searchParams.PERSONDOCNUMBER;
	delete form.searchParams.OPF;
	delete form.searchParams.CLIENTNAME;
	/*if (form['cbDocType'].isEnabled()){
		delete form.searchParams.DOCTYPESYSNAME;
	}*/
	delete form.searchParams.DOCUMENTNUMBER;
	delete form.searchParams.STATE;
	///delete form.searchParams.bankProductGroupId;
	if (form['cbOrgNode'].isEnabled()){
		delete form.searchParams.BRANCHID;
	}
	form.searchParams.PERIOD = 'last_week';
	form.searchParams.STATE = form.settings.defaultState;//form.getResourceBundle('DOCUMENT.STATE.All');
	form.settings.clearSearchParams();
};
/*form.documentType = {
    change : function() {
        var DOCTYPESYSNAME = 'lead';
        var TYPEIDS=[];
		var applicationTypeList=form.applicationTypeList || [];
		for (var i=0;i<applicationTypeList.length;i++){
			if (applicationTypeList[i]["TYPESYSNAME"]+''== DOCTYPESYSNAME){
				TYPEIDS.push(applicationTypeList[i]["DOCUMENTTYPEID"]);
			}
		}
		if (TYPEIDS.length>0){
			form.state.disable();
			form.dsCall("[frontws2]","smStateGetListByParams",{
					TYPEIDS:TYPEIDS,
					ORDERBY:"NAME"
				}).then(
				function(p){
					lgr("onAfterSmStateGetListByParams")
					p=nvl(p['data']['Result'],[]);
					var items=[];
					var data={};

					items.push({NAME:form.getResourceBundle('DOCUMENT.STATETYPE_NOT_EQUAL')});

					for (var i=0;i<p.length;i++){
						data[p[i]['NAME']]=true
					}
					for (var ar in data){
						items.push({NAME:ar});
					}
					form.state.enable();
					lgr(items);
					form.state.setItems(items);
					form.searchParams.STATE = form.getResourceBundle('DOCUMENT.STATETYPE_NOT_EQUAL');
					///form.changeBankProductGroup(DOCTYPESYSNAME);
			})
		}else{
			form.state.clearItems();
			///delete form.searchParams.bankProductGroupId;
			form.state.setItems([{NAME:form.getResourceBundle('DOCUMENT.STATETYPE_NOT_EQUAL')}]);
			form.searchParams.STATE = form.getResourceBundle('DOCUMENT.STATETYPE_NOT_EQUAL');
		}
    }
};

form.changeBankProductGroup = function(DOCTYPESYSNAME){
	var GROUPBRIEFNAME = '';
	var DOCTYPESYSNAME = 'lead';
	switch (DOCTYPESYSNAME){
		case 'mortgageMiniApp':
		case 'mortgageLoanApp':
			GROUPBRIEFNAME = 'mortgageProductGroups';
			break;
		case 'autoLoanApp':
		case 'autoMiniApp':
			GROUPBRIEFNAME = 'autoProductGroups';
			break;
	}

	if (GROUPBRIEFNAME!='') {
		form.dsCall("[corews]", "startprocess", {
			GROUPBRIEFNAME: GROUPBRIEFNAME,
			PROCESSNAME: 'COMMON/bankProductGroupGetListByBrief',
			STARTIMMEDIATLY: true,
			LIGHTPROCESS: true
		}).then(
			function (p) {
				lgr("onAfterchangeBankProductGroup");
				if (form['cbBankProductGroup'])form.cbBankProductGroup.clearItems();
				form.bankProductGroupParams.BankProductGroup_ITEMS = nvl(p['data']['productGroupList'], {});

			})
	}else{
		if (form['cbBankProductGroup'])form.cbBankProductGroup.clearItems();
		delete form.searchParams.bankProductGroupId;
	}
}*/
form.executeCommand = function(message){
	switch(message.event) {
		case 'DOCTYPES':
			form.applicationTypeList=nvl(message.params.applicationTypeList,[]);
			//form.cbDocType.setItems(form.applicationTypeList);
			break;
		default:
			break;
	}
};


form.CHANGE_PERSON = function() {
    function replaceToMask(mask, value){
        if (value == undefined || value == null){
    		return value;
    	}
    	var count = 0;
    	if (mask){
    		var tA = mask.split(" ");
    		for (var i=0;i<tA.length; i++){
    			tA[i] = value.substring(count, count+tA[i].length);
    			count+=tA[i].length;
    		}
    		return tA.join(" ").trim();
    	}
    	return value;
    }
	var sp = form.searchParams;
    /*form.inputParams.SearchParams.CurrentSurname         = form.searchParams.STRING3;
    form.inputParams.SearchParams.CurrentName            = form.searchParams.STRING4;
    form.inputParams.SearchParams.CurrentPatronymicName  = form.searchParams.STRING5;
    form.inputParams.SearchParams.BirthDay               = form.searchParams.PERSONBIRTHDAY;*/
    form.inputParams.SearchParams.CurrentSurname         = sp.PERSONLASTNAME;
    form.inputParams.SearchParams.CurrentName            = sp.PERSONFIRSTNAME;
    form.inputParams.SearchParams.CurrentPatronymicName  = sp.PERSONMIDDLENAME;
    form.inputParams.SearchParams.BirthDay               = sp.PERSONBIRTHDAY;

	//form.inputParams.SearchParams.clientDocSeries        = sp.PERSONDOCSERIES;
	//form.inputParams.SearchParams.clientDocNumber        = sp.PERSONDOCNUMBER;
	form.command({
        event:'CHANGE_PERSON',
       	params: form.inputParams.SearchParams
    });
};

form.onShow=function(){
    form.command({event:'DOCTYPES'});
};