/*DSMETA version = "5.11.01-HF011-25050501" hash = "297947136890eac65ce2391ed00ce6f1b0ffcda5"*/
/* global form */

function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
service = registerMethod(service);

var convertDate = service.convertDate;
var getTableContent = service.getTableContent;
var gRB = service.gRB;
var nvl = service.nvl;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);

form.isFormEditMode = form.inputParams.EDITMODE || false;

var inputParams = form.inputParams;
var outputParams = form.outputParams;

form.formParams = inputParams.formParams;
outputParams.formParams = form.formParams;

form.person = {};
form.personDocMask = {
    number: form.person.IdentityCardNumberMask || undefined
};

form.formParams = inputParams.formParams || {};
outputParams.formParams = form.formParams;

form.formParams.clientInAppMap = inputParams.formParams.clientInAppMap || {};
outputParams.formParams.clientInAppMap = form.formParams.clientInAppMap;
form.formParams.clientInAppMap.clientAge = "";

if(form.formParams.clientInAppMap.clientIsResident == undefined) {
    form.formParams.clientInAppMap.clientIsResident = form.formParams.clientCitizenshipCodeFlag ? true : false;
}

form.contactTableList = form.formParams.clientInAppMap.contactTableList || [];
form.addressTableList = form.formParams.clientInAppMap.addressTableList || [];
form.docTypeNewList = form.inputParams.docTypeNewList || [];
form.deleteContactList = form.formParams.clientInAppMap.contactToDeleteList || [];
form.deleteAddressList = form.formParams.clientInAppMap.addressToDeleteList || [];

form.templateData={
    templateKind:"small" ,
    address:{},
    addressText:"",
}

form.onShow = function () {
    form.getAge();
    service.wizFormNavigatorCommand({
       context: form,
       event: 'CURPAGE_MSG'
    });
    form.checkClientContactInfo('show');
    form.checkClientAddress('show');
    form.tblClientAddressObj.setItems(form.formParams.clientInAppMap.addressTableList || []);

    var contactTableList = form.formParams.clientInAppMap.contactTableList || [];
    var contactTypeList  = form.inputParams.contactTypeList || [];
    var contactTypeMap   = {};
    for (var i = 0; i < contactTypeList.length; i++) {
        var contactType = contactTypeList[i];
        contactTypeMap[contactType.ContactTypeBrief] = contactType.ContactTypeMaskCode + contactType.ContactTypeMaskNumber;
    }
    for (var i = 0; i < contactTableList.length; i++) {
        var contactType = contactTableList[i].contactType;
        if (contactTypeMap[contactType] != undefined) {
            contactTableList[i].contactText = service.setMask(contactTableList[i].contactValue, contactTypeMap[contactType], true);
        }
    }
    form.tblClientContactObj.setItems(contactTableList);

    var searchParamsFlag =  form.formParams.searchParamsFlag;
    if(searchParamsFlag == true) {
        setTimeout(function() { form.addRowDefault() }, 10);
    }

    //Правки по задаче 2377305	RM#11312 The mask of National ID was not applied when users went back to edit
    if (form.isFormEditMode && form.formParams.clientInAppMap.clientMainDocTypeName) {
        form.onChangeDocType(form.formParams.clientInAppMap.clientMainDocTypeName, true);
    }
    //---------------------------------------------
    if (!form.isFormEditMode) {
        if (form.btnNext) {
            form.btnNext.setFocus();
        }
        else if (form.btnSave) {
            form.btnSave.setFocus();
        }
        else {
            form.btnCancel.setFocus();
        }
    }
};

form.getMapFromList = function (list, key, val) {
    for (var i = 0; i < list.length; i++) {
        if (list[i][key] + '' === val + '') {
            return list[i];
        }
    }
};

form.setDocMasks = function (docTypeSysName, docTypeList, maskObj) {
    var docType = undefined;
    if (!docTypeSysName || !(docType = form.getMapFromList(docTypeList, 'IdentityCardTypeBrief', docTypeSysName))) {
        maskObj.number = undefined;
        return;
    }
    maskObj.number = docType.NumberMask;
    return maskObj;
};

form.onChangeDocType = function (value, checkFlag) {
    form.personMaskObj = form.setDocMasks(value, form.inputParams.docTypeNewList, form.personDocMask);
    if (!checkFlag) {
        return;
    }
    var baseIdentityCardFlagTemp = false;
    if (form.formParams.clientInAppMap.clientMainDocTypeName && form.formParams.clientInAppMap.clientMainDocTypeName.toLowerCase() == "nationalid") {
        baseIdentityCardFlagTemp = true;
   }
    form.formParams.clientInAppMap.BaseIdentityCardFlag = baseIdentityCardFlagTemp;
};

form.addRowDefault = function() {
    var searchParams =  form.formParams.searchParams;
        if(searchParams != undefined) {
        var SearchingStrategy = searchParams["SearchingStrategy"];
        if(SearchingStrategy!=undefined) {
            if(SearchingStrategy == 'By phone number') {
                form.tblClientContactObj.addNewRow();
            }
        } else {
             //If action PROCESS_RIGHT_LIST search
             form.tblClientContactObj.addNewRow();
        }
        setTimeout(function() { form.setDefaultParams() }, 10);
    }
};

form.setDefaultParams = function() {
    var searchParams =  form.formParams.searchParams;
     if(searchParams != undefined) {
         //If action PROCESS_RIGHT_LIST search
         //Document Type
         var IdentityCardTypeBrief = searchParams["IdentityCardTypeBrief"];
         form.cmbDocumentType.setValue(IdentityCardTypeBrief);

         //Main Document
         if(IdentityCardTypeBrief.toLowerCase() == 'nationalid') {
             form.formParams.BaseIdentityCardFlag = true;
         }
         //Document Number
         var IdentityCardNumber = searchParams["IdentityCardNumber"];
         form.edDocumentNumber.setValue(IdentityCardNumber);

         //Phone Number
         var ContactValue = searchParams["ContactValue"];
         form.contactValue.setValue(ContactValue);
         //Customer Name
         var CurrentName = searchParams["CurrentName"];
         //Date of Birth
         var BirthDay = searchParams["BirthDay"];

         form.formParams.clientFirstName = CurrentName;
         form.formParams.clientBirthDate = BirthDay;
    }
};

form.settings = {
    cmSex_items: [{
        value: 'Male',
        text: gRB('Male')
    }, {
        value: 'Female',
        text: gRB('Female')
    }
    ],
    marriageStatusParams : {
        ReferenceGroupName: 'Unsecured Loan Application',
        ReferenceSysName: 'marriageStatusBorrowerConsLOS',
        ORDERBY: 'ReferenceItemID'
    }
};

form.getMinBirthDate = function () {
    var now = new Date();
    return service.convertDate(new Date(now.setFullYear(now.getFullYear() - 18)));
};

form.getAge = function () {
    var bDate = (form.formParams.clientInAppMap.clientBirthDate) ? service.convertDate(form.formParams.clientInAppMap.clientBirthDate) : '';
    if (bDate) {
        form.formParams.clientInAppMap.clientAge = parseInt(service.diffDate(bDate, form.curDate, 'year'));
    }else{
        form.formParams.clientInAppMap.clientAge = undefined;
    }
};

if (form.clBirthDate && form.formParams.clientInAppMap.clientAge == null) {
    form.formParams.clientInAppMap.clientAge = parseInt(service.diffDate(convertDate(new Date(form.clBirthDate)), convertDate(new Date()), 'year'));
}

var sendMessage = function (message) {
    var PROCESS_RIGHT_LIST = getInputParams("PROCESS_RIGHT_LIST");
    if (PROCESS_RIGHT_LIST) {
        for (var ar in PROCESS_RIGHT_LIST) {
            form.commandRight(ar, message);
        }
    }
};

form.curDate = service.convertDate(new Date());


form.action = function (tag) {
    outputParams.TRANSTYPE = tag;
    if (form.inputParams.EDITMODE) {
        var diff = (form.clIssueDate && form.clExpiryDate) ? utils.diffDate(service.convertDate(form.clIssueDate.getValue()), service.convertDate(form.clExpiryDate.getValue()), 'day') : 0;
        outputParams.formParams.clientInAppMap.clientAdditionalDocsTable = [{
            documentType : (form.cmbDocumentType) ? form.cmbDocumentType.getValue() : "",
            documentTypeName : (form.cmbDocumentType) ? form.cmbDocumentType.getText() : "",
            documentNumber : form.formParams.clientInAppMap.clientMainDocNumber,
            documentIssuedBy : form.formParams.clientInAppMap.clientMainDocIssuedBy,
            documentIssueDate : form.formParams.clientInAppMap.clientMainDocIssueDate,
            documentExpirationDate : form.formParams.clientInAppMap.documentExpirationDate,
            BaseIdentityCardFlag : true,
            ActiveFlag : !(diff <= -1)
        }];
        outputParams.formParams.clientInAppMap.clientAdditionalDocsTable.push({
            documentType : "FamilyBook ",
            documentTypeName : "Family Book ",
            documentNumber : form.formParams.clientInAppMap.clientFamilyBookDocNumber,
            BaseIdentityCardFlag : false,
            ActiveFlag : true
        });
        if(form["edSocialInsuranceNumber"].getValue()) {
            outputParams.formParams.clientInAppMap.clientAdditionalDocsTable.push({
                documentType : "SocialInsuranceNumber",
                documentTypeName : "Social Insurance Number",
                documentNumber : form.formParams.clientInAppMap.socialInsuranceNumber,
                BaseIdentityCardFlag : false,
                ActiveFlag : true
            });
        } //2381298 - если в заявке не указан параметр Social Insurance Number, то в БД его сохранять не требуется
        outputParams.formParams.clientInAppMap.addressTableList = form.tblClientAddressObj.getItems();
        form.formParams.clientInAppMap.addressTableList.forEach(function(item){
            if(item.addressType == "FactAddress"){
                outputParams.formParams.currentAddress = item;
            }
            if(item.addressType == "CurrentMainWorkingAddress"){
                outputParams.formParams.clientJobFactAddress = item;
            }
        });
        outputParams.formParams.clientInAppMap.contactTableList = form.tblClientContactObj.getItems();
        form.formParams.clientInAppMap.clientCitizenship = (form.cmbCitizenship) ? form.cmbCitizenship.getText() : "";
        form.formParams.clientInAppMap.clientMainDocTypeNameText = (form.cmbDocumentType) ? form.cmbDocumentType.getText() : "";
        if(form.clientFactLiveAddressRegion != undefined) {
             form.formParams.clientInAppMap.clientFactLiveAddressRegion = form.clientFactLiveAddressRegion;
        }
        outputParams.formParams.clientInAppMap.deleteContactList = form.deleteContactList;
        outputParams.formParams.clientInAppMap.deleteAddressList = form.deleteAddressList;

        outputParams.formParams.clientInAppMap.MaritalStatusText = form['cmbMarriageStatus'].getText();
        outputParams.formParams.MaritalStatus = form.formParams.clientInAppMap.MaritalStatus; //need to wizard conditions params
    }
    if (tag === 'CLOSE') {
        if(form.inputParams.EDITMODE === false){
            form.sendForm('GO',false);
        }else {
            form.verifyForm(true, tag);
            service.showDialogCancelConfirm(
                form,
                function () {
                    outputParams.TRANSTYPE = 'SAVEDRAFT';
                    form.sendForm('GO', false);
                }
            )
        }
    } else {

        if (tag === 'NEXT' && !form.verifyForm(true)) {
            return;
        } else {
            form.verifyForm(false);
        }
        form.sendForm('GO', false);
    }
};

form.verifyForm = function (showFlag, tag) {
    var verified = true;
    var buttonNextSave = (form.isLastWizForm) ? "btnSave" : "btnNext";
    if (tag === 'CLOSE') {
        buttonNextSave = "btnCancel";
    }
    try {
        if ((form.validateControlsByIds("pnlMainInformationEdit,pnlMainDocumentInfoEdit,pnlAdditionalDocumentInfoEdit,pnlAddressInfo,pnlClientContact", showFlag === true ? buttonNextSave : undefined).isShowFormErrors)) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    form.outputParams.VERIFIED = verified;
    return verified;
};

form.executeCommand = function(msg){
    if (msg.event === 'FAB_NAVIGATOR_NAVIGATE'){
        outputParams.NEXTPAGE = msg.params.step;
        form.action('DIRECT');
    }
    if (msg.event === 'GO_TO_PAGEFLOW'){
        form.startNewPageFlowProcess(msg.caption, msg.params.PAGEFLOW, {
            APPLICATIONID: msg.params.APPLICATIONID,
            EDITMODE: false
        });
    }
};
/////Адрес
form.tblClientAddressObj = (function (grId) {
    var gridId = grId;
    var options = {
        isFormEditMode: form.inputParams.EDITMODE || false,
        addressTypeResult : form.inputParams.addressTypeResult,
        disableAddressIsSameAsFlag : false,
        templateData:form.templateData,
        addressIsSameAsParams: {
            ReferenceGroupName: 'Unsecured Loan Application',
            ReferenceSysName: 'addressTypeConsLOS',
            ORDERBY: 'ReferenceItemID'
        },
        requiredElements : [
            "addressType",
            "addressBlock",
            "edDurationOfResidence",
            "addressIsSameAs"
        ],
        data: {},
        cancel: function () {
            form[gridId].hideEditor();
            form.btnAddressAdd.enable();
        },
        save: function () {
            var selectedRow = form.tblClientAddress.getSelectedRow()[0];
            if (form.checkDuplicateAddress(options.data.addressType, selectedRow.addressType)) {
                return;
            }
            // Оключена проверка на 0 по задаче в rms #2349247
            /*
            var durationResidence = (form.edDurationOfResidence) ? parseInt(form.edDurationOfResidence.getValue()) : undefined;
            if (form.edDurationOfResidence && durationResidence == 0) {
                form.showErrorDialog(gRB("checkIsNullDurationResidenceErrMsg"), function () {}, [{
                    caption: gRB('dialog.ok')
                }]);
                return;
            }
            */
            var selectedAddressValue = form.addressType.getValue();
            if(selectedAddressValue == "FactAddress") {
                //form.clientFactLiveAddressRegion = form.addressBlock.getValue().Region;
                form.clientFactLiveAddressRegion = form.addressBlock.data.address.Region;
            }

            var newRow = {
                addressType         : form.addressType.getValue(),
                addressTypeText     : form.addressType.getText(),
                addressIsSameAs     : (form.addressIsSameAs.getValue()) ? form.addressIsSameAs.getValue() : '',
                addressIsSameAsText : (form.addressIsSameAs.getText()) ? form.addressIsSameAs.getText() : '',
                blockAddress                : form.addressBlock.data.address,
                addressString               : form.addressBlock.data.address.addressText,
                //blockAddress        : (form.addressIsSameAs.getValue()) ? options.data.blockAddress : form.addressBlock.getValue(),
                //addressString       : (form.addressIsSameAs.getValue()) ? options.data.addressString : form.addressBlock.getText(),
                StayDuration        : (form.edDurationOfResidence) ? parseInt(form.edDurationOfResidence.getValue()) : ''
            };
            angular.extend(newRow, form.addressBlock.data.address);
           // angular.extend(newRow, form.addressBlock.getValue());
           options.clearFields();
            if (selectedRow['id']) {
                newRow['id'] = selectedRow['id'];
                form[gridId].hideEditor();
                form[gridId].updateRow(obj.selectedId, newRow);
                if (selectedRow['addressType'] != 'MailingAddress')
                    form.updateClientAddress(selectedRow);

            } else {
                newRow['id'] = new Date().getTime();
                form[gridId].hideEditor();
                form[gridId].addRow(newRow);
            }
            form.checkClientAddress();
            form.btnAddressAdd.enable();
        },
        clearFields: function () {
            delete options.data.addressType;
            if (form.addressType)
               form.addressType.clearValue();
            delete options.data.addressIsSameAs;
            if(form.addressBlock) {
                        form.addressBlock.data.address={};
                        form.addressBlock.data.addressText="";
                    }
            delete options.data.addressString;
            delete options.data.isSameAddressFlag;
            delete options.data.StayDuration;
        },

        edit: function () {
            form.addAddrMode = 'edit';
            form[gridId].showEditor('edit');
            options.clearFields();
            var selectedRow = form.tblClientAddress.getSelectedRow()[0];
            form.fillComboAddressIsSameAs(selectedRow.addressType);
            form.tblClientAddressObj.options.data = {
                addressType       : selectedRow["addressType"],
                addressIsSameAs   : selectedRow["addressIsSameAs"],
                blockAddress      : selectedRow['blockAddress'],
                StayDuration      : selectedRow['StayDuration'],
                addressString     : selectedRow["addressString"],
                isSameAddressFlag : (nvl(selectedRow["addressIsSameAs"], '') != '')
            };
             form.tblClientAddressObj.options.templateData.address=selectedRow["blockAddress"];
             form.tblClientAddressObj.options.templateData.addressText=selectedRow["addressString"];
            form.checkClientAddress();
            form.btnAddressAdd.disable();
        },
        delete: function () {
            var row = form.tblClientAddress.getSelectedRow()[0];
            if (row) {
                var addressList = getTableContent(form.tblClientAddress);
                var mailingAddressRow = null; //Так как Mailing Address обязан совпадать с каким-то существующим, то мы его должны тоже очищать в случае совпадения
                if (addressList instanceof Object && Object.keys(addressList).length > 1) {
                    for (var i = 0, count = addressList.length; i < count; i++) {
                        var addressIsSameAsCur = nvl(addressList[i].addressIsSameAs, '');
                        if (addressIsSameAsCur.toLowerCase() == row.addressType.toLowerCase()) {
                            if (addressList[i].addressType.toLowerCase() == 'mailingaddress') {
                                mailingAddressRow = i;
                            }
                            addressList[i].addressIsSameAs = null;
                            delete addressList[i].addressIsSameAsText;
                        }
                    }
                    form.tblClientAddressObj.setItems(addressList);
                }
                if (mailingAddressRow) {
                    form.tblClientAddress.deleteRow(addressList[mailingAddressRow].id);
                }
                form.tblClientAddress.deleteRow(obj.selectedId);
                form[gridId].refresh();
                if (mailingAddressRow) {
                    form.deleteAddressList.push(addressList[mailingAddressRow]);
                }
                form.deleteAddressList.push(row);
            }
            form.checkClientAddress();
            form.btnAddressAdd.enable();
        },
        fillAddressIsSameAs : function (item) {
            if (nvl(item.value, '') != '') {
                var addressList = getTableContent(form.tblClientAddress);
                if (addressList instanceof Object && Object.keys(addressList).length > 0) {
                    for (var i = 0, count = addressList.length; i < count; i++) {
                        if (addressList[i].addressType && item.value.toLowerCase() == addressList[i].addressType.toLowerCase()) {
                           // this.data.blockAddress      = addressList[i].blockAddress;
                            this.templateData.address      = addressList[i].blockAddress;
                            this.templateData.address.addressText      = addressList[i].addressString;
                            this.data.addressString     = addressList[i].addressString;
                            this.data.isSameAddressFlag = true;
                            break;
                        }
                    }
                }
            }
            else 
                this.data.isSameAddressFlag = false;
        },
        onChangeAddressType : function (item) {
            var selectedRow = form.tblClientAddress.getSelectedRow()[0];
            form.fillComboAddressIsSameAs(item.addressTypeBrief, selectedRow.addressType);
        }
    };

    var obj = {
        gridId: grId,
        refresh: function () {
            form[gridId].refresh();
        },
        onChangeItems: function () {
        },
        addNewRow: function () {
            form.addAddrMode = 'add';
            form[gridId].showEditor('add');
            options.clearFields();
            form.fillComboAddressIsSameAs();
            form.btnAddressAdd.disable();
        },
        setItems: function (items) {
            form[gridId].setItems(items);
        },
        getItems: function () {
            return form[gridId].getItems();
        },
        onSelectRow: function () {
            options.items = [];
            if (form.isFormEditMode == true) {
                var selRow = form[gridId].getSelectedRow()[0] || {};
                options.items = [
                    {caption: gRB('edit'),   click: form.tblClientAddress.options.edit},
                    {caption: gRB('delete'), click: form.tblClientAddress.options.delete}
                ];
            }
        }
    };
    obj.options = options;
    return obj;
})('tblClientAddress');
/////Контакт
form.tblClientContactObj = (function (grId) {
    var gridId = grId;
    var options = {
        isFormEditMode: form.inputParams.EDITMODE || false,
        addressIsSameAs_ITEMS : [],
        contactTypeComboBoxParams_ITEMS: form.inputParams.contactTypeList || {},
        requiredElements : [
            "contactType",
            "contactValue",
            "contactComment"
        ],
        data: {},
        cancel: function () {
            form[gridId].hideEditor();
            form.btnContactAdd.enable();
        },
        save: function () {
            var selectedRow = form.tblClientContact.getSelectedRow()[0];
            var newRow = {
                contactType     : form.contactType.getValue(),
                contactTypeText : form.contactType.getText(),
                contactValue    : form.contactValue.getValue(),
                contactText     : form.contactValue.getText(),
                contactComment  : form.contactComment.getValue()
            };
            if (selectedRow['id']) {
                newRow['id'] = selectedRow['id'];
                form[gridId].hideEditor();
                form[gridId].updateRow(obj.selectedId, newRow);

            } else {
                newRow['id'] = new Date().getTime();
                form[gridId].hideEditor();
                form[gridId].addRow(newRow);

            }
            form.checkClientContactInfo();
            form.btnContactAdd.enable();
            form.setSearchParamsFlag('By phone number', false);
        },
        clearFields: function () {
            delete options.data.contactType;
            delete options.data.contactValue;
            delete options.data.contactComment;
        },
        edit: function () {
            options.clearFields();

            var selectedRow = form.tblClientContact.getSelectedRow()[0];

            form[gridId].showEditor('edit');
            form.tblClientContactObj.options.data = {
                contactType    : selectedRow["contactType"],
                contactValue   : selectedRow["contactValue"],
                contactComment : selectedRow['contactComment']
            };
            for (var i = 0, count = options.contactTypeComboBoxParams_ITEMS.length; i < count; i++) {
                if (options.data.contactType == options.contactTypeComboBoxParams_ITEMS[i].ContactTypeBrief) {
                    options.onChangeContactType(options.contactTypeComboBoxParams_ITEMS[i]);
                    break;
                }
            }
            form.btnContactAdd.disable();

        },
        delete: function () {
            var row = form.tblClientContact.getSelectedRow()[0];
            if (row) {
                if (form.formParams.selectedNumber == form.tblClientContact.getSelectedRow()[0].contactValue && form.formParams.smsInformingSysName == form.tblClientContact.getSelectedRow()[0].contactType) {
                    form.formParams.smsInformingSysName = "";
                    form.formParams.smsInforming = "";
                    form.formParams.selectedNumber = "";
                }
                if (form.formParams.selectedAddress == form.tblClientContact.getSelectedRow()[0].contactValue && form.formParams.emailInformingSysName == form.tblClientContact.getSelectedRow()[0].contactType) {
                    form.formParams.emailInformingSysName = "";
                    form.formParams.emailInforming = "";
                    form.formParams.selectedAddress = "";
                }
                form.deleteContactList.push(row);
                form.tblClientContact.deleteRow(obj.selectedId);
                form[gridId].refresh();
                form.checkClientContactInfo();
                form.btnContactAdd.enable();
            }
        },

        onChangeContactType : function (item, clearValue) {
            options.emailCheckValueRX = '';
            options.emailFilterRX = '';
            options.numberMask = '';
            if (clearValue) {
                form.contactValue.setValue("")
            }
            if (item && item.ContactTypeBrief != undefined){
                options.numberMask = item.ContactTypeMaskCode+item.ContactTypeMaskNumber;
                if (item.ContactTypeBrief.indexOf("Email") > 0) {
                    options.emailCheckValueRX = '^([a-zA-Z0-9_-]+\\.)*[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\\.[a-zA-Z0-9_-]+)*\\.[a-z]{2,}$';
                    options.emailFilterRX = '[.@a-zA-Z0-9_-]';
                }
            }
        },
        onChangeContactTypeReq: function(items) {
           options.emailCheckValueRX = '';
           options.emailFilterRX = '';
           if(items) {
              items.forEach(function(row) {
                 if(row.ContactTypeBrief === options.data.contactType) options.numberMask = row.ContactTypeMaskCode + row.ContactTypeMaskNumber
              }, this);
           }
        }
	
    };

    var obj = {
        gridId: grId,
        refresh: function () {
            form[gridId].refresh();
        },
        onChangeItems: function () {
        },
        addNewRow: function () {
            form[gridId].showEditor('add');
            options.clearFields();
            options.onChangeContactType(form.tblClientContact.getSelectedRow()[0]['contactType']);
            form.btnContactAdd.disable();
        },
        setItems: function (items) {
            form[gridId].setItems(items);
        },
        getItems: function () {
            return form[gridId].getItems();
        },
        onSelectRow: function () {
            options.items = [];
            if (form.isFormEditMode == true) {
                var selRow = form[gridId].getSelectedRow()[0] || {};
                options.items = [
                    {caption: gRB('edit'),   click: form.tblClientContact.options.edit},
                    {caption: gRB('delete'), click: form.tblClientContact.options.delete}
                ];
            }
        }
    };
    obj.options = options;
    return obj;
})('tblClientContact');

form.addClientContact = function (item) {
    form.tblClientContactObj.options.clearFields();
    form.btnContactAdd.disable();
    form.tblClientContactObj.options.data.contactType = item.ContactTypeBrief;
    form.tblClientContactObj.options.onChangeContactType(item['ContactTypeBrief']);
};

form.addOneAddress = function(item) {
    form.tblClientAddressObj.options.clearFields();
    form.btnAddressAdd.disable();
    form.addAddrMode = 'add';
    form.tblClientAddressObj.options.data.addressType = item.addressTypeBrief;
    form.tblClientAddressObj.options.onChangeAddressType(item);
};

form.fillComboAddressIsSameAs = function (curAddrType, oldAddressType) {
    curAddrType    = nvl(curAddrType, '');
    oldAddressType = nvl(oldAddressType, '');
    form.tblClientAddressObj.options.disableAddressIsSameAsFlag = true;
    form.tblClientAddressObj.options.addressIsSameAs_ITEMS = [];
    var addressList = getTableContent(form.tblClientAddress);
    if (addressList instanceof Object && Object.keys(addressList).length > 0) {
        for (var i = 0, count = addressList.length; i < count; i++) {
            var addressType = addressList[i].addressType;
            if (addressType && curAddrType != addressType && oldAddressType != addressType && addressType != 'MailingAddress')
                form.tblClientAddressObj.options.addressIsSameAs_ITEMS.push({value : addressType, text : gRB("addressCoincidesWith") + " " + addressList[i].addressTypeText.toLowerCase()});
        }
        if (form.addAddrMode == 'edit' && addressList.length == 1)
            form.tblClientAddressObj.options.disableAddressIsSameAsFlag = false;
    }
    else {
        form.tblClientAddressObj.options.disableAddressIsSameAsFlag = false;
    }
};

form.checkDuplicateAddress = function (addressType, oldAddressType) {
    oldAddressType = nvl(oldAddressType, '');
    var addressList = getTableContent(form.tblClientAddress);
    if (addressList instanceof Object && Object.keys(addressList).length > 0) {
        for (var i = 0, count = addressList.length; i < count; i++) {
            if (addressType == addressList[i].addressType && addressType != oldAddressType) {
                form.showErrorDialog(gRB("duplicateAddressErrMsg"), function () {}, [{
                    caption: gRB('dialog.ok')
                }]);
                return true;
            }
        }
    }
    return false;
};
///функция для отмены показа requiredItems для контактов
form.checkClientContactInfo = function(mode) {
    form.clientContactRequiredItems = [];
    var mandatoryContactTypesList = form.formParams.MandatoryContactTypes ? form.formParams.MandatoryContactTypes.split(',') : [];
    var contactTypeRefList = inputParams.contactTypeList || [];
    var contactTableList = (mode == 'show') ? form.contactTableList || [] : getTableContent(form.tblClientContact);
    if (contactTypeRefList && contactTypeRefList.length) {
        for (var i = 0, countI = contactTypeRefList.length; i < countI; i++) {
            var contactTypeRefMap = contactTypeRefList[i];
            var contactTypeMap = form.getMapFromList(contactTableList, "contactType", contactTypeRefMap["ContactTypeBrief"]) || {};
            if (contactTypeMap instanceof Object && Object.keys(contactTypeMap).length == 0) {
                if(mandatoryContactTypesList && mandatoryContactTypesList.length > 0 && mandatoryContactTypesList.indexOf(contactTypeRefMap["ContactTypeBrief"]) != -1) {
                    form.clientContactRequiredItems.push({
                        caption : contactTypeRefMap["ContactTypeName"],
                        ContactTypeBrief : contactTypeRefMap["ContactTypeBrief"]
                    });
                } 
            }
        }
    }
};

form.checkClientAddress = function (mode){
    form.clientAddressRequiredItems = [];
    var mandatoryAddressTypesList = form.formParams.MandatoryAddressTypes ? form.formParams.MandatoryAddressTypes.split(',') : [];
    var addressTypeRefList = inputParams.addressTypeResult || [];
    var addressTableList = (mode == 'show') ? form.addressTableList || [] : getTableContent(form.tblClientAddress);
    if (addressTypeRefList && addressTypeRefList.length) {
        for (var i = 0, countI = addressTypeRefList.length; i < countI; i++) {
            var addressTypeRefMap = addressTypeRefList[i];
            var addressTypeMap = form.getMapFromList(addressTableList, "addressType", addressTypeRefMap["ReferenceItemCode"]) || {};
            if (addressTypeMap instanceof Object && Object.keys(addressTypeMap).length == 0) {
                if(mandatoryAddressTypesList && mandatoryAddressTypesList.length > 0 && mandatoryAddressTypesList.indexOf(addressTypeRefMap["ReferenceItemCode"]) != -1) {
                    form.clientAddressRequiredItems.push({
                        caption : addressTypeRefMap["ReferenceItemBrief"],
                        addressTypeBrief : addressTypeRefMap["ReferenceItemCode"]
                    });
                } 
            }
        }
    }
};

form.updateClientAddress = function (row) {
    if (row) {
        var addressList = getTableContent(form.tblClientAddress);
        if (addressList instanceof Object && Object.keys(addressList).length > 1) {
            form.prepareAddressListForUpdate(addressList, row);
            form.tblClientAddressObj.setItems(addressList);
        }
        form.tblClientAddress.refresh();
    }
};

form.prepareAddressListForUpdate = function (addressList, row) {
    if (addressList instanceof Object && Object.keys(addressList).length > 1) {
        for (var i = 0, count = addressList.length; i < count; i++) {
            var addressIsSameAsCur = nvl(addressList[i].addressIsSameAs, '');
            if (addressIsSameAsCur.toLowerCase() == row.addressType.toLowerCase()) {
                //addressList[i].blockAddress      = form.addressBlock.getValue();
                //addressList[i].addressString     = form.addressBlock.getText();
                addressList[i].blockAddress      =form.addressBlock.data.address;
                addressList[i].addressString     =form.addressBlock.data.address.addressText,
                form.prepareAddressListForUpdate(addressList, addressList[i]);
            }
        }
    }
};

form.setSearchParamsFlag = function (strategy, value) {
    strategy = nvl(strategy, '');
    if (nvl(strategy, '') != '') {
        var searchParams = form.formParams.searchParams;
        if (searchParams != undefined) {
            var SearchingStrategy = searchParams["SearchingStrategy"];
            if (SearchingStrategy == strategy) 
                form.formParams.searchParamsFlag = value;
        }
    }
    else
        form.formParams.searchParamsFlag = value;
};