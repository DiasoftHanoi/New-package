/*DSMETA version = "5.11.01-HF005-24081901" hash = "4cd547598d027700741c8a66fbb72ee9e4c816e8"*/
service.getShortClientName = function(appMap){
    var clientName = appMap["STRING3"];
    if (appMap["STRING4"]){
        clientName+=appMap["STRING4"][0];
    }
    if (appMap["STRING5"]){
        clientName+=appMap["STRING5"][0];
    }
    return clientName;
};