/*DSMETA version = "5.11.01-HF005-24081901" hash = "ed40848bb3836d57a22f62cd054813206f4d6e2a"*/
/* global form */

function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
service = registerMethod(service);

var convertDate = service.convertDate;
var getTableContent = service.getTableContent;
var gRB = service.gRB;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);

form.isFormEditMode = form.inputParams.EDITMODE || false;

var inputParams = form.inputParams;
var outputParams = form.outputParams;

form.formParams = inputParams.formParams || {};
outputParams.formParams = form.formParams;

form.requiredElements = [
    "tblIncome",
    "edCommentFinInfo"
];

form.data = {
    incomeAmountTotal : 0,
    expenseAmountTotal : 0
};

form.onShow = function () {
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });
    /*if(!form.formParams.clientBusinessmanFlag){
        form.pnlRevenue.hide();
    }*/
    // соберем обязательные параметры со всех блоков
    form.requiredElements = form.requiredElements.concat(form.tblIncomeObj.options.requiredElements, form.tblRevenueObj.options.requiredElements, form.tblExpensesObj.options.requiredElements);
    form.checkIncomeInfo('show');
    form.getExpenseAmountTotal('show');
    form.tblIncomeObj.setItems(form.inputParams.incomeList || []);

    if (form.formParams.clientBusinessmanFlag) {
        form.tblRevenueObj.setItems(form.inputParams.revenueList || []);
    }
    form.tblExpensesObj.setItems(form.inputParams.expenseList || []);
    form.tblIncome.setSelectedRow(undefined);

};

var sendMessage = function (message) {
    var PROCESS_RIGHT_LIST = getInputParams("PROCESS_RIGHT_LIST");
    if (PROCESS_RIGHT_LIST) {
        for (var ar in PROCESS_RIGHT_LIST) {
            form.commandRight(ar, message);
        }
    }
};

form.curDate = service.convertDate(new Date());

form.yesFunc = function() {
    form.outputParams.TRANSTYPE = 'SAVEDRAFT';
    form.sendForm('GO', false);
};

form.action = function (tag) {
    outputParams.TRANSTYPE = tag;
    if ((form.inputParams.EDITMODE == true) || (form.inputParams.EDITMODE == 'true'))  {
       outputParams.incomeList  = form.tblIncomeObj.getItems();
       outputParams.revenueList = (form.formParams.clientBusinessmanFlag) ? form.tblRevenueObj.getItems() : [];
       outputParams.expenseList = form.tblExpensesObj.getItems();
       outputParams.formParams.totalIncome = form.data.incomeAmountTotal;
        outputParams.formParams.totalExpense = form.data.expenseAmountTotal;
    }
    

    if (tag === 'CLOSE' && form.isFormEditMode) {
        form.verifyForm(true, tag);
        service.showDialogCancelConfirm(
            form,
            form.yesFunc
        )
    }
    else {
        if (tag === 'NEXT' && !form.verifyForm(true)) {
            return;
        } else {
            form.verifyForm(false);
        }
        form.sendForm('GO', false);
    }
};

form.verifyForm = function (showFlag, tag) {
    var verified = true;
    var buttonNextSave = (form.isLastWizForm) ? "btnSave" : "btnNext";
    if (tag === 'CLOSE') {
        buttonNextSave = "btnCancel";
    }
    try {
        if ((form.validateControlsByIds(form.requiredElements.join(','), showFlag === true ? buttonNextSave : undefined).isShowFormErrors)) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    form.outputParams.VERIFIED = verified;
    return verified;
};

form.executeCommand = function (message) {
    if (message.event == "FAB_NAVIGATOR_NAVIGATE") {
        form.outputParams.NEXTPAGE = message.params.step;
        form.action("DIRECT");
    }
};

/////////////////////////////////////////////////////////////////////////////////////
form.getMapFromList = function (list, key, val) {
    for (var i = 0; i < list.length; i++) {
        if (list[i][key] + '' === val + '') {
            return list[i];
        }
    }
    return "";
};

form.templateData={
    templateKind:"small" ,
    address:{},
    addressText:"",    
}

////Incomes
form.tblIncomeObj = (function (grId) {
    var gridId = grId;
    var options = {
        templateData:form.templateData,
        clientBusinessmanFlag: form.formParams.clientBusinessmanFlag,
        creditCurrencySysName: form.formParams.creditCurrencySysName,
        employment_ITEMS: form.inputParams.employmentITEMS,
        asset_ITEMS: form.inputParams.assetsITEMS,
        incomeTypeTypeComboBoxParams: {
            ReferenceSysName: 'incomeTypeLOS',
            ORDERBY: 'ReferenceItemID'
        },
        methodPaymentComboBoxParams: {
            ReferenceSysName: 'methodOfPaymentLOS',
            ReferenceItemName: form.formParams.TYPESYSNAME,
            ORDERBY: 'ReferenceItemID'
        },
        data : {
            assets_ITEMS : [],
            employmentList_ITEMS : []
        },
        requiredElements : [
            'cmbIncomeType',
            'cmbEmployment',
            'cmbMethodPayment',
            'edMonthlySalary',
            'edOtherValue',
            'edTotalIncome',
            'edIncomeAmount',
            'edOtherValueDescription',
            'edIncomeTypeOther',
            'cmbAsset',
            'edDetailsIncome',
            'edMethodPaymentOther',
            'edMonthlyAllowance',
            'edOtherValue',
            'edOtherValueDescription',
            'edFullNameRenter',
            'edDocumentType',
            'edNumber',
            'edDetailLendingContract'
        ],
        cancel: function () {
            options.clearFields();
            form[gridId].hideEditor();
            form.btnIncomeAdd.enable();
        },
        save: function () {
            var selectedRow = form.tblIncome.getSelectedRow()[0];
            var newRow = {
                incomeType              : options.incomeType,
                incomeTypeBrief         : form.cmbIncomeType ? form.cmbIncomeType.getText() : undefined,
                incomeTypeOther         : options.incomeTypeOther,
                methodOfPayment         : options.methodOfPayment,
                methodOfPaymentBrief    : form.cmbMethodPayment ? form.cmbMethodPayment.getText() : undefined,
                methodOfPaymentOther    : options.methodOfPaymentOther,
                incomeAmount            : options.incomeAmount,
                detailOfIncome          : options.detailOfIncome
            };
            var incomeType = options.incomeType.toLowerCase();
            if (incomeType == 'rent') {
                newRow["LinkID"]                 = options.Asset;
                newRow["Asset"]                  = options.Asset;
                newRow["AssetBrief"]             = form.cmbAsset ? form.cmbAsset.getText() : undefined;
                newRow["typeAssets"]             = form.cmbAsset ? (form.cmbAsset.getText() ?
                                                                     form.cmbAsset.getText().substring(0, form.cmbAsset.getText().search(',')) 
                                                                     : undefined)
                                                                 : undefined;
                newRow["detailLendingContract"]  = options.detailLendingContract;
                newRow["fullNameOfRenter"]       = options.fullNameOfRenter;
                newRow["adbAddressRenter"]       = form.adbAddressRenter ? form.adbAddressRenter.data.address : {};
                newRow["adbAddressRenterString"] = form.adbAddressRenter ? form.adbAddressRenter.data.address.addressText : "";
                newRow["documentType"]           = options.documentType;
                newRow["number"]                 = options.number;
                newRow["phoneNumber"]            = options.phoneNumber;
            } else if (incomeType == 'salary') {
                newRow["LinkID"]                = options.employment || selectedRow["LinkID"] || new Date().getTime();
                newRow["employment"]            = options.employment;
                newRow["employmentBrief"]       = form.cmbEmployment ? form.cmbEmployment.getText() : undefined;
                newRow["monthlySalary"]         = options.monthlySalary;
                newRow["monthlyAllowance"]      = options.monthlyAllowance;
                newRow["otherValue"]            = options.otherValue;
                newRow["otherValueDescription"] = options.otherValueDescription;
            }
            options.clearFields();
            if (selectedRow["LinkID"]) {
                if (incomeType == 'other') {
                    if (incomeType == selectedRow["incomeType"])
                        newRow["LinkID"] = selectedRow["LinkID"];
                    else
                        newRow["LinkID"] = new Date().getTime();
                }    
                form[gridId].hideEditor();
                form[gridId].updateRow(obj.selectedId, newRow);
            }
            else {
                if (incomeType == 'other')
                    newRow["LinkID"] = new Date().getTime();
                form[gridId].hideEditor();
                form[gridId].addRow(newRow);
            }
            form.checkIncomeInfo();
            form.btnIncomeAdd.enable();
        },
        clearFields: function () {
            options.incomeType = null;
            options.incomeTypeOther = null;
            options.employment = null;
            options.Asset = null;
            options.methodOfPayment = null;
            options.methodOfPaymentOther = null;
            options.monthlySalary = null;
            options.monthlyAllowance = null;
            options.otherValue = null;
            options.incomeAmount = null;
            options.otherValueDescription = null;
            options.detailLendingContract = null;
            options.fullNameOfRenter = null;
            options.documentType = null;
            if(form.adbAddressRenter) {
                form.adbAddressRenter.data.address={};
                form.adbAddressRenter.data.addressText="";
            }
            options.number = null;
            options.phoneNumber = null;
            options.detailOfIncome = null;
            if (form.cmbAsset) {   // не работает очистка items через двунаправленную связь, только напрямую, с исправлением в платформе убрать этот код
                form.cmbAsset.clearItems();
                form.cmbAsset.value = null;
            }
            if (form.cmbEmployment) {
                form.cmbEmployment.clearItems();
                form.cmbEmployment.value = null;
            }
        },
        edit: function () {
            var selectedRow = form.tblIncome.getSelectedRow()[0];
            form[gridId].showEditor('edit');
            options.incomeType            = selectedRow['incomeType'];
            options.incomeTypeOther       = selectedRow['incomeTypeOther'];
            options.employment            = selectedRow['employment'];
            options.Asset                 = selectedRow['Asset'];
            options.methodOfPayment       = selectedRow['methodOfPayment'];
            options.methodOfPaymentOther  = selectedRow['methodOfPaymentOther'];
            options.monthlySalary         = selectedRow['monthlySalary'];
            options.monthlyAllowance      = selectedRow['monthlyAllowance'];
            options.otherValue            = selectedRow['otherValue'];
            options.incomeAmount          = selectedRow['incomeAmount'];
            options.otherValueDescription = selectedRow['otherValueDescription'];
            options.detailLendingContract = selectedRow['detailLendingContract'];
            options.fullNameOfRenter      = selectedRow['fullNameOfRenter'];
            options.documentType          = selectedRow['documentType'];
            options.number                = selectedRow['number'];
            options.phoneNumber           = selectedRow['phoneNumber'];
            options.detailOfIncome        = selectedRow['detailOfIncome'];
            form.tblIncomeObj.options.templateData.address=selectedRow["adbAddressRenter"];
            form.tblIncomeObj.options.templateData.addressText=selectedRow["adbAddressRenterString"]; 
            options.fillAssetsEmploymentCombo(); // не отрабатывает on-change (value не очищается через двунаправленную связь, только напрямую), с исправлением в платформе убрать этот код
            form.btnIncomeAdd.disable();
        },
        delete: function () {
            if (form.tblIncome.getSelectedRow()[0]) {
                form.tblIncome.deleteRow(obj.selectedId);
                form[gridId].refresh();
            }
            form.checkIncomeInfo();
            form.btnIncomeAdd.enable();
        },
        foldAmountIncome: function () {
            options.incomeAmount = parseFloat(options.monthlySalary || 0) + parseFloat(options.monthlyAllowance || 0) + parseFloat(options.otherValue || 0);
        },
        view: function () {
            var financialInfoParam = {
                formParams : form.tblIncome.getSelectedRow()[0],
                PAGEHEADER : "${viewFinInfo}"
            };
            financialInfoParam.formParams["creditCurrencySysName"] = form.formParams.creditCurrencySysName;
            form.startModalPageFlowProcess(form.getCurrentProjectSysname() + "/FORMLIB/inputApplication/financialInfo/clientFinancialInfoView", financialInfoParam).then(function (response) {
            });
        },
        fillAssetsEmploymentCombo: function () {
            form.tblIncomeObj.options.data.assets_ITEMS = [];
            form.tblIncomeObj.options.data.employment_ITEMS = [];
            var assetsList = inputParams.assetsList || [];
            var employmentList = inputParams.employmentList || [];
            var incomeList = form.tblIncomeObj.getItems();
            var assetsListTemp_ITEMS = [];
            var employmentListTemp_ITEMS = [];
            var selRow = form.tblIncome.getSelectedRow();
            var diffLinkID, incomeLinkID, selRowLinkID;
            if (options.incomeType && options.incomeType != undefined && options.incomeType.toLowerCase() == 'rent') {
                if (assetsList instanceof Object && Object.keys(assetsList).length > 0) {
                    for (var i = 0, countI = assetsList.length; i < countI; i++) {
                        var assetsMap = assetsList[i];
                        diffLinkID = true;
                        var assetLinkID = "" + assetsMap.LinkID;
                        incomeLinkID = form.getMapFromList(incomeList, "LinkID", assetLinkID);
                        selRowLinkID = form.getMapFromList(selRow, "LinkID", assetLinkID);
                        if (incomeLinkID) {
                            diffLinkID = false;
                            if (selRowLinkID && selRow[0].LinkID) {
                                diffLinkID = true;
                            }
                        }
                        var assetTemp = assetsMap.typeAssets;
                        if (assetsMap.sysnameTypeAssets && assetsMap.sysnameTypeAssets != undefined && assetsMap.sysnameTypeAssets.toLowerCase() == "realestate" && diffLinkID && assetsMap.cbNewObject!="true") {
                            assetTemp += (assetsMap.addressString) ? ", " + assetsMap.addressString : "";
                            assetsListTemp_ITEMS.push({value: assetsMap.LinkID, text: assetTemp});
                        } else if (assetsMap.sysnameTypeAssets && assetsMap.sysnameTypeAssets != undefined && assetsMap.sysnameTypeAssets.toLowerCase() == "vehicle" && diffLinkID && assetsMap.cbNewObject!="true") {
                            assetTemp += (assetsMap.brandCar) ? ", " + assetsMap.brandCar : "";
                            assetTemp += (assetsMap.noChassis) ? ", " + assetsMap.noChassis : "";
                            assetTemp += (assetsMap.engineNumber) ? ", " + assetsMap.engineNumber : "";
                            assetsListTemp_ITEMS.push({value: assetsMap.LinkID, text: assetTemp});
                        }
                    }
                    if (!assetsListTemp_ITEMS.length) {
                        options.Asset = null;
                    }
                }
            }
            if (options.incomeType && options.incomeType != undefined && options.incomeType.toLowerCase() == 'salary') {
                if (employmentList instanceof Object && Object.keys(employmentList).length > 0) {
                    for (var k = 0, countK = employmentList.length; k < countK; k++) {
                        var employmentMap = employmentList[k];
                        diffLinkID = true;
                        var employmentLinkID = "" + employmentMap.LinkID;
                        incomeLinkID = form.getMapFromList(incomeList, "LinkID", employmentLinkID);
                        selRowLinkID = form.getMapFromList(selRow, "LinkID", employmentLinkID);
                        if (incomeLinkID) {
                            diffLinkID = false;
                            if (selRowLinkID && selRow[0].LinkID) {
                                diffLinkID = true;
                            }
                        }
                        var employmentTemp = employmentMap.employmentType + ", " + employmentMap.ExternalEmployerBrief;
                        if (diffLinkID) {
                            employmentListTemp_ITEMS.push({value: employmentMap.LinkID, text: employmentTemp});
                        }
                    }
                    if (!employmentListTemp_ITEMS.length) {
                        options.employment = null;
                    }
                }
            }
            form.tblIncomeObj.options.data.assets_ITEMS = assetsListTemp_ITEMS;
            form.tblIncomeObj.options.data.employment_ITEMS = employmentListTemp_ITEMS;

        }
    };
    var obj = {
        gridId: grId,
        refresh: function () {
            form[gridId].refresh();
        },
        onChangeItems: function () {
        },
        addNewRow: function () {
            form[gridId].showEditor('add');
            form.btnIncomeAdd.disable();
        },
        setItems: function (items) {
            form[gridId].setItems(items);
        },
        getItems: function () {
            return form[gridId].getItems();
        },
        onSelectRow: function () {
            options.items = [];
            var selectedRow = form.tblIncome.getSelectedRow()[0];
            if (form.isFormEditMode == true) {
                options.items = [
                    {caption: gRB('edit'), click: form.tblIncome.options.edit},
                    {caption: gRB('delete'), click: form.tblIncome.options.delete}
                ];
            }
            else {
                options.items = [
                    {caption: gRB('view'), click: form.tblIncome.options.view}
                ];
            }
        }
    };
    obj.options = options;
    return obj;
})('tblIncome');

/////Revenue
form.tblRevenueObj = (function (grId) {
    var gridId = grId;
    var options = {
        creditCurrencySysName: form.formParams.creditCurrencySysName,
        requiredElements : [
            "edDescriptionRevenue",
            "edRevenue",
            "edProfit",
            "edAverageIncome",
            "edWeightCapital"
        ],
        cancel: function () {
            form[gridId].hideEditor();
            form.btnRevenueAdd.enable();
        },
        save: function () {
            var selectedRow = form.tblRevenue.getSelectedRow()[0];
            var newRow = {
                descriptionOfRevenue : form.edDescriptionRevenue.getValue(),
                revenue              : form.edRevenue.getValue(),
                profit               : form.edProfit.getValue(),
                weightOfCapital      : form.edWeightCapital.getValue(),
                averageIncome        : form.edAverageIncome.getValue()
            };
            if (selectedRow['id']) {
                newRow['id'] = selectedRow['id'];
                form[gridId].hideEditor();
                form[gridId].updateRow(obj.selectedId, newRow);
            }
            else {
                newRow['id'] = new Date().getTime();
                form[gridId].hideEditor();
                form[gridId].addRow(newRow);
            }
            form.btnRevenueAdd.enable();
        },
        clearFields: function () {
            delete options.descriptionOfRevenue;
            delete options.revenue;
            delete options.profit;
            delete options.weightOfCapital;
            delete options.averageIncome;
        },
        edit: function () {
            form[gridId].showEditor('edit');
            options.clearFields();
            var selectedRow = form.tblRevenue.getSelectedRow()[0];
            options.descriptionOfRevenue = selectedRow["descriptionOfRevenue"];
            options.revenue              = selectedRow["revenue"];
            options.profit               = selectedRow['profit'];
            options.weightOfCapital      = selectedRow['weightOfCapital'];
            options.averageIncome        = selectedRow['averageIncome'];
            form.btnRevenueAdd.disable();
        },
        delete: function () {
            if (form.tblRevenue.getSelectedRow()[0]) {
                form.tblRevenue.deleteRow(obj.selectedId);
                form[gridId].refresh();
            }
            form.btnRevenueAdd.enable();
        },
        view: function () {
            var financialInfoParam = {
                formParams : form.tblRevenue.getSelectedRow()[0],
                PAGEHEADER : "${viewFinInfo}"
            };
            financialInfoParam.formParams["creditCurrencySysName"] = form.formParams.creditCurrencySysName;
            form.startModalPageFlowProcess(form.getCurrentProjectSysname() + "/FORMLIB/inputApplication/financialInfo/clientFinancialInfoView", financialInfoParam).then(function (response) {
            });
        }
    };
    var obj = {
        gridId: grId,
        revenuePanelIsCollapsed: !inputParams.revenueList || inputParams.revenueList.length == 0,
        refresh: function () {
            form[gridId].refresh();
        },
        onChangeItems: function () {
        },
        addNewRow: function () {
            obj.revenuePanelIsCollapsed = false;
            form[gridId].showEditor('add');
            options.clearFields();
            form.btnRevenueAdd.disable();
        },
        setItems: function (items) {
            form[gridId].setItems(items);
        },
        getItems: function () {
            return form[gridId].getItems();
        },
        onSelectRow: function () {
            options.items = [];
            var selectedRow = form.tblRevenue.getSelectedRow()[0];
            if (form.isFormEditMode == true) {
                options.items = [
                    {caption: gRB('edit'), click: form.tblRevenue.options.edit},
                    {caption: gRB('delete'), click: form.tblRevenue.options.delete}
                ];
            }
            else {
                options.items = [
                    {caption: gRB('view'), click: form.tblRevenue.options.view}
                ];
            }
        }
    };
    obj.options = options;
    return obj;
})('tblRevenue');

/////Expenses
form.tblExpensesObj = (function (grId) {
    var gridId = grId;
    var options = {
        creditCurrencySysName: form.formParams.creditCurrencySysName,
        requiredElements : [
            "cmbExpenseType",
            "edAverageIncome",
            "edValueExpense",
            "edDetailExpense"
        ],
        expenseTypeComboBoxParams: {
            ReferenceSysName: 'expenseTypeLOS',
            ORDERBY: 'ReferenceItemID'
        },
        data: {},
        cancel: function () {
            form[gridId].hideEditor();
            form.btnExpensesAdd.enable();
        },
        save: function () {
            var selectedRow = form.tblExpenses.getSelectedRow()[0];
            var newRow = {
                expenseType      : form.cmbExpenseType.getValue(),
                expenseTypeBrief : form.cmbExpenseType.getText(),
                value            : form.edValueExpense.getValue(),
                detailOfExpense  : form.edDetailExpense.getValue()
            };
            if (selectedRow['LinkID']) {
                newRow['LinkID'] = selectedRow['LinkID'];
                form[gridId].hideEditor();
                form[gridId].updateRow(obj.selectedId, newRow);
            }
            else {
                newRow['LinkID'] = new Date().getTime();
                form[gridId].hideEditor();
                form[gridId].addRow(newRow);
            }
            form.btnExpensesAdd.enable();
            form.getExpenseAmountTotal();
        },
        clearFields: function () {
            delete options.expenseType;
            delete options.expenseTypeBrief;
            delete options.value;
            delete options.detailOfExpense;
        },
        edit: function () {
            form[gridId].showEditor('edit');
            options.clearFields();
            var selectedRow = form.tblExpenses.getSelectedRow()[0];
            options.expenseType     = selectedRow["expenseType"];
            options.value           = selectedRow["value"];
            options.detailOfExpense = selectedRow['detailOfExpense'];
            form.btnExpensesAdd.disable();
        },
        delete: function () {
            if (form.tblExpenses.getSelectedRow()[0]) {
                form.tblExpenses.deleteRow(obj.selectedId);
                form[gridId].refresh();
            }
            form.btnExpensesAdd.enable();
            form.getExpenseAmountTotal();
        },
        view: function () {
            var financialInfoParam = {
                formParams : form.tblExpenses.getSelectedRow()[0],
                PAGEHEADER : "${viewFinInfo}"
            };
            financialInfoParam.formParams["creditCurrencySysName"] = form.formParams.creditCurrencySysName;
            form.startModalPageFlowProcess(form.getCurrentProjectSysname() + "/FORMLIB/inputApplication/financialInfo/clientFinancialInfoView", financialInfoParam).then(function (response) {
            });
        }
    };
    var obj = {
        gridId: grId,
        expenseAmountTotal : 0,
        expensePanelIsCollapsed: !inputParams.expenseList || inputParams.expenseList.length == 0,
        refresh: function () {
            form[gridId].refresh();
        },
        onChangeItems: function () {
        },
        addNewRow: function () {
            obj.expensePanelIsCollapsed = false;
            form[gridId].showEditor('add');
            options.clearFields();
            form.btnExpensesAdd.disable();
        },
        setItems: function (items) {
            form[gridId].setItems(items);
        },
        getItems: function () {
            return form[gridId].getItems();
        },
        onSelectRow: function () {
            options.items = [];
            var selectedRow = form.tblExpenses.getSelectedRow()[0];
            if (form.isFormEditMode == true) {
                options.items = [
                    {caption: gRB('edit'), click: form.tblExpenses.options.edit},
                    {caption: gRB('delete'), click: form.tblExpenses.options.delete}
                ];
            }
            else {
                options.items = [
                    {caption: gRB('view'), click: form.tblExpenses.options.view}
                ];
            }
        }
    };
    obj.options = options;
    return obj;
})('tblExpenses');

///функция для отмены показа requiredItems для контактов
form.checkIncomeInfo = function(mode) {
    if (form.isFormEditMode == true) {
        form.tblIncomeRequiredItems = [
            {
                caption: "${oneIncome}"
            }
        ];
    } else {
        form.tblIncomeRequiredItems = [];
    }
    if (!!form.formParams.unemployed) {
        form.tblIncomeRequiredItems = [];
    }
    var incomeAmountTotal = 0;
    var incomeTableList = (mode == 'show') ? form.inputParams.incomeList || [] : getTableContent(form.tblIncome);
    if (incomeTableList instanceof Object && Object.keys(incomeTableList).length > 0) {
        for (var i = 0, count = incomeTableList.length; i < count; i++) {
            incomeAmountTotal += parseFloat(incomeTableList[i].incomeAmount);
        }
        form.tblIncomeRequiredItems = [];
    }
    form.data.incomeAmountTotal = incomeAmountTotal;
    form.data.creditCurrencySysName = form.formParams.creditCurrencySysName;
};

form.getExpenseAmountTotal = function(mode) {
    var expenseAmountTotal = 0;
    var expenseTableList = (mode == 'show') ? form.inputParams.expenseList || [] : getTableContent(form.tblExpenses);
    if (expenseTableList instanceof Object && Object.keys(expenseTableList).length > 0) {
        for (var i = 0, count = expenseTableList.length; i < count; i++) {
            expenseAmountTotal += parseFloat(expenseTableList[i].value);
        }
    }
    form.data.expenseAmountTotal = expenseAmountTotal;
    form.data.creditCurrencySysName = form.formParams.creditCurrencySysName;
};