var inputParams = template.data.parentForm.inputParams;
var outputParams = template.data.parentForm.outputParams;

template.inputParams = inputParams;
template.formParams = inputParams.formParams;
template.isFormEditMode = inputParams.EDITMODE;
outputParams.formParams = template.formParams;

var employeeRoleSysName = inputParams.employeeRoleSysName;

inputParams.decisionItems=inputParams.decisionItems.reverse();
var mandatoryResponsible = inputParams.mandatoryResponsible ? inputParams.mandatoryResponsible.toUpperCase() : '';
template.isChooseAUser = mandatoryResponsible ==="NO" ? false : true;

template.Responsible = {
    responsibleType: {
        methodParams: JSON.stringify({
            RoleSysName : employeeRoleSysName,
            DepartmentIDList : inputParams.DepartmentIDList
        }),
        lookupFields: [
            {
                value: "USERLOGIN",
                caption: "Login",
                width: 3
            },
            {
                value: "EMPLOYEENAME",
                caption: "Name",
                width: 9
            }
        ]
    }
};

template.onChange = function () {
    template.outputParams.formParams.RefuseReason = template.cbReasonId ? template.cbReasonId.getText() : undefined;
    template.outputParams.formParams.ChooseUser = template.chooseAUserID ? template.chooseAUserID.getText() : undefined;
    template.outputParams.formParams.CURRENTUSERID = template.chooseAUserID ? template.chooseAUserID.getValue() : undefined;
};

