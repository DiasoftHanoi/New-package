template.inputParams = template.data.parentForm.inputParams || {};
template.isFormEditMode = (template.data.parentForm.inputParams.EDITMODE==true || template.data.parentForm.inputParams.EDITMODE=='true') ? 'true' : 'false';
template.bundleName=template.data.bundleName;
template.getRadioGroupText = function(value) {
    var str="fieldCheck."+value;
    return form.getResourceBundle(str);
};

