template.inputParams = template.data.parentForm.inputParams || {};
template.isFormEditMode = (template.data.parentForm.inputParams.EDITMODE==true || template.data.parentForm.inputParams.EDITMODE=='true') ? 'true' : 'false';
template.noRecords = template.data.noRecords || '';
template.tabIndex=template.data.tabIndex;
template.flag=template.data.flag;
template.list=template.data.flag === "RentForOperatingBusiness"? template.inputParams.SelectedRow.rentingFaresSimilarBusiness || [] : template.inputParams.SelectedRow.rentingFaresSimilar || [];
template.onShow = function(){
    template.list = template.flag === "RentForOperatingBusiness"? template.inputParams.SelectedRow.rentingFaresSimilarBusiness || [] : template.inputParams.SelectedRow.rentingFaresSimilar || []
    template.tabRentingFaresSimilarObj.setItems(template.list || []);

}
template.pnlRentingFaresSimilarIsCollapsed=template.list.length>0 ? false :true ;
template.tabRentingFaresSimilarObj = (function (grId) {
    var gridId = grId;
    var options = {
        requiredElements : [
            "edPropertiesDescriptionOfFares",
            "edContactInfo",
            "edPrice"
        ],
        fieldsCaption: {},
        cancelFields: function () {
            template[gridId].hideEditor();
            template.addButtonRentingFaresSimilar.enable();
        },
        saveFields: function () {
            var selectedRow = template.tabRentingFaresSimilar.getSelectedRow()[0];

            var newRow ={
                PropertiesDescriptionOfFares    : template.edPropertiesDescriptionOfFares.getValue(),
                ContactInfo                     : template.edContactInfo.getValue(),
                Price                           : template.edPrice.getValue(),

            };
            if (selectedRow['id']) {
                newRow['id'] = selectedRow['id'];
                template[gridId].hideEditor();
                template[gridId].updateRow(obj.selectedId, newRow);

            } else {
                newRow['id'] = new Date().getTime();
                template[gridId].hideEditor();
                template[gridId].addRow(newRow);
            }
            template.addButtonRentingFaresSimilar.enable();
            if(template.flag==="RentForOperatingBusiness"){
                template.inputParams.SelectedRow.rentingFaresSimilarBusiness=template.tabRentingFaresSimilarObj.getItems();
            }else{
                template.inputParams.SelectedRow.rentingFaresSimilar=template.tabRentingFaresSimilarObj.getItems();
            }
        },
        clearFields: function () {
            if(options.data===undefined){
                options.data={};
            }
            delete options.data.PropertiesDescriptionOfFares;
            delete options.data.ContactInfo;
            delete options.data.Price;
        },
        edit: function () {
            options.clearFields();
            var selectedRow = template.tabRentingFaresSimilar.getSelectedRow()[0];
            template[gridId].showEditor('edit');
            options.data.PropertiesDescriptionOfFares = selectedRow['PropertiesDescriptionOfFares'];
            options.data.ContactInfo                  = selectedRow['ContactInfo'];
            options.data.Price                        = selectedRow['Price'];
            template.addButtonRentingFaresSimilar.disable();
            if(template.flag==="RentForOperatingBusiness"){
                template.inputParams.SelectedRow.rentingFaresSimilarBusiness=template.tabRentingFaresSimilarObj.getItems();
            }else{
                template.inputParams.SelectedRow.rentingFaresSimilar=template.tabRentingFaresSimilarObj.getItems();
            }
        },
        delete: function () {
            if (template.tabRentingFaresSimilar.getSelectedRow()[0]) {
                template.tabRentingFaresSimilar.deleteRow(obj.selectedId);
                template[gridId].refresh();
            }
            template.addButtonRentingFaresSimilar.enable();
            if(template.flag==="RentForOperatingBusiness"){
                template.inputParams.SelectedRow.rentingFaresSimilarBusiness=template.tabRentingFaresSimilarObj.getItems();
            }else{
                template.inputParams.SelectedRow.rentingFaresSimilar=template.tabRentingFaresSimilarObj.getItems();
            }
        }
    };

    var obj = {
        gridId: grId,
        refresh: function () {
            template[gridId].refresh();
        },
        onChangeItems: function () {

        },
        addNewRow: function () {
            template.pnlRentingFaresSimilarIsCollapsed=false;
            template[gridId].showEditor('add');
            options.clearFields();
            template.addButtonRentingFaresSimilar.disable();

        },
        setItems: function (items) {
            template[gridId].setItems(items);
        },
        getItems: function () {
            return template[gridId].getItems();
        },
        onSelectRow: function () {
            options.items = [];
            if (template.isFormEditMode==='true') {
                var selRow = template[gridId].getSelectedRow()[0] || {};
                options.items = [
                    {caption: form.getResourceBundle('edit'), click: template.tabRentingFaresSimilar.options.edit},
                    {caption: form.getResourceBundle('delete'), click: template.tabRentingFaresSimilar.options.delete}
                ];
            }
        }
    };

    obj.options = options;
    return obj;
})('tabRentingFaresSimilar');