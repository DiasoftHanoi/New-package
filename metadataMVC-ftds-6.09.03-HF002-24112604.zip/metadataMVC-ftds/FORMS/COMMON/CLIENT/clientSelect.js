/* global form, moment, service */

//service.form = form;
form.legal = {
    IsKIOFlag: false
};

form.KIOTIN_LIST = [
    {value: false, text: form.getResourceBundle('INN')},
    {value: true, text: form.getResourceBundle('KIO')}
];

form.ShowSelector = service.nvl(form.inputParams.ShowSelector, true);

var nvl = service.nvl;


var getProperty = function (participantType, property) {
    var props = {
        'INN_KIND': {
            '1': 'dfINNP',
            '2': 'dfINNL'
        },
        'PRT_NAME_CAP': {
            '1': form.getResourceBundle('some.FIO'),
            '2': form.getResourceBundle('some.Named')
        }
    };
    return props['' + property]['' + participantType];
};

// Список параметров, доступных для поиска Физиков
var personParamList = [
    {apiName: 'PARTICIPANTTYPE', queryName: 'participantType', javaType: 'java.lang.Integer', skip: 'api'},
    {apiName: 'PARTICIPANTNAME', queryName: 'PRTNAME', javaType: 'java.lang.String'},
    {apiName: 'EXTERNALID', queryName: 'EXTERNALID', javaType: 'java.lang.String'},
    {apiName: 'STATE', queryName: 'STATE', javaType: 'java.lang.String'},
    {apiName: 'DOCTYPESYSNAME', queryName: 'documentList_DOCTYPESYSNAME', javaType: 'java.lang.String'},
    {apiName: 'DOCSERIES', queryName: 'documentList_DOCSERIES', javaType: 'java.lang.String'},
    {apiName: 'DOCNUMBER', queryName: 'documentList_DOCNUMBER', javaType: 'java.lang.String'},
    {apiName: 'INN', queryName: 'INN', javaType: 'java.lang.String'},
    {apiName: 'ISBUSINESSMAN', queryName: 'ISBUSINESSMAN', javaType: 'java.lang.Integer'}
];
// Список параметров, доступных для поиска юриков
var legalParamList = [
    {apiName: 'PARTICIPANTTYPE', queryName: 'participantType', javaType: 'java.lang.Integer', skip: 'api'},
    {apiName: 'PARTICIPANTNAME', queryName: 'PRTNAME', javaType: 'java.lang.String'},
    /*{apiName: 'EXTERNALID', queryName: 'EXTERNALID', javaType: 'java.lang.String'},
     {apiName: 'DOCTYPESYSNAME', queryName: 'documentList_DOCTYPESYSNAME', javaType: 'java.lang.String'},
     {apiName: 'DOCSERIES', queryName: 'documentList_DOCSERIES', javaType: 'java.lang.String'},
     {apiName: 'DOCNUMBER', queryName: 'documentList_DOCNUMBER', javaType: 'java.lang.String'},*/
	{apiName: 'ISCLIENT', queryName: 'ISCLIENT', javaType: 'java.lang.Integer'},
    {apiName: 'STATE', queryName: 'STATE', javaType: 'java.lang.String'},
    {apiName: 'EXTENDED_PartnerType', queryName: 'EXTENDED_PartnerType', javaType: 'java.lang.String'},
    {apiName: 'StringValue', queryName: 'StringValue', javaType: 'java.lang.String'},
    {apiName: 'INN', queryName: 'INN', javaType: 'java.lang.String'},
    {apiName: 'KIO', queryName: 'KIO', javaType: 'java.lang.String'}
];
// Список параметров доступных для поиска Всех типов клиентов
var participantParamList = [
    {apiName: 'PARTICIPANTNAME', queryName: 'PRTNAME', javaType: 'java.lang.String'},
    {apiName: 'EXTERNALID', queryName: 'EXTERNALID', javaType: 'java.lang.String'},
    {apiName: 'STATE', queryName: 'STATE', javaType: 'java.lang.String'}
];

// Подготовка параметров для обычного метода
var createFilterParams = function (paramMap, paramInfolist) {
    var params = {
        putParam: function (key, value) {
            if ([undefined, null, ''].indexOf(value) !== -1) {
                if (this.hasOwnProperty(key)) {
                    delete this[key];
                }
            } else {
                this[key] = value;
            }
        }
    };
    for (var i = 0, N = paramInfolist.length; i < N; i++) {
        var apiParamName = paramInfolist[i]['apiName'];
        if (paramInfolist[i]['skip'] !== 'api') {
            if (apiParamName === 'PARTICIPANTNAME') {
                switch (paramMap.PARTICIPANTTYPE) {
                    case '1' :
                        var FIO = paramMap[apiParamName];
                        var fioArr = (FIO || '').trim().split(/\s+/);
                        if (fioArr[0]) {
                            params.putParam('LASTNAME', fioArr[0]);
                        }
                        if (fioArr[1]) {
                            params.putParam('FIRSTNAME', fioArr[1]);
                        }
                        if (fioArr[2]) {
                            params.putParam('MIDDLENAME', fioArr[2]);
                        }
                        break;
                    case '2' :
                        params.putParam('Name', paramMap[apiParamName]);
                        break;
                    default :
                        params.putParam('BRIEFNAME', paramMap[apiParamName]);
                        params.putParam('PRTNAME', paramMap[apiParamName]);
                        break;
                }
            } else if (apiParamName === 'DOCSERIES') {
                params.putParam('DOCSERIES', form.edSeries.getText());
            } else if (apiParamName === 'DOCSERIES') {
                params.putParam('DOCNUMBER', form.edNumber.getText());
            } else {
                params.putParam(apiParamName, paramMap[apiParamName]);
            }
        }
    }

    //params.DISABLE_CLOB = 'true';
    //params.ISBUSINESSMAN = inputParams.ISBUSINESSMAN;

    delete params.putParam;
    return params;
};

// Подготовка параметров для метода FTSE
var createFtseParams = function (paramMap, paramInfolist) {

    // Функция преобразует шаблон с параметрами {{param}}, подставляя значения из объекта {key: value}
    function build(template, data) {
        var reg = /{{(\w+)}}/g;
        if (!data)
            return template;
        return template.replace(reg, function (str, key) {
            return (key in data) ? data[key] : '';
        });
    }

    var xml = "<?xml version='1.0' encoding='UTF-8'?>" +
            "<BODY version='2.11'>" +
            "{{content}}" +
            "</BODY>";

    var param = "<{{paramName}} type='{{paramType}}'>{{paramValue}}</{{paramName}}>";

    var params = '';

    for (var i = 0, N = paramInfolist.length; i < N; i++) {
        var paramInfoObj = paramInfolist[i];
        if (paramInfoObj['queryName'] && paramInfoObj['skip'] !== 'query') {

            var apiParamName = paramInfoObj['apiName'];
            var queryParamName = paramInfoObj['queryName'];
            var queryParamType = paramInfoObj['javaType'];

            if ([null, undefined, ''].indexOf(paramMap[apiParamName]) !== -1) {
                continue;
            }

            var queryParamValue = undefined;
            switch (queryParamType) {
                case 'java.lang.Integer' :
                    queryParamValue = parseInt(paramMap[apiParamName]);
                    break;
                default :
                    if (apiParamName === 'DOCSERIES') {
                        queryParamValue = '' + form.edSeries.getText();
                    } else if (apiParamName === 'DOCSERIES') {
                        queryParamValue = '' + form.edNumber.getText();
                    } else {
                        queryParamValue = '' + paramMap[apiParamName];
                    }
                    break;
            }

            params += build(param, {
                paramName: queryParamName,
                paramValue: queryParamValue,
                paramType: queryParamType
            });
        }
    }
    return build(xml, {
        content: params
    });
};

// Формирование параметров и метода начитки грида
form.prepareFilter = function (searchParamValMap) {

    var paramMap = searchParamValMap /*|| form.inputParams.searchParamValMap*/;
    var ParticipantType = '' + paramMap.PARTICIPANTTYPE;

    var remoteMethod = form.participantObj.remoteMethod;
    if (form.EnableFtseSearch && inputParams.PARTICIPANTNAME && ''+inputParams.isAppraisalCompany!='true'){
        remoteMethod.filterParams['SearchQuery'] = form.inputParams.PARTICIPANTNAME;
    }
    if (form.inputParams.SearchTemplateSysName){
        remoteMethod.filterParams['SearchTemplateSysName'] = form.inputParams.SearchTemplateSysName;
    }

    switch (ParticipantType) {
        case '1': // Физ. лицо
            if (form.EnableFtseSearch) {
                remoteMethod.method = 'dsPersonBrowseListByQuery';
                remoteMethod.field = 'PersonID';
                remoteMethod.filterParams['AddParams'] = createFtseParams(paramMap, personParamList);
                form.participantResultName = 'Result';
            } else {
                remoteMethod.method = /*'dsPersonBrowseListByParam'*/ 'personGetListByParams';
                remoteMethod.filterParams = createFilterParams(paramMap, personParamList);
                form.participantResultName = 'PersonBrowseList';
            }
            break;
        case '2': // Юр. лицо
            if (form.EnableFtseSearch) {
                remoteMethod.field = 'LegalID';
                remoteMethod.method = 'dsLegalBrowseListByQuery';
                remoteMethod.filterParams['AddParams'] = createFtseParams(paramMap, legalParamList);
            } else {
                remoteMethod.field = 'LegalID';
                remoteMethod.method = 'dsLegalBrowseListByParam' /*'companyGetListByParams'*/;
                remoteMethod.filterParams = createFilterParams(paramMap, legalParamList)
            }
            form.participantResultName = 'Result';
            break;
        default: // Все
            var searchQuery = paramMap['SearchQuery'];
            if (searchQuery) {
                var oneLineMode = true;
                if (form.EnableFtseSearch) {
                    remoteMethod.method = 'dsParticipantBrowseListByQuery';
                    remoteMethod.field = 'ParticipantID';
                    remoteMethod.filterParams['SearchQuery'] = searchQuery;
                    remoteMethod.filterParams['SearchTemplateSysName'] = 'crm_ParticipantFulltextFuzzySearchActual';
                    break;
                }
            }
            if (form.EnableFtseSearch) {
                remoteMethod.field = 'ParticipantID';
                remoteMethod.method = 'dsParticipantBrowseListByQuery';
                remoteMethod.filterParams['AddParams'] = createFtseParams(paramMap, participantParamList);
            } else {
                remoteMethod.field = 'ParticipantID';
                form.participantListParams.method = /*'dsParticipantBrowseListByParam2'*/ 'participantGetListByParams';
                remoteMethod.filterParams = createFilterParams(paramMap, participantParamList);
            }
            form.participantResultName = 'Result';
            break;
    }

    var EndSearchDate = paramMap.EndSearchDate;
    if (form.EnableFtseSearch && !oneLineMode) {
        if (EndSearchDate) {
            remoteMethod.filterParams['SearchTemplateSysName'] = 'crm_ParticipantFuzzySearchHistoryByParam';
            remoteMethod.filterParams['EndSearchDate'] = moment(EndSearchDate).toDate(); // JS-дата
        } else {
            remoteMethod.filterParams['SearchTemplateSysName'] = 'crm_ParticipantFuzzySearchActualByParam';
        }
    }

    remoteMethod.service = 'crmws';
    remoteMethod.filterParams.ROWSCOUNT = 10;
};

// Короткие ссылки
var inputParams = form.inputParams;
var outputParams = form.outputParams;

form.enablePartType = true;
if ([undefined, null, ''].indexOf(inputParams.CLIENTTYPE) === -1) {
    inputParams.PARTICIPANTTYPE = '' + inputParams.CLIENTTYPE;
    form.enablePartType = false;
} else if ([undefined, null, ''].indexOf(inputParams.PARTICIPANTTYPE) === -1) {
    inputParams.PARTICIPANTTYPE = '' + inputParams.PARTICIPANTTYPE;
} else {
    inputParams.PARTICIPANTTYPE = form.PARTTYPE_ITEMS[0].value;
}

if (!inputParams.STATE) {
    inputParams.STATE = 'ACTIVE';
}

// Имя параметра с результатами метода поиска клиентов по умолчанию
form.participantResultName = 'Result';

// Режим поиска
form.EnableFtseSearch = form.inputParams.EnableFtseSearch;

form.participantObj = (function () {
    var legalCols = [
        {
            name: form.EnableFtseSearch ? 'LegalName' : 'Name',
            value: form.EnableFtseSearch ? 'LegalName' : 'Name',
            caption: 'Наименование',
            type: 'text',
            width: 45
        },
        {
            name: form.EnableFtseSearch ? 'ExtCode' : 'EXTERNALID',
            value: form.EnableFtseSearch ? 'ExtCode' : 'EXTERNALID',
            caption: 'Код',
            type: 'text',
            width: 20
        },
        {
            name: 'INN',
            value: 'INN',
            caption: 'ИНН',
            type: 'text',
            width: 15
        },
        {
            name: form.EnableFtseSearch ? 'State' : 'STATENAME',
            value: form.EnableFtseSearch ? 'State' : 'STATENAME',
            caption: 'Состояние',
            type: 'text',
            width: 20
        }
    ];

    var obj = {
        remoteMethod: {
            field: 'LegalID',
            service: 'crmws',
            method: 'personGetListByParams',
            filterParams: {
            }
        },
        cols: [],
        setCols: function (participantType) {
            while (this.cols.length) {
                this.cols.shift();
            }
            var selSols = legalCols;
            for (var i = 0, N = selSols.length; i < N; i++) {
                this.cols.push(selSols[i]);
            }
        },
        refresh : function (){
            form.tbParticipantObj.refresh();
        }
    };

    var options = {
        getFullAddress : function(list){
            var l = list || [];
            var str='';
            for (var i=0;i<l.length;i++){
                var map = l[i];
                if(map['AddressTypeBrief']==='JuridicalAddress' && map['ActiveFlag']==true){
                    str = map['AlterName'];
                    break;
                }
            } 
            return str==='' ? 'Нет адреса': str ;
        },
        getOKVEDCode: function(list){
            var l = list || [];
            var strCode='';
            for (var i=0;i<l.length;i++){
                var map = l[i];
                if(map['CodeTypeBrief']==='OKVEDCODE' && map['ActiveFlag']==true){
                    strCode+= (strCode !=='' ? ', '+map['CodeValueDescription']: map['CodeValueDescription']);
                }
            } 
            return strCode;
        }
    };
    obj.options = options;

    return obj;
})();

// Принициализируем колонки
form.participantObj.setCols(inputParams.PARTICIPANTTYPE);

form.prepareFilter(inputParams);

/*
 *
 */

form.getProperty = getProperty;


form.search = function () {

    if (inputParams.extINN+''=='1') {
        var isLegal = inputParams.isLegal;
        if(form.inputParams.INN && form.inputParams.INN.length == 12){
            inputParams.PARTICIPANTTYPE = '1';
        }else if(form.inputParams.INN && form.inputParams.INN.length == 10 || isLegal){
            inputParams.PARTICIPANTTYPE = '2';
        }
    }
    // Меняем описание колонки
    form.participantObj.setCols(inputParams.PARTICIPANTTYPE);  
    form.prepareFilter(inputParams); 
    form.participantObj.refresh();
};

form.select = function (item) {

    function go(data) {
        if (data) {
            outputParams.PARTICIPANTTYPE = inputParams.PARTICIPANTTYPE;
            outputParams.participantData = data;
            outputParams.BIRTHDATE = data.BIRTHDATE || null;
            form.sendForm('SELECT');
        }
    }
	
	var DISABLE_ATTRIBUTES = ['ADDRESS', 'CONTACT', 'ALTNAME', 'PREVNAME', 'PARTCODE', 'PARTREGDOC', 'PARTDEPLINK', 'AFFILIATEIFNS', 'EXTATTRIBUTE'];

    switch (inputParams.PARTICIPANTTYPE) {
        case '1' :
            var id = form.EnableFtseSearch ? item.PersonID : item.PARTICIPANTID;
            var fName = form.EnableFtseSearch ? [item.SurName, item.Name, item.PatronymicName].join(' ') : item.PERSONFULLNAME;
            var bName = form.EnableFtseSearch ? item.PersonBrief : item.BRIEFNAME;
            outputParams._CLIENT_TYPE = 'PERSON';
            outputParams._CLIENT_ID = id;
            outputParams._CLIENT_NAME = fName;
            outputParams.KEY = id;
            outputParams.VALUE = fName;
            outputParams.DESCRIPTION = bName;
            outputParams.LOOKUP_RESULT = 'OK';

            form.dsCall('[crmws]', 'personGetByIdFull', {PARTICIPANTID: id, ReturnAsHashMap: 'TRUE', DISABLE_ATTRIBUTES: DISABLE_ATTRIBUTES}).then(
                    function (R) {
                        //if (service.checkCode200Error(R.data, form)) {
                        //    return false;
                        //}
                        return form.Q.resolve(R.data);
                    },
                    function (R) {
                        //if (service.checkCode500Error(R.data, form)) {
                        //    return false;
                        //}
                    }).then(go);
            break;
        case '2' :
            var id = form.EnableFtseSearch ? item.LegalID : item.LegalID;
            var fName = form.EnableFtseSearch ? item.LegalName : item.Name;
            var bName = form.EnableFtseSearch ? item.LegalBrief : item.LegalBrief;
            var INN = form.EnableFtseSearch ? item.INN : item.INN;
            var KIO = form.EnableFtseSearch ? item.KIO : item.KIO;
            outputParams._CLIENT_TYPE = 'COMPANY';
            outputParams._CLIENT_ID = id;
            outputParams._CLIENT_NAME = fName;
            outputParams.SELECT_RESULT = 'OK';
            outputParams._CLIENT_INN = INN;
            outputParams._CLIENT_KIO = KIO;
            outputParams.clientCorporateCategory = item.CorporateCategory;
            form.sendForm('SELECT');
            /*form.dsCall('[crmws]', 'companyGetByIdFull', {PARTICIPANTID: id, ReturnAsHashMap: 'TRUE', DISABLE_ATTRIBUTES: DISABLE_ATTRIBUTES}).then(
                    function (R) {
                        //if (service.checkCode200Error(R.data, form)) {
                        //    return false;
                        //}
                        return form.Q.resolve(R.data);
                    },
                    function (R) {
                        //if (service.checkCode500Error(R.data, form)) {
                        //    return false;
                        //}
                    }).then(go);*/

            break;
    }
    outputParams.PARTICIPANTTYPE = inputParams.PARTICIPANTTYPE;
};

form.action = function (tag) {
    if (tag == 'SELECT') {
        var selRows = form.tbParticipantObj.getSelectedRow();
        var selRow = null;
        if (selRows.length > 0) {
            selRow = selRows[0];
        }
        if (selRow != null) {
            form.select(selRow);
        }
    } else if (tag == 'NotRef') {
        outputParams.SELECT_RESULT = tag;
        form.sendForm('SELECT');
    } else{
        form.sendForm('SELECT');
    }    
};

form.delKIO = function(){
    setTimeout(function() {
        if (form.edINN.getValue() && form.edINN.getValue() == '') {
            form.edKIO.setValue(undefined);
        }
    }, 10)
}
form.delINN = function() {
    setTimeout(function() {
        if (form.edKIO.getValue() && form.edKIO.getValue() == '') {
            form.edINN.setValue(undefined);
        }
    }, 10)
}

form.clearINNKIO = function(){
    delete inputParams.INN;
    delete inputParams.KIO;
}



form.checkINNValid = function(val,fieldName){

    var innVal = nvl(inputParams[val],'').trim();
    if (innVal+''!=''){
        if (innVal.length < 10) {
            return form.getResourceBundle('minINNLength')
        }
        if (form[fieldName] && form.inputParams[val] != undefined && form.inputParams[val].length >= 10 && form.inputParams[val].length <= 12 || form.inputParams[val].length < 10) {
            if (form[fieldName].getValue() != null && !service.checkINN(form[fieldName].getValue())) {
                return form.getResourceBundle('invalidINN')
            } else {
                return ''
            }
        }
    } else {
        return ''
    }

};