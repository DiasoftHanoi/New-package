function registerMethod(initService){
	var service={};
	for (var ar in initService){
		if (initService.hasOwnProperty(ar)){
			if (ar.indexOf('Service')>-1 || typeof (initService[ar]) != 'function'){
				service[ar]=initService[ar];
			}else{
				var fn=initService[ar].toString();
				var sIdx=fn.search(/\(/)+1;
				var eIdx=fn.search(/\)\{/);
				var args=fn.substring(sIdx,eIdx)
				eval("service."+ar+"=function("+args+")"+fn.substring(eIdx+1,fn.length));
			}
		}
	}
	return service;
}
service=registerMethod(service);
var lgr=service.lgr;
var getInputParams=service.getInputParams;
var setOutputParams=service.setOutputParams;
var nvl=service.nvl;
var gRBT=service.gRBT;
var gRB=service.gRB;
var getSelectedRow2=service.getSelectedRow2;
var showAlert=service.showAlert;

form.application=nvl(getInputParams('application'),{});
var PROJECT=getInputParams('PROJECT');
form.commonSrc='resource/'+PROJECT+'/TEMPLATES/application/common/'+form.application['DOCTYPESYSNAME']+'.html';

var gRB = service.gRB;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);
form.isFormEditMode = form.inputParams.EDITMODE || false;
form.isFormEditModeMain = form.inputParams.EDITMODE;
var inputParams = form.inputParams;
var outputParams = form.outputParams;
form.formParams = inputParams.formParams || {};
outputParams.formParams = form.formParams;
form.subjectItem={};
form.isAttachedDocsVisible=false;
form.onShow = function () {
	service.wizFormNavigatorCommand({
		context: form,
		event: 'CURPAGE_MSG'
	});
	form.subjectTable.setItems(form.inputParams.subjectList || []);
	if(form.inputParams.subjectList && form.inputParams.subjectList.length>0){
		form.isAttachedDocsVisible=true;
		form.subjectItem=form.inputParams.subjectList[0];
		for (var i=0;i<form.inputParams.subjectList.length;i++){
			var item=form.inputParams.subjectList[i];
			if(parseInt(form.subjectItem["DOCUMENTID"])>=(item["DOCUMENTID"])){
				form.subjectItem=item;
			}
		}
		form.GetAttachedDocs(form.subjectItem);

	}
};
form.GetAttachedDocs = function(item){
	var dsCallparams = {
		OBJECTID: item["DOCUMENTID"],
		OBJTYPENAME: item["DOCTYPESYSNAME"]
	};
	return form.dsCall('[frontws2]', 'attachmentGetListByParams', dsCallparams).then(function (response){
		var data = response.data.Result;
		form.attachTable.setItems(data || []);

	}).catch(function (e){
		form.showErrorDialog('error', function(){}, [{caption: 'OK'}]);
	});
}
form.attachObj={
	options:{
		calcSize:function(sz){
			var sz=service.strToNum(sz);
			 if (sz<1024){
				return sz+' '+gRB('bytes');
			 }else{
				sz/=1024;
				if (sz<1024){
				   return Math.round(sz*10,2)/10+' '+gRB('KB');
				}else{
				   sz/=1024;
				   return Math.round(sz*10,2)/10+' '+gRB('MB');
				}
			}
			return '-';
		},
		getSubjectName:function(id){
			var subjectList=nvl(form.inputParams.subjectList,[]);
			for (var i=0;i<subjectList.length;i++){
				if (subjectList[i]["DOCUMENTID"]+''==id+''){
					return subjectList[i]['subjectType']+' '+subjectList[i]['CLIENT_FIO'];
				}
			}
		}
	},
	remoteMethod:{
		filterParams:function(){
			return attachFilterParams={
				OBJECTID:form.subjectItem['DOCUMENTID'],
				OBJTYPENAME:form.subjectItem['DOCTYPESYSNAME']
			}
		}
	}
}


form.onViewAttachment=function(){
	lgr('onClickAttachment',arguments);
}
form.onDeleteAttachment=function(){
	lgr('onDeleteAttachment',arguments);
	var item=getSelectedRow2(form.attachTable);
	if (item){
		form.showQuestionDialog(
			gRB("AttachmentList.AttachDeleteConfirm"),
			function(idxData){
				if (idxData.buttonIndex==0){
					form.dsCall("[frontws2]","attachmentDelete",{
						ATTACHFILEDELETE:true,
						ATTACHMENTID:item.ATTACHMENTID
					}).then(
					function(p){
						p=p['data'];
						if (p['Status']=='OK'){
							form.GetAttachedDocs(form.subjectItem);
						}else{
							showAlert(gRB('AttachmentList.errorDeleteAttachNotify'));
						}
					})
				}
			},
			[{caption:gRB('OK')},{caption:gRB('some.Cancel')}]
		)
	}
}

form.onAttach=function(){
	service.showModalWindow(form,
		'COMMON/APPLICATION/ATTACHMENT/addAttachment',
		{
			OBJECTID:form.subjectItem["DOCUMENTID"],
			OBJTYPENAME:form.subjectItem["DOCTYPESYSNAME"]
		},
		function (result) {
			if (result.uploadAction=="OK"){
				form.GetAttachedDocs(form.subjectItem);
			}
		}
	)
}

form.onSelectSubject=function(item){
	if(item.length || item.length === 0) {
		return;
	}
	form.subjectItem = item;
	form.GetAttachedDocs(form.subjectItem);
}

form.onSelectAttachment=function(item){
	form.attachObj.options['ID'+item.ATTACHMENTID]=[
		{
			caption:gRB('some.Download'),
			click: form.onDownloadAttach
		},
		{
			caption:gRB('some.Delete'),
			click: form.onDeleteAttachment
		}
	]
}
form.onDownloadAttach = function () {
	var item = getSelectedRow2(form.attachTable);
	if (item) {
		service.pageflowCall2(form.getCurrentProjectSysname(),
			'COMMON/APPLICATION/ATTACHMENT/getAttachLink',
			{
				//ExtCode: inputParams.CIF,
				ATTACHTYPENAME: item.ATTACHTYPENAME,
				ATTFILEPATH: item.ATTFILEPATH,
				ATTNAME: item.ATTNAME
			},
			function (p) {
				if (p['HASHCODE']) {
					service.downloadFileByLink(p['HASHCODE']);
				} else {
					form.showErrorDialog(gRB(form, 'downloadError', 'Error'), function () {
					}, [{caption: 'OK'}]);
				}
			},
			form
		);
	}
};
form.onDblClickAttachment=function(item){
	form.attachTable.setSelectedRow(item[form.attachTable.itemIdField]);
	form.onDownloadAttach();
}

form.executeCommand = function (message) {
	switch (message.event) {
	case 'REFRESH_APP':
		if (message.params.APPLICATIONID+''==getInputParams('application').DOCUMENTID+''){
			form.sendForm("REFRESH",true);
		}
		break;
	case 'viewAplication':
		service.setActiveTab(
			getInputParams('PROJECT'),
			"COMMON/APPLICATION/viewApplication", 
			{
				APPLICATIONID:getInputParams('application').DOCUMENTID
			},
			true,
			message.caption+' № '+form.application.DOCUMENTNUMBER
		);
		break;
	case 'stageApplication':
		service.setActiveTab(
			form.getCurrentProjectSysname(),
			"COMMON/APPLICATION/PROCESSING/applicationProcessing", 
			{
				APPLICATIONID:getInputParams('application').DOCUMENTID
			},
			true,
			message.caption+' '+gRBT('applicationNo',form.application.DOCUMENTNUMBER)
		);
		break;
	
	case 'linkedApplication':
		service.setActiveTab(
			form.getCurrentProjectSysname(),
			"COMMON/APPLICATION/LINKEDAPP/applicationLinked", 
			{
				APPLICATIONID:getInputParams('application').DOCUMENTID,
				PROJECT:getInputParams('PROJECT')
			},
			true,
			message.caption+' '+gRBT('applicationNo',form.application.DOCUMENTNUMBER)
		);
		break;	
		case 'TRANS_DIRECT':
			form.sendForm("CLOSE", false);
			break;	
		default:
			break;
	}
}
form.yesFunc = function() {
	outputParams.TRANSTYPE = 'SAVEDRAFT';
	form.sendForm('GO', false);
};
form.action = function (tag) {
	outputParams.TRANSTYPE = tag;
	/* if (form.isFormEditModeMain) {
	 outputParams.formParams.householdName                = form.params.householdName;

	 }*/
	if (tag === 'CLOSE') {
		service.showDialogCancelConfirm(
			form,
			form.yesFunc
		)
	}
	else {
		/*if (tag === 'NEXT' && !form.verifyForm(true) ) {
		 return;
		 }else{
		 form.verifyForm(false);
		 }*/
		form.sendForm('GO', false);
	}
}
