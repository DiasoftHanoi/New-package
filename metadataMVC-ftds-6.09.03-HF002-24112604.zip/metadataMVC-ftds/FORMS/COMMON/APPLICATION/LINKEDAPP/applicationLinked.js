function registerMethod(initService) {
	var service = {};
	for (var ar in initService) {
		if (initService.hasOwnProperty(ar)) {
			if (ar.indexOf('Service') > -1 || typeof(initService[ar]) != 'function') {
				service[ar] = initService[ar];
			} else {
				var fn = initService[ar].toString();
				var sIdx = fn.search(/\(/) + 1;
				var eIdx = fn.search(/\)\{/);
				var args = fn.substring(sIdx, eIdx)
					eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
			}
		}
	}
	return service;
}
service = registerMethod(service);

var getInputParams = service.getInputParams;
var lgr = service.lgr;
var showAlert = service.showAlert;
var gRBT = service.gRBT;
var gRB = service.gRB;
var nvl = service.nvl;

form.onSelectApplication = function (item) {
	lgr('onSelectApplication', arguments);
	var params = {
		MAINAPPLICATIONID : getInputParams('APPLICATIONID'),
		APPLICATIONID : item.DOCUMENTID,
		PROJECT: getInputParams('PROJECT'),
	}
	if (!form.linkedObj.options['ID' + item.DOCUMENTID]) {
		service.pageflowCall(nvl(getInputParams('PROJECT'),form.getCurrentProjectSysname()),
			'COMMON/APPLICATION/LINKEDAPP/getLinkedAppActions', params,
			function (p) {
				lgr('fillActions', p);
				var transfersList = nvl(p['transferList'],[]);
				var resActions=[];
				for (var i=0;i<transfersList.length;i++){
					resActions.push({
						caption:transfersList[i]["NAME"],
						click:function(){form.onApplicationAction(this,item)},
						SYSNAME:transfersList[i]["SYSNAME"],
						PAGEFLOWNAME:transfersList[i]["PAGEFLOWNAME"],
					})
				}
				form.linkedObj.options['ID' + item.DOCUMENTID] = resActions;
			}
		);
	}
}

form.preparePath=function(str,project){
	str+="";
	var data=str.split("[");
	if (data.length>1){
		var data2=data[1].split("]");
		return {project:data2[0],pageflow:data2[1]}
	}else{
		return {project:service.nvl(project,form.getCurrentProjectSysname()),pageflow:str}
	}
}

form.onApplicationAction=function(data,item){
	lgr("onApplicationAction");
	var path=form.preparePath(data.PAGEFLOWNAME);
	service.setActiveTab(path.project, path.pageflow,{
			APPLICATIONID:getInputParams("APPLICATIONID"),
			MAINAPPLICATIONID:item.DOCUMENTID,
	},true, data.caption+' ('+service.gRB("Application")+' № '+item['DOCUMENTNUMBER']+')');
}

form.linkedObj = {
	cols : [
		{
                value: 'DOCUMENTNUMBER',
                type: 'text',
                caption: gRB('documentNumber'),
                width: 15
            },
            {
				value: 'STRING3',
                type: 'text',
                caption: gRB('Client'),
                width: 15
            },
            {
				value: 'STRING4',
                type: 'text',
                width: 15
            },
            {
				value: 'STRING5',
                type: 'text',
                width: 15
            },
            {
				value: 'STATE',
                type: 'text',
                caption: gRB('State'),
                width: 10
            },
            {
				value: 'CREATIONDATE',
                type: 'date',
                caption: gRB('creationDate'),
                width: 15
            },

            {
				value: 'FIOBankEmployee',
                type: 'text',
                caption:gRB("employeeName"),
                width: 15
            }
	],

	options : {
		prepareTemplatePath:function(item){
			return '/webmvc/resource/'+form.getCurrentProjectSysname()+'/TEMPLATES/application/grid/'+item.DOCTYPESYSNAME+'.html';
		},
		checkState:function(item){
			return true;
		}
	}
}

form.executeCommand = function (message) {
	switch (message.event) {
		case 'TRANS_DIRECT':
			service.sendForm("CLOSE", false);
			break;	
		default:
			break;
	}
}
