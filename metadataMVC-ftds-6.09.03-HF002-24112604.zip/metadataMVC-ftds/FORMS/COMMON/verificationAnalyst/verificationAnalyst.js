/* global form, service */

var inputParams = form.inputParams || {};
form.formParams = inputParams.formParams;
form.formParams.objId = form.inputParams.APPLICATIONID;

var outputParams = form.outputParams || {};
outputParams.formParams = form.formParams;

var lgr = service.lgr;
var nvl = service.nvl;
var strToNum = service.strToNum;
form.strToNum = service.strToNum;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);

form.templateData = form.formParams;
form.templateData.isAutoFlag = form.formParams.TYPESYSNAME == 'autoLoanApp' ? true : false;

form.formParams.STAGECOMMENT = inputParams.STAGEDETAILS;

form.rbDecisionType_items = form.formParams.rbDecisionType_items;



form.executeCommand = function (msg) {
    //form.sendForm(msg.event);
    switch (msg.event) {
        case 'viewApplication':
            form.startNewPageFlowProcess(msg.caption, "FTFLOANSMVC/loanApp/"+form.formParams.TYPESYSNAME+"/inputApplication/inputApplication", {
                APPLICATIONID: form.formParams.DOCUMENTID
            });
            break;
        case 'attachedDocuments':
            form.startNewPageFlowProcess(msg.caption, "FTFLOANSMVC/COMMON/APPLICATION/applicationListAttachment", {
                APPLICATIONID: form.formParams.DOCUMENTID
            });
            break;
        case 'processingStage':
            form.startNewPageFlowProcess(msg.caption, "FTFLOANSMVC/COMMON/APPLICATION/PROCESSING/applicationProcessing", {
                APPLICATIONID: form.formParams.DOCUMENTID
            });
            break;
        case 'linkedDocuments':
            form.startNewPageFlowProcess(msg.caption, "FTFLOANSMVC/COMMON/APPLICATION/LINKEDAPP/applicationLinked", {
                APPLICATIONID: form.formParams.DOCUMENTID
            });
            break;

        case 'analysisResult':
            form.startNewPageFlowProcess(msg.caption, "FTFLOANSMVC/loanApp/mortgageLoanApp/viewDecisionCC/analysisResults", {
                SHOWRESULT: false,
                APPLICATIONID: form.formParams.DOCUMENTID
            });
            break;
    }
};

form.requiredControls = function (){
    var controls = [
        /* id обязательных элементов*/
    ];
    return controls.join(',');
}


form.verifyForm = function (showFlag) {
    var verified = true;
    try {
        var btnNext =  form['btnNext'] ? 'btnNext' : 'btnSave';
        if (form.validateControlsByIds(form.requiredControls(), showFlag === true ? btnNext : undefined).isShowFormErrors) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {lgr(e);
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    form.outputParams.VERIFIED = verified;
    return verified;
};

form.action = function (tagName) {
    outputParams.EXIT_TYPE = tagName;
    form.formParams.SuspensiveConditionList = form.suspensiveConditionPnl.tabSuspensiveCondition.getItems();
    form.formParams.AtypicalConditionList = form.atypicalConditionsPnl.tabAtypicalCondition.getItems();
    form.formParams.AddConditionList = form.additionalConditionsPnl.tabAddCondition.getItems();

    if (tagName === 'CLOSE') {
        service.showDialogCancelConfirm(
            form,
            function (){
                form.outputParams.EXIT_TYPE = 'CLOSE';
                form.verifyForm(false);
                form.sendForm('GO', false);
            },
            function (){
                form.outputParams.EXIT_TYPE = 'CLOSE';
                form.sendForm('CLOSE', false);
            }
        )
    } else {

        if (tagName === 'NEXT' && !form.verifyForm(true)) {
            return;
        } else {
            form.verifyForm(false);
        }

        var calculateLTVBeforeMaternityCapital = form.formParams.calculateLTVBeforeMaternityCapital;
        var standardLTVWithMaternityCapital = form.formParams.standardLTVWithMaternityCapital;
        var calculateLTV = strToNum(form.formParams.calculateLTV);
        var standardLTV = strToNum(form.formParams.standardLTV);
        var message = '';

        if (calculateLTVBeforeMaternityCapital && standardLTVWithMaternityCapital){
            if (strToNum(calculateLTVBeforeMaternityCapital) > strToNum(standardLTVWithMaternityCapital)){
                message = 'Значение К/З мск составляет '+strToNum(calculateLTVBeforeMaternityCapital).toFixed(2)+'% и превышает нормативное значение, установленное в размере '+strToNum(standardLTVWithMaternityCapital).toFixed(2)+'%.';
            }
        }

        if (calculateLTV && standardLTV){
            if (strToNum(calculateLTV) > strToNum(standardLTV)){
                message += (message ? '\n' : '') + 'Значение К/З составляет '+strToNum(calculateLTV).toFixed(2)+'% и превышает нормативное значение, установленное в размере '+strToNum(standardLTV).toFixed(2)+'%.';
            }
        }


        form.outputParams.EXIT_TYPE = 'SAVE';

        if (message != '') {
            form.showInformationDialog(message, function () {
                form.sendForm('GO', false);
            }, [{caption: 'OK'}]);
        }else
        {
            form.sendForm('GO', false);
        }
    }
}