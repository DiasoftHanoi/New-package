/* global form */
function registerMethod(initService) {
	var service = {};
	for (var ar in initService) {
		if (initService.hasOwnProperty(ar)) {
			if (ar.indexOf('Service') > -1 || typeof(initService[ar]) != 'function') {
				service[ar] = initService[ar];
			} else {
				var fn = initService[ar].toString();
				var sIdx = fn.search(/\(/) + 1;
				var eIdx = fn.search(/\)\{/);
				var args = fn.substring(sIdx, eIdx)
					eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
			}
		}
	}
	return service;
}
service = registerMethod(service);
var gRB = service.gRB;
var lgr = service.lgr;

var inputParams = form.inputParams || {};
form.formParams = inputParams.formParams;
var outputParams = form.outputParams || {};
outputParams.formParams = form.formParams;

form.onClickPage = function (item) {
    if (item.sysname) {
        form.command({event: item.sysname, caption: item.caption});
    }
};
form.pageItems = [{
        caption: '${attachedDocuments.caption}',
        sysname: 'attachedDocuments'
    }, {
        caption: '${processingStage.caption}',
        sysname: 'processingStage'
    }
];
