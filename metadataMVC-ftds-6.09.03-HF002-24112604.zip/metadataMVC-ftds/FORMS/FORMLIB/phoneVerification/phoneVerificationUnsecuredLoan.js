function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
var service = registerMethod(service);

var lgr = service.lgr;
var nvl = service.nvl;
var gRB = service.gRB;
var inputParams = form.inputParams;
var outputParams = form.outputParams || {};
form.formParams = inputParams.formParams || {};
outputParams.formParams = form.formParams;
form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);
form.isFormEditMode = form.inputParams.EDITMODE;

var phoneVerificationList = form.formParams.phoneVerificationList || [];

form.onShow = function () {
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });
        form['tblChecksInfo'] ? form['tblChecksInfo'].setItems(phoneVerificationList) : undefined;
};

form.executeCommand = function(msg){
    service.lgr(msg.event);
    if (msg.event === 'FAB_NAVIGATOR_NAVIGATE'){
        outputParams.NEXTPAGE = msg.params.step;
        form.action('DIRECT');
     service.lgr(msg.params.step);   
    }
    if (msg.event === 'GO_TO_PAGEFLOW'){
        form.startNewPageFlowProcess(msg.caption, msg.params.PAGEFLOW, {
            APPLICATIONID: msg.params.APPLICATIONID,
            EDITMODE: false
        }).then(function (responseAddContacts) {
                if (!responseAddContacts) {
                    return;
                }
                var addContactsList  = responseAddContacts.additionalContactsList;
                var checksList = form['tblChecksInfo'].getItems();
                var newChecksList = [];
                var index = new Date().getTime();
                //Смотрим, изменились ли существующие элементы грида. Собираем новый список проверок для отображения
                for (var i = 0; i < checksList.length; i++){
                    var selectedCheckRow = checksList[i];
                    if (selectedCheckRow && selectedCheckRow["phoneVerContactType"] == 'additionalContact'){
                        var existContactId = null;
                        var changedContact = false;
                        var contactValue = selectedCheckRow["phoneVerContactNumber"];
                        for (var newContactsCount = 0; newContactsCount < addContactsList.length; newContactsCount++){
                            var selectedAdditionalContact = addContactsList[newContactsCount];
                            if (selectedAdditionalContact && (selectedCheckRow["additionalContactID"] == selectedAdditionalContact["id"])){
                                existContactId = newContactsCount;
                                if (contactValue != selectedAdditionalContact["value"]){
                                    changedContact = true;
                                    contactValue = selectedAdditionalContact["value"];
                                }
                                break;
                            }
                        }
                        if (existContactId != null) {
                            newChecksList.push({
                                id                      : index++,
                                phoneVerContactType     : selectedCheckRow["phoneVerContactType"],
                                phoneVerContactTypeText : selectedCheckRow["phoneVerContactTypeText"],
                                phoneVerContactNumber   : contactValue,
                                phoneVerResult          : (changedContact === false) ? selectedCheckRow['phoneVerResult'] : undefined,
                                phoneVerRemark          : (changedContact === false) ? selectedCheckRow['phoneVerRemark'] : undefined,
                                additionalContactID     : selectedCheckRow['additionalContactID'],
                            });
                        }
                    } else{
                        newChecksList.push({
                            id                      : index++,
                            phoneVerContactType     : selectedCheckRow["phoneVerContactType"],
                            phoneVerContactTypeText : selectedCheckRow["phoneVerContactTypeText"],
                            phoneVerContactNumber   : selectedCheckRow["phoneVerContactNumber"],
                            phoneVerResult          : selectedCheckRow['phoneVerResult'],
                            phoneVerRemark          : selectedCheckRow['phoneVerRemark'],
                            additionalContactID     : selectedCheckRow['additionalContactID'],
                        });
                    }
                }
                //Смотрим, появились ли новые элементы грида для отображения в списке
                for (var newContactsCount = 0; newContactsCount < addContactsList.length; newContactsCount++){
                    var selectedAdditionalContact = addContactsList[newContactsCount];
                    var existingContact = false;
                    for (var i = 0; i < checksList.length; i++){
                        var selectedCheckRow = checksList[i];
                        if (selectedCheckRow && (selectedCheckRow["additionalContactID"] == selectedAdditionalContact["id"])){
                            existingContact = true;
                            break;
                        }
                    }
                    if (existingContact === false) {
                        newChecksList.push({
                            id                      : index++,
                            phoneVerContactType     : "additionalContact",
                            phoneVerContactTypeText : selectedAdditionalContact["contactType"] +  " (" + selectedAdditionalContact["additionalContactStage"] + ")",
                            phoneVerContactNumber   : selectedAdditionalContact["value"],
                            phoneVerResult          : undefined,
                            phoneVerRemark          : undefined,
                            additionalContactID     : selectedAdditionalContact['id'],
                        });
                    }
                }
                form['tblChecksInfo'].setItems(newChecksList);
                form['tblChecksInfo'].refresh();
                outputParams.formParams.additionalContactsList = addContactsList;
            });
    }
};

form.verifyForm = function (showFlag) {
    var verified = true;

    if (!form.isFormEditMode){
        outputParams.VERIFIED = inputParams.VERIFIED;
        return verified;
    }

    try {
        var btnNext =  form['btnNext'] ? 'btnNext' : 'btnSave';
        if (form.validateControlsByIds('*', showFlag === true ? btnNext : undefined).isShowFormErrors) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {lgr(e);
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    outputParams.VERIFIED = verified;
    return verified;
};

form.action = function (tagName) {
    outputParams.TRANSTYPE = tagName;
    if (form.isFormEditMode){
        form['tblChecksInfo'] ? form.formParams.phoneVerificationList = form['tblChecksInfo'].getItems() : form.formParams.phoneVerificationList = undefined;
    }
    if (tagName === 'CLOSE') {
        if (!form.isFormEditMode){
            form.sendForm('GO',false);
        }else {
            form.verifyForm(true, tagName);
            service.showDialogCancelConfirm(
                form,
                function () {
                    outputParams.TRANSTYPE = 'SAVEDRAFT';
                    form.sendForm('GO', false);
                }
            )
        }
    } else {

        if (tagName === 'NEXT' && !form.verifyForm(true)) {
            return;
        } else {
            form.verifyForm(false);
        }
        form.sendForm('GO', false);
    }
};

form.tblChecksInfoObj = (function (grId) {
    var gridId = grId;
    var options = {
        data: {},
        settings: {},
        
        checkResultsList : form.inputParams.checkResultsList || [],
        
        requiredElements: [
            "edContactTypeGrid",
            "edContactNumberGrid",
        ],

        cancel: function () {
            form[gridId].hideEditor();
            form.btnCheckAdd.enable();
        },
        save: function () {
            var selectedRow = form[gridId].getSelectedRow()[0];
            var newRow = {
                phoneVerContactType    : selectedRow.phoneVerContactType ? selectedRow.phoneVerContactType : undefined,
                phoneVerContactTypeText    : form.edContactTypeGrid ? form.edContactTypeGrid.getValue() : undefined,
                phoneVerContactNumber  : form.edContactNumberGrid ? form.edContactNumberGrid.getValue() : undefined,
                phoneVerResult         : form.rgPhoneVerResult.getValue(),
                phoneVerRemark         : form.edRemarkGrid.getValue(),
                additionalContactID    : selectedRow.additionalContactID ? selectedRow.additionalContactID : undefined
            };

            if (selectedRow['id']) {
                newRow['id'] = selectedRow['id'];
                form[gridId].hideEditor();
                form[gridId].updateRow(obj.selectedId, newRow);

            } else {
                newRow['id'] = new Date().getTime();
                form[gridId].hideEditor();
                form[gridId].addRow(newRow);
            }
            form.btnCheckAdd.enable();
        },
        clearFields: function () {
            delete options.data.phoneVerResult;
            delete options.data.phoneVerRemark;
        },
        edit: function () {
            form.addAddrMode = 'edit';
            form[gridId].showEditor('edit');
            options.clearFields();
            var selectedRow = form[gridId].getSelectedRow()[0];
            form[gridId].options.data = {
                phoneVerContactType   : selectedRow["phoneVerContactType"],
                phoneVerContactTypeText   : selectedRow["phoneVerContactTypeText"],
                phoneVerContactNumber : selectedRow["phoneVerContactNumber"],
                phoneVerResult        : selectedRow['phoneVerResult'],
                phoneVerRemark        : selectedRow['phoneVerRemark'],
                additionalContactID   : selectedRow['additionalContactID']
            };
            form.btnCheckAdd.disable();
        },
        delete: function () {
            var row = form[gridId].getSelectedRow()[0];
            if (row) {
                form[gridId].deleteRow(obj.selectedId);
                form[gridId].refresh();
            }
            options.clearFields();
            form.btnCheckAdd.enable();
        }
    };

    var obj = {
        gridId: grId,
        refresh: function () {
            form[gridId].refresh();
        },
        addNewRow: function () {
            form.addAddrMode = 'add';
            form[gridId].showEditor('add');
            options.clearFields();
            form.btnCheckAdd.disable();
        },
        setItems: function (items) {
            form[gridId].setItems(items);
        },
        getItems: function () {
            return form[gridId].getItems();
        },
        onSelectRow: function () {
            options.items = [];
            if (form.isFormEditMode){
                var selRow = form[gridId].getSelectedRow()[0] || {};
                options.items = [
                    {caption: gRB('edit'),   click: form[gridId].options.edit},
                ];
            }
        }
    };
    obj.options = options;
    return obj;
})('tblChecksInfo');