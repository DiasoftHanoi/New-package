/*DSMETA version = "6.01.01" hash = "68c577c77e631f6a6c3b0e4fa9f4d9934cf8e459"*/
﻿
function findInterestRate(interestRate,currency,term,firstPaymentPersent) {
  var condition = new Array();
  condition[0] =  new Array();
  condition[0]["name"]="LoanCurrency";
  condition[0]["type"]="equal";
  condition[0]["value"]=currency;  
  condition[1] =  new Array();
  condition[1]["name"]="LoanTerm";
  condition[1]["type"]="span";
  condition[1]["value"]=term;  
  condition[1]["minnull"]=0; 
  condition[1]["maxnull"]=12000; 
  condition[2] =  new Array();
  condition[2]["name"]="LoanFirstAmountPercent";
  condition[2]["type"]="span";
  condition[2]["value"]=firstPaymentPersent;  
  condition[2]["minnull"]=0; 
  condition[2]["maxnull"]=100;
  return findParamProduct(interestRate,condition);
} 

function findInterestRateConsumer(interestRate,currency,term) {
  var condition = new Array();
  condition[0] =  new Array();
  condition[0]["name"]="LoanCurrency";
  condition[0]["type"]="equal";
  condition[0]["value"]=currency;  
  condition[1] =  new Array();
  condition[1]["name"]="LoanTerm";
  condition[1]["type"]="span";
  condition[1]["value"]=term;  
  condition[1]["minnull"]=0; 
  condition[1]["maxnull"]=12000; 
  return findParamProduct(interestRate,condition);
} 

function findInterestRateCard(interestRate,currency) {  
  var condition = new Array();
  condition[0] =  new Array();
  condition[0]["name"]="CardAccountCurrency";
  condition[0]["type"]="equal";
  condition[0]["value"]=currency;   
  return findParamProduct(interestRate,condition);
}

function findCardServiceFee(cardServiceFee,currency,type) {
  var condition = new Array();
  condition[0] = new Array();
  condition[0]["name"]="CardAccountCurrency";
  condition[0]["type"]="equal";
  condition[0]["value"]=currency;  
  condition[1] = new Array(); 
  condition[1]["name"]="CardType";
  condition[1]["type"]="equal";
  condition[1]["value"]=type;   
  return findParamProduct(cardServiceFee,condition); 
}

function findCardCreditLimit(cardCreditLimit,currency) {
  var condition = new Array();
  condition[0] =  new Array();
  condition[0]["name"]="CardAccountCurrency";
  condition[0]["type"]="equal";
  condition[0]["value"]=currency;   
  return findParamProduct(cardCreditLimit,condition);
}

function findParamProduct(param,condition) {

  function conditionEqual() {
	if (param[i][j]["CONDITIONNAME"]==condition[l]["name"] ) {	
        if (param[i][j]["VALUE1"]==condition[l]["value"]) {		
          flag[l]=true;        
		}  		
    }      
  }  
  
  function conditionSpan() {
    if (param[i][j]["CONDITIONNAME"]==condition[l]["name"]) {
      if (condition[l]["value"]>=nvl(param[i][j]["VALUE1"],condition[l]["minnull"]) && 
	      condition[l]["value"]<=nvl(param[i][j]["VALUE2"],condition[l]["maxnull"]))  {        
        flag[l]=true;        
	  }	
    }
  }  
  
  function flagReset() {
  	var x;	
    for(x=0;x<condition.length;x++) {
      flag[x] = (condition[x]["value"] == null ? true : false);	 
    }
  } 
  
  function flagCheck() {
    var cnt=0, y;	
	for(y=0;y<flag.length;y++) {	 
      cnt += flag[y]==true ? 1 : 0;
    }
	if (cnt==flag.length) {
	  return true;
	}
  } 
  
  if (param==null || condition==null) {
	return null;	
  }
  
  var i,j,l; 
  var flag = new Array();   
  for(i=0;i<param.length;i++) {
    flagReset();
	for(j=0;j<param[i].length;j++) {
	  for(l=0;l<condition.length;l++) {
		switch (condition[l]["type"]) {
		  case "equal" : 
		    conditionEqual();
			break;
		  case "span" :
		    conditionSpan();
			break;
		}		
	  }
	  if (flagCheck()==true) {
	  	return param[i][j]["RESULTVALUE"];
      }	
	}
  }
  return null;
}