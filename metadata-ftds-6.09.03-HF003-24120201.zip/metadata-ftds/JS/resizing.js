/*DSMETA version = "6.01.01" hash = "00121262429a284d82e55374edc6309859bac371"*/
function resizeFormHeight(table, limitForSearchForms, childTablePanel) {
	var windowHeight = cbsGetClientWindowHeight();
	var childTablePanelHeight = 0;
	if (windowHeight > (limitForSearchForms ? limitForSearchForms : 400)) {
		var ids = getAllIds();
		var tableContainer = "";
		var containers = getNewList();
		for (var i = 0; i < ids.size(); i++) {
			var id = ids.get(i);
			var arrIdPath = id.split('.');
			var idLevel = arrIdPath.length;
			if (id == table) {
				var tableContainer = arrIdPath[0] + "." + arrIdPath[1];
			}
			if (idLevel == 2) {
				containers.add(id);
			}
		}
		//Ищем нижний контейнер
		var bottomContainer = containers.get(0);
		var bottomContainerCoordY = getCoordY(bottomContainer);
		for (var i = 1; i < containers.size(); i++) {
			var iContainer = containers.get(i);
			var iContainerCoordY = getCoordY(iContainer);
			if (iContainerCoordY > bottomContainerCoordY) {
				bottomContainerCoordY = iContainerCoordY;
				bottomContainer = iContainer;
			}
		}
		if (childTablePanel){ //для форм поиска с дочерней таблицей, при уходе с открытой дочерней таблицей и по возвращению ломался вертикальный ресайз
			(isVisible(childTablePanel)) ? childTablePanelHeight = getHeight(childTablePanel) : childTablePanelHeight = 0;
		}
        var formCaptionLabelHeight=getHeight("formCaptionLabel");  //высота стандартного заголовка формы FormCaption 
		var difference = windowHeight - bottomContainerCoordY - getHeight(bottomContainer)-formCaptionLabelHeight-2;
		cbsExpandComponent(tableContainer, difference);
		//есть формы с ошибками, как то без панели под таблицу. В таком случае вычисление tableContainer даст результат равный имени table
		if (tableContainer != table)
		{
			cbsExpandComponent(table, difference + childTablePanelHeight);
		}   
                 
		var arrTablePath = table.split('.');
		setHeight(arrTablePath[0], windowHeight-formCaptionLabelHeight-2);  //2px- толщина линии под заголовком 
	}
}

function resizeFormWidth(conteinersList, rightAlignComponentList, columnComponentList, labelWidth, MaxComponentWidth, indentMap) {
	if (!columnComponentList){
		columnComponentList = getNewList();
	}
	//сохранение дефолтных значений координаты Х и ширины всех компонент
	saveCmponentDefaultCoords(conteinersList, rightAlignComponentList, columnComponentList);

	var windowSizeWidth = cbsGetClientWindowWidth()-20;
	var startFormWidth = 800; // Свойство Width формы
	//1974770	ЮКБ_управление документами. Не фиксируется нижняя часть формы - возврат к предыдущим координатам не является решением проблемы, так как предыдущие координаты могут выпадать за границы визуальной формы. Выходит оптимальным решением становится расположение элементов на форме размером 800 пикселей - минимально допустимой ширине окна
	if (windowSizeWidth < startFormWidth) {
		windowSizeWidth = startFormWidth;
	}
		// Установка ширины контейнеров
		if (conteinersList != null && conteinersList.size() > 0) {
			for (var i = 0; i < conteinersList.size(); i++) {
				setWidth(conteinersList.get(i), windowSizeWidth - 30);
			}
		}

		//Выравнивание компонент по правому краю
		if (rightAlignComponentList != null && rightAlignComponentList.size() > 0) {
			for (var i = 0; i < rightAlignComponentList.size(); i++) {
				var iComponent = rightAlignComponentList.get(i);
				setCoordX(iComponent, getWidth(getParentElementPath(iComponent)) - getWidth(iComponent) - 35);
			}
		}

		//Расположение элементов в 3х колонках
		 if(MaxComponentWidth && columnComponentList != null && columnComponentList.size() > 0) {
			var newIndentMap = indentMap || getNewMap(); //мапа отступов
			var rightIndent = newIndentMap.get("Right") || 0;
			var leftIndent = newIndentMap.get("Left") || 0;
			var columnsCount = columnComponentList.size();
			var defaultSearchParamsWidth = columnsCount * (labelWidth +  MaxComponentWidth + 30) - 20;			
			
			windowSizeWidth = windowSizeWidth - 38 - leftIndent - rightIndent;
			if(defaultSearchParamsWidth  <  windowSizeWidth){
			    var delta = defaultSearchParamsWidth  / columnsCount;
			}else{
			    var delta = windowSizeWidth/ columnsCount;
			}
			renderComponentColumn(columnComponentList.get(0), 8, 8, delta - 8, rightAlignComponentList, labelWidth);
			for (var i = 1; i < columnComponentList.size(); i++) {
				var iColumnComponentList = columnComponentList.get(i);
				if (iColumnComponentList != null && iColumnComponentList.size() > 0) {
					renderComponentColumn(iColumnComponentList, delta * i + 20, delta *i + 20, delta - 20, rightAlignComponentList, labelWidth);
				}
			}
		}
	/*} else {
		returnDefaultCoords(columnComponentList.size());
	}*/
}

function renderComponentColumn(componentList, labelCoordX, componentCoordX, componentWidth, rightAlignComponentList, labelWidth) {
	if (componentList != null && componentList.size() > 0) {
		for (var i = 0; i < componentList.size(); i++) {
			var iComponent = componentList.get(i);
			var labelComponentPath = iComponent.get("labelComponentPath");
			var componentPath = iComponent.get("componentPath");
			var flexWidth = iComponent.get("flexWidth");

			// console.log("fullWidth = " + iComponent.get("fullWidth"));
			// console.log("ccx+lw = " +  (componentCoordX + labelWidth));
			// console.log("ccx = " +  (componentCoordX));
			// console.log("ccx+lw = " +  (componentWidth - labelWidth));
			// console.log("ccx = " +  (componentWidth));
			// console.log("componentPath = " + componentPath);
			// console.log("labelComponentPath = " + labelComponentPath);
			// console.log("flexWidth = " + flexWidth);

			// Если свойство компонента fullWidth не активно, то устанавливаем позицию компонента по Х с учетом позиции лейбла, связанного с данным компонентом, если активно
			// позиция компонента по Х будет рассчитываться без учета лейбла
			var correctedComponentCoordX = (iComponent.get("fullWidth") != true) ? (componentCoordX + labelWidth) : componentCoordX;
			// Если свойство компонента fullWidth не активно, то устанавливаем ширину компонента с учетом ширины лейбла, связанного с данным компонентом, ести активно
			// компонент будет растянут на всю ширину колонки
			var correctedComponentWidth = (iComponent.get("fullWidth") != true) ? (componentWidth - labelWidth) : componentWidth;

			if (labelComponentPath != null && labelComponentPath != "") {
				setCoordX(labelComponentPath, labelCoordX);
			}
			if (componentPath != null && componentPath != "") {
				setCoordX(componentPath, correctedComponentCoordX);
			}
			if (iComponent.get("flexWidth") == true) {

				if (!isEmptyList(rightAlignComponentList)) {
					for (var j = 0; j < rightAlignComponentList.size(); j++) {
						var rName = rightAlignComponentList.get(j);
						var rCompY = getCoordY(rName);
						var rCompX = getCoordX(rName);
						var rCompW = getWidth(rName);

						// Если "колоночный" компонент имеет ту же координату Y, что и компонент, который выровнен по правому краю, и они пересекаются по Х координате, то
						// уменьшаем ширину "колоночного" компонента на то, насколько "колоночный" компонент залезает за "правый" компонент
						var diff = (getCoordX(componentPath) + correctedComponentWidth) - rCompX;
						if (getCoordY(componentPath) == rCompY && diff >= 0) {
							setWidth(componentPath, correctedComponentWidth - diff - 10);
							break;
						}
					}
					if (j == rightAlignComponentList.size()) { // Если прошли весь цикл и проверка на пересечение координат не выполнилась,
						// то устанавливаем значение ширины на основе correctedComponentWidth
						setWidth(componentPath, correctedComponentWidth);
					}
				} else { // если "правых" компонент нет, то устанавливаем значение ширины на основе correctedComponentWidth
					setWidth(componentPath, correctedComponentWidth);
				}
			}
		}
	}
}

function getParentElementPath(elementPath) {
	var parentElementPath = "";
	if (elementPath != null && elementPath != "") {
		var pos = elementPath.indexOf(".");
		var lastIndex = 0;
		while (pos != -1) {
			lastIndex = pos;
			pos = elementPath.indexOf(".", pos + 1);
		}
		parentElementPath = elementPath.substring(0, lastIndex);
	}
	return parentElementPath;
}

// возвращение исходного расположения и размеров компонент
function returnDefaultCoords(columnsCount) {
	var conteinersListDefaultCoords = getInputParams("conteinersListDefaultCoords");
	setDefaultCoords(conteinersListDefaultCoords);

	var rightAlignComponentListDefaultCoords = getInputParams("rightAlignComponentListDefaultCoords");
	setDefaultCoords(rightAlignComponentListDefaultCoords);

	if (columnsCount != null && columnsCount != "") {
		for (var i = 0; i < columnsCount; i++) {
			var iColumnComponentListDefaultCoords = getInputParams("columnComponentListDefaultCoords_" + i);
			setDefaultCoords(iColumnComponentListDefaultCoords);
		}
	}
}

// возвращение исходного расположения и размеров компонент
function setDefaultCoords(componentList) {
	if (componentList != null && componentList.size() > 0) {
		for (var i = 0; i < componentList.size(); i++) {
			var iComponent = componentList.get(i);
			setCoordX(iComponent.get("componentPath"), iComponent.get("componentCoordX"));
			setWidth(iComponent.get("componentPath"), iComponent.get("componentWidth"));
		}
	}
}

//сохранение дефолтных значений координаты Х и ширины всех компонент
function saveCmponentDefaultCoords(conteinersList, rightAlignComponentList, columnComponentList) {
	if (conteinersList != null && conteinersList.size() > 0) {
		var conteinersListDefaultCoords = getNewList();
		for (var i = 0; i < conteinersList.size(); i++) {
			var elementDefaultCoords = getNewMap();
			var elementName = conteinersList.get(i);
			elementDefaultCoords.put("componentPath", elementName);
			elementDefaultCoords.put("componentCoordX", getCoordX(elementName));
			elementDefaultCoords.put("componentWidth", getWidth(elementName));
			conteinersListDefaultCoords.add(elementDefaultCoords)
		}
		setInputParam("conteinersListDefaultCoords", conteinersListDefaultCoords);
	}
	if (rightAlignComponentList != null && rightAlignComponentList.size() > 0) {
		var rightAlignComponentListDefaultCoords = getNewList();
		for (var i = 0; i < rightAlignComponentList.size(); i++) {
			var elementDefaultCoords = getNewMap();
			var elementName = rightAlignComponentList.get(i);
			elementDefaultCoords.put("componentPath", elementName);
			elementDefaultCoords.put("componentCoordX", getCoordX(elementName));
			elementDefaultCoords.put("componentWidth", getWidth(elementName));
			rightAlignComponentListDefaultCoords.add(elementDefaultCoords)
		}
		setInputParam("rightAlignComponentListDefaultCoords", rightAlignComponentListDefaultCoords);
	}
	if (columnComponentList != null && columnComponentList.size() > 0) {
		for (var i = 0; i < columnComponentList.size(); i++) {
			var iColumnComponentList = columnComponentList.get(i);
			if (iColumnComponentList != null && iColumnComponentList.size() > 0) {
				saveDefaultColumnComponentsCoords(iColumnComponentList, "columnComponentListDefaultCoords_" + i);
			}
		}
	}
}

function saveDefaultColumnComponentsCoords(componentList, paramName) {
	if (componentList != null && componentList.size() > 0) {
		var columnComponentListDefaultCoords = getNewList();
		for (var i = 0; i < componentList.size(); i++) {
			var componentDefaultCoords = getNewMap();
			var iComponent = componentList.get(i);
			var labelComponentPath = iComponent.get("labelComponentPath");
			var componentPath = iComponent.get("componentPath");

			if (labelComponentPath != null && labelComponentPath != "") {
				componentDefaultCoords.put("componentPath", labelComponentPath);
				componentDefaultCoords.put("componentCoordX", getCoordX(labelComponentPath));
				componentDefaultCoords.put("componentWidth", getWidth(labelComponentPath));
				columnComponentListDefaultCoords.add(componentDefaultCoords);
			}
			if (componentPath != null && componentPath != "") {
				componentDefaultCoords.put("componentPath", componentPath);
				componentDefaultCoords.put("componentCoordX", getCoordX(componentPath));
				componentDefaultCoords.put("componentWidth", getWidth(componentPath));
				columnComponentListDefaultCoords.add(componentDefaultCoords);
			}
		}
		setInputParam(paramName, columnComponentListDefaultCoords);
	}
}

function addResizeComponentToList(columnComponentList, labelComponentPath, componentPath, flexWidth) {
	var componentParams = getNewMap();
	componentParams.put("labelComponentPath", labelComponentPath);
	componentParams.put("componentPath", componentPath);
	componentParams.put("flexWidth", flexWidth);
	columnComponentList.add(componentParams);
}


function cbsGetClientWindowWidth() {
    try{//не работает в ie
        return cbsGetParentElementByClassName("diasoft-tabs-panel").getWidth();
    }catch(e){
        return getClientWindowSize().get(0);
    }
}

function cbsGetClientWindowHeight() { // лечение рейсайза при открытии нескольких вкладок, было $(document).height()
    try{
        return window.parent["isc_HTMLPane_0"].getHeight();
    }catch(e){
        getClientWindowSize().get(1);
    }
}

function cbsGetParentElementByClassName(className) {
    return window.parent[window.parent.document.getElementsByClassName(className)[0].getAttribute("eventproxy")];
}

/*Расширяет контейнер/элемент, сдвигая все остальные элементы внутри родительского контейнера вниз*/
function cbsExpandComponent(component, height) {
 if (!component)
  return;

 var arrComponentPath = component.split('.');
 var componentLevel = arrComponentPath.length;
 var componentCoordY = getCoordY(component);

 var ids = getAllIds();
 for (var i = 0; i < ids.size(); i++) {
  var id = ids.get(i);
  var arrIdPath = id.split('.');
  var idLevel = arrIdPath.length;
  var idCoordY = getCoordY(id);
  if (id != component && idLevel == componentLevel && arrIdPath[idLevel - 2] == arrComponentPath[idLevel - 2] && idCoordY > componentCoordY) {
   //Если найденный компонент удовлетворяет следующим условиям:
   //1. Совпадают уровни вложенности 2. Принадлежат одному компоненту 3. расположен ниже расширяемого
   //То сдвигаем его вниз на величину расширения
   setCoordY(id, idCoordY + height);
  }
 }
 setHeight(component, getHeight(component) + height);
}

function isEmptyList(entity) {
  return (entity == null || entity.size() == 0);
}