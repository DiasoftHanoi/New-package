/*DSMETA version = "6.01.01" hash = "c9685fddeea7a236f3453ff2768c96acd9ba37a0"*/
////////////////////////////////////////////////////////////////////////////////
function formatAmountPFD(productAmount) {
  if (productAmount != "" && productAmount != null) {

    var nf = new java.text.NumberFormat.getInstance(new java.util.Locale("ru_RU"));
    nf.setGroupingUsed(true);
    nf.setMaximumFractionDigits(2);
    nf.setMinimumFractionDigits(2);  
    productAmount = nf.format(new java.lang.Double((productAmount instanceof java.lang.String) ? productAmount.replace(" ",""): productAmount));     
                                          
    if (new java.lang.String(productAmount).length() > 3) {
      var mainDigits = new java.lang.String(productAmount).substring(0,new java.lang.String(productAmount).length()-3).replaceAll(",", " ");
      //var pointDigit = new java.lang.String(productAmount).substring(new java.lang.String(productAmount).length()-3,new java.lang.String(productAmount).length()-2).replaceAll(",", ".");
      var fractionalDigits = new java.lang.String(productAmount).substring(new java.lang.String(productAmount).length()-2,new java.lang.String(productAmount).length());
      productAmount = mainDigits + "." + fractionalDigits;
    }
  }// else productAmount = " ";  
  return new java.lang.String(productAmount);
}
////////////////////////////////////////////////////////////////////////////////
function getResourceBundleByTemplate(key) {
    var str = getResourceBundle(key);
    if(str != null && arguments.length > 1){
        for (var i = 1; i < arguments.length; i++) {
            str = str.replace("%"+i+"$", String(arguments[i]));
        }
    }
    return str;
}                                           
////////////////////////////////////////////////////////////////////////////////
function ddmmyyyy(dt){
   var res="";
   var formatter = new java.text.SimpleDateFormat("dd.MM.yyyy");
   if (dt != null && dt !=""){
      if (dt instanceof java.util.Date){res="";res=formatter.format(dt);} else if (dt instanceof java.lang.String){res="";res=formatter.format(formatter.parse(dt));}
   }
   return res;
}


function getConvDate (date){
   var dateFormat = new java.text.SimpleDateFormat("dd.MM.yyyy");
   cal=new java.util.GregorianCalendar();
   cal.setTimeZone(java.util.TimeZone.getTimeZone ("GMT"));
   cal.set(java.util.Calendar.DATE,1);
   cal.set(java.util.Calendar.MONTH,0);
   cal.set(java.util.Calendar.YEAR,1900);

   if (date!=null){
     if (date instanceof java.util.Date){
         cal.setTime(date);
		 cal.setTimeZone(java.util.TimeZone.getTimeZone ("GMT"));
         cal.set(java.util.Calendar.HOUR_OF_DAY,0);
         cal.set(java.util.Calendar.MINUTE,0);
         cal.set(java.util.Calendar.SECOND,0);
         cal.set(java.util.Calendar.MILLISECOND,0);
         return  cal.getTime();
     }else if (date instanceof java.lang.String && date!=""){
         if (parseStringDate("dd.MM.yyyy",date)!=null) {date=parseStringDate("dd.MM.yyyy",date);}
//         if (parseStringDate("ddMMyyyy",date)!=null) {date=parseStringDate("ddMMyyyy",date);}
         if (date instanceof java.util.Date){ cal.setTime(date);}
     }else if (date instanceof java.math.BigDecimal){
        var util = new Packages.ru.diasoft.utils.XMLUtil();
        cal.setTime(util.convertDate(date));
		cal.setTimeZone(java.util.TimeZone.getTimeZone ("GMT"));
     }
   }
   cal.set(java.util.Calendar.HOUR_OF_DAY,0);
   cal.set(java.util.Calendar.MINUTE,0);
   cal.set(java.util.Calendar.SECOND,0);
   cal.set(java.util.Calendar.MILLISECOND,0);
   return cal.getTime();
}