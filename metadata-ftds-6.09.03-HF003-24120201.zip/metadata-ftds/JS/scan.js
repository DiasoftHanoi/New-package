/*DSMETA version = "6.01.01" hash = "bae798f07c41aefbdabe091a63a3717e31a5ad10"*/
var anyDocScanResultFunctionName;
function createAnyDocScanPanel(id){
	apl4ScanObjectflag = false;
	apl4ScanObjectTree = {};
	docList = [];
	docIdList = [];
	if ((id)&&gbiFlex(id)){
		anyDocScanPanel = id;
		var params = getNewMap();
		params.put('SYSNAMETYPE','Common');
		params.put('SYSNAMECONSTANT',"anyDocScanPanelSettings");
		dsCall('[frontws2]','settingsGetByParams',params,'checkAnyDocScanSettings');
	} else {
		alert(showModalZag['error']+': panel\'s name is wrong');
	};
}


function checkAnyDocScanSettings(p){
	println("checkAnyDocScanSettings started");
	println(p);
	if (p){  
		if (p['Result']){
			if (p['Result']['PARAMS']){
				p['Result']['PARAMS']['callbackFunction'] = "anyDocScanResultFunction";//(!!p['Result']['PARAMS']['callbackFunction'])?p['Result']['PARAMS']['callbackFunction']:'anyDocScanResultFunction'
				anyDocScanSettings = p['Result']['PARAMS'];
				if (p['Result']['PARAMS']['useAnyDocScanPanel']) {
					createAnyDocScanElems();return true;
				}
			}
		}
	}
	return false;
}

function saveTreeData(p){
	apl4ScanObjectTree = p;
}

function getAnyScanSettins(){
	if (Mode=='WEB'){
		//var e = event || event;
		var title = getFormName(anyDocScanPanel);
		open('/webclient/pages/static/scan/settings.htm?'+title,title,'toolbar=no, titlebar=no, resizable=no, status=no, height=485, width=375, scrollbars=yes, dependent=yes');
	}
}

function scanAnyDoc(){
	docIdList = [];
	apl4ScanObjectflag = true;
	createAnyDocScanElems();
}

function createAnyDocScanElems(){
	println("createAnyDocScanElems started...")
	var str ='<TABLE style="width:100%;height:100%"><tbody><TR>';
	/*if (!!anyDocScanSettings['showSettings']){
		str +=	'<TD style="padding-right:5px">'+
			'<IMG onclick="getAnyScanSettins()" src="/webclient/pages/static/scan/settings.png" width=16 height=16>'+
			'</TD>'+
			'<TD>'+
			'<NOBR class="link" onclick="getAnyScanSettins()">Настройки</NOBR>'+
			'</TD>';
	}*/
	str += '<TD width="1%" id="'+anyDocScanPanel+'.TD"></TD>'+
		'<TD align="center"><IMG onclick="scanAnyDoc()" src="/webclient/pages/static/scan/scanner.png" width=16 height=16></TD>'+
		'<TD><NOBR class="link" onclick="scanAnyDoc()">Сканировать документ</NOBR></TD></TR></tbody></TABLE>';
	gbiFlex(anyDocScanPanel).innerHTML = str;
	var p = getNewMap();
	p.put("SYSNAMETYPE", "Form");
	p.put("SYSNAMECONSTANT", getFormName(anyDocScanPanel)+'_anyDocScanSettings');

	println("createAnyDocScanElems dsCall started...")
	dsCall('[frontws2]','settingsGetByParams',p,'createAnyDocScanApplet');
}

	
function createAnyDocScanApplet(p){
	println("createAnyDocScanApplet started");
	println(p);
	dsCall('[frontws2]','attachTypeGetTree',getNewMap(),'saveTreeData')
	var myId = 'apl4ScanObject';
	var atr = anyDocScanSettings;
	apl = document.createElement('APPLET');
	apl.setAttribute('codebase',atr['codebase']);
	apl.setAttribute('archive','frontapplet.jar, log4j-1.2.13.jar, commons-codec-1.4.jar, cayenne-2.0.3.jar');
	apl.setAttribute('code','ru.diasoft.fa.front.applets.MorenaScanApplet.class');
	apl.setAttribute('codetype','application/java');
	apl.width=1;
	apl.height=1;
	apl.name=myId;
	apl.id=myId;

	var par = document.createElement('PARAM');
	par.name = 'callbackFunctionName';
	par.value = 'callbackFunctionName';
	apl.appendChild(par);

	if(p['Result']){
		if(p['Result']['PARAMS']){
			var el = p['Result']['PARAMS'];
			anyDocScanParametrs = el;

			par = document.createElement('PARAM');
			par.name = 'callbackFunctionName';
			par.value = 'callbackFunctionName';
			apl.appendChild(par);
			
			par = document.createElement('PARAM');
			par.name = 'maxFileSize';
			par.value = 1024 * 1024 * 100;
			apl.appendChild(par);
			
			anyDocScanResultFunctionName = "anyDocScanResultFunction";//(!!el['callbackFunction'])?el['callbackFunction']:'anyDocScanResultFunction';

			if (!el['useDefaultSettings']){
				for (var k in el){
					if(typeof(el[k])!='function'){
						par = document.createElement('PARAM');
						par.name = k;
						par.value = el[k];    
						apl.appendChild(par);
					}
				}
			}
		};
	}
	
	println("anyDocScanResultFunctionName: "+anyDocScanResultFunctionName);

	par = document.createElement('PARAM');
	par.name = 'executeScan';
	par.value = eval('!!'+myId+'flag');
	par.id = myId+'flag';
	apl.appendChild(par);
	gbiFlex(anyDocScanPanel+'.TD').appendChild(apl);
}

// дерево и выбор
function makeTree(p){
	var sSl = document.styleSheets.length-1;
	document.styleSheets[sSl].addRule ('.tree tr td','vertical-align:top;border-width : 0px;padding:0;margin:0');
	document.styleSheets[sSl].addRule ('.tree','border: 0px solid red;');
	document.styleSheets[sSl].addRule ('.treeLst',"padding:10px;width:520px; background-color:#fff;height:300px; overflow-y: scroll");
	document.styleSheets[sSl].addRule ('.subHead',"font-weight: bold;text-decoration:underline");
	document.styleSheets[sSl].addRule ('TD.frstTD',"width:25px;text-align:center; text-decoration:none");
	var str ='';var tid ='tree';
	if (p){ 
		if (p['Result']){
			var dd = p['Result'].length;
			for (var i=0;i<dd;i++){
				str += crTreeLine(p['Result'][0]['Children'],'');
			}
		};
	}
	str = '<table width=100% height=100%><tr><td align=center valign=middle>' +
		'<form><table width=300px cellspacing=2><tr><th colspan=2 class="mheader">' + p['Result'][0]['NAME'] + '</th></tr>' +
		'<tr valign=top class=mpanel><td width=1 style="padding-right:0"></td><td>' +
		'<div class="rama_all treeLst">' +
	str +
		'</div>'+
		'</td></tr><tr><td colspan=2 style="padding-bottom:10px" align=center><input type=button value="' + myTxt['btnCancel'] + '"  class="btn" onClick="closemodal(' + "'" + tid + "'" + ')" id="' + tid + '_btn" />'+
		'</td></tr></table></form>';

	crmodal(str, tid)
	return str
}



function makeTree4Doc(p,num, fileResponse){
	println("makeTree4Doc started...")
	var sSl = document.styleSheets.length-1;
	document.styleSheets[sSl].addRule ('.tree tr td','vertical-align:top;border-width : 0px;padding:0;margin:0');
	document.styleSheets[sSl].addRule ('.tree','border: 0px solid red;');
	document.styleSheets[sSl].addRule ('.treeLst',"padding:10px;width:520px; background-color:#fff;height:300px; overflow-y: scroll");
	document.styleSheets[sSl].addRule ('.subHead',"font-weight: bold;text-decoration:underline");
	document.styleSheets[sSl].addRule ('TD.frstTD',"width:25px;text-align:center; text-decoration:none");
	println("fileResponse");
	println(fileResponse);
	var fileBase64List = fileResponse["fileBase64List"] || getNewList();
	var str ='';
	var tid ='tree';
	if (p) {
		if (p['Result']){
			var dd = p['Result'].length;
			for (var i=0;i<dd;i++){
				str += crTreeLine(p['Result'][0]['Children'],num)
			}
		}
	}
	
	str = '<table width=100% height=100%><tr><td align=center valign=middle>' +
		  '<form><table width=450px cellspacing=2><tr><th colspan=2 class="mheader">' + p['Result'][0]['NAME'] + '</th></tr>' +
		  '<tr valign=top class=mpanel><td width=150 style="padding-right:0"><img id="anyDocScanImg'+num+'" src="" width=150px style="display:blocked;cursor: pointer" '+(!Ext.isIE ? 'onClick="showImage('+num+')"' : '')+'></td><td>' +
		  '<div class="rama_all treeLst">' +
			  str +
		  '</div>'+
		  '</td></tr><tr><td colspan=2 style="padding-bottom:10px; padding-right:10px" align=right>'+
		  '<input type=button value="Выбрать" class="btn" onClick="selAttType(getSelectedNode2(' + num +'),'+num+ ')" id="' + tid + '_btn" />'+
		  '&nbsp<input type=button value="' + myTxt['btnCancel'] + '"  class="btn" onClick="closemodal(' + "'" + tid + num + "'" + ')" id="' + tid + '_btn" />'+
		  '</td></tr></table></form>';
	crmodal(str, tid+num);
	gbiFlex('anyDocScanImg'+num).src = "data:image/png;base64, "+(fileBase64List.length >=num ? ((fileBase64List[num] || getNewMap())["FILEBASE64"] || "") : "");
	return str
}
function showImage(n){
	window.open(gbiFlex('anyDocScanImg'+n).src);
}

function getSelectedNode2(n){
	var trs = getLikeElementsIn(gbiFlex('tipaModaltree'+n),'TR');
	for (var i=0; i<trs.length; i++){
		if (trs[i].getAttribute("selected_")+"" == "true"){
			return trs[i];
		}
	}
}

function getFilesBase64FromUpload(p){
	createModalLoader();
	println("getFilesBase64FromUpload");
	var params = getNewMap();
	var filePathList = getNewList();
	println(docList);
	for (var i=0;i<docList.length; i++){
		filePathList.add(docList[i]["SERVER_FILE_NAME"]);
	}
	params.put("filePathList", filePathList);	
	params.put("STARTIMMEDIATLY", true);
	params.put("PROCESSNAME", "ATTACHMENT/getBase64FromUploadFilePath");
	
	dsCall("[corews]", "startprocess", params, function (resp){
		println(resp);
		hideModalLoader();
		for (var i=0; i<docList.length; i++){
			makeTree4Doc(p, i, resp)
		}
		
		
	});	
}

function selAttType(el,num){
	println("selAttType started...")
	if (!el) {
		showAlert("Выберите тип прикрепляемого документа!");
		return;
	}
	var sys = el.getAttribute('sysname');
	if (anyDocScanParametrs['objectTypeSource']=='')
		anyDocScanParametrs['objectTypeSource']='"documentGroup"';
	var objType = eval(anyDocScanParametrs['objectTypeSource']);
	var objId = eval(anyDocScanParametrs['objectIdSource']);
	var author = eval(anyDocScanParametrs['authorSource']);
	var imageType = anyDocScanParametrs['imageType'];
	switch (imageType) {
	   case 'pdf':
		  imageType = 'application/pdf';
		  break
	   case 'jpg':
		  imageType = 'image/jpeg';
		  break
	   default:
		  imageType = 'image/'+imageType;
		  break
	}
	closemodal('tree'+num);
	createModalLoader();
	var d = new Date(); 
	var o = d.getTimezoneOffset();
	
	var p = getNewMap();
	p.put("OBJTYPENAME", objType);
	p.put("ATTACHTYPENAME", sys);
	p.put("ATTFILEPATH", docList[num]['SERVER_FILE_NAME']);
	p.put("ATTNAME", docList[num]['CLIENT_FILE_NAME'].split('\\').pop());
	p.put("CREATIONDATE", d);
	p.put("ATTSIZE", docList[num]['FILE_SIZE']);
	p.put("CREATEDBY", author);
	p.put("ISINVALID", 0);
	p.put("CONTENTTYPE", imageType);
	p.put("STATE", "Действует");
	p.put("VERSION", "1.0");
	p.put("OBJECTID", objId);

	dsCall('[frontws2]','attachmentCreate',p, function (resp){
		if (resp["Result"]["ATTACHMENTID"]){
			checkFinishSave(p);
		}
	});
}

function checkFinishSave(p){
	println("checkFinishSave started");
	docIdList.add(p);
	hideModalLoader()
	//closemodal('zhdi');
	var pops = getLikeElements('DIV', 'class', 'popUpStyle');
	if (pops.length==0) {
		eval(anyDocScanResultFunctionName+'(docIdList)')
	};
}

function crTreeLine(e,pad){
	var str = '<table class=tree style="border:0">';
	var dd = e.length;
	for (var i=0;i<dd;i++){
		str +='<tr id="att_'+e[i]['ID']+'_'+pad+'" sysname="'+e[i]['SYSNAME']+'" style="cursor: pointer" onclick="';
		str += (e[i]['Children'])?'chTreeViz(this, '+pad+')" class="subHead"><td class="frstTD">-</td><td> '+e[i]['NAME']+'</td></tr><tr><td></td><td id="att_'+e[i]['ID']+'_'+pad+'_chld">'+crTreeLine(e[i]['Children'],pad):'selectCurTreeLine(this,'+pad+')" ondblclick="selAttType(this,'+pad+')"><td class="frstTD"></td><td> '+e[i]['NAME'];
		str+='</td></tr>';
	}
	return str+'</table>';
}

function chTreeViz(el, p){
	var viz = gbiFlex(el.id+"_chld");
	println(viz);
	var col = el.childNodes[0];
	println(col);
	if (col.innerText=='+') {
		col.innerHTML='-';viz.style.display=''
	} else {
		col.innerHTML='+';viz.style.display='none'
	};
}

function selectCurTreeLine(el,n){
println("selectCurTreeLine");
println(n);
println(el);
	var trs = getLikeElementsIn(gbiFlex('tipaModaltree'+n),'TR');
	var dd = trs.length;
	for (var i=0; i<dd; i++){
		trs[i].style.backgroundColor = "transparent";
		trs[i].setAttribute("selected_", false);
	}
	el.style.backgroundColor = "#D8E2F4";
	el.setAttribute("selected_", true);
}
function createAnyDocScanAppletReal(p){
	var atr = anyDocScanSettings;
	apl = document.createElement('APPLET');
	apl.setAttribute('codebase',atr['codebase']);
	apl.setAttribute('archive','frontapplet.jar,log4j-1.2.13.jar,commons-codec-1.4.jar,cayenne-2.0.3.jar');
	apl.setAttribute('code','ru.diasoft.fa.front.applets.MorenaScanApplet.class');
	apl.setAttribute('codetype','application/java');
	apl.width=1;
	apl.height=1;
	apl.name='apl4AnyScan';
	apl.id='apl4AnyScan';
	if(p['Result']){
		if(p['Result']['PARAMS']){
			var el = p['Result']['PARAMS'];
			if (!el['useDefaultSettings']){
				for (var k in el){
					if(typeof(el[k])!='function'){
						var par = document.createElement('PARAM');
						par.name = k;
						par.value = el[k];    
						apl.appendChild(par);
					}
				}
			}
		} 
	}
	gbiFlex(anyDocScanPanel+'.TD').appendChild(apl); 
}

function callbackFunctionName(p){
	println("callbackFunctionName started");
	println(p);
	if ((p+'')>'[]'){
		p = eval((p+'').replace(/\\/mg, '\\\\').replace(/([^{\s]+)=([^,\s}]+)/mg, "'$1':'$2'"));
		docList = p;
		getFilesBase64FromUpload(apl4ScanObjectTree);
	}
}
function anyDocScanResultFunction(p){
	println(p);
	var str=''; 
	if (p){ 
		if (p.length){
			var str = "Создан(ы) документ(ы):";
			for (var i=0;i<p.length; i++){
				str+="\n"+p[i]["ATTNAME"]+";";
			}
			showInfo(str)
		}
	}
}

function getFormName(anyDocScanPanel){
	return anyDocScanPanel.split('.').shift()
}