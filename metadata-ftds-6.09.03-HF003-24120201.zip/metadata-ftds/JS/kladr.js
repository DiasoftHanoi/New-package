/*DSMETA version = "6.01.01" hash = "5dc12eb705ef5aeff53908b9dcf4efc859b7b951"*/
// Javascript Console
try {
if (window){
var ksokr = new Array();
ksokr[0] = new Array();
ksokr[0]['id'] = '.Country';
ksokr[1] = new Array();
ksokr[1]['id'] = '.Region';
ksokr[1]["Автономная область"] = "Аобл";
ksokr[1]["Автономный округ"] = "АО";
ksokr[1]["Город"] = "г";
ksokr[1]["Край"] = "край";
ksokr[1]["Область"] = "обл";
ksokr[1]["Округ"] = "округ";
ksokr[1]["Республика"] = "Респ";
ksokr[2] = new Array();
ksokr[2]['id'] = '.District';
ksokr[2]["Автономный округ"] = "АО";
ksokr[2]["Кожуун"] = "кожуун";
ksokr[2]["Район"] = "р-н";
ksokr[2]["Территория"] = "тер";
ksokr[2]["Улус"] = "у";
ksokr[3] = new Array();
ksokr[3]['id'] = '.City';
ksokr[3]["Волость"] = "волость";
ksokr[3]["Город"] = "г";
ksokr[3]["Дачный поселок"] = "дп";
ksokr[3]["Курортный поселок"] = "кп";
ksokr[3]["Массив"] = "массив";
ksokr[3]["Поселок городского типа"] = "пгт";
ksokr[3]["Почтовое отделение"] = "п/о";
ksokr[3]["Рабочий поселок"] = "рп";
ksokr[3]["Сельская администрация"] = "с/а";
ksokr[3]["Сельский округ"] = "с/о";
ksokr[3]["Сельское муниципальное образо"] = "с/мо";
ksokr[3]["Сельское поселение"] = "с/п";
ksokr[3]["Сельсовет"] = "с/с";
ksokr[3]["Сумон"] = "сумон";
ksokr[3]["Территория"] = "тер";
ksokr[4] = new Array();
ksokr[4]['id'] = '.Town';
ksokr[4]["Аал"] = "аал";
ksokr[4]["Автодорога"] = "автодорога";
ksokr[4]["Арбан"] = "арбан";
ksokr[4]["Аул"] = "аул";
ksokr[4]["Волость"] = "волость";
ksokr[4]["Выселки(ок)"] = "высел";
ksokr[4]["Город"] = "г";
ksokr[4]["Городок"] = "городок";
ksokr[4]["Дачный поселок"] = "дп";
ksokr[4]["Деревня"] = "д";
ksokr[4]["ж/д останов. (обгонный) пункт"] = "ж/д_оп";
ksokr[4]["Железнодорожная будка"] = "ж/д_будка";
ksokr[4]["Железнодорожная казарма"] = "ж/д_казарм";
ksokr[4]["Железнодорожная платформа"] = "ж/д_платф";
ksokr[4]["Железнодорожная станция"] = "ж/д_ст";
ksokr[4]["Железнодорожный пост"] = "ж/д_пост";
ksokr[4]["Железнодорожный разъезд"] = "ж/д_рзд";
ksokr[4]["Жилой район"] = "жилрайон";
ksokr[4]["Заимка"] = "заимка";
ksokr[4]["Казарма"] = "казарма";
ksokr[4]["Квартал"] = "кв-л";
ksokr[4]["Кордон"] = "кордон";
ksokr[4]["Курортный поселок"] = "кп";
ksokr[4]["Леспромхоз"] = "лпх";
ksokr[4]["Местечко"] = "м";
ksokr[4]["Микрорайон"] = "мкр";
ksokr[4]["Населенный пункт"] = "нп";
ksokr[4]["Остров"] = "остров";
ksokr[4]["Планировочный район"] = "п/р";
ksokr[4]["Погост"] = "погост";
ksokr[4]["Поселок"] = "п";
ksokr[4]["Поселок городского типа"] = "пгт";
ksokr[4]["Поселок и(при) станция(и)"] = "п/ст";
ksokr[4]["Починок"] = "починок";
ksokr[4]["Почтовое отделение"] = "п/о";
ksokr[4]["Промышленная зона"] = "промзона";
ksokr[4]["Рабочий поселок"] = "рп";
ksokr[4]["Разъезд"] = "рзд";
ksokr[4]["Садовое неком-е товарищество"] = "снт";
ksokr[4]["Село"] = "с";
ksokr[4]["Слобода"] = "сл";
ksokr[4]["Станица"] = "ст-ца";
ksokr[4]["Станция"] = "ст";
ksokr[4]["Территория"] = "тер";
ksokr[4]["Улус"] = "у";
ksokr[4]["Хутор"] = "х";
ksokr[5] = new Array();
ksokr[5]['id'] = '.Street';
ksokr[5]["Аал"] = "аал";
ksokr[5]["Абонентский ящик"] = "а/я";
ksokr[5]["Аллея"] = "аллея";
ksokr[5]["Арбан"] = "арбан";
ksokr[5]["Аул"] = "аул";
ksokr[5]["Бульвар"] = "б-р";
ksokr[5]["Вал"] = "вал";
ksokr[5]["Въезд"] = "въезд";
ksokr[5]["Выселки(ок)"] = "высел";
ksokr[5]["Гаражно-строительный кооперат"] = "гск";
ksokr[5]["Городок"] = "городок";
ksokr[5]["Деревня"] = "д";
ksokr[5]["Дорога"] = "дор";
ksokr[5]["ж/д останов. (обгонный) пункт"] = "ж/д_оп";
ksokr[5]["Железнодорожная будка"] = "ж/д_будка";
ksokr[5]["Железнодорожная казарма"] = "ж/д_казарм";
ksokr[5]["Железнодорожная платформа"] = "ж/д_платф";
ksokr[5]["Железнодорожная станция"] = "ж/д_ст";
ksokr[5]["Железнодорожный пост"] = "ж/д_пост";
ksokr[5]["Железнодорожный разъезд"] = "ж/д_рзд";
ksokr[5]["Животноводческая точка"] = "жт";
ksokr[5]["Заезд"] = "заезд";
ksokr[5]["Казарма"] = "казарма";
ksokr[5]["Канал"] = "канал";
ksokr[5]["Квартал"] = "кв-л";
ksokr[5]["Километр"] = "км";
ksokr[5]["Кольцо"] = "кольцо";
ksokr[5]["Коса"] = "коса";
ksokr[5]["Леспромхоз"] = "лпх";
ksokr[5]["Линия"] = "линия";
ksokr[5]["Местечко"] = "м";
ksokr[5]["Микрорайон"] = "мкр";
ksokr[5]["Мост"] = "мост";
ksokr[5]["Набережная"] = "наб";
ksokr[5]["Населенный пункт"] = "нп";
ksokr[5]["Остров"] = "остров";
ksokr[5]["Парк"] = "парк";
ksokr[5]["Переезд"] = "переезд";
ksokr[5]["Переулок"] = "пер";
ksokr[5]["Планировочный район"] = "п/р";
ksokr[5]["Платформа"] = "платф";
ksokr[5]["Площадка"] = "пл-ка";
ksokr[5]["Площадь"] = "пл";
ksokr[5]["Полустанок"] = "полустанок";
ksokr[5]["Поселок"] = "п";
ksokr[5]["Поселок и(при) станция(и)"] = "п/ст";
ksokr[5]["Починок"] = "починок";
ksokr[5]["Почтовое отделение"] = "п/о";
ksokr[5]["Проезд"] = "проезд";
ksokr[5]["Просек"] = "просек";
ksokr[5]["Проселок"] = "проселок";
ksokr[5]["Проспект"] = "пр-кт";
ksokr[5]["Проток"] = "проток";
ksokr[5]["Проулок"] = "проулок";
ksokr[5]["Разъезд"] = "рзд";
ksokr[5]["Ряды"] = "ряды";
ksokr[5]["Сад"] = "сад";
ksokr[5]["Садовое неком-е товарищество"] = "снт";
ksokr[5]["Село"] = "с";
ksokr[5]["Сквер"] = "сквер";
ksokr[5]["Слобода"] = "сл";
ksokr[5]["Спуск"] = "спуск";
ksokr[5]["Станция"] = "ст";
ksokr[5]["Строение"] = "стр";
ksokr[5]["Территория"] = "тер";
ksokr[5]["Тракт"] = "тракт";
ksokr[5]["Тупик"] = "туп";
ksokr[5]["Улица"] = "ул";
ksokr[5]["Участок"] = "уч-к";
ksokr[5]["Ферма"] = "ферма";
ksokr[5]["Хутор"] = "х";
ksokr[5]["Шоссе"] = "ш";
ksokr[6] = new Array();
ksokr[6]['id'] = '';
ksokr[6]["Дом"] = "ДОМ";
}
} catch(e) {}


function formKladrString(id){
var str = getComboSelectedText(id+'.Country')+', '+getValue(id+'.PostalCode.Name');
for (var i=1;i<6;i++){
str +=', ';
var t = getValue(id+ksokr[i]['id']+'.Name');
if (t) str += t +' ' + ksokr[i][getValue(id+ksokr[i]['id']+'Type')];
}
str += ', ' + getValue(id+'.House.Name')+
', ' + getValue(id+'.Housing.Name')+ ' ' + getValue(id+'.Building.Name')+
', ' + getValue(id+'.Flat.Name');

return str
}

function formKladrStringShort(id){
var str = getComboSelectedText(id+'.Country');
if (getValue(id+'.PostalCode.Name') != '') str += ', '+getValue(id+'.PostalCode.Name')
for (var i=1; i<6; i++){
   var t = getValue(id+ksokr[i]['id']+'.Name');
   if (t != '') {
      str +=', ';
      if (i < 3) str += t +' ' + ksokr[i][getValue(id+ksokr[i]['id']+'Type')];
      else str += ksokr[i][getValue(id+ksokr[i]['id']+'Type')] + ' ' + t;
   }
}
if (getValue(id+'.House.Name') != '') str += ', д ' + getValue(id+'.House.Name');
if (getValue(id+'.Housing.Name') != '') str += ', к ' + getValue(id+'.Housing.Name');
if (getValue(id+'.Building.Name') != '') str += ', стр ' + getValue(id+'.Building.Name');
if (getValue(id+'.Flat.Name') != '') str += ', кв ' + getValue(id+'.Flat.Name');

return str
}


// если адрес не по КЛАДР
function isAddresByKLADR(shortName,pfx){
	if (window["customAddressBlockFlag"]!=true){
		pfx=nvl(pfx,"");
		var cbName = shortName+'ByKLADR'+pfx;
		var edName = shortName+'String'+pfx;
		if(checkBoxChecked(EI[cbName])) {
			showElement(EI[shortName+'Red'+pfx]);
			hideElement(EI[shortName+'Black'+pfx]); 
			setAddressVerificationMode(EI[shortName+'Block'+pfx],'avNone');
			setOutputParams(shortName+'StringByKLADR'+pfx,getValue(EI[edName])+'<br />'+'<span style="color:red">Адрес введен не по КЛАДРу</span>');
		} else {                               
			showElement(EI[shortName+'Black'+pfx]);
			hideElement(EI[shortName+'Red'+pfx]);
			setAddressVerificationMode(EI[shortName+'Block'+pfx],'avCheckOnly');
			setOutputParams(shortName+'StringByKLADR'+pfx,getValue(EI[edName]));
		}
	}
}

function clearAddressSimple (c,strEL){
	if (isEnabled(c+".Region.Name")){
		for(var b in sootKLADR){
			if (sootKLADR.hasOwnProperty(b) && (b+"").indexOf("Type")==-1) {
				println(c+"."+sootKLADR[b])
				setValue(c+"."+sootKLADR[b],"",true)
			}
        }
	 	if (gbiFlex(strEL)){
			setValue(strEL,"");
		}
		setComboOptionByText(c+".Country","РОССИЯ");
        if (window[c.replace(/[.]/gi,"_")+"_onchange"]){
		  window[c.replace(/[.]/gi,"_")+"_onchange"]();
		}
	}
}

/////////////////////////////////////////////////////////
function addressInString (addressArray) {
 var addressString  = addressArray['PostalCode'] != "" ? addressArray['PostalCode'] : "";
     addressString += addressArray['Country'] != "" ? (addressString != "" ? ", "+addressArray['Country'] : addressArray['Country']) : "";
     addressString += addressArray['Region'] != "" ? ", "+addressArray['RegionType']+" "+addressArray['Region'] : "";
     addressString += addressArray['District'] != "" ? ", "+addressArray['DistrictType']+" "+addressArray['District'] : "";
     addressString += addressArray['City'] != "" ? ", "+addressArray['CityType']+" "+addressArray['City'] : "";
     addressString += addressArray['Town'] != "" ? ", "+addressArray['TownType']+" "+addressArray['Town'] : "";
     addressString += addressArray['Street'] != "" ? ", "+addressArray['StreetType']+" "+addressArray['Street'] : "";
     addressString += addressArray['House'] != "" ? ", д."+addressArray['House'] : "";
     addressString += addressArray['Housing'] != "" ? ", корп."+addressArray['Housing'] : "";
     addressString += addressArray['Building'] != "" ? ", стр."+addressArray['Building'] : "";
     addressString += addressArray['Flat'] != "" ? ", кв."+addressArray['Flat'] : "";
     return addressString;
}