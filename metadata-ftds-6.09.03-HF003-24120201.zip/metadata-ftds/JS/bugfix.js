/*DSMETA version = "6.01.01" hash = "77cb7861292dfda897769ad96732571f90673732"*/
//////////////// Copy from FTFWF/////////////////////
////////////////////////////////////////////////////////////////////////////////
initSCFix=function (onlyISC){
	if (window["isc"]!=window.parent.isc){
		isc= window.parent.isc;
		if (!onlyISC){
			for (var ar in window.parent.Array.prototype){Array.prototype[ar]=window.parent.Array.prototype[ar]}
			for (var ar in window.parent.Array.prototype.constructor){Array.prototype.constructor[ar]=window.parent.Array.prototype.constructor[ar]}
			for (var ar in window.parent.Date.prototype){Date.prototype[ar]=window.parent.Date.prototype[ar]}
			Array.prototype.find=window.parent.Array.prototype.find;
			Array.prototype.findIndex=window.parent.Array.prototype.findIndex;
			Array.prototype.map=window.parent.Array.prototype.map;
		}
	}
}
////////////////////////////////////////////////////////////////////////////////
try{
	if (window && window["getGWTFrame"]){
		initSCFix();
	}
}catch(e){}
////////////////////////////////////////////////////////////////////////////////
try{
	if (window["getGWTFrame"]){
		FlexteraVersion="8.1";
	}else{
		FlexteraVersion="7.01";
		//////////////////////////////////////////
		if (dsCall.toString()!="function dsCall(service,method,params,callback){var res=FLX.dscall({service:service,method:method,params:params,callback:callback});return res}"){
			if (window["console"]){
				console.log("ATTENTION! dsCall is Changed! Need check dsCall realization in bugfix.js");
			}
		}
		dsCall=function (service,method,params,callback){var res=FLX.dscall({service:service,method:method,params:prepareVal(params,true),callback:genRouteFunction(callback,null,"string")});return res}
		//////////////////////////////////////////
	}
}catch(e){}
////////////////////////////////////////////////////////////////////////////////
prepareVal=function(obj,firstLevelFlag){
    var res=null;    
    if (obj instanceof window.Date){
		return obj;
	}
	if (obj instanceof Object){
      var isMap=false;
		
        for (var ar in obj){
          if (obj.hasOwnProperty(ar) && (ar+"").search(/[^0-9]/gi)>-1 && typeof(obj[ar])+""!="function"){
            isMap=true;
            break;
          }
        }
		if (obj.isMap && obj.isMap()==true){
			isMap=true;
		}
		if (firstLevelFlag==true){
			isMap=true;
		}
		if (isMap){
			res=getNewMap();
			for (var ar in obj){
				if (obj.hasOwnProperty(ar) && typeof(obj[ar])+""!="function"){
					res.put(ar,prepareVal(obj[ar]));
				}
			}
		}else{
			res=getNewList();
			var dd=obj.length;
			for (var i=0;i<dd;i++){
				res.add(prepareVal(obj[i]));
			}          
		}
		return res;
	}
    return obj;
}
////////////////////////////////////////////////////////////////////////////////
function dsCall2(a,b,c,d){
	lgr("dsCall2 " + a+"?"+b);
	dsCall(a,b,prepareVal(c,true),genRouteFunction(d));
}
////////////////////////////////////////////////////////////////////////////////
function genRouteFunction (funName,value,retType){
	retType=nvl(retType,"string");
	var uid='funct'+(new Date()).getTime();
	var uid2='functCallBack'+(new Date()).getTime();
	if (typeof funName=="function"){
		window[uid2]=funName;
	}else{
		uid2=nvl(funName,"stubFn");
	}
	var resFnString=uid+'=function(p){'+uid2+'(p,"'+value+'"); if (Ext.isIE){window["'+uid+'"]=null}else{delete window["'+uid+'"];}'+  (uid2!=funName ? ' if (window.parent.isc.Browser.isIE){window["'+uid2+'"]=null}else{delete window["'+uid2+'"];}' : "") +'};'
	var retFunct=eval(resFnString);
	if (retType=="string"){
		return uid;
	}else{
		return retFunct;
	}
}
////////////////////////////////////////////////////////////////////////////////
function stubFn(){println("stubFn");}
////////////////////////////////////////////////////////////////////////////////