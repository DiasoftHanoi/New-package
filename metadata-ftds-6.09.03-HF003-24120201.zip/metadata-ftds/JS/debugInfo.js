/*DSMETA version = "6.01.01" hash = "7ca090e0ef0718f4b6dd2c987b3243fe28cd3617"*/
function printDebugInfo(str){
//println(str);
}