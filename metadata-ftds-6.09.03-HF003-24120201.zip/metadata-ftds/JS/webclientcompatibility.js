/*DSMETA version = "6.01.01" hash = "1d774ad99dce19cf12648bc5f38bf57ed911b1ba"*/
try{
	if(isPlatform8()){
		/*
		 * Обратная совместимость фукнции getValue.
		 * Конвертирует в строку дату, если нужнен объект дата, удалить эту фукнцию
		 */
		getValue = function (object) {
		    var objectType = getGWTFrame().getObjectType(object);
		    if (objectType) {
		        if (objectType === 'TWCalendar' ||
		            objectType === 'TWCalendarLookup') {
		            return convertDate(getGWTFrame().getValue(object));
		        }
		    }
		    return  getGWTFrame().getValue(object);
		};

		/*
		 * Устанавливает параметры и производит обратный вызов
		 */
		setInputParam = function (key, value, callback) {
		    value = convertDateToJavaDate(value);
		    return getGWTFrame().setInputParam(key, value, callback);
		};
	}
}catch(e){}