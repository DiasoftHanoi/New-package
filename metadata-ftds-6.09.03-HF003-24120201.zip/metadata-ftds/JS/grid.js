/*DSMETA version = "6.01.01" hash = "3404d21dac6e2727e7fd5d7be815bb0b3646e559"*/
function simpleHighlightingRows(params){

var text    = params['TEXT'];
var color   = params['COLOR'];
var odd     = params['ODD'];
var even    = params['EVEN'];
var docList = params['TABLE'];

var dd = stringToNumeric(getRowsCount(docList))+1;
for(var i=1;i<dd;i++){
   var colId = docList+'.Item'+i+(((i%2)==0)? even:odd);
   var rowId = colId.split('.');
   rowId.pop();
   rowId = rowId.join('.');
   if (getValue(colId)==text) {
      setStyle(rowId,'backgroundColor',color);
  } else {setStyle(rowId,'backgroundColor',gbiFlex(rowId).getAttribute('RowBGColor'))}

}

}

function simpleSearchAndDo(params){

var text     = params['TEXT'];
var trueAct  = params['trueAction'];
var falseAct = params['falseAction'];
var odd      = params['ODD'];
var even     = params['EVEN'];
var docList  = params['TABLE'];

var dd = stringToNumeric(getRowsCount(docList))+1;
for(var i=1;i<dd;i++){
   var colId = docList+'.Item'+i+(((i%2)==0)? even:odd);
   var rowId = colId.split('.');
   rowId.pop();
   rowId = rowId.join('.');
   if (getValue(colId)==text) {
       eval(trueAction);
   } else {
       eval(falseAction);
   }

}
}

function getTableContent(id){
  /*  List mapov stranitsy tablitsy  */
	if (!isPlatform8()){
		var ret = getNewList();
		if (gbiFlex(id)) {
			var tblStr = id.replace(/\./g, '_');
			var tbl = eval(tblStr);
			tbl.stopEditing();
			var len = tbl.getStore().getCount();
			for (var i = 0; i < len; i++) {
				ret[i] = getNewMap();
				var m = tbl.getStore().getAt(i).data;
				for (var k in m) if (typeof(m[k]) != 'function') ret[i][k] = m[k];
			}
		}
		return ret;
	} else {
		var localTest=nvl(getSCElementByID(id).getData(),getNewMap());
		var localData=localTest.localData;
		if (localData.length>0 && localData[0]["loadingMarker"]==true){
			return getNewList();
		}
		return nvl(getRows(id),getNewList());
	}
}

function setTableAmount(id, name){
var ret = new Array();
if (gbiFlex(id)){
    var tblStr = id.replace(/\./g, '_');
    var tbl = eval(tblStr);
    tbl.stopEditing();

	var len = tbl.getStore().getCount();
	for (var i = 0; i < len; i++) {
		tbl.getStore().getAt(i).set(name,formatAmount(stringToNumeric(tbl.getStore().getAt(i).data[name]),2))
	}
}
return ret
}

function setColumnBgColor(id, colName, color){
	var n = findColumnByName(id,colName);
	if (n){
		var id2 = getLikeElementsIn(gbiFlex(id), 'div')[0].id//, attrName, attrValue)
		var id0 = '_addStyle_'+id.replace(/\./g, '_')+'_'+colName;
		var tHeader = Ext.query('TABLE',gbiFlex(id))[0];
		if (tHeader){
			var cls = (Ext.query('DIV[className]',tHeader)[0]).className.split(' ').pop().split('hd-');
			n = +cls[1]+n-1;
			var newClass = '#'+id2+' .'+cls[0]+'col-'+n;
			var newStyle = 'background-color:'+color;
			if (window.HTMLElement){
				if (!gbiFlex(id0)){
					var bod = document.getElementsByTagName('body')[0];
					var st = document.createElement('style');
					st.id = id0;
					st.setAttribute('type', "text/css");
					bod.appendChild(st);		
				}
				gbiFlex(id0).innerHTML = newClass+' {'+newStyle+'}';
			} else {
				document.styleSheets[document.styleSheets.length-1].addRule (newClass,newStyle);
			}
			} else {return 'Wrong table: '+id;}
	}
}

getSelectedRowIndex = function(id) {
  var ret = null;
  var tblStr = id.replace(/\./g, "_");
  var tbl = eval(tblStr);
  tbl.stopEditing();
  var selModel = tbl.getSelectionModel();
  if (!selModel.hasSelection()) return ret;
  return selModel.lastActive;
}