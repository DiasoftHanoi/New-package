/*DSMETA version = "6.01.01" hash = "5c16f3d46f2a120b8dd3b3b859458a8d7b60ce40"*/
function frntFormatAmount(amount, currency){
	var retVal = "";
	var currencyFullName = "рублей РФ";
	var fractionalPart = "00/100";
	var strAmount = amount + "";
	var currGroup = "";
	var idx = 0;
	var lastNumbers = new Array(
		"",
		"один",
		"два",
		"три",
		"четыре",
		"пять",
		"шесть",
		"семь",
		"восемь",
		"девять",
		"десять",
		"одиннадцать",
		"двенадцать",
		"тринадцать",
		"четырнадцать",
		"пятнадцать",
		"шестнадцать",
		"семнадцать",
		"восемнадцать",
		"девятнадцать"
	);
	
	var middleNumbers = new Array(
		"",
		"",
		"двадцать",
		"тридцать",
		"сорок",
		"пятьдесят",
		"шестьдесят",
		"семьдесят",
		"восемьдесят",
		"девяносто"
	);
	
	var firstNumbers = new Array(
		"",
		"сто",
		"двести",
		"триста",
		"четыреста",
		"пятьсот",
		"шестьсот",
		"семьсот",
		"восемьсот",
		"девятьсот"
	);
	
	var thousandsWords = new Array(
		"тысяча",
		"тысячи",
		"тысяч"
	);
	
	var thousandsLastNumbers = new Array(
		"одна",
		"две"
	);
	
	var millionWords = new Array(
		"миллион",
		"миллиона",
		"миллионов"
	);
	
	getStrByGroupId = function(amount, group){
		var retVal = "";
		var strParts = new Array();
		var currIdx = parseInt(parseInt(amount, 10)/100);
		strParts[strParts.length] = firstNumbers[currIdx];
		currIdx = parseInt(amount, 10) - (parseInt(parseInt(amount, 10)/100))*100;
		if(currIdx > 19){
			currIdx = parseInt(currIdx/10);
			strParts[strParts.length] = middleNumbers[currIdx];
			currIdx = parseInt(amount.charAt(amount.length - 1));
		}
		switch(parseInt(group)){
			case 3:
				if(parseInt(amount) > 0){
					strParts[strParts.length] = lastNumbers[currIdx];
					if(currIdx ==1){
						strParts[strParts.length] = millionWords[0];
					}else{
						if(currIdx < 5 && currIdx != 0){
							strParts[strParts.length] = millionWords[1];
						}else{
							strParts[strParts.length] = millionWords[2];
						}
					}
				}
			break;
			case 2:
				if(parseInt(amount, 10) > 0){
					if(currIdx ==1){
						strParts[strParts.length] = thousandsLastNumbers[0];
						strParts[strParts.length] = thousandsWords[0];
					}else{
						if(currIdx ==2){
							strParts[strParts.length] = thousandsLastNumbers[1];
							strParts[strParts.length] = thousandsWords[1];
						}else{
							if(currIdx < 5 && currIdx != 0){
								strParts[strParts.length] = lastNumbers[currIdx];
								strParts[strParts.length] = thousandsWords[1];
							}else{
								strParts[strParts.length] = lastNumbers[currIdx];
								strParts[strParts.length] = thousandsWords[2];
							}
						}
					
					}
				}
			break;
			case 1:
				strParts[strParts.length] = lastNumbers[currIdx];
			break;
		}
		for(var i = 0; i < strParts.length; i++){
			if(i > 0 && strParts[i] != "" && retVal != ""){
				retVal +=" ";
			}
			retVal += strParts[i];
		}
		return retVal;
	}
	if(amount != null && amount != ""){
		if(currency == "USD"){
			currencyFullName = "долларов США";
		}else{
			if(currency == "EUR"){
				currencyFullName = "Евро";
			}
		}
		retVal = strAmount;
		if(strAmount.indexOf(".") > 0){
			fractionalPart = strAmount.substr(strAmount.indexOf(".") + 1) 
			if(fractionalPart.length == 1){
				fractionalPart += "0";
				retVal += "0";
			}
			fractionalPart += "/100";
			strAmount = strAmount.substr(0, strAmount.indexOf("."));
		}else{
			retVal += ",00";
		}
		while(strAmount.length%3 > 0){
			strAmount = "0" + strAmount;
		}
		retVal += " (";
		var tmpStr = "";
		for(var i = strAmount.length/3; i >= 1; i--){
			currGroup = strAmount.substr(idx, 3);
			if(i < strAmount.length/3 && getStrByGroupId(currGroup, i) != ""){
				tmpStr += " ";
			}
			tmpStr += getStrByGroupId(currGroup, i);
			idx += 3;
		}
		tmpStr = tmpStr.charAt(0).toUpperCase() + tmpStr.substr(1);
		retVal += tmpStr + " и " + fractionalPart + ") " + currencyFullName;
	}
	return retVal.replace(".", ",");
}