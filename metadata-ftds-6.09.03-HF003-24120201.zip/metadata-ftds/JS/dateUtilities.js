/*DSMETA version = "6.01.01" hash = "6aba6169536bf45015471ce6525992032bb06d03"*/
/*
Набор функций для работ с датами в pageflow. На формах в webclient'е работать не будут!
dgrishkin
*/
function beautifulDate(someDate){
	logger.info("#####Call function beautifulDate(" + someDate + ")");
	try{
		if(someDate != null){
			if(someDate instanceof java.util.Date != true){
				var dateFormatter = new java.text.SimpleDateFormat("dd.MM.yyyy");
				tmpDate = dateFormatter.parse(someDate);
			}else{
				tmpDate = someDate;
			}
			return Packages.ru.diasoft.utils.format.FormatUtils.format(tmpDate, new java.util.Locale("RU")).toLowerCase();
		}else{
			return "";
		}
	}catch(e){
		logger.info("#####Call failed with params: ");
		logger.info("#####someDate: " + someDate);
	}
}

function getProperDate(invalidDate){
	try{
		logger.info("#####Call function getProperDate(" + invalidDate + ")");
		if(invalidDate != null && invalidDate instanceof java.util.Date){
			var properDate = new java.util.GregorianCalendar();
			properDate.setTime(invalidDate);
			if(properDate.get(java.util.Calendar.getInstance().MILLISECOND) > 0){
				properDate.add(java.util.Calendar.getInstance().MILLISECOND, 1000 - properDate.get(java.util.Calendar.getInstance().MILLISECOND));			
			}
			if(properDate.get(java.util.Calendar.getInstance().SECOND) > 0){
				properDate.add(java.util.Calendar.getInstance().SECOND, 60 - properDate.get(java.util.Calendar.getInstance().SECOND));
			}
			return properDate.getTime();
		}
		return invalidDate
	}catch(e){
		logger.info("#####Call failed with params: ");
		logger.info("#####invalidDate: " + invalidDate);
	}
}

function prilWordGen(value){
	var loanRepaymentDateGen="";
	if (parseInt(value)==1) loanRepaymentDateGen="Первого";
	if (parseInt(value)==2) loanRepaymentDateGen="Второго";    
	if (parseInt(value)==3) loanRepaymentDateGen="Третьего";    
	if (parseInt(value)==4) loanRepaymentDateGen="Четвертого";    
	if (parseInt(value)==5) loanRepaymentDateGen="Пятого";    
	if (parseInt(value)==6) loanRepaymentDateGen="Шестого";    
	if (parseInt(value)==7) loanRepaymentDateGen="Седьмого";    
	if (parseInt(value)==8) loanRepaymentDateGen="Восьмого";    
	if (parseInt(value)==9) loanRepaymentDateGen="Девятого";    
	if (parseInt(value)==10) loanRepaymentDateGen="Десятого";    
	if (parseInt(value)==11) loanRepaymentDateGen="Одиннадцатого";    
	if (parseInt(value)==12) loanRepaymentDateGen="Двенадцатого";    
	if (parseInt(value)==13) loanRepaymentDateGen="Тринадцатого";    
	if (parseInt(value)==14) loanRepaymentDateGen="Четырнадцатого";    
	if (parseInt(value)==15) loanRepaymentDateGen="Пятнадцатого";    
	if (parseInt(value)==16) loanRepaymentDateGen="Шестнадцатого";    
	if (parseInt(value)==17) loanRepaymentDateGen="Семнадцатого";    
	if (parseInt(value)==18) loanRepaymentDateGen="Восемнадцатого";    
	if (parseInt(value)==19) loanRepaymentDateGen="Девятнадцатого";    
	if (parseInt(value)==20) loanRepaymentDateGen="Двадцатого";    
	if (parseInt(value)==21) loanRepaymentDateGen="Двадцать первого";    
	if (parseInt(value)==22) loanRepaymentDateGen="Двадцать второго";    
	if (parseInt(value)==23) loanRepaymentDateGen="Двадцать тертьего";    
	if (parseInt(value)==24) loanRepaymentDateGen="Двадцать четвертого";    
	if (parseInt(value)==25) loanRepaymentDateGen="Двадцать пятого";    
	if (parseInt(value)==26) loanRepaymentDateGen="Двадцать шестого";    
	if (parseInt(value)==27) loanRepaymentDateGen="Двадцать седьмого";    
	if (parseInt(value)==28) loanRepaymentDateGen="Двадцать восьмого";    
	if (parseInt(value)==29) loanRepaymentDateGen="Двадцать девятого";    
	if (parseInt(value)==30) loanRepaymentDateGen="Тридцатого";    
	if (parseInt(value)==31) loanRepaymentDateGen="Тридцать первого";

	return loanRepaymentDateGen;
}

function prilWordNative(value){
	var loanRepaymentDateGen="";
	if (parseInt(value)==1) loanRepaymentDateGen="Первое";
	if (parseInt(value)==2) loanRepaymentDateGen="Второе";    
	if (parseInt(value)==3) loanRepaymentDateGen="Третье";    
	if (parseInt(value)==4) loanRepaymentDateGen="Четвертое";    
	if (parseInt(value)==5) loanRepaymentDateGen="Пятое";    
	if (parseInt(value)==6) loanRepaymentDateGen="Шестое";    
	if (parseInt(value)==7) loanRepaymentDateGen="Седьмое";    
	if (parseInt(value)==8) loanRepaymentDateGen="Восьмое";    
	if (parseInt(value)==9) loanRepaymentDateGen="Девятое";    
	if (parseInt(value)==10) loanRepaymentDateGen="Десятое";    
	if (parseInt(value)==11) loanRepaymentDateGen="Одиннадцатое";    
	if (parseInt(value)==12) loanRepaymentDateGen="Двенадцатое";    
	if (parseInt(value)==13) loanRepaymentDateGen="Тринадцатое";    
	if (parseInt(value)==14) loanRepaymentDateGen="Четырнадцатое";    
	if (parseInt(value)==15) loanRepaymentDateGen="Пятнадцатое";    
	if (parseInt(value)==16) loanRepaymentDateGen="Шестнадцатое";    
	if (parseInt(value)==17) loanRepaymentDateGen="Семнадцатое";    
	if (parseInt(value)==18) loanRepaymentDateGen="Восемнадцатое";    
	if (parseInt(value)==19) loanRepaymentDateGen="Девятнадцатое";    
	if (parseInt(value)==20) loanRepaymentDateGen="Двадцатое";    
	if (parseInt(value)==21) loanRepaymentDateGen="Двадцать первое";    
	if (parseInt(value)==22) loanRepaymentDateGen="Двадцать второе";    
	if (parseInt(value)==23) loanRepaymentDateGen="Двадцать третье";    
	if (parseInt(value)==24) loanRepaymentDateGen="Двадцать четвертое";    
	if (parseInt(value)==25) loanRepaymentDateGen="Двадцать пятое";    
	if (parseInt(value)==26) loanRepaymentDateGen="Двадцать шестое";    
	if (parseInt(value)==27) loanRepaymentDateGen="Двадцать седьмое";    
	if (parseInt(value)==28) loanRepaymentDateGen="Двадцать восьмое";    
	if (parseInt(value)==29) loanRepaymentDateGen="Двадцать девятое";    
	if (parseInt(value)==30) loanRepaymentDateGen="Тридцатое";    
	if (parseInt(value)==31) loanRepaymentDateGen="Тридцать первое";
	
	return loanRepaymentDateGen;
}