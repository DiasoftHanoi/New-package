/*DSMETA version = "6.01.01" hash = "8c154928501f3b2ac263a950fdd584f8ee511691"*/
function CheckAmount(edit) {
  var summ = getValue(edit)+"";
  var newsumm='';
  for (i=0;i<summ.length;i++){
    if ((summ.substr(i,1) != '.')&&(summ.substr(i,1) != ',')) {
      newsumm=newsumm + summ.substr(i,1);
    }
  }
  setValue(edit,newsumm);
}

function submForm3(frm) {
window.allErrors = '';
errorSoob = new Function('el','window.allErrors += getErrorMessage(el.id)+"\\n";');
     getObInp(frm);
     var tt = obInp.length;
     var err = '';
     var flaag = true;
     var el;
   //  var allErrors = '';
     frm.elements[(frm.elements.length - 1)].className = frm.elements[(frm.elements.length - 1)].className.replace('error ', '');
     /* первая проверка - на заполненность обязательных полей */
     for (var i = 0; i < tt; i++) {
          el = frm.elements[obInp[i]];
          if (!!el.type) {
               el.className = el.className.replace('error ', '');
          }
          else {
               el[0].className = el[0].className.replace('error ', '');
          }

        if (el['ReqValue']=='True') {

           flaag = false;
           elem = el;
           var t = el.type.substring(0, 3);

  switch (t) {
   case 'sel': flaag = provSelect2(el);break;
   case 'che': flaag = provCheckbox(el);break;
   case 'tex': flaag = provEl1(el, 'submit');break;
   case 'pas': flaag = provEl1(el, 'submit');break;
   case 'hid': flaag = provEl1(el, 'submit');break;
         }
       }
 }
    if (window.allErrors!='')
      {
      alert(window.allErrors);
      }
errorSoob = new Function('el','var err = getErrorMessage(el.id);alert(err);if (isVisibleEl(el) && window.event && window.event.srcElement != el){try{el.focus();}catch(e){}}');
     return window.allErrors;
}


function submForm3NoAlert(frm) {
window.allErrors = '';
errorSoob = new Function('el','window.allErrors += getErrorMessage(el.id)+"\\n";');
     getObInp(frm);
     var tt = obInp.length;
     var err = '';
     var flaag = true;
     var el;
   //  var allErrors = '';
     frm.elements[(frm.elements.length - 1)].className = frm.elements[(frm.elements.length - 1)].className.replace('error ', '');
     /* первая проверка - на заполненность обязательных полей */
     for (var i = 0; i < tt; i++) {
          el = frm.elements[obInp[i]];
          if (!!el.type) {
               el.className = el.className.replace('error ', '');
          }
          else {
               el[0].className = el[0].className.replace('error ', '');
          }

        if (el['ReqValue']=='True') {

           flaag = false;
           elem = el;
           var t = el.type.substring(0, 3);

  switch (t) {
   case 'sel': flaag = provSelect2(el);break;
   case 'che': flaag = provCheckbox(el);break;
   case 'tex': flaag = provEl1(el, 'submit');break;
   case 'pas': flaag = provEl1(el, 'submit');break;
   case 'hid': flaag = provEl1(el, 'submit');break;
         }
       }
 }

errorSoob = new Function('el','var err = getErrorMessage(el.id);alert(err);if (isVisibleEl(el) && window.event && window.event.srcElement != el){try{el.focus();}catch(e){}}');
     return window.allErrors;
}

function panelReadOnly(id){
            var w=gbiFlex(id);
            var ar = ['INPUT','SELECT','TEXTAREA','BUTTON'];
            var dd = ar.length;
            for (var i=0;i<dd;i++){
                        var tmp = getLikeElementsIn(w, ar[i], 'id');
                        var d2 = tmp.length;
                        for (var j=0;j<d2;j++) diselem(tmp[j])
            };
            var tmp = getLikeElementsIn(w, 'DIV', 'tagtype', 'table');
            var d2 = tmp.length;
            for (var j=0;j<d2;j++) disTable(tmp[j].id);
            var tmp = Ext.query('DIV[tagtype=calendar][id^='+id+'] IMG');
            var d2 = tmp.length;
            for (var j=0;j<d2;j++) diselem(tmp[j]);
			var io = document.activeElement; if (io.id) setValue(io.id,getValue(io.id));
            setFocusInMinTA();
}

function disTable(id){
  var tbl = eval(id.replace(/\./g,'_'));
  tbl.selModel.locked=true;
  for (var k in tbl.events) {
            if (typeof(tbl.events[k])=='object')
                        tbl.events[k] = true;
  }
}

function setVotingPanel(checkNo, checkYes, voteEdit, checkFlag) {

   if (checkFlag == "NO") {
   
      if (checkBoxChecked(checkNo)) {
         setCheckBoxChecked(checkYes, false);
         disableElement(voteEdit);
         setValue(voteEdit, "");
         setErrorClass(voteEdit,false);
      }
   }
   
   if (checkFlag == "YES") {
   
      if (checkBoxChecked(checkYes)) {
         setCheckBoxChecked(checkNo, false);
         enableElement(voteEdit);
      } 
	  else {
	     disableElement(voteEdit);
		 setValue(voteEdit, "");
      }		 
   }
}

function getErrorClass(id) {
    var el = gbiFlex(id);
    var str = el.className;
if (str =='error ')return true;
else return false;
}

function setUnderlinedText (id, flag) {
  if(!isPlatform8()){
    //id = id.replaceAll('.','_');
    var el = gbiFlex(id);
    if (el) {
	  if (flag == true) {
	    el.setAttribute('class','undrl');
      } 
	  else {
        el.setAttribute('class','');
      }
	}
  }
  else{
   if (flag == true) {
     setCSSClass(id, "undrl");  
   }
   else setCSSClass(id, "");  
  }
}

//элементы формы
function getFormAllIds() {
	EI = [];
	var eIds = getAllIds();
	for ( var i = 0; i < eIds.size(); i++){
	  var elID = eIds.get(i)
	  var idxDot = elID.lastIndexOf(".")
	  if (idxDot == -1) {
	    idxDot = elID.lastIndexOf("_");
	    if (idxDot == -1){idxDot = 0;}
        else { idxDot++;}
      } 
	  else { idxDot++; }

   EI[elID.substring(idxDot)] = elID.replace(/_/g,'.');

   }
	return EI;
}

function simpleDecimalToWords(number){
   try {
   var javaNames = JavaImporter();
   javaNames.importPackage(Packages.java.util);
   javaNames.importPackage(Packages.java.text);
   javaNames.importPackage(Packages.ru.diasoft.utils.format.money);
   number = number + "";
   var tempArray = number.split(".") ;
   var intactPart = tempArray[0] ;
   var fractionalPart = tempArray[1] ;
   var intactText = "" ;
   var fractionalText = "" ;
   var isOne = false ;
   var isNoFrac = false ;
   
   if(parseInt(tempArray.length) == 1){
       fractionalPart = "" ;
       isNoFrac = true ;
   } else if(parseInt(fractionalPart) == 0) {
       fractionalPart = "" ;
       isNoFrac = true ;
   } else {
       fractionalText = javaNames.MoneyFormatUtils.toWords(new java.math.BigDecimal(fractionalPart), "RUB")+"" ;
       fractionalText = fractionalText.substring(0, fractionalText.indexOf("рубл") - 1);
       fractionalText = fractionalText.toLowerCase() ;
       if(fractionalText.slice((fractionalText.length-2)) == "ва"){                      
          fractionalText = fractionalText.substring(0,(fractionalText.length-2))+"ве" ;
       }
       if(fractionalText.slice((fractionalText.length-2)) == "ин"){                      
          fractionalText = fractionalText.replace("один","одна");
          isOne = true ;
       } 
   }
   
   intactText = javaNames.MoneyFormatUtils.toWords(new java.math.BigDecimal(intactPart), "RUB")+"" ;
   intactText = intactText.substring(0, intactText.indexOf("рубл") - 1);
   intactText = intactText.toLowerCase() ;
   
   if((intactText.slice((intactText.length-2)) == "ва")&&(isNoFrac == false)){                      
      intactText = intactText.substring(0,(intactText.length-2))+"ве" ;
   }
   if((intactText.slice((intactText.length-2)) == "ин")&&(isNoFrac == false)){                      
      intactText = intactText.replace("один","одна") + " целая" ;
   } else if(isNoFrac == false){
      intactText = intactText + " целых" ;
   }
   
   var numberText = "" ;
   switch(parseInt(fractionalPart.length)){
       case 0 : numberText = intactText; break ;
       case 1 : numberText = intactText + " и " + fractionalText + " десятых" ; break ;
       case 2 : numberText = intactText + " и " + fractionalText + " сотых" ; break ;
       case 3 : numberText = intactText + " и " + fractionalText + " тысячных" ; break ;
       case 4 : numberText = intactText + " и " + fractionalText + " десятитысячных" ; break ;
       case 5 : numberText = intactText + " и " + fractionalText + " стотысячных" ; break ;
   } 
   
   if(isOne == true) {
      numberText = numberText.substring(0,(numberText.length-2))+"ая" ;
   }
   return numberText ;
   } catch (e) {
   
   }
}

function simpleNumberToPercents(number) {
   try {
   var words = simpleDecimalToWords(number) ;
   var percents = "" ;
   var ending = words.slice((words.length-2)) ;
   if((ending == "ых") || (ending == "ая") ||(ending == "ва")||(ending == "ри")||(ending == "ре")){
       percents = "процента" ;       
   } else if(ending == "ин") {
       percents = "процент" ;
   } else {
       percents = "процентов" ;
   }
   return percents ;
   } catch (e) {
   
   }
}

function parseDateFromString(str){

 var dateFormat = new java.text.SimpleDateFormat("dd.MM.yyyy"); 

 if (str !=null){
   var n = str.split(' ');
   switch (n[1]+''){
     case "Jan": n[1]="01";break;
     case "Feb": n[1]="02";break;
     case "Mar": n[1]="03";break;
     case "Apr": n[1]="04";break;
     case "May": n[1]="05";break;
     case "Jun": n[1]="06";break;
     case "Jul": n[1]="07";break;
     case "Aug": n[1]="08";break;
     case "Sep": n[1]="09";break;
     case "Oct": n[1]="10";break;
     case "Nov": n[1]="11";break;
     case "Dec": n[1]="12";break;
  }
   var date = n[2]+ "."+ n[1]+ "."+ n[5];
   date = dateFormat.parse(date);
   return date;
 }
 else return str; 
}
function checkForm (formName, flag) {
    var checkFormList = getInputParams("checkFormList");
	if(checkFormList!=null && typeof(checkFormList) == "object")
	{
    for (var i = 0; i< checkFormList.size();i++)
        {
        if (formName == checkFormList.get(i).get("FORMSYSNAME"))
           {
           checkFormList.get(i).put("FLAG", flag);
           }
        }
    setOutputParams("checkFormList", checkFormList);
	}
}

function setMaskInnOgrn(opf,elIdInn,elIdOgrn){
  if(elIdInn) setInputKind(elIdInn,'dfNone');
  if(elIdOgrn) setInputKind(elIdOgrn,'dfNone');
  if (opf =='ИП') {
    if(elIdInn) setInputMask(elIdInn,'############');
    if(elIdOgrn)setInputMask(elIdOgrn,'###############');
  }
  else {
    if(elIdInn) setInputMask(elIdInn,'##########');
    if(elIdOgrn) setInputMask(elIdOgrn,'#############');
  }
}
function provEl1(el, sob) {
    var e = e || window.event;
    var re = new RegExp(getParam(el, 'InputCheckValueRX'));
    var str = getValue(el.id);
    var ik = el.getAttribute('InputKind');
    if (ik == "dfRusIndex") { 
        var onch = ''+el.onchange;
        onch = ''+onch.match(/validateKladr.*\)/g);
        if (onch) eval(onch.replace(')',',1)'));
    }
    if (ik == 'dfAccount' && !el.getAttribute('InputMask')) str = str.replace(/\s/g, '').replace(/&nbsp;/g, '');
    if (ik == 'dfAmount') str = str != null ? str.replace(/\s/g, '').replace(/&nbsp;/g, '').replace(/,/,'.') : '';
    if (ik == 'dfDate' && str == '')if(sob != 'submit') return true;   
    var cleanStr = clearValue(str, getParam(el, 'InputMask'));
    var flag = re.test(cleanStr);
    if (flag)
        if (el.getAttribute('InputMask'))
            flag = checkMask(el);
    if (flag)
        flag = eval(getParam(el, 'addPr'));
    if (flag)
        flag = MLTextarea(el, e);
    if (flag)
        flag = MinLenText(el, e);
    if (!flag) {
        setErrorMark(el.id, true);
    }
    else {
        setErrorMark(el.id, false);
    }
    return flag;
}
