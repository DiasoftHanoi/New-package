/*DSMETA version = "6.01.01" hash = "f1e452c95bdc303ec1b37a58b51f2f19549e7ec5"*/
function hideModalLoaderEvent(){
   if (window["waitFormEvent"]!=null) {clearTimeout(window["waitFormEvent"]);} window["waitFormEvent"]=setTimeout('hideModalLoader()', 300)
}
////////////////////////////////////////////////////////////////////////////////
function hideModalLoader(){
   println("hideModalLoader: "+window["createModalLoaderCounter"]);
   window["createModalLoaderCounter"]--;
   if (window["waitForm"]!=null && window["createModalLoaderCounter"]==0){
      window["waitForm"].hide();
   }
   onShowFlag = false;
}
////////////////////////////////////////////////////////////////////////////////
function createModalLoader(text) {
    window["waitFormEvent"]=nvl(window["waitFormEvent"],null);
    window["waitForm"]=nvl(window["waitForm"],null);
	window["createModalLoaderCounter"]=nvl(window["createModalLoaderCounter"],0);
	
	window["createModalLoaderCounter"]++;
    println("createModalLoader: "+window["createModalLoaderCounter"]);
	
    var loadMask=(new Ext.LoadMask(Ext.getBody(), {msg: nvl(text,myTxt.progress3), removeMask: true}));
    loadMask.show();
    var els=Ext.query("DIV[class*=x-mask-loading]");
    if (els.length>0){
      var el=Ext.query("DIV[class*=x-mask-loading]")[0].previousSibling;
      if (el.className=="ext-el-mask"){
        el.style.zIndex=10000;
        var maskHeight=getFormHeight();
        if (maskHeight<getHeight(Ext.query("body")[0].getAttribute("id"))){
            maskHeight= getHeight(Ext.query("body")[0].getAttribute("id"));
        }
        el.style.height=maskHeight;
      }
    }
    if (waitFormEvent!=null) {clearTimeout(waitFormEvent);}    
    waitForm=loadMask;
	return waitForm;
}