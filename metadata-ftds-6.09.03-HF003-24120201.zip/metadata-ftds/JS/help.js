/*DSMETA version = "6.01.01" hash = "9ab84cf4363df45bd0dfbe39e437731ba30b8415"*/
function getHelp(openHelpTitle){
	if (!window.formHelper){
        window.formHelper=[];
	}
	
	window.formHelper.openHelpTitle=openHelpTitle;
	dsCall('[frontws2]','isHelpEditable',[],'onAfterCheckHelpMode');
}
////////////////////////////////////////////////////////////////////////
function onAfterCheckHelpMode(p){
	if (!!p){
		window.formHelper.editableHelp = !!p['Result']['ISHELPEDITABLE']; //<ISHELPEDITABLE>true</ISHELPEDITABLE> in common-config.xml
	};
	var par = {'HELPTITLE':window.formHelper.openHelpTitle};
	par['IGNOREROLES']=true;
	dsCall('[frontws2]','helpGetListByParams', par, 'onAfterGetHelpData');
}
////////////////////////////////////////////////////////////////////////
function onAfterGetHelpData(p){
	if (p['Result']){
		var helpData=p['Result'][0];
		helpData= helpData==null ? [] : helpData;
		helpData["HELPTITLE"]=window.formHelper.openHelpTitle;
		if (window.formHelper.editableHelp==true || window.formHelper.editMode==true){
			ShowModalWindow ("/ADMIN/HELPER/helpEditor", 600, 600, helpData, "Редактор справки - " + window.formHelper.openHelpTitle, "onAfterHelpEdit");
		}else{
			frameID=(new Date()).getTime();
  			window.formHelper.win = new Ext.Window({
                		"width":500,
                		"height":300,
                		"resizable":true,
                		"closable":true,
                		"minWidth":300,
                		"minHeight":300,
                		"modal": false,
                		"html": "<iframe id='"+frameID+"' name='"+frameID+"' frameborder='0' width='100%' height='100%' marginheight='0' marginwidth='0'>Ошибка отображения отчета</iframe>",
                		"autoScroll":true,
                		"bodyStyle": "background-color:white; padding: 0 0 0 10"
                		});
  			window.formHelper.win.show();
  			gbiFlex(frameID+"").contentWindow.document.write(nvl(helpData["HELPTEXT"],""));
			window.formHelper.win.setTitle(nvl(helpData["DESCRIPTION"],""));
		}
	}
}
function onAfterHelpEdit(){}


