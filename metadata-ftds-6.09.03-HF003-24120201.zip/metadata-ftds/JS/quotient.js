/*DSMETA version = "6.01.01" hash = "4629f249d5528214dcdbc8ffb7f1cdcf74361024"*/
function getQuotientResult (qrlist, id) {
	if (qrlist != null) {
		for (var k = 0; k < qrlist.size(); k++) {
			if (qrlist.get(k).get("QuotientID") == id) {
				var res = qrlist.get(k).get("QuotientResult");
                            if(res==null || !isFinite(res) || isNaN(res)) res=0;
				if (res >= 100) res = formatSumm(parseFloat(res));
				else res = formatSumm(Math.round(res * 10000) / 10000.0);
				return res;
			}
		}
	}
	return null;
}

function getIdList(formulaParamList){
	var idList = getNewList();
	if (formulaParamList != null && typeof(formulaParamList) == "object") {
		var sz = formulaParamList.size();       
	    for (var i = 0; i < sz; i++) {
	    	var linkID = formulaParamList.get(i).get("LinkID");
	    	var notFound = true;
	    	for (var j = 0; j < idList.size(); j++) {
	    		if (idList.get(j).get("QuotientID") == linkID) {
	    			notFound = false;
	    			break;
	    		}
	    	}
	    	if (notFound) {
	    		var idmap = getNewMap();
	    		idmap.put("LinkID", linkID); 
	    		idmap.put("QuotientID", linkID);
	    		idList.add(idmap);
	    	}
	    }      
	}
	return idList;
}

function updateQuotientParams(sysname, value, formulaParamList) {
	if (formulaParamList != null && typeof(formulaParamList) == "object") {
		var sz = formulaParamList.size();   	    
	    for (var i = 0; i < sz; i++) {
	    	if (formulaParamList.get(i).get("ParamSysName") == sysname)  {
	    		formulaParamList.get(i).put("ParamValue", value); 
	    	}
		}       
	}
}