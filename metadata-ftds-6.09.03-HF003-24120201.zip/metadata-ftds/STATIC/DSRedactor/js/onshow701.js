onshowFnc=function(){

	isCtrl = false;

	Ext.get(document).on("keyup",function(e){ if(e.keyCode == 17) isCtrl=false; });
	Ext.get(document).on("keydown",function(e) {  if(e.keyCode == 17) isCtrl=true;});


	resizeFlag=false;
	searchParams=getNewMap();
	quickSearchEvent=null;
	quickSearchParamEvent=null;
	quickSearchParamTypeEvent=null;
	quickSearchDepartmentEvent=null;
	resizeFormEvent=null;

	setCoordY(EI["wrapper"],0);
	setCoordX(EI["contentPnl"],0);
	
	var treeList=getInputParams("smStateTree");
	//Tree products and panels
	new Ext.Panel({
		layout: 'border',
		renderTo: EI["wrapper"],
		id: "DSContainer",
		height:getHeight(EI["wrapper"]),
		items: [{
			region: 'west',
			id: 'stateNav', 
			title: gRB('DSRedactor.objectAndStates'),
			backgroundColor:"#F0F0F0",
			split: true,
			width: getWidth(EI["treePnl"]),
			minSize: 175,
			maxSize: 400,
			collapsible: true,
			//margins: '0 0 0 0',
	        items: [{
						id:"stateNav_Container",
						border: false,
						contentEl:gbi(EI["treePnl"]),
						height: getHeight(EI["treePnl"]),
						collapsible: false
					}
				]
            },
 			{
				id:"Content",
				title:gRBT("DSRedactor.parameters","..."),
				region: 'center',
				contentEl:gbi(EI["contentPnl"]),
				xtype: 'panel'
            }
			
			]
	});

	Ext.getCmp(EI["StatesTree"]+"_tree").on("click",stateDialog.clickStateTreeNode);
	
	
	Ext.getCmp("stateNav").on("resize",onResizeNavigator);
	Ext.getCmp("stateNav").on("collapse",onResizeNavigator);
	Ext.getCmp("stateNav").on("expand",onResizeNavigator);
	
	Ext.get(EI["stateSearch"]).on("keydown",function(){if (quickSearchEvent!=null) {clearTimeout(quickSearchEvent);} quickSearchEvent=setTimeout('refreshStateTree()', 500)});
	

	Ext.getCmp(EI["StatesTree"]+"_tree").setRootNode(getInputParams("smStateTree"));
	Ext.getCmp(EI["StatesTree"]+"_tree").collapseAll();
	Ext.getCmp(EI["StatesTree"]+"_tree").getRootNode().eachChild(setTreeNodeHint,this); 
	

	hideElement(EI["indPanel"]);
	showElement(EI["wrapper"]);
	resizeFormCommon();
	//setTimeout("resizeForm()",300);
}  



