////////////////////////////////////////////////////////////////////////////////
editProductDialog=function(){
   alert("editProductDialog");
}
////////////////////////////////////////////////////////////////////////////////
editNodeDialog=function(node){
	selectNodeByPath(node.getPath());
	var attr=node.attributes;
	var ntype=attr.ntype;  
	if (ntype=="product"){ productDialog.editProductDialogShow();}
	//if (ntype=="productGroup"){groupDialog.editGroupDialogShow();}  
}
////////////////////////////////////////////////////////////////////////////////
selectNodeByPath=function(path,id){
	return Ext.getCmp(id).selectPath(path);
}
////////////////////////////////////////////////////////////////////////////////
onResizeNavigator=function(el, adjWidth){
   lgr("onResizeNavigator",el,adjWidth);
   adjWidth=stringToNumeric(adjWidth);
   adjWidth= adjWidth==0 ? Ext.getCmp("stateNav").getWidth() : adjWidth ;
   resizeFormCommon();
}
////////////////////////////////////////////////////////////////////////////////
showInactive=function(el){
   var elUI= el.getUI();
   elUI.activeHidden=el.hidden;
   el.getUI().show();
}
////////////////////////////////////////////////////////////////////////////////
hideInactive=function(el){
   var elUI= el.getUI();
   if (elUI.activeHidden==true){
      el.getUI().hide();
   }
}
////////////////////////////////////////////////////////////////////////////////
createNewTreeNode=function(id,nodeData,parentNodeID){
	var tree=Ext.getCmp(id);
	var parentNode=tree.getNodeById(parentNodeID);
	console.log(parentNode);
	var newNode=new Ext.tree.TreeNode(nodeData);
	console.log(newNode);
	parentNode.appendChild(newNode);
	setTreeNodeHint(newNode,null,true);
}
////////////////////////////////////////////////////////////////////////////////
setViewStateNode=function(el){
	var attr=el.attributes;
	var searchString=(searchParams["searchString"]+"").toUpperCase();
	var isShow=true;
	var elUI= el.getUI();
	var checkStringFlag=((el.text+"").toUpperCase()).indexOf(searchString)>-1;
   
    if (checkStringFlag && searchString!=""){
		if (attr["ntype"]=="smObject"){
			Ext.getCmp(EI["StatesTree"]+"_tree").expandPath(el.getPath());
		}
	}
    
   
   if (isShow){
       elUI.show();
   }else{
      elUI.hide();
   }   
   el.eachChild(setViewStateNode,this);
}
////////////////////////////////////////////////////////////////////////////////
setTreeNodeHint=function(el,text,propFlag){
   var attr=el.attributes;
   var hintText=nvl(text,attr["descr"],"")+"";
   hintText=hintText.replace(/&lt;/gi,"<").replace(/&gt;/gi,">");
   var elNode= el.getUI().elNode;
   //console.log(el);
   
   if (el["tooltip"]!=null){
      el["tooltip"].destroy();
   }
	
	el.tooltip=new Ext.ToolTip({
			target: elNode,
			html: hintText,
			anchor: 'left',
			anchorOffset: 0
	});
    if (propFlag==null){
      el.eachChild(setTreeNodeHint,this);
	}
}
////////////////////////////////////////////////////////////////////////////////
refreshStateTree=function(){
   searchParams=getNewMap();
   searchParams["searchString"]=getValue(EI["stateSearch"]);
   if (searchParams["searchString"]!=""){
		Ext.getCmp(EI["StatesTree"]+"_tree").collapseAll();
   }
   Ext.getCmp(EI["StatesTree"]+"_tree").getRootNode().eachChild(setViewStateNode,this);    
}
////////////////////////////////////////////////////////////////////////////////
setInactiveAtribute=function(el){
    if (el.hidden==true){
       el.inactive=true;
    }else{
      el.inactive=false;
    }
}
////////////////////////////////////////////////////////////////////////////////
generateComboProductGroupItem= function(id,node,depth,curNodeID){
   //addComboOption(id,node["attributes"]["PRODUCTGROUPID"],node["text"]);
   var childNodes=node.childNodes;
   var dd= childNodes.length;
   for (var i=0;i<dd;i++){
      var children=childNodes[i];
      //console.log(children);
      if (children["attributes"]["ntype"]=="productGroup" && curNodeID!=children["attributes"]["PRODUCTGROUPID"]){
         var margin="";
         for (var j=0;j<depth*5;j++){
            margin+="-";
         }
         addComboOption(id,  children["attributes"]["PRODUCTGROUPID"],margin+" "+children["attributes"]["GROUPNAME"]);
         generateComboProductGroupItem(id,children,depth+1,curNodeID);
      }
   }
}
///////////////////////////////////////////////////////////////////////////////
fillComboProductGroup=function(id,curNodeID){
	var root=Ext.getCmp("productTree").getRootNode();
	clearComboOptions(id);
	addComboOption(id,"0",gRB("DSRedactor.rootElement"));
	generateComboProductGroupItem(id,root,1,curNodeID);
}


