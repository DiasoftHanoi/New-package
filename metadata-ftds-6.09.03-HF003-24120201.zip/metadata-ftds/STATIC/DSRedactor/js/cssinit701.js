crDynEl=function (tag, p, parent){ 
   if (!parent){return false;}
   p['width'] = p['width']||'100%'; 
   p['height'] = p['height']||'100%'; 
   var el = document.createElement(tag); 
   var onev = {}; 
   for (var k in p){ 
      if (/^on/i.test(k)){ 
	     addHandler(el, k.replace(/^on/i,''), p[k])
	   } else{
 	     if (typeof(p[k])!='function'){
            switch (k) {
				case 'style':el.style.cssText = p[k];break; case 'class':el.setAttribute('className',p[k]);el.setAttribute('class',p[k]);break;
				default: el.setAttribute(k,p[k])
			}
		  }
	   }
	}
	parent.appendChild(el);
	return true;
}
////////////////////////////////////////////////////////////////////////////////
crDynEl('link', {'rel':'stylesheet','type':'text/css', 'href': js.rootUrl+"DSRedactor/css/DSRedactor.css"}, Ext.query('HEAD')[0]);
Ext.each(Ext.query("*[name=barvalue]"),function(item){Ext.get(this).addClass("barvalue")});