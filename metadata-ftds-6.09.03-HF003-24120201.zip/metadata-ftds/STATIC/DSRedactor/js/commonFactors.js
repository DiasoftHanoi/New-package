﻿/////////////////////////////////////////////////////////////////
commonFactorsConstructor=function(){
	var commonFactorsDialog=new Object();
	commonFactorsDialog.curoper="none";

	commonFactorsDialog.panel=createExpandPanel(EI["tbCommonFactors"],EI["contentPnl"],{title:gRB("DSRedactor.commonFactors")});
	commonFactorsDialog.window=createSimpleModal2(EI["commonFactorsPnl"]);

	///////////////////////////////////////////////////////////////////////
	commonFactorsDialog.getContextMenu=function(){
		var attr=getSelectedRow(EI["tbCommonFactors"]);
		var trFl="true";
		var createMenu= getNewList(); 
		addMenuItem(createMenu,gRB("DSRedactor.addCommonFactor"),"",trFl,"SCRIPT","", "commonFactorsDialog.addCommonFactorsDialogShow()","");  
		if (attr!=null & attr!==""){
				addMenuItem(createMenu,gRB("DSRedactor.editCommonFactor"),"",trFl,"SCRIPT","", "commonFactorsDialog.editCommonFactorsDialogShow()",""); 
				addMenuItem(createMenu,gRB("DSRedactor.delCommonFactor"),"",trFl,"SCRIPT","", "commonFactorsDialog.delCommonFactorsDialogShow()",""); 
		}
		return createMenu; 	
	}
	///////////////////////////////////////////////////////////////////////
	commonFactorsDialog.addCommonFactorsDialogShow=function(){
		if (stateDialog.selectedStateID!=null){
			commonFactorsDialog.window.setTitle(gRB("DSRedactor.addCommonFactor"));
			setValue(EI["edCommonFactorName"],"");
			setValue(EI["edCommonFactorSysname"],"");
			setComboOptionByValue(EI["cmCommonFactorType"],"");
			setValue(EI["mmCommonFactorProcessName"],"");
			commonFactorsDialog.curoper="add";
			commonFactorsDialog.window.show();
			showElement(EI["commonFactorsPnl"]);
		}
	}
	///////////////////////////////////////////////////////////////////////
	commonFactorsDialog.editCommonFactorsDialogShow=function(){
		var attr=getSelectedRow(EI["tbCommonFactors"]);
		if (stateDialog.selectedStateID!=null){
			commonFactorsDialog.window.setTitle(gRB("DSRedactor.editCommonFactor"));
			var type=attr["COMMONFACTORTYPE"];
			setComboOptionByValue(EI["cmCommonFactorType"],attr["COMMONFACTORTYPE"]);
			
			if (type=="quotient"){
				setComboOptionByValue(EI["cbQuotientGroups"],attr["COMMONFACTORRULE"]);
			    commonFactorsDialog.selectedQuotient=attr["COMMONFACTORSYSNAME"];
				commonFactorsDialog.fillQuotient();
			}else{
			    setValue(EI["mmCommonFactorProcessName"],attr["COMMONFACTORRULE"]);
				setValue(EI["edCommonFactorSysname"],attr["COMMONFACTORSYSNAME"]);
				setValue(EI["edCommonFactorName"],attr["COMMONFACTORNAME"]);
			}
			commonFactorsDialog.selectedCommonFactorID=attr["COMMONFACTORID"]
			commonFactorsDialog.curoper="edit";
			commonFactorsDialog.window.show();
			showElement(EI["commonFactorsPnl"]);
		}
	}
	///////////////////////////////////////////////////////////////////////
	commonFactorsDialog.fillQuotient=function(){
		if (commonFactorsDialog.fillQuotientFlag!=true){
		    println("commonFactorsDialog.fillQuotient");
			commonFactorsDialog.fillQuotientFlag=true;
			var curGroupName=nvl(getComboSelectedValue(EI["cbQuotientGroups"]),"");
			clearComboOptions(EI["cbQuotient"]);
			if (curGroupName!=""){
				var params=getNewMap();
				params.put("GROUPNAME",curGroupName);
				dsCall("[frontws2]","quotientGetListByGroupName",params,"commonFactorsDialog.onAfterFillQuotient");
			}
		}
	}
	///////////////////////////////////////////////////////////////////////
	commonFactorsDialog.onAfterFillQuotient=function(p){
		println("commonFactorsDialog.onAfterFillQuotient");
		commonFactorsDialog.fillQuotientFlag=false;
		p=nvl(p["Result"],getNewList());
		commonFactorsDialog.quotientList=p;
		for (var i=0;i<p.length;i++){
			addComboOption(EI["cbQuotient"],p[i]["QUOTIENTSYSNAME"],p[i]["QUOTIENTNAME"] +" ("+p[i]["QUOTIENTSYSNAME"]+")");
		}
		if (commonFactorsDialog.selectedQuotient){
			setComboOptionByValue(EI["cbQuotient"],commonFactorsDialog.selectedQuotient);
			commonFactorsDialog.selectedQuotient=null;
		}
	}
	///////////////////////////////////////////////////////////////////////
	commonFactorsDialog.delCommonFactorsDialogShow=function(){
		var attr=getSelectedRow(EI["tbCommonFactors"]);
		if (attr!=null && attr!==""){
			if (showConfirm(gRB("DSRedactor.deleteCommonFactorConfirm"))){
				var params=getNewMap();
				params["STATEID"]=stateDialog.selectedStateID;
				params["DELCOMMONFACTORID"]=attr["COMMONFACTORID"]+"";
				params["PROCESSNAME"]="DSRedactor/saveCommonFactor";
				params["LIGHTPROCESS"]=true;
				params["STARTIMMEDIATLY"]=true;
				dsCall("[corews]","startprocess",params,"commonFactorsDialog.onAfterChangeCommonFactor");
				createModalLoader();			
			}
		}
	} 
	///////////////////////////////////////////////////////////////////////
	commonFactorsDialog.addCommonFactorDialogHide=function(){
		commonFactorsDialog.curoper="none";
		commonFactorsDialog.window.hide();
		hideElement(EI["commonFactorsPnl"]);
	}

	///////////////////////////////////////////////////////////////////////
	commonFactorsDialog.applyCommonFactorDialog=function(){
		lgr("commonFactorsDialog.applyCommonFactorDialog");
		if (commonFactorsDialog.checkParams()){
			commonFactorsDialog[commonFactorsDialog.curoper](); 
		}else{
			showAlert(gRB("DSRedactor.validateFieldsWarning"));
		}		
	}
	////////////////////////////////////////////////////////////////////
	commonFactorsDialog.checkParams=function(){
		lgr("commonFactorsDialog.checkParams");
		var curType=getComboSelectedValue(EI["cmCommonFactorType"]);
		var returnFlag=false;
		var type=getComboSelectedValue(EI["cmCommonFactorType"]);
		if (type=="quotient"){
			returnFlag=checkElements([EI["cmCommonFactorType"],EI["cbQuotientGroups"],EI["cbQuotient"]]);
		}else{
			returnFlag=checkElements([EI["edCommonFactorName"],EI["edCommonFactorSysname"],EI["cmCommonFactorType"],EI["mmCommonFactorProcessName"]]);
		}
		if (returnFlag==false){
			showAlert(gRB("DSRedactor.validateFieldsWarning"));
		}
		return returnFlag;
	}
	////////////////////////////////////////////////////////////////////
	commonFactorsDialog.getQuotientNameBySysname=function(sysname){
		for (var i=0;i<commonFactorsDialog.quotientList.length;i++){
			if (commonFactorsDialog.quotientList[i]["QUOTIENTSYSNAME"]==sysname){
				return commonFactorsDialog.quotientList[i]["QUOTIENTNAME"];
			}
		}
		return sysname;
	}
	////////////////////////////////////////////////////////////////////
	commonFactorsDialog.add=function(){
		var attr=getSelectedRow(EI["tbCommonFactors"]);
		lgr("commonFactorsDialog.add");
		var params=getNewMap();
		params["STATEID"]=stateDialog.selectedStateID;
		var type=getComboSelectedValue(EI["cmCommonFactorType"]);
		params["COMMONFACTORTYPE"]=type;
		if (type=="quotient"){
			params["COMMONFACTORNAME"]= commonFactorsDialog.getQuotientNameBySysname(getComboSelectedValue(EI["cbQuotient"]));
			params["COMMONFACTORSYSNAME"]=getComboSelectedValue(EI["cbQuotient"]);
			params["COMMONFACTORRULE"]=getComboSelectedValue(EI["cbQuotientGroups"]);
		}else{
			params["COMMONFACTORNAME"]=getValue(EI["edCommonFactorName"]);
			params["COMMONFACTORSYSNAME"]=getValue(EI["edCommonFactorSysname"]);
			params["COMMONFACTORRULE"]=getValue(EI["mmCommonFactorProcessName"]);
		}

		params["PROCESSNAME"]="DSRedactor/saveCommonFactor";
		params["LIGHTPROCESS"]=true;
		params["STARTIMMEDIATLY"]=true;
		dsCall("[corews]","startprocess",params,"commonFactorsDialog.onAfterChangeCommonFactor");
		createModalLoader();
	}
	
	////////////////////////////////////////////////////////////////////
	commonFactorsDialog.edit=function(){
		lgr("commonFactorsDialog.edit");
		var attr=getSelectedRow(EI["tbCommonFactors"]);
		var params=getNewMap();
		params["STATEID"]=stateDialog.selectedStateID;

		var type=getComboSelectedValue(EI["cmCommonFactorType"]);
		params["COMMONFACTORTYPE"]=type;
		if (type=="quotient"){
			params["COMMONFACTORNAME"]=commonFactorsDialog.getQuotientNameBySysname(getComboSelectedValue(EI["cbQuotient"]));
			params["COMMONFACTORSYSNAME"]=getComboSelectedValue(EI["cbQuotient"]);
			params["COMMONFACTORRULE"]=getComboSelectedValue(EI["cbQuotientGroups"]);
		}else{
			params["COMMONFACTORNAME"]=getValue(EI["edCommonFactorName"]);
			params["COMMONFACTORSYSNAME"]=getValue(EI["edCommonFactorSysname"]);
			params["COMMONFACTORRULE"]=getValue(EI["mmCommonFactorProcessName"]);
		}
		params["CURCOMMONFACTORID"]=attr["COMMONFACTORID"];		
		params["PROCESSNAME"]="DSRedactor/saveCommonFactor";
		params["LIGHTPROCESS"]=true;
		params["STARTIMMEDIATLY"]=true;
		
		dsCall("[corews]","startprocess",params,"commonFactorsDialog.onAfterChangeCommonFactor");
		createModalLoader();
	}	

	///////////////////////////////////////////////////////////////////////
	commonFactorsDialog.onAfterChangeCommonFactor=function(p){
		hideModalLoaderEvent();
		if ((p["lastErrorMessage"]!=null && p["lastErrorMessage"]!="") || (p["ErrorMessage"]!=null && p["ErrorMessage"]!="") || p["Result"]!="Ok"){
			showError(nvl(nvl(p["ErrorMessage"],p["lastErrorMessage"]),gRB("DSRedactor.saveCommonFactorError")));
			return false;
		}
		commonFactorsDialog.addCommonFactorDialogHide();
		commonFactorsDialog.getCommonFactors();
	}
	///////////////////////////////////////////////////////////////////////
	commonFactorsDialog.getCommonFactors=function(){
		var params=getNewMap();
		params["STATEID"]=stateDialog.selectedStateID;
		params["PROCESSNAME"]="DSRedactor/getStateCommonFactors";
		params["LIGHTPROCESS"]=true;
		params["STARTIMMEDIATLY"]=true;
		dsCall("[corews]","startprocess",params,"commonFactorsDialog.onAfterGetCommonFactors");	
		createModalLoader();
	}
	///////////////////////////////////////////////////////////////////////
	commonFactorsDialog.onAfterGetCommonFactors=function(p){
		console.log(p)
		hideModalLoaderEvent();
		if ((p["lastErrorMessage"]!=null && p["lastErrorMessage"]!="") || (p["ErrorMessage"]!=null && p["ErrorMessage"]!="") || p["Result"]!="Ok"){
			showError(nvl(nvl(p["ErrorMessage"],p["lastErrorMessage"]),gRB("DSRedactor.saveCommonFactorError")));
			return false;
		}
		commonFactorsDialog.refreshTable(p["commonFactorsList"]);		
	}
	///////////////////////////////////////////////////////////////////////
	commonFactorsDialog.refreshTable=function(list){
		clearTable(EI["tbCommonFactors"]);
		for (var i=0;i<list.length;i++){
			addtr(EI["tbCommonFactors"],list[i]);
		}
	}
	///////////////////////////////////////////////////////////////////////
	commonFactorsDialog.onChangeCommonFactorType=function(){
		var curType=getComboSelectedValue(EI["cmCommonFactorType"]);
		if (curType=="quotient"){
			showElement(EI["quotientPnl"]);
		}else{
			hideElement(EI["quotientPnl"]);
		}
	}	
	///////////////////////////////////////////////////////////////////////
	return commonFactorsDialog;
}

commonFactorsDialog=commonFactorsConstructor();