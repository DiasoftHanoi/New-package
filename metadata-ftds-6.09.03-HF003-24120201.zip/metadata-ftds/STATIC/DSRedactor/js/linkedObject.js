﻿/////////////////////////////////////////////////////////////////
linkedObjectsConstructor=function(){
	var linkedObjectsDialog=new Object();
	linkedObjectsDialog.curoper="none";
 	
	linkedObjectsDialog.panel=createExpandPanel(EI["linkedObjectsAndInfo"],EI["contentPnl"],{title:gRB("DSRedactor.linkedObjectAndInfo")});
	gbi(EI["linkedObjectsAndInfo"]).style.border="1px solid #E3E9F2"
	linkedObjectsDialog.window=createSimpleModal2(EI["linkedObjectPnl"]);
	linkedObjectsDialog.infoWindow=createSimpleModal2(EI["infoPnl"]);
	///////////////////////////////////////////////////////////////////////
	linkedObjectsDialog.getContextMenu=function(){
		var attr=getSelectedNode(EI["linkedObjectsAndInfo"]);
		var trFl="true";
		var createMenu= getNewList(); 
		addMenuItem(createMenu,gRB("DSRedactor.addLinkedObject"),"",trFl,"SCRIPT","", "linkedObjectsDialog.addLinkedObjectDialogShow()","");  

		if (attr){
			if (attr["ntype"]=="linkedObject"){
				addMenuItem(createMenu,gRB("DSRedactor.editLinkedObject"),"",trFl,"SCRIPT","", "linkedObjectsDialog.editLinkedObjectDialogShow()",""); 
				addMenuItem(createMenu,gRB("DSRedactor.delLinkedObject"),"",trFl,"SCRIPT","", "linkedObjectsDialog.delLinkedObjectDialogShow()",""); 
				addMenuItem(createMenu,gRB("DSRedactor.addInfoBlock"),"",trFl,"SCRIPT","", "linkedObjectsDialog.addInfoBlockDialogShow()",""); 
			}
			
			
			if (attr["ntype"]=="info"){
				addMenuItem(createMenu,gRB("DSRedactor.editInfoBlock"),"",trFl,"SCRIPT","", "linkedObjectsDialog.editInfoBlockDialogShow()",""); 
				addMenuItem(createMenu,gRB("DSRedactor.delInfoBlock"),"",trFl,"SCRIPT","", "linkedObjectsDialog.delInfoBlockDialogShow()",""); 
			}			
		}
		return createMenu; 	
	}
	///////////////////////////////////////////////////////////////////////
	linkedObjectsDialog.addLinkedObjectDialogShow=function(){
		if (stateDialog.selectedStateID!=null){
			linkedObjectsDialog.window.setTitle(gRB("DSRedactor.addLinkedObject"));
			setComboOptionByValue(EI["linkedObjectType"],"");
			setValue(EI["linkedObjectViewPageflowname"],"");
			setValue(EI["titleFormat"],"");
			linkedObjectsDialog.curoper="add";
			linkedObjectsDialog.window.show();
			showElement(EI["linkedObjectPnl"]);
		}
	}
	///////////////////////////////////////////////////////////////////////
	linkedObjectsDialog.editLinkedObjectDialogShow=function(){
		var attr=getSelectedNode(EI["linkedObjectsAndInfo"]);
		if (stateDialog.selectedStateID!=null){
			linkedObjectsDialog.window.setTitle(gRB("DSRedactor.editLinkedObject"));
			setComboOptionByValue(EI["linkedObjectType"],attr["OBJECTTYPEID"]);
			setValue(EI["titleFormat"],attr["TITLEFORMAT"]);
			setValue(EI["linkedObjectViewPageflowname"],attr["VIEWPAGEFLOWNAME"]);
			linkedObjectsDialog.curoper="edit";
			linkedObjectsDialog.selectedLinkedObjectID=attr["OBJECTTYPEID"];
			linkedObjectsDialog.window.show();
			showElement(EI["linkedObjectPnl"]);
		}
	}
	///////////////////////////////////////////////////////////////////////
	linkedObjectsDialog.editInfoBlockDialogShow=function(){
		var attr=getSelectedNode(EI["linkedObjectsAndInfo"]);
		if (stateDialog.selectedStateID!=null){
			linkedObjectsDialog.infoWindow.setTitle(gRB("DSRedactor.editInfoBlock"));
			setValue(EI["getProcessName"],attr["GETPROCESSNAME"]);
			setValue(EI["modifyPageflowName"],attr["MODIFYPAGEFLOWNAME"]);
			setValue(EI["infoBlockSysname"],attr["INFOBLOCKSYSNAME"]);
			setValue(EI["infoBlockName"],attr["INFOBLOCKNAME"]);			
			setValue(EI["infoBlockCategory"],attr["INFOBLOCKCATEGORY"]);			
			linkedObjectsDialog.selectedInfoBlockID=attr["INFOBLOCKID"];
			linkedObjectsDialog.selectedLinkedObjectID=attr["OBJECTTYPEID"];
			linkedObjectsDialog.curoper="editInfo";
			linkedObjectsDialog.infoWindow.show();
			showElement(EI["infoPnl"]);
		}		
	}
	///////////////////////////////////////////////////////////////////////
	linkedObjectsDialog.delInfoBlockDialogShow=function(){
		var attr=getSelectedNode(EI["linkedObjectsAndInfo"]);
		if (attr && attr["ntype"]=="info"){
			if (showConfirm(gRB("DSRedactor.deleteInfoBlockConfirm"))){
				var params=getNewMap();
				params["STATEID"]=stateDialog.selectedStateID;
				params["OBJECTTYPEID"]=attr["OBJECTTYPEID"]+"";
				params["DELINFOBLOCKID"]=attr["INFOBLOCKID"]+"";
				params["PROCESSNAME"]="DSRedactor/saveInfoBlock";
				params["LIGHTPROCESS"]=true;
				params["STARTIMMEDIATLY"]=true;
				dsCall("[corews]","startprocess",params,"linkedObjectsDialog.onAfterChangeInfoBlock");
				createModalLoader();			
			}
		}
	} 
	///////////////////////////////////////////////////////////////////////
	linkedObjectsDialog.delLinkedObjectDialogShow=function(){
		var attr=getSelectedNode(EI["linkedObjectsAndInfo"]);
		if (attr && attr["ntype"]=="linkedObject"){
			if (showConfirm(gRB("DSRedactor.deleteLinkedObjectConfirm"))){
				var params=getNewMap();
				params["STATEID"]=stateDialog.selectedStateID;
				params["OBJECTTYPEID"]=attr["OBJECTTYPEID"]+"";
				params["DELOBJECTTYPEID"]=attr["OBJECTTYPEID"]+"";
				params["PROCESSNAME"]="DSRedactor/saveLinkedObject";
				params["LIGHTPROCESS"]=true;
				params["STARTIMMEDIATLY"]=true;
				dsCall("[corews]","startprocess",params,"linkedObjectsDialog.onAfterChangeLinkedObject");
				createModalLoader();			
			}
		}
	} 
	///////////////////////////////////////////////////////////////////////
	linkedObjectsDialog.addLinkedObjectDialogHide=function(){
		linkedObjectsDialog.curoper="none";
		linkedObjectsDialog.window.hide();
		hideElement(EI["linkedObjectPnl"]);
	}
	///////////////////////////////////////////////////////////////////////
	linkedObjectsDialog.addInfoBlockDialogHide=function(){
		linkedObjectsDialog.curoper="none";
		linkedObjectsDialog.infoWindow.hide();
		hideElement(EI["infoPnl"]);		
	}	
	///////////////////////////////////////////////////////////////////////
	linkedObjectsDialog.applyLinkedObjectDialog=function(){
		lgr("linkedObjectsDialog.applyLinkedObjectDialog");
		if (linkedObjectsDialog.checkParams()){
			linkedObjectsDialog[linkedObjectsDialog.curoper](); 
		}else{
			showAlert(gRB("DSRedactor.validateFieldsWarning"));
		}		
	}
	////////////////////////////////////////////////////////////////////
	linkedObjectsDialog.applyInfoBlockDialog=function(){
		lgr("linkedObjectsDialog.applyInfoBlockDialog");
		if (linkedObjectsDialog.checkInfoParams()){
			linkedObjectsDialog[linkedObjectsDialog.curoper](); 
		}else{
			showAlert(gRB("DSRedactor.validateFieldsWarning"));
		}		
	}
	////////////////////////////////////////////////////////////////////
	linkedObjectsDialog.checkInfoParams=function(){
		lgr("linkedObjectsDialog.checkInfoParams");
		var returnFlag=checkElements([EI["infoBlockName"],EI["infoBlockSysname"],EI["getProcessName"]]);
		if (returnFlag==false){
			showAlert(gRB("DSRedactor.validateFieldsWarning"));
		}
		return returnFlag;		
	}
	////////////////////////////////////////////////////////////////////
	linkedObjectsDialog.checkParams=function(){
		lgr("linkedObjectsDialog.checkParams");
		var returnFlag=checkElements([EI["linkedObjectType"],EI["titleFormat"]]);
		if (returnFlag==false){
			showAlert(gRB("DSRedactor.validateFieldsWarning"));
		}
		return returnFlag;
	}
	////////////////////////////////////////////////////////////////////
	linkedObjectsDialog.add=function(){
		lgr("linkedObjectsDialog.add");
		var params=getNewMap();
		params["STATEID"]=stateDialog.selectedStateID;
		params["OBJECTTYPEID"]=getComboSelectedValue(EI["linkedObjectType"])+"";
		params["TITLEFORMAT"]=getValue(EI["titleFormat"]);
		params["VIEWPAGEFLOWNAME"]=getValue(EI["linkedObjectViewPageflowname"]);
		params["PROCESSNAME"]="DSRedactor/saveLinkedObject";
		params["LIGHTPROCESS"]=true;
		params["STARTIMMEDIATLY"]=true;
		dsCall("[corews]","startprocess",params,"linkedObjectsDialog.onAfterChangeLinkedObject");
		createModalLoader();
	}
	
	////////////////////////////////////////////////////////////////////
	linkedObjectsDialog.addInfo=function(){
		lgr("linkedObjectsDialog.addInfo");
		var attr=getSelectedNode(EI["linkedObjectsAndInfo"]);
		var params=getNewMap();
		params["STATEID"]=stateDialog.selectedStateID;
		params["OBJECTTYPEID"]=attr["OBJECTTYPEID"]+"";
		params["INFOBLOCKNAME"]=getValue(EI["infoBlockName"]);
		params["INFOBLOCKSYSNAME"]=getValue(EI["infoBlockSysname"]);
		params["INFOBLOCKCATEGORY"]=getValue(EI["infoBlockCategory"]);
		params["MODIFYPAGEFLOWNAME"]=getValue(EI["modifyPageflowName"]);
		params["GETPROCESSNAME"]=getValue(EI["getProcessName"]);
		params["PROCESSNAME"]="DSRedactor/saveInfoBlock";
		params["LIGHTPROCESS"]=true;
		params["STARTIMMEDIATLY"]=true;
		dsCall("[corews]","startprocess",params,"linkedObjectsDialog.onAfterChangeInfoBlock");
		createModalLoader();
	}	
	////////////////////////////////////////////////////////////////////
	linkedObjectsDialog.editInfo=function(){
		lgr("linkedObjectsDialog.editInfo");
		var attr=getSelectedNode(EI["linkedObjectsAndInfo"]);
		
		var params=getNewMap();
		params["STATEID"]=stateDialog.selectedStateID;
		params["OBJECTTYPEID"]=attr["OBJECTTYPEID"]+"";
		params["CURINFOBLOCKID"]=attr["INFOBLOCKID"]+"";
		params["INFOBLOCKNAME"]=getValue(EI["infoBlockName"]);
		params["INFOBLOCKSYSNAME"]=getValue(EI["infoBlockSysname"]);
		params["INFOBLOCKCATEGORY"]=getValue(EI["infoBlockCategory"]);
		params["MODIFYPAGEFLOWNAME"]=getValue(EI["modifyPageflowName"]);
		params["GETPROCESSNAME"]=getValue(EI["getProcessName"]);		
		params["PROCESSNAME"]="DSRedactor/saveInfoBlock";
		params["LIGHTPROCESS"]=true;
		params["STARTIMMEDIATLY"]=true;
		dsCall("[corews]","startprocess",params,"linkedObjectsDialog.onAfterChangeInfoBlock");
		createModalLoader();
	}	
	////////////////////////////////////////////////////////////////////
	linkedObjectsDialog.edit=function(){
		lgr("linkedObjectsDialog.edit");
		var params=getNewMap();
		params["STATEID"]=stateDialog.selectedStateID;
		params["OBJECTTYPEID"]=getComboSelectedValue(EI["linkedObjectType"])+"";
		params["CUROBJECTTYPEID"]=linkedObjectsDialog.selectedLinkedObjectID+"";
		params["VIEWPAGEFLOWNAME"]=getValue(EI["linkedObjectViewPageflowname"]);
		params["TITLEFORMAT"]=getValue(EI["titleFormat"]);
		params["PROCESSNAME"]="DSRedactor/saveLinkedObject";
		params["LIGHTPROCESS"]=true;
		params["STARTIMMEDIATLY"]=true;
		dsCall("[corews]","startprocess",params,"linkedObjectsDialog.onAfterChangeLinkedObject");
		createModalLoader();
	}	

	///////////////////////////////////////////////////////////////////////
	linkedObjectsDialog.onAfterChangeInfoBlock=function(p){
		hideModalLoaderEvent();
		if ((p["lastErrorMessage"]!=null && p["lastErrorMessage"]!="") || (p["ErrorMessage"]!=null && p["ErrorMessage"]!="") || p["Result"]!="Ok"){
			showError(nvl(nvl(p["ErrorMessage"],p["lastErrorMessage"]),gRB("DSRedactor.saveInfoBlockError")));
			return false;
		}
		linkedObjectsDialog.addInfoBlockDialogHide();
		linkedObjectsDialog.getLinkedObjectTree();	
	}
	///////////////////////////////////////////////////////////////////////
	linkedObjectsDialog.onAfterChangeLinkedObject=function(p){
		hideModalLoaderEvent();
		if ((p["lastErrorMessage"]!=null && p["lastErrorMessage"]!="") || (p["ErrorMessage"]!=null && p["ErrorMessage"]!="") || p["Result"]!="Ok"){
			showError(nvl(nvl(p["ErrorMessage"],p["lastErrorMessage"]),gRB("DSRedactor.saveLinkedObjectError")));
			return false;
		}
		linkedObjectsDialog.addLinkedObjectDialogHide();
		linkedObjectsDialog.getLinkedObjectTree();
	}
	///////////////////////////////////////////////////////////////////////
	linkedObjectsDialog.getLinkedObjectTree=function(){
		var params=getNewMap();
		params["STATEID"]=stateDialog.selectedStateID;
		params["PROCESSNAME"]="DSRedactor/getStateLinkedObject";
		params["LIGHTPROCESS"]=true;
		params["STARTIMMEDIATLY"]=true;
		dsCall("[corews]","startprocess",params,"linkedObjectsDialog.onAfterGetLinkedObject");	
		createModalLoader();
	}
	///////////////////////////////////////////////////////////////////////
	linkedObjectsDialog.addInfoBlockDialogShow=function(){
		if (stateDialog.selectedStateID!=null){
			linkedObjectsDialog.infoWindow.setTitle(gRB("DSRedactor.addInfoBlock"));
			setValue(EI["getProcessName"],"");
			setValue(EI["modifyPageflowName"],"");
			setValue(EI["infoBlockSysname"],"");
			setValue(EI["infoBlockName"],"");
			setValue(EI["infoBlockCategory"],"");			
			linkedObjectsDialog.curoper="addInfo";
			linkedObjectsDialog.infoWindow.show();
			showElement(EI["infoPnl"]);
		}		
	} 
	///////////////////////////////////////////////////////////////////////
	linkedObjectsDialog.onAfterGetLinkedObject=function(p){
		console.log(p)
		hideModalLoaderEvent();
		if ((p["lastErrorMessage"]!=null && p["lastErrorMessage"]!="") || (p["ErrorMessage"]!=null && p["ErrorMessage"]!="") || p["Result"]!="Ok"){
			showError(nvl(nvl(p["ErrorMessage"],p["lastErrorMessage"]),gRB("DSRedactor.saveLinkedObjectError")));
			return false;
		}
		linkedObjectsDialog.refreshTree(p["linkedObjectTree"]);		
	}
	///////////////////////////////////////////////////////////////////////
	linkedObjectsDialog.refreshTree=function(tree){
		Ext.getCmp(EI["linkedObjectsAndInfo"]+"_tree").setRootNode(tree);
		Ext.getCmp(EI["linkedObjectsAndInfo"]+"_tree").getRootNode().eachChild(setTreeNodeHint,this); 
	}
	///////////////////////////////////////////////////////////////////////
	return linkedObjectsDialog;
}

linkedObjectsDialog=linkedObjectsConstructor();