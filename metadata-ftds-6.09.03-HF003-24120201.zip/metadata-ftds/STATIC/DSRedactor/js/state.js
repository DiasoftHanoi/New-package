﻿/////////////////////////////////////////////////////////////////
stateConstructor=function(){
	var stateDialog=new Object();
	///////////////////////////////////////////////////////////////////////
	stateDialog.createMenuForSmObject=function(node){
		var attr=getSelectedNode(EI["StatesTree"]);
		if (attr){
			var menu=getNewList(); 
			var trFl="true";

			var createMenu= getNewList(); 
			addMenuItem(menu,"----------------------------------","","false");   
			return menu;  
		}
	}
	////////////////////////////////////////////////////////////////////////////////
	stateDialog.createMenuForState=function(node){
		var attr=getSelectedNode(EI["StatesTree"]);
		var menu=getNewList();
		var trFl="true";
		addMenuItem(menu,"----------------------------------","","false");   
		return menu;
	}

	////////////////////////////////////////////////////////////////////////////////
	stateDialog.getContextMenu=function(node,e){
		var attr=getSelectedNode(EI["StatesTree"]);
		var menu=getNewList();
		if (attr){
			var ntype=attr["ntype"];
			//selectNodeByPath(node.getPath()); 
			if (ntype=="smState"){
				menu=stateDialog.createMenuForState(node);   
			}
			if (ntype=="smObject"){
				menu=stateDialog.createMenuForSmObject(node);   
			}

		}
		return menu;		
	}
	////////////////////////////////////////////////////////////////////////////////
	stateDialog.clickStateTreeNode=function(){
		var attr=getSelectedNode(EI["StatesTree"]);
		var ntype=attr.ntype;  
		if (ntype=="smState"){
			stateDialog.setTitle(gRBT("DSRedactor.stateTitle",attr["NAME"]));
			stateDialog.selectedStateID=attr["STATEID"];
			var params=getNewMap();
			params.put("STATEID",attr["STATEID"]);
			params.put("LIGHTPROCESS",true);
			params.put("STARTIMMEDIATLY",true);
			params.put("PROCESSNAME","DSRedactor/getStateDecisionData");
			dsCall("[corews]","startprocess",params,"stateDialog.onAfterGetStateDecisionData")
			createModalLoader();
		}
	}
	////////////////////////////////////////////////////////////////////////////////
	stateDialog.onAfterGetStateDecisionData=function(p){
		lgr("stateDialog.onAfterGetStateDecisionData");
		lgr(p);
		hideModalLoaderEvent();
		if ((p["lastErrorMessage"]!=null && p["lastErrorMessage"]!="") || (p["ErrorMessage"]!=null && p["ErrorMessage"]!="") || p["Result"]!="Ok"){
			showError(nvl(nvl(p["ErrorMessage"],p["lastErrorMessage"]),gRB("DSRedactor.saveLinkedObjectError")));
			return false;
		}		
		var linkedObjectTree=nvl(p["linkedObjectTree"],getNewMap());
		linkedObjectsDialog.refreshTree(linkedObjectTree);
		var commonFactorsList=nvl(p["commonFactorsList"],getNewMap());
		commonFactorsDialog.refreshTable(commonFactorsList);
		var askedParams=nvl(p["askedParams"],getNewList());
		askedParamsDialog.refreshTable(askedParams);
		var stagesAndDecisions=nvl(p["stagesAndDecisions"],getNewList());
		stagesAndDecisionsDialog.refreshTable(stagesAndDecisions);
		stagesAndDecisionsDialog.fillStageCombo(p["stagesList"]);
		stagesAndDecisionsDialog.fillDecisionCombo(p["decisionList"])	
	}
	////////////////////////////////////////////////////////////////////////////////
	stateDialog.setTitle=function(title){
		setPanelTitle("Content",title);
	}
	////////////////////////////////////////////////////////////////////////////////
	return stateDialog;
}

stateDialog=stateConstructor();