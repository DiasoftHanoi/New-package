lgr=function (){
   if (window["console"]){
		for (var i=0;i<arguments.length;i++){
			console.log(arguments[i]);
		}
   }
}
//////////////////////////////////////////////////////////////////////////////
gRB=function (key){
	var bundle=getResourceBundle(key);
	return bundle!=null ? bundle : key;
} 
//////////////////////////////////////////////////////////////////////////////
gRBT=function (key) {
    var str = getResourceBundle(key);
    if(str != null && arguments.length > 1){
        for (var i = 1; i < arguments.length; i++) {
            str = str.replace("%"+i+"$", String(arguments[i]));
        }
		return str;
    }
    return key;
} 
//////////////////////////////////////////////////////////////////////////////
hasClass=function (ele, cls) {
        return (nvl(ele.className,"")).match(new RegExp('(\\s|^)' + cls + '(\\s|$)'));
}
//////////////////////////////////////////////////////////////////////////////
addClass=function (ele, cls) {
     if (!this.hasClass(ele, cls)) ele.className += " " + cls;
}
//////////////////////////////////////////////////////////////////////////////
toogleClass=function (ele, cls1,cls2) {
    if (hasClass(ele,cls1)){
      removeClass(ele,cls1);
      addClass(ele,cls2);      
   }else{
      removeClass(ele,cls2);
      addClass(ele,cls1);      
   } 
}
//////////////////////////////////////////////////////////////////////////////
removeClass=function (ele, cls) {
    if (hasClass(ele, cls)) {
       var reg = new RegExp('(\\s|^)' + cls + '(\\s|$)');
       ele.className = (nvl(ele.className,"")).replace(reg, ' ');
    }
}
function removeElement(elem) {
  return elem.parentNode ? elem.parentNode.removeChild(elem) : elem;
}
////////////////////////////////////////////////////////////////////////////////
changeTableSortOrder=function (idTable, order) {
    return false;
}
////////////////////////////////////////////////////////////////////////////////
closeVisLMnu=function () {
    var lm = gbi("lmTD");
    if (lm) {
        if (lm.style.display != "none") {
            lm.style.display = "none";
            gbi("lm_close_btn").style.backgroundPosition = "6";
            //setCookie("clozedLM", true);
        }
    }
    try {
        callOnResize();
    } catch (e) {
    }
}
////////////////////////////////////////////////////////////////////////////////
getScroll=function (a) {
   var  d = document,
        b = d.body,
        e = d.documentElement,
        c = "client" + a;
        a = "scroll" + a;
    return /CSS/.test(d.compatMode)? (e[c]< e[a]) : (b[c]< b[a])
};
////////////////////////////////////////////////////////////////////////////////
resizeElement=function (Data,rootWidth,rootHeight){

  var dataWidth=getWidth(Data["id"]);
  var dataHeight=getHeight(Data["id"]);
  var marginbtm=Data["margin-bottom"];

  if (Data["width"]){
      dataWidth= (Data["width"].indexOf("%")>-1) ? stringToNumeric(Data["width"].replace("%",""))/100*rootWidth : stringToNumeric(Data["width"]);
      if (dataWidth!=getWidth(Data["id"])){setWidth(Data["id"],dataWidth);}
    }   
    if (Data["height"]){
      dataHeight= (Data["height"].indexOf("%")>-1) ? stringToNumeric(Data["height"].replace("%",""))/100*rootHeight : stringToNumeric(Data["height"]);
      dataHeight= marginbtm ? dataHeight-stringToNumeric(marginbtm) : dataHeight;
      if (dataHeight!=getHeight(Data["id"])){setHeight(Data["id"],dataHeight);}   
  }
  if (Data["bottom"]){
    setCoordY(Data["id"],rootHeight-dataHeight-stringToNumeric(Data["bottom"]));
  }
  if (Data["right"]){
    setCoordX(Data["id"],rootWidth-dataWidth-stringToNumeric(Data["right"]));
  }
  
  var rect={"width":dataWidth,"height":dataHeight}
    if (Data["childs"]){
      var dd=Data["childs"].length;
    for (var i=0;i<dd;i++){
           var childEl=Data["childs"][i];
       var rect=resizeElement(childEl,dataWidth,dataHeight);
       if (childEl["display"]=="block"){
        dataHeight-=rect["height"];
       }
    }
  }
  return rect;
}
////////////////////////////////////////////////////////////////////////////////
commonResize=function(){
    var minWidth=800;
    var minHeight=670;
    setPageBodyContainerWidth(minWidth);
    setFormHeight(minHeight);
    var mainformWidth,mainformHeight;

    var bodyEl=Ext.get(Ext.query("BODY")[0]);
    mainformWidth=bodyEl.getWidth();
    mainformHeight=bodyEl.getHeight();

    var fWidth=  mainformWidth<minWidth ? minWidth : mainformWidth;
    var fHeight = mainformHeight<minHeight ? minHeight : mainformHeight;
    return [fWidth,fHeight];
}
////////////////////////////////////////////////////////////////////////////////
resizeFormCommon=function(){
   lgr("resizeFormCommon");
   if (resizeFlag==false){
    resizeFlag=true;
    containerBox=commonResize();
    var fWidth=containerBox[0];
    var fHeight=containerBox[1];
	if (getScroll("Width")){fWidth-=30;}
	if (getScroll("Height")){fHeight-=30;}
	
	
	setPageBodyContainerWidth(fWidth);
    setFormHeight(fHeight);
    setWidth("DSRedactor",fWidth);
    setHeight("DSRedactor",fHeight);

    setWidth(EI["wrapper"],fWidth);
    setHeight(EI["wrapper"],fHeight);

    Ext.getCmp("DSContainer").setWidth(fWidth);
    Ext.getCmp("DSContainer").setHeight(fHeight);

	lgr("fWidth="+fWidth+" fHeight="+fHeight);
	
	
	var stateNavWidth=Ext.get("stateNav").getWidth();
	var stateNavHeight=Ext.get("stateNav").getHeight();

    setWidth(EI["treePnl"],stateNavWidth);
	setHeight(EI["treePnl"],stateNavHeight);
	
	
	
	setWidth(EI["StatesTree"],stateNavWidth);
	Ext.getCmp(EI["StatesTree"]+"_tree").setWidth(stateNavWidth);
	setHeight(EI["StatesTree"],stateNavHeight-getCoordY(EI["StatesTree"])-Ext.getCmp("stateNav").header.getHeight());
	
	Ext.getCmp("stateNav_Container").setWidth(stateNavWidth);
	Ext.getCmp("stateNav_Container").setHeight(stateNavHeight);
	
	setWidth(EI["stateNavPanel"],stateNavWidth);
     
	setWidth(EI["stateSearch"],stateNavWidth-getCoordX(EI["stateSearch"])-10);
	
	var ContentBox={width:fWidth-stateNavWidth-4,height:fHeight};
	Ext.getCmp("Content").setSize(ContentBox);

	lgr("ContentBox=",ContentBox);
	
	setWidth(EI["contentPnl"],ContentBox["width"]-4);
	setHeight(EI["contentPnl"],ContentBox["height"]-Ext.getCmp("Content").header.getHeight()-3);
	
	var cW=getWidth(EI["contentPnl"])-16;
	
	setWidth(EI["linkedObjectsAndInfo"],cW-2);

	setWidth(EI["tbCommonFactors"],cW);
	var cols=["COMMONFACTORSYSNAME","COMMONFACTORNAME","COMMONFACTORTYPE","COMMONFACTORRULE"];
	for (var i=0;i<cols.length;i++){setColumnWidth(EI["tbCommonFactors"],cols[i],(cW-40)/cols.length)}

	setWidth(EI["tbAskedParams"],cW);
	var cols=["PARAMSYSNAME","PARAMNAME","GETPROCESS"];
	for (var i=0;i<cols.length;i++){setColumnWidth(EI["tbAskedParams"],cols[i],(cW-40)/cols.length)}

	setWidth(EI["tbStagesAndDecisions"],cW);
	var cols=["TYPENAME","NAME","SYSNAME","ATTACHNAME"];
	for (var i=0;i<cols.length;i++){setColumnWidth(EI["tbStagesAndDecisions"],cols[i],(cW-40)/cols.length)}
	
    resizeFlag=false;
     if (gbi("stateNav-xcollapsed")){
       if (getWidth("stateNav-xcollapsed")==0) setWidth("stateNav-xcollapsed",20);
     }
	 
   }
}
////////////////////////////////////////////////////////////////////////////////
resizeForm=function(){
  if (resizeFormEvent!=null) {
      clearTimeout(resizeFormEvent);
  } 
  resizeFormEvent=setTimeout('resizeFormCommon()', 200);
}

////////////////////////////////////////////////////////////////////////////////
createSimpleModal2=function  (id, popUpStyle,closable,resizable,resizeFunction,modal) {
  closable= closable==null ? true : closable;
  modal= modal==null ? true : modal;
  var minWidth= resizable==null ? null : 300;
  resizable= resizable==null ? false : resizable;

  var widthPnl=getWidth(id)+ (Ext.isIE ? 17 : 15);
  var heightPnl=null;
  if (closable==true) {
    heightPnl=getHeight(id)+  (Ext.isIE ? 34 : 33); 
  }else{
    heightPnl=getHeight(id)+(Ext.isIE ? 15 : 17)
  }
  
  var xcoord= Ext.isIE ? 0 : 7;
  var ycoord= Ext.isIE ? 0 : 1;
  setCoordX(id,xcoord);
  setCoordY(id,ycoord);
  var win = new Ext.Window({
                "width":widthPnl,
                "height":heightPnl,
                "resizable":resizable,
                "contentEl":id,
                "closable":closable,
                "closeAction":'hide',
                "minWidth":minWidth,
                "modal": modal,
                "plain": true});
  if (resizeFunction){
     win.on("bodyresize",resizeFunction);
  }
  win.hide();
  return win;
}
////////////////////////////////////////////////////////////////////////////////
createModalLoader=function(text) {
    window["waitFormEvent"]=nvl(window["waitFormEvent"],null);
    window["waitForm"]=nvl(window["waitForm"],null);
	println("createModalLoader");
    var loadMask=(new Ext.LoadMask(Ext.getBody(), {msg: nvl(text,myTxt.progress3), removeMask: true}));
    loadMask.show();
    var els=Ext.query("DIV[class*=x-mask-loading]");
    if (els.length>0){
      var el=Ext.query("DIV[class*=x-mask-loading]")[0].previousSibling;
      if (el.className=="ext-el-mask"){
        el.style.zIndex=10000;
        var maskHeight=getFormHeight();
        if (maskHeight<getHeight(Ext.query("body")[0].getAttribute("id"))){
            maskHeight= getHeight(Ext.query("body")[0].getAttribute("id"));
        }
        el.style.height=maskHeight;
      }
    }
    if (waitFormEvent!=null) {clearTimeout(waitFormEvent);}    
    waitForm=loadMask;
	return waitForm;
}
////////////////////////////////////////////////////////////////////////////////
hideModalLoaderEvent=function (){
   if (window["waitFormEvent"]!=null) {clearTimeout(window["waitFormEvent"]);} window["waitFormEvent"]=setTimeout('hideModalLoader()', 300)
} 
////////////////////////////////////////////////////////////////////////////////
hideModalLoader=function (){
   println("hideModalLoader");
   if (window["waitForm"]!=null){window["waitForm"].hide();}
} 
////////////////////////////////////////////////////////////////////////////////
createExpandPanel=function(contentID,targetID,params){
	setCoordY(contentID,0);
	params=nvl(params,[]);
	var pnl=new Ext.Panel({
		renderTo:targetID,
		border:false,
		id: contentID+".wrapPnl",		
		contentEl:contentID,
		collapsible:true,
		border:false,
		title: params["title"],
		animCollapse:false,
        listeners: params["listeners"],
		height: getHeight(contentID)
	});
	pnl.setHeight(pnl.header.getHeight()+getHeight(contentID));
	return pnl;
}
////////////////////////////////////////////////////////////////////////////////
setPanelTitle=function(id,title){
	Ext.getCmp(id).setTitle(title);
}
////////////////////////////////////////////////////////////////////////////////
crmodal=function (str, id, hid, popUpStyle) {
    if (!popUpStyle) {
        popUpStyle = "popUpStyle";
    }
    var rs = self.document.readyState;
    if (self.HTMLElement) {
        rs = "loaded";
    }
    if (/loaded|complete/.test(rs)) {
        var htm = self.document.getElementsByTagName("html")[0];
        var bod = self.document.getElementsByTagName("body")[0];
        var dd = getLikeElements("DIV", "class", popUpStyle);
        if (dd.length < 1) {
            bod.style.overflow = "hidden";
            htm.scrollbars = "0";
            bod.style.height = "100%";
            htm.style.height = "100%";
        }
        var scrollX = getScrollLeft();
        var scrollY = getScrollTop();
        if (gbi("tipaModal" + id)) {
            return;
        }
        var lb = self.document.createElement("div");
        lb.style.position = "absolute";
        setScroll(scrollX, scrollY);
        lb.style.left = scrollX;
        lb.style.top = scrollY;
        lb.id = "tipaModal" + id;
        lb.style.width = "100%";
        lb.style.height = "100%";
        lb.style.zIndex = 10000;
        lb.className = popUpStyle;

        if (hid == "hid") {
            lb.style.display = "none";
        } else {
            hidAllSel(id);
        }
        lb.innerHTML = str;
        bod.appendChild(lb);
        if (gbi(id + "btn")) {
            addHandler(gbi(id + "btn"), "click", function () {closemodal(id);});
        }
        if (hid != "hid") {
            setFocus("tipaModal" + id);
        }
    } else {
        setTimeout(function () {crmodal(str, id, hid);}, 500);
    }
}
////////////////////////////////////////////////////////////////////////////////
function showElement(id) {
    var el = gbi(id);
    if (el) {
      Ext.get(el).stopFx(true)
	    Ext.get(el).show(true);
        el.style.display = '';
        if(Ext.isIE) {
			el.style.visibility='';
		}
        if (el.tagName == 'IMG'){ 
       Ext.get(el.parentNode).stopFx(true)
		   Ext.get(el.parentNode).show(true);
		   el.parentNode.style.display = '';
		}   

        // Show formCaption 
        if (el.tagName == "DIV" && el.parentNode.id == "PageBodyContainer") {
            el.parentNode.parentNode.style.display = '';
            showElement(gbi("formCaptionLabel"));
        } else if (el.tagName == "DIV" && el.id == "formCaptionLabel") {
            // do not show empty form caption
            el.style.display = el.innerText==''?'none':'';
        } 
        
        if (el.tagtype&& el.tagtype== 'table') {eval(id.replace(/\./g,"_")).setVisible(true);}
    }
    if (gbi(id + '.parent.popUp')) {
		id = id + '.parent.popUp'
        var popUpStyle = 'popUpStyle';
		var htm = self.document.getElementsByTagName('html')[0];
        var bod = self.document.getElementsByTagName('body')[0];
        var dd = getLikeElements('DIV', 'class', popUpStyle);
        if (dd.length == 0) {
            bod.style.overflow = 'hidden';
            htm.style.overflow = 'hidden';
            htm.scrollbars = '0';
            bod.style.height = '100%';
            htm.style.height = '100%';
        }
		
		
		var scrollX = getScrollLeft();
        var scrollY = getScrollTop();
        gbi(id).style.left = scrollX;
        gbi(id).style.top = scrollY;
        var dd = Ext.DomQuery.select("div.popUpStyle");
        if (dd.length < 1) hidAllSel();
		showElement(id);
    }
    if (gbi(id + '.parent')) showElement(id + '.parent');
    fixTabVisualPosition();
    var inners;
    try {
        inners = Ext.query("[id^="+id+"]");
    } catch(e) {
    	inners = [];
    }
	var innersLength=inners.length;
	for(var i = 0 ; i < innersLength; i++){
		var fullid = inners[i].id;
		var elid = fullid.replace(/[\.]/g,'_');
		if(isVisible(fullid)) {
			eval("try{"+elid+".setHeight("+elid+".height);" +elid+".updateBox("+elid+".getBox());}catch(e){}");
		}
	}
}
////////////////////////////////////////////////////////////////////////////////
getAbsolutePosition = function (el) {
	var rEl = { x:  stringToNumeric(el.offsetLeft || el.style.left), 
                y:  stringToNumeric(el.offsetTop || el.style.top)};
    if (el.parentNode && el.id!="mainform" && el.parentNode.tagName!="BODY") {
        var tmp = getAbsolutePosition(el.parentNode);
		rEl.x =rEl.x+ tmp.x;
		rEl.y =rEl.y+ tmp.y;
	}
	return rEl ;
}
////////////////////////////////////////////////////////////////////////////////
function destroySimpleModal2(id){
   if (gbi(id+'.parent.popUp')){
      var idxDot=id.lastIndexOf(".");
      if (idxDot==-1){idxDot=id.length;}else{idxDot;}
      var parentid=id.substring(0,idxDot);
      if (parentid!=id){
         var el=gbi(id);
         var parentEl=gbi(parentid);
         parentEl.appendChild(el);
         setCoordX(id,el.getAttribute("oldx"));
         setCoordY(id,el.getAttribute("oldy"));

         var popupel=gbi(id+'.parent.popUp');
         popupel.parentNode.removeChild(popupel);
         removeClass(el,"shadall");
         removeClass(el,"poprama");
		 removeClass(el,"css3");
         //refreshCSS3(el);
		 var htm = self.document.getElementsByTagName('html')[0];
         var bod = self.document.getElementsByTagName('body')[0];
         var dd = getLikeElements('DIV', 'class', 'popUpStyle');

         if (dd.length == 0) {
             bod.style.overflow = 'auto';
             htm.style.overflow = 'auto';
         }
      }
	  
   }
}
////////////////////////////////////////////////////////////////////////////////
checkElements=function (list){
  var resultFlag=true;
  for (var i=0;i<list.length;i++){
    var el=list[i];
    
    if (gbi(el).tagName=="SELECT"){
      var selComboValue=getComboSelectedValue(el);
      if (selComboValue=="" || selComboValue==null || selComboValue=="0"){
        setErrorClass(el,true);
        resultFlag=false;    
      } 
    }else 
    if  (gbi(el).getAttribute("tagtype")=="table"){
      if (getRowsCount(el)==0){
        setErrorClass(el,true);
        resultFlag=false;        
      }
    }else{
      if (getValue(el)=="" || getValue(el)==null || (hasClass(gbi(el),"error") && isEnabled(el))){
        setErrorClass(el,true);
        resultFlag=false;
      }else{
         setErrorClass(el,false);
      }
    }
  }
  return resultFlag;
}
////////////////////////////////////////////////////////////////////////////////
cloneObj=function (obj){
    if(obj == null || typeof(obj) != 'object')
        return obj;
    var temp = new obj.constructor();
    for(var key in obj)
        temp[key] = clone(obj[key]);
    return temp;
}
////////////////////////////////////////////////////////////////////////////////
function preventSelection(element){
  var preventSelection = false;

  function addHandler(element, event, handler){
    if (element.attachEvent) 
      element.attachEvent('on' + event, handler);
    else 
      if (element.addEventListener) 
        element.addEventListener(event, handler, false);
  }
  function removeSelection(){
    if (window.getSelection) { window.getSelection().removeAllRanges(); }
    else if (document.selection && document.selection.clear)
      document.selection.clear();
  }
  function killCtrlA(event){
    var event = event || window.event;
    var sender = event.target || event.srcElement;

    if (sender.tagName.match(/INPUT|TEXTAREA/i))
      return;

    var key = event.keyCode || event.which;
    if (event.ctrlKey && key == 'A'.charCodeAt(0))  // 'A'.charCodeAt(0) may replace on 65
    {
      removeSelection();

      if (event.preventDefault) 
        event.preventDefault();
      else
        event.returnValue = false;
    }
  }

  // do not give the mouse to select
  addHandler(element, 'mousemove', function(){
    if(preventSelection)
      removeSelection();
  });
  addHandler(element, 'mousedown', function(event){
    var event = event || window.event;
    var sender = event.target || event.srcElement;
    preventSelection = !sender.tagName.match(/INPUT|TEXTAREA/i);
  });

  // fighting with dblclick
  // if the function does not hang on the event dblclick, can be avoided
  // temporary text selection in some browsers
  addHandler(element, 'mouseup', function(){
    if (preventSelection)
      removeSelection();
    preventSelection = false;
  });

  // fighting with ctrl+A
  // probably it is not necessary, besides there is a suspicion 
  // that in case such a need still need to function 
  // hang up once on document, and not to the element
  addHandler(element, 'keydown', killCtrlA);
  addHandler(element, 'keyup', killCtrlA);
}
///////////////////////////////////////////////////////////////////////////////
function addMenuItem(menuObj, nameValue, childrenValue, enableValue, typeValue, tagValue, scriptValue, validateValue){
  //define default values
  if (!nameValue) nameValue=""; 
  if (!childrenValue) childrenValue="";
  if (!enableValue) enableValue="true";
  if (!typeValue) typeValue="";
  if (!tagValue) tagValue="";
  if (!scriptValue) scriptValue="";
  if (!validateValue) validateValue="false";

  //create menu item
  var map = getNewMap();//get empty map 
  map.put("name", nameValue);
  if (childrenValue!=="")
    map.put("children", childrenValue)
  map.put("enabled", enableValue); 
  map.put("type", typeValue);
  map.put("tag", tagValue);
  map.put("script", scriptValue);
  map.put("validate", validateValue);
  menuObj.add(map);
}
///////////////////////////////////////////////////////////////////////////////////

function tableDisable(id){
  var tblStr = id.replace(/\./g, "_");
  var tbl = eval(tblStr);
  tbl.disable();
}
///////////////////////////////////////////////////////////////////////////////////
function tableEnable(id){
  var tblStr = id.replace(/\./g, "_");
  var tbl = eval(tblStr);
  tbl.enable();
}
///////////////////////////////////////////////////////////////////////////////////
generateContextMenu=function(e,arr){
    if (!(e)) var e = event;
    var items = [];
    var arrLength = arr.length;
    for( var i = 0; i < arrLength; i++){
         items.add(createCMLine(arr[i]));
    }
    var menu = new Ext.menu.Menu({items: items});
    menu.showAt([e.xy[0] ,e.xy[1] ]);
}
////////////////////////////////////////////////////////////////////////////////
fixColumns=function(id){
	var tableCmp=window[id.replace(/\./gi,"_")];
	var model=tableCmp.getColumnModel();
	for (var i=0;i<model.config.length;i++){
		model.setRenderer(i,function(value){return value})
	}
}
//fixColumns(EI["dbParamConditionTable"]);
//fixColumns(EI["conditonTestList"]);
