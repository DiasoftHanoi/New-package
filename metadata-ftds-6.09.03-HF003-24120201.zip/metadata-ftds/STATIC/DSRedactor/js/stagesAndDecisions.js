﻿/////////////////////////////////////////////////////////////////
stagesAndDecisionsConstructor=function(){
	var stagesAndDecisionsDialog=new Object();
	stagesAndDecisionsDialog.curoper="none";
 	
	stagesAndDecisionsDialog.panel=createExpandPanel(EI["tbStagesAndDecisions"],EI["contentPnl"],{title:gRB("DSRedactor.stagesAndDecisions")});
	stagesAndDecisionsDialog.window=createSimpleModal2(EI["stagesAndDecisionsPnl"]);
	
	
	///////////////////////////////////////////////////////////////////////
	stagesAndDecisionsDialog.fillStageCombo=function(stagesList){
		stagesList=nvl(stagesList,getNewList());
		stagesAndDecisionsDialog.stagesList=stagesList;
		
		for (var i=0;i<stagesList.length;i++){
			addComboOption(EI["cbStages"],stagesList[i]["DOCPROCTYPEID"],stagesList[i]["NAME"]+" ("+stagesList[i]["SYSNAME"]+")");
		}
	}
	///////////////////////////////////////////////////////////////////////
	stagesAndDecisionsDialog.fillDecisionCombo=function(decisionList){
		decisionList=nvl(decisionList,getNewList());
		stagesAndDecisionsDialog.decisionList=decisionList;
		
		for (var i=0;i<decisionList.length;i++){
			addComboOption(EI["cbDecisions"],decisionList[i]["DECISIONSTAGEID"],decisionList[i]["STAGENAME"]+" ("+decisionList[i]["STAGESYSNAME"]+")");
		}
	}	
	///////////////////////////////////////////////////////////////////////
	stagesAndDecisionsDialog.checkType=function(){
		var type=getComboSelectedValue(EI["cmStageDecisionType"]);
		if (type==null || type==""){
			disableElement(EI["cbDecisions"]);
			disableElement(EI["cbStages"]);
			setComboOptionByValue(EI["cbDecisions"],"");
			setComboOptionByValue(EI["cbStages"],"");
		}else{
			enableElement(EI["cbDecisions"]);
			enableElement(EI["cbStages"]);
		}
		if (type=="decisionStageType"){
			showElement(EI["cbDecisions"]);
			hideElement(EI["cbStages"]);
			setValue(EI["lbStageDecisionType"],gRB("DSRedactor.decision"));
		}
		if (type=="docProcType"){
			hideElement(EI["cbDecisions"]);
			showElement(EI["cbStages"]);
			setValue(EI["lbStageDecisionType"],gRB("DSRedactor.docStage"));
		}
	} 
	///////////////////////////////////////////////////////////////////////
	stagesAndDecisionsDialog.getContextMenu=function(){
		var attr=getSelectedRow(EI["tbStagesAndDecisions"]);
		var trFl="true";
		var createMenu= getNewList(); 
		addMenuItem(createMenu,gRB("DSRedactor.addStagesAndDecisions"),"",trFl,"SCRIPT","", "stagesAndDecisionsDialog.addStagesAndDecisionsDialogShow()","");  

		if (attr!=null && attr!=""){
			addMenuItem(createMenu,gRB("DSRedactor.editStagesAndDecisions"),"",trFl,"SCRIPT","", "stagesAndDecisionsDialog.editStagesAndDecisionsDialogShow()",""); 
			addMenuItem(createMenu,gRB("DSRedactor.delStagesAndDecisions"),"",trFl,"SCRIPT","", "stagesAndDecisionsDialog.delStagesAndDecisionsDialogShow()",""); 
		}
		return createMenu; 	
	}
	///////////////////////////////////////////////////////////////////////
	stagesAndDecisionsDialog.addStagesAndDecisionsDialogShow=function(){
		if (stateDialog.selectedStateID!=null){
			stagesAndDecisionsDialog.window.setTitle(gRB("DSRedactor.addStagesAndDecisions"));

			setComboOptionByValue(EI["cmStageDecisionType"],"");
			setComboOptionByValue(EI["cbStages"],"");
			setComboOptionByValue(EI["cbDecisions"],"");
			setComboOptionByValue(EI["cbAttachedType"],"");
			setValue(EI["edStageDecisionSysname"],"");
			setValue(EI["edStageDecisionName"],"");			
			stagesAndDecisionsDialog.curoper="add";
			stagesAndDecisionsDialog.window.show();
			showElement(EI["stagesAndDecisionsPnl"]);
		}
	}
	///////////////////////////////////////////////////////////////////////
	stagesAndDecisionsDialog.checkStage=function(){
		lgr("stagesAndDecisionsDialog.checkStage");
		var stagesList=nvl(stagesAndDecisionsDialog.stagesList,getNewList());
		var selStageID=getComboSelectedValue(EI["cbStages"]);
		for (var i=0;i<stagesList.length;i++){
			if (selStageID+""==stagesList[i]["DOCPROCTYPEID"]){
				setValue(EI["edStageDecisionSysname"],stagesList[i]["SYSNAME"]);
				setValue(EI["edStageDecisionName"],stagesList[i]["NAME"]);		
				break;
			}
		}
	}
	///////////////////////////////////////////////////////////////////////
	stagesAndDecisionsDialog.checkDecision=function(){
		lgr("stagesAndDecisionsDialog.checkDecision");
		var decisionList=nvl(stagesAndDecisionsDialog.decisionList,getNewList());
		var selDecisionID=getComboSelectedValue(EI["cbDecisions"]);
		for (var i=0;i<decisionList.length;i++){
			if (selDecisionID+""==decisionList[i]["DECISIONSTAGEID"]){
				setValue(EI["edStageDecisionSysname"],decisionList[i]["STAGESYSNAME"]);
				setValue(EI["edStageDecisionName"],decisionList[i]["STAGENAME"]);		
				break;
			}
		}
	}	
	///////////////////////////////////////////////////////////////////////
	stagesAndDecisionsDialog.editStagesAndDecisionsDialogShow=function(){
		var attr=getSelectedRow(EI["tbStagesAndDecisions"]);
		if (stateDialog.selectedStateID!=null && attr!=null && attr!==""){
			stagesAndDecisionsDialog.window.setTitle(gRB("DSRedactor.editStagesAndDecisions"));

			setValue(EI["edStageDecisionSysname"],"");
			setValue(EI["edStageDecisionName"],"");	
			
			setComboOptionByValue(EI["cmStageDecisionType"],attr["TYPE"]);
			if (attr["TYPE"]=="decisionStageType"){
				setComboOptionByValue(EI["cbDecisions"],attr["ID"]);
			}

			if (attr["TYPE"]=="docProcType"){
				setComboOptionByValue(EI["cbStages"],attr["ID"]);
			}
			setComboOptionByValue(EI["cbAttachedType"],attr["ATTACHTYPEID"]);
			
			stagesAndDecisionsDialog.curoper="edit";
			stagesAndDecisionsDialog.selectedStagesAndDecisionsID=attr["ID"];
			stagesAndDecisionsDialog.window.show();
			showElement(EI["stagesAndDecisionsPnl"]);
		}
	}
	///////////////////////////////////////////////////////////////////////
	stagesAndDecisionsDialog.delStagesAndDecisionsDialogShow=function(){
		var attr=getSelectedRow(EI["tbStagesAndDecisions"]);
		if (attr!=null && attr!==""){
			if (showConfirm(gRB("DSRedactor.deleteStagesAndDecisionsConfirm"))){
				var params=getNewMap();
				params["STATEID"]=stateDialog.selectedStateID;
				params["DELLINKID"]=attr["OBJLINKID"]+"";
				params["PROCESSNAME"]="DSRedactor/saveStagesAndDecisions";
				params["LIGHTPROCESS"]=true;
				params["STARTIMMEDIATLY"]=true;
				dsCall("[corews]","startprocess",params,"stagesAndDecisionsDialog.onAfterChangeStagesAndDecisions");
				createModalLoader();			
			}
		}
	} 
	///////////////////////////////////////////////////////////////////////
	stagesAndDecisionsDialog.addStagesAndDecisionsDialogHide=function(){
		stagesAndDecisionsDialog.curoper="none";
		stagesAndDecisionsDialog.window.hide();
		hideElement(EI["stagesAndDecisionsPnl"]);
	}
	///////////////////////////////////////////////////////////////////////
	stagesAndDecisionsDialog.applyStagesAndDecisionsDialog=function(){
		lgr("stagesAndDecisionsDialog.applyStagesAndDecisionsDialog");
		if (stagesAndDecisionsDialog.checkParams()){
			stagesAndDecisionsDialog[stagesAndDecisionsDialog.curoper](); 
		}else{
			showAlert(gRB("DSRedactor.validateFieldsWarning"));
		}		
	}
	////////////////////////////////////////////////////////////////////
	stagesAndDecisionsDialog.checkParams=function(){
		lgr("stagesAndDecisionsDialog.checkParams");
		var returnFlag=checkElements([EI["cmStageDecisionType"],EI["edStageDecisionName"],EI["edStageDecisionSysname"]]);

		if (returnFlag==false){
			showAlert(gRB("DSRedactor.validateFieldsWarning"));
		}
		return returnFlag;
	}	
	////////////////////////////////////////////////////////////////////
	stagesAndDecisionsDialog.add=function(){
		lgr("stagesAndDecisionsDialog.add");
		var params=getNewMap();
		params["STATEID"]=stateDialog.selectedStateID;
		var stageDecisionType=getComboSelectedValue(EI["cmStageDecisionType"]);
		
		params["TYPE"]=stageDecisionType;
		if (stageDecisionType=="docProcType"){
			params["ID"]=getComboSelectedValue(EI["cbStages"]);
		}
		if (stageDecisionType=="decisionStageType"){
			params["ID"]=getComboSelectedValue(EI["cbDecisions"]);
		}
		params["ATTACHTYPEID"]=getComboSelectedValue(EI["cbAttachedType"]);
		params["PROCESSNAME"]="DSRedactor/saveStagesAndDecisions";
		params["LIGHTPROCESS"]=true;
		params["STARTIMMEDIATLY"]=true;
		dsCall("[corews]","startprocess",params,"stagesAndDecisionsDialog.onAfterChangeStagesAndDecisions");
		createModalLoader();
	}
	////////////////////////////////////////////////////////////////////
	stagesAndDecisionsDialog.edit=function(){
		var attr=getSelectedRow(EI["tbStagesAndDecisions"]);
		lgr("stagesAndDecisionsDialog.edit");
		var params=getNewMap();
		params["STATEID"]=stateDialog.selectedStateID;
		params["CURLINKID"]=attr["OBJLINKID"];
		var stageDecisionType=getComboSelectedValue(EI["cmStageDecisionType"]);
		params["TYPE"]=stageDecisionType;
		if (stageDecisionType=="docProcType"){
			params["ID"]=getComboSelectedValue(EI["cbStages"]);
		}
		if (stageDecisionType=="decisionStageType"){
			params["ID"]=getComboSelectedValue(EI["cbDecisions"]);
		}
		params["ATTACHTYPEID"]=getComboSelectedValue(EI["cbAttachedType"]);
		params["PROCESSNAME"]="DSRedactor/saveStagesAndDecisions";
		params["LIGHTPROCESS"]=true;
		params["STARTIMMEDIATLY"]=true;
		lgr("params",params);
		dsCall("[corews]","startprocess",params,"stagesAndDecisionsDialog.onAfterChangeStagesAndDecisions");
		createModalLoader();
	}	
	///////////////////////////////////////////////////////////////////////
	stagesAndDecisionsDialog.onAfterChangeStagesAndDecisions=function(p){
		hideModalLoaderEvent();
		if ((p["lastErrorMessage"]!=null && p["lastErrorMessage"]!="") || (p["ErrorMessage"]!=null && p["ErrorMessage"]!="") || p["Result"]!="Ok"){
			showError(nvl(nvl(p["ErrorMessage"],p["lastErrorMessage"]),gRB("DSRedactor.saveStagesAndDecisionsError")));
			return false;
		}
		stagesAndDecisionsDialog.addStagesAndDecisionsDialogHide();
		stagesAndDecisionsDialog.getStagesAndDecisions();
	}
	///////////////////////////////////////////////////////////////////////
	stagesAndDecisionsDialog.getStagesAndDecisions=function(){
		var params=getNewMap();
		params["STATEID"]=stateDialog.selectedStateID;
		params["PROCESSNAME"]="DSRedactor/getStateStagesAndDecisions";
		params["LIGHTPROCESS"]=true;
		params["STARTIMMEDIATLY"]=true;
		dsCall("[corews]","startprocess",params,"stagesAndDecisionsDialog.onAfterGetStagesAndDecisions");	
		createModalLoader();
	}
	///////////////////////////////////////////////////////////////////////
	stagesAndDecisionsDialog.onAfterGetStagesAndDecisions=function(p){
		console.log(p)
		hideModalLoaderEvent();
		if ((p["lastErrorMessage"]!=null && p["lastErrorMessage"]!="") || (p["ErrorMessage"]!=null && p["ErrorMessage"]!="") || p["Result"]!="Ok"){
			showError(nvl(nvl(p["ErrorMessage"],p["lastErrorMessage"]),gRB("DSRedactor.saveStagesAndDecisionsError")));
			return false;
		}
		stagesAndDecisionsDialog.refreshTable(p["stagesAndDecisions"]);		
	}
	///////////////////////////////////////////////////////////////////////
	stagesAndDecisionsDialog.refreshTable=function(list){
		clearTable(EI["tbStagesAndDecisions"]);
		for (var i=0;i<list.length;i++){
			list[i]["TYPENAME"]=gRB("DSRedactor."+list[i]["TYPE"]);
			addtr(EI["tbStagesAndDecisions"],list[i]);
		}
	}
	///////////////////////////////////////////////////////////////////////
	return stagesAndDecisionsDialog;
}

stagesAndDecisionsDialog=stagesAndDecisionsConstructor();