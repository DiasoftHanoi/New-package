﻿/////////////////////////////////////////////////////////////////
linkedObjectsConstructor=function(){
	var askedParamsDialog=new Object();
	askedParamsDialog.curoper="none";
 	
	askedParamsDialog.panel=createExpandPanel(EI["tbAskedParams"],EI["contentPnl"],{title:gRB("DSRedactor.askedParams")});
	askedParamsDialog.window=createSimpleModal2(EI["askedParamPnl"]);
	///////////////////////////////////////////////////////////////////////
	askedParamsDialog.getContextMenu=function(){
		var attr=getSelectedRow(EI["tbAskedParams"]);
		var trFl="true";
		var createMenu= getNewList(); 
		addMenuItem(createMenu,gRB("DSRedactor.addAskedParams"),"",trFl,"SCRIPT","", "askedParamsDialog.addAskedParamsDialogShow()","");  

		if (attr!=null && attr!=""){
			addMenuItem(createMenu,gRB("DSRedactor.editAskedParams"),"",trFl,"SCRIPT","", "askedParamsDialog.editAskedParamsDialogShow()",""); 
			addMenuItem(createMenu,gRB("DSRedactor.delAskedParams"),"",trFl,"SCRIPT","", "askedParamsDialog.delAskedParamsDialogShow()",""); 
		}
		return createMenu; 	
	}
	///////////////////////////////////////////////////////////////////////
	askedParamsDialog.addAskedParamsDialogShow=function(){
		if (stateDialog.selectedStateID!=null){
			askedParamsDialog.window.setTitle(gRB("DSRedactor.addAskedParams"));
			setValue(EI["edAskedParamName"],"");			
			setValue(EI["edAskedParamSysname"],"");			
			setValue(EI["mmAskedParamGetProcess"],"");			
			askedParamsDialog.curoper="add";
			askedParamsDialog.window.show();
			showElement(EI["askedParamPnl"]);
		}
	}
	///////////////////////////////////////////////////////////////////////
	askedParamsDialog.editAskedParamsDialogShow=function(){
		var attr=getSelectedRow(EI["tbAskedParams"]);
		if (stateDialog.selectedStateID!=null && attr!=null && attr!==""){
			askedParamsDialog.window.setTitle(gRB("DSRedactor.editAskedParams"));

			setValue(EI["edAskedParamName"],attr["PARAMNAME"]);			
			setValue(EI["edAskedParamSysname"],attr["PARAMSYSNAME"]);			
			setValue(EI["mmAskedParamGetProcess"],attr["GETPROCESS"]);	
			
			askedParamsDialog.curoper="edit";
			askedParamsDialog.selectedAskedParamsID=attr["PARAMID"];
			askedParamsDialog.window.show();
			showElement(EI["askedParamPnl"]);
		}
	}
	///////////////////////////////////////////////////////////////////////
	askedParamsDialog.delAskedParamsDialogShow=function(){
		var attr=getSelectedRow(EI["tbAskedParams"]);
		if (attr!=null && attr!==""){
			if (showConfirm(gRB("DSRedactor.deleteAskedParamsConfirm"))){
				var params=getNewMap();
				params["STATEID"]=stateDialog.selectedStateID;
				params["DELPARAMID"]=attr["PARAMID"]+"";
				params["PROCESSNAME"]="DSRedactor/saveAskedParams";
				params["LIGHTPROCESS"]=true;
				params["STARTIMMEDIATLY"]=true;
				dsCall("[corews]","startprocess",params,"askedParamsDialog.onAfterChangeAskedParams");
				createModalLoader();			
			}
		}
	} 
	///////////////////////////////////////////////////////////////////////
	askedParamsDialog.addAskedParamsDialogHide=function(){
		askedParamsDialog.curoper="none";
		askedParamsDialog.window.hide();
		hideElement(EI["askedParamPnl"]);
	}

	///////////////////////////////////////////////////////////////////////
	askedParamsDialog.applyAskedParamsDialog=function(){
		lgr("askedParamsDialog.applyAskedParamsDialog");
		if (askedParamsDialog.checkParams()){
			askedParamsDialog[askedParamsDialog.curoper](); 
		}else{
			showAlert(gRB("DSRedactor.validateFieldsWarning"));
		}		
	}
	////////////////////////////////////////////////////////////////////
	askedParamsDialog.checkParams=function(){
		lgr("askedParamsDialog.checkParams");
		var returnFlag=checkElements([EI["edAskedParamName"],EI["edAskedParamSysname"]]);
		if (returnFlag==false){
			showAlert(gRB("DSRedactor.validateFieldsWarning"));
		}
		return returnFlag;
	}	
	////////////////////////////////////////////////////////////////////
	askedParamsDialog.add=function(){
		lgr("askedParamsDialog.add");
		var params=getNewMap();
		params["STATEID"]=stateDialog.selectedStateID;
		
		params["PARAMNAME"]=getValue(EI["edAskedParamName"]);
		params["PARAMSYSNAME"]=getValue(EI["edAskedParamSysname"]);
		params["GETPROCESS"]=getValue(EI["mmAskedParamGetProcess"]);
		params["PROCESSNAME"]="DSRedactor/saveAskedParams";
		params["LIGHTPROCESS"]=true;
		params["STARTIMMEDIATLY"]=true;
		dsCall("[corews]","startprocess",params,"askedParamsDialog.onAfterChangeAskedParams");
		createModalLoader();
	}
	////////////////////////////////////////////////////////////////////
	askedParamsDialog.edit=function(){
		var attr=getSelectedRow(EI["tbAskedParams"]);
		lgr("askedParamsDialog.edit");
		var params=getNewMap();
		params["STATEID"]=stateDialog.selectedStateID;

		params["CURPARAMID"]=attr["PARAMID"];
		params["PARAMNAME"]=getValue(EI["edAskedParamName"]);
		params["PARAMSYSNAME"]=getValue(EI["edAskedParamSysname"]);
		params["GETPROCESS"]=getValue(EI["mmAskedParamGetProcess"]);
		
		params["PROCESSNAME"]="DSRedactor/saveAskedParams";
		params["LIGHTPROCESS"]=true;
		params["STARTIMMEDIATLY"]=true;
		dsCall("[corews]","startprocess",params,"askedParamsDialog.onAfterChangeAskedParams");
		createModalLoader();
	}	
	///////////////////////////////////////////////////////////////////////
	askedParamsDialog.onAfterChangeAskedParams=function(p){
		hideModalLoaderEvent();
		if ((p["lastErrorMessage"]!=null && p["lastErrorMessage"]!="") || (p["ErrorMessage"]!=null && p["ErrorMessage"]!="") || p["Result"]!="Ok"){
			showError(nvl(nvl(p["ErrorMessage"],p["lastErrorMessage"]),gRB("DSRedactor.saveAskedParamsError")));
			return false;
		}
		askedParamsDialog.addAskedParamsDialogHide();
		askedParamsDialog.getAskedParams();
	}
	///////////////////////////////////////////////////////////////////////
	askedParamsDialog.getAskedParams=function(){
		var params=getNewMap();
		params["STATEID"]=stateDialog.selectedStateID;
		params["PROCESSNAME"]="DSRedactor/getStateAskedParams";
		params["LIGHTPROCESS"]=true;
		params["STARTIMMEDIATLY"]=true;
		dsCall("[corews]","startprocess",params,"askedParamsDialog.onAfterGetAskedParams");	
		createModalLoader();
	}
	///////////////////////////////////////////////////////////////////////
	askedParamsDialog.onAfterGetAskedParams=function(p){
		console.log(p)
		hideModalLoaderEvent();
		if ((p["lastErrorMessage"]!=null && p["lastErrorMessage"]!="") || (p["ErrorMessage"]!=null && p["ErrorMessage"]!="") || p["Result"]!="Ok"){
			showError(nvl(nvl(p["ErrorMessage"],p["lastErrorMessage"]),gRB("DSRedactor.saveAskedParamsError")));
			return false;
		}
		askedParamsDialog.refreshTable(p["askedParams"]);		
	}
	///////////////////////////////////////////////////////////////////////
	askedParamsDialog.refreshTable=function(list){
		clearTable(EI["tbAskedParams"]);
		for (var i=0;i<list.length;i++){
			addtr(EI["tbAskedParams"],list[i]);
		}
	}
	///////////////////////////////////////////////////////////////////////
	return askedParamsDialog;
}

askedParamsDialog=linkedObjectsConstructor();