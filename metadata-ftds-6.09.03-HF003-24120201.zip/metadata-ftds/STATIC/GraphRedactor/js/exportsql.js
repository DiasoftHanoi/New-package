exportDataDialogConstructor=function(){
	var exportDataDialog=new Object();
	
	exportDataDialog.window=createSimpleModal2(EI["exportPanel"]);


	exportDataDialog.strBuffer="";
	exportDataDialog.curExportType="";
	exportDataDialog.selectedRuleID=null;//ruleDialog.selectedRuleID;
	exportDataDialog.selectedGroupID=null;
	exportDataDialog.prfx="SCR";
	exportDataDialog.cmt="\nGO\n";
	/////////////////////////////////////////////////
	exportDataDialog.initSQL=function(){
		lgr("exportDataDialog.initSQL");
		exportDataDialog.selectedRuleID=ruleDialog.selectedRuleID;
		if (exportDataDialog.selectedRuleID!=null && exportDataDialog.selectedRuleID!=""){
			exportDataDialog.curExportType="SQL";
			exportDataDialog.strBuffer="";
			exportDataDialog.window.setTitle("Выгрузка данных SQL");
			setValue(EI["WLabel12"],"Идет формирование выгрузки данных правила, подождите...");
      		ruleNodeDialog.loadwindow.show(ruleNodeDialog.loadwindow);
      		showElement(EI["loadRuleNodesPanel"]);
      		setValue(EI["loadNodesProgress"],formatAmount(0,2));
			ruleDialog.getRulesByParams({"RULEID":exportDataDialog.selectedRuleID},"exportDataDialog.onAfterGetRuleData");
		}else{
			showAlert("Внимание! не выбрано правило для выгрузки")
		}
	}
	////////////////////////////////////////////////
	exportDataDialog.initORACLE=function(){
		lgr("exportDataDialog.iniORACLE");
    exportDataDialog.selectedRuleID=ruleDialog.selectedRuleID;
    if (exportDataDialog.selectedRuleID!=null && exportDataDialog.selectedRuleID!=""){
      exportDataDialog.curExportType="ORACLE";
      exportDataDialog.strBuffer="";
      exportDataDialog.window.setTitle("Выгрузка данных ORACLE");
      setValue(EI["WLabel12"],"Идет формирование выгрузки данных правила, подождите...");
          ruleNodeDialog.loadwindow.show(ruleNodeDialog.loadwindow);
          showElement(EI["loadRuleNodesPanel"]);
          setValue(EI["loadNodesProgress"],formatAmount(0,2));
      ruleDialog.getRulesByParams({"RULEID":exportDataDialog.selectedRuleID},"exportDataDialog.onAfterGetRuleData");
    }else{
      showAlert("Внимание! не выбрано правило для выгрузки")
    }



	}
	////////////////////////////////////////////////
	exportDataDialog.onAfterGetRuleData=function(p){
    	lgr("exportDataDialog.onAfterGetRuleData");
    	var prfx=exportDataDialog.prfx;
    	var cmt=exportDataDialog.cmt;
    	if (p["Status"]=="OK"){
    		var p=nvl(p["Result"],[]);
    		var p=nvl(p[0],[]);

    		exportDataDialog.strBuffer+="/* Создание записи правила*/\n";
    		exportDataDialog.strBuffer+="DELETE FROM "+prfx+"_RULE WHERE RULEID="+p["RULEID"]+cmt;
    		exportDataDialog.strBuffer+="INSERT INTO "+prfx+"_RULE (RULEID, SYSNAME, NAME, DESCRIPTION, RULEGROUPID, DATASETID)\n"+
    									"   VALUES ("+p["RULEID"]+",'"+p["SYSNAME"]+"','"+p["NAME"]+"','"+p["DESCRIPTION"]+"',"+p["RULEGROUPID"]+","+p["DATASETID"]+")"+cmt;

     		exportDataDialog.selectedGroupID=p["RULEGROUPID"];	
		  	exportDataDialog.selectedDatasetID=p["DATASETID"];	

			  setValue(EI["loadNodesProgress"],formatAmount(15,2));

    		groupDialog.getGroupsByParams({"RULEGROUPID":p["RULEGROUPID"]},"exportDataDialog.onAfterGetGroupRuleData");
    	}else{
    		showAlert("Ошибка получения данных правила");
    	}
  	}		
	////////////////////////////////////////////////
	exportDataDialog.onAfterGetGroupRuleData=function(p){
    	lgr("exportDataDialog.onAfterGetGroupRuleData");
    	var prfx=exportDataDialog.prfx;
    	var cmt=exportDataDialog.cmt;
    	if (p["Status"]=="OK"){
    		var p=nvl(p["Result"],[]);
    		var p=nvl(p[0],[]);
    		exportDataDialog.strBuffer+="/* Создание записи группы правила*/\n";
    		exportDataDialog.strBuffer+="DELETE FROM "+prfx+"_RULEGROUP WHERE RULEGROUPID="+p["RULEGROUPID"]+cmt;
    		exportDataDialog.strBuffer+="INSERT INTO "+prfx+"_RULEGROUP (RULEGROUPID, SYSNAME, NAME, DESCRIPTION)\n"+
    									"   VALUES ("+p["RULEGROUPID"]+",'"+p["SYSNAME"]+"','"+p["NAME"]+"','"+p["DESCRIPTION"]+"')"+cmt;
    		
			setValue(EI["loadNodesProgress"],formatAmount(20,2));
    		datasetDialog.getDatasetByParams({"DATASETID":exportDataDialog.selectedDatasetID},"exportDataDialog.onAfterGetDatasetData");
    	}else{
    		showAlert("Ошибка получения данных группы правила");
    	}
  	}	
  	///////////////////////////////////////////////////
  	exportDataDialog.onAfterGetDatasetData=function(p){
    	lgr("exportDataDialog.onAfterGetDatasetData");
    	var prfx=exportDataDialog.prfx;
    	var cmt=exportDataDialog.cmt;
    	if (p["Status"]=="OK"){
    		var p=nvl(p["Result"],[]);
    		var p=nvl(p[0],[]);
    		exportDataDialog.strBuffer+="/* Создание записи множества параметров*/\n";
    		exportDataDialog.strBuffer+="DELETE FROM "+prfx+"_DATASET WHERE DATASETID="+p["DATASETID"]+cmt;
    		exportDataDialog.strBuffer+="INSERT INTO "+prfx+"_DATASET (DATASETID, SYSNAME, FULLNAME)\n"+
    									"   VALUES ("+p["DATASETID"]+",'"+p["SYSNAME"]+"','"+p["FULLNAME"]+"')"+cmt;

			setValue(EI["loadNodesProgress"],formatAmount(30,2));    		
    		datasetParamDialog.getDatasetParamByParams({"DATASETID":exportDataDialog.selectedDatasetID},"exportDataDialog.onAfterGetDatasetParamsData");
    	}else{
    		showAlert("Ошибка получения данных группы правила");
    	}
  	}
  	////////////////////////////////////////////////////
  	exportDataDialog.onAfterGetDatasetParamsData=function(p){
  		lgr("exportDataDialog.onAfterGetDatasetParamsData");
    	var prfx=exportDataDialog.prfx;
    	var cmt=exportDataDialog.cmt;
    	if (p["Status"]=="OK"){
    		var p=nvl(p["Result"],[]);
    		
    		exportDataDialog.strBuffer+="/* Создание записи входных параметров*/\n";
    		exportDataDialog.strBuffer+="DELETE FROM "+prfx+"_DATASETPARAM WHERE DATASETID="+exportDataDialog.selectedDatasetID+cmt;
    		
    		var dd=p.length;
    		for (var i=0;i<dd;i++){
    			var rec=p[i];
    			exportDataDialog.strBuffer+="INSERT INTO "+prfx+"_DATASETPARAM (DATASETPARAMID, DATASETID, PARAMTYPE, SYSNAME, FULLNAME, PARAMVALUETYPE, ISREQUIRED)\n"+
    										"   VALUES ("+	rec["DATASETPARAMID"]+","+
    														rec["DATASETID"]+","+
    														rec["PARAMTYPE"]+",'"+
    														rec["SYSNAME"]+"','"+
    														rec["FULLNAME"]+"','"+
    														rec["PARAMVALUETYPE"]+"',"+
    														rec["ISREQUIRED"]+")"+cmt;
    		}
    		
   			setValue(EI["loadNodesProgress"],formatAmount(40,2));
    		ruleNodeDialog.getRuleNodesByParams({"RULEID":exportDataDialog.selectedRuleID},"exportDataDialog.onAfterGetRuleNodesData");
    	}else{
    		showAlert("Ошибка получения данных группы правила");
    	}  		
  	}
  	/////////////////////////////////////////////////////////
  	exportDataDialog.onAfterGetRuleNodesData=function(p){
  		lgr("exportDataDialog.onAfterGetRuleNodesData");
     	var prfx=exportDataDialog.prfx;
    	var cmt=exportDataDialog.cmt;
    	if (p["Status"]=="OK"){
    		var p=nvl(p["Result"],[]);
    		
    		exportDataDialog.strBuffer+="/* Создание записей узлов правила */\n";
    		exportDataDialog.strBuffer+="DELETE FROM "+prfx+"_RULENODE WHERE RULEID="+exportDataDialog.selectedRuleID+cmt;
    		
    		var dd=p.length;
    		var ids="";

        if (exportDataDialog.curExportType=="ORACLE"){
          exportDataDialog.strBuffer+="declare\n"; 
          exportDataDialog.strBuffer+="clob_var_node1 CLOB;\n";
          exportDataDialog.strBuffer+="clob_var_node2 CLOB;\n";
          exportDataDialog.strBuffer+="begin\n";
        }

    		for (var i=0;i<dd;i++){
    			var rec=p[i];
    			
          rec["NODEVALUE"]=nvl(rec["NODEVALUE"],"");
          rec["DEFAULTVALUE"]=nvl(rec["DEFAULTVALUE"],"");
          rec["VALUEID"]=nvl(rec["VALUEID"],"NULL");
          rec["ISUSEDEFAULT"]=nvl(rec["ISUSEDEFAULT"],"NULL");
          rec["ORDERNO"]=nvl(rec["ORDERNO"],"NULL");
          
          
          if (exportDataDialog.curExportType=="SQL"){
            exportDataDialog.strBuffer+="INSERT INTO "+prfx+"_RULENODE (RULENODEID, PARENTRULENODEID, RULEID, NODETYPE, VALUEID, NODEVALUE, DEFAULTVALUE, ISUSEDEFAULT, ORDERNO)\n"+
                        "   VALUES ("+  rec["RULENODEID"]+","+
                                        rec["PARENTRULENODEID"]+","+
                                        rec["RULEID"]+",'"+
                                        rec["NODETYPE"]+"',"+
                                        rec["VALUEID"]+",'"+
                                        rec["NODEVALUE"]+"','"+
                                        rec["DEFAULTVALUE"]+"',"+
                                        rec["ISUSEDEFAULT"]+","+
                                        rec["ORDERNO"]+")"+cmt;
            
          }
          if (exportDataDialog.curExportType=="ORACLE"){
              exportDataDialog.strBuffer+="clob_var_node1 :='"+ nvl(rec["NODEVALUE"],"")+"';\n"; 
              exportDataDialog.strBuffer+="clob_var_node2 :='"+ nvl(rec["DEFAULTVALUE"],"")+"';\n"; 
              
              exportDataDialog.strBuffer+="INSERT INTO "+prfx+"_RULENODE (RULENODEID, PARENTRULENODEID, RULEID, NODETYPE, VALUEID, NODEVALUE, DEFAULTVALUE, ISUSEDEFAULT, ORDERNO)\n"+
                        "   VALUES ("+  rec["RULENODEID"]+","+
                                        rec["PARENTRULENODEID"]+","+
                                        rec["RULEID"]+",'"+
                                        rec["NODETYPE"]+"',"+
                                        rec["VALUEID"]+","+
                                        "clob_var_node1"+","+
                                        "clob_var_node2"+","+
                                        rec["ISUSEDEFAULT"]+","+
                                        rec["ORDERNO"]+")";
               exportDataDialog.strBuffer+=";\n";
          }
          ids+= (i==0 ? "" : ",")  + rec["RULENODEID"];         
    		}

        if (exportDataDialog.curExportType=="ORACLE"){
          exportDataDialog.strBuffer+="end;"+cmt;
        }       
    		
    		exportDataDialog.ruleNodes=p;
    		exportDataDialog.strBuffer+="/* Создание сообщений для узлов правила */\n";
    		exportDataDialog.strBuffer+="DELETE FROM "+prfx+"_RULENODELOG WHERE RULENODEID in ("+ids+")"+cmt;

			setValue(EI["loadNodesProgress"],formatAmount(50,2));

    		exportDataDialog.exportRuleNodeLogs();
    	}else{
    		showAlert("Ошибка получения данных группы правила");
    	}   		
  	}
  	/////////////////////////////////////////////////////////////////
  	 exportDataDialog.exportRuleNodeLogs=function(){
  		lgr("exportDataDialog.exportRuleNodeLogs");
  		var curNode=exportDataDialog.ruleNodes.splice(0,1)[0];
  		if (curNode!=null){
  			logSchemeDialog.getLogListByParams({"RULENODELOGID":curNode["RULENODEID"]}," exportDataDialog.onAfterGetRuleNodeLog");
  		}else{
  			testDatasetDialog.testDatasetGetListByParams({"RULEID":exportDataDialog.selectedRuleID}," exportDataDialog.onAfterGetTestDatasetData");
  		}
  	}
  	/////////////////////////////////////////////////////////////////
  	 exportDataDialog.onAfterGetRuleNodeLog=function(p){
  		lgr(" exportDataDialog.onAfterGetRuleNodeLog");
    	var prfx=exportDataDialog.prfx;
    	var cmt=exportDataDialog.cmt;
    	if (p["Status"]=="OK"){
    		var p=nvl(p["Result"],[]);
    		var dd=p.length;
    		for (var i=0;i<dd;i++){
    			var rec=p[i];
     			exportDataDialog.strBuffer+="INSERT INTO "+prfx+"_RULENODELOG (RULENODELOGID, RULENODEID, LOGSCHEMEID, LOGMESSAGE)\n"+
    										"   VALUES ("+rec["RULENODELOGID"]+","+rec["RULENODEID"]+","+rec["LOGSCHEMEID"]+",'"+rec["LOGMESSAGE"]+"')"+cmt;   			
    		}
			setValue(EI["loadNodesProgress"],formatAmount(60,2));
			exportDataDialog.exportRuleNodeLogs();
    	}else{
    		showAlert("Ошибка получения данных группы правила");
    	}  		

  	}
  	////////////////////////////////////////////////////////////////////
  	 exportDataDialog.onAfterGetTestDatasetData=function(p){
  		lgr(" exportDataDialog.onAfterGetTestDatasetData");
    	var prfx=exportDataDialog.prfx;
    	var cmt=exportDataDialog.cmt;
    	if (p["Status"]=="OK"){
    		var p=nvl(p["Result"],[]);
    		var termStr="";
    		var ids="";

    		var dd=p.length;
        if (dd>0){
          if (exportDataDialog.curExportType=="ORACLE"){
            termStr+="declare clob_var_dataset CLOB;\n";
            termStr+="begin\n";
          }

      		for (var i=0;i<dd;i++){
      			var rec=p[i];
            rec["CREATIONDATE"]=nvl(rec["CREATIONDATE"],"NULL");

            if (exportDataDialog.curExportType=="SQL"){
       			  termStr+="INSERT INTO "+prfx+"_TESTDATASET (TESTDATASETID, RULEID, FULLNAME, RESULTVALUE, DATASET, CREATIONDATE)\n"+
      				  						"   VALUES ("+rec["TESTDATASETID"]+","+
      					         								  rec["RULEID"]+",'"+
      									         				  rec["FULLNAME"]+"','"+
      													          rec["RESULTVALUE"]+"','"+
        													        rec["DATASET"]+"',"+
       													          rec["CREATIONDATE"]+")"+cmt;   			
      			
      		  }
            if (exportDataDialog.curExportType=="ORACLE"){
                termStr+="clob_var_dataset :='"+ rec["DATASET"]+"';\n"; 

                termStr+="INSERT INTO "+prfx+"_TESTDATASET (TESTDATASETID, RULEID, FULLNAME, RESULTVALUE, DATASET, CREATIONDATE)\n"+
                            "   VALUES ("+rec["TESTDATASETID"]+","+
                                          rec["RULEID"]+",'"+
                                          rec["FULLNAME"]+"','"+
                                          rec["RESULTVALUE"]+"',"+
                                          "clob_var_dataset"+","+
                                          rec["CREATIONDATE"]+");\n";                
            }
          ids+= (i==0 ? "" : ",")  + rec["TESTDATASETID"];
          }
          
          if (exportDataDialog.curExportType=="ORACLE"){
            termStr+="end;"+cmt;
          }          

      		exportDataDialog.strBuffer+="/* Создание записей тестовых данных правила */\n";
      		exportDataDialog.strBuffer+="DELETE FROM "+prfx+"_TESTDATASET WHERE TESTDATASETID in ("+ids+")"+cmt;    		
      		exportDataDialog.strBuffer+=termStr;    		
        }
    		setValue(EI["loadNodesProgress"],formatAmount(100,2));
      	ruleNodeDialog.loadwindow.hide();
      	hideElement(EI["loadRuleNodesPanel"]);

      	setValue(EI["mmExportData"],exportDataDialog.strBuffer);
			  exportDataDialog.window.show(exportDataDialog.window);
			  showElement(EI["exportPanel"]);     		

    	}else{
    		showAlert("Ошибка");
    	}   		
  	}



	return exportDataDialog;
}

exportDataDialog=exportDataDialogConstructor();

