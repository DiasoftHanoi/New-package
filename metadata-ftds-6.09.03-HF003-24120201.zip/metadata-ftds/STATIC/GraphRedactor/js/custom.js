
is7=true;
var temp=[];
if (temp["Class"]!=null){
  is7=true;
}

clearTable=function (id) {var tblStr = id.replace(/\./g, '_');var tbl = eval(tblStr);tbl.stopEditing();var store = tbl.getStore();if (store) {store.removeAll();}else {return false;}doStoreTableXML(tblStr, tbl.getStore());return true;}

lgr=function(msg){
/*   try {
     console.log(msg);
   }catch (e){}
*/
}
//////////////////////////////////////////////////////////////////////////////
/*
dsCall=function (p,d,arr,cb){var UID=new Date().getTime();
arr=prepareVal(arr);
var cbFunc=eval(cb);
if(cbFunc){window["cbfunc"+UID]=cbFunc;
cb="cbfunc"+UID
}var url="";
if(window.document.forms.length>0){url=window.document.forms.mainform.getAttribute("dsCallTransport")
}else{url=gbi("mainreportform").getAttribute("dsCallTransport")
}var item={servicename:p,servicemethod:d,functionname:cb,income:arr,frameUUID:gbi("UUIDField").value};
Wicket.Log.info("Send ajax request with params: "+p+", "+d+", "+cb);
wicketAjaxPost(url,ajaxBobyFromObject(item),function(){},function(){})
} 
*/

/*
function dsCall(p, d, arr, cb) {
 var UID = new Date().getTime(); 
 var cbFunc = eval(cb);  
 if (cbFunc) {
  window['cbfunc' + UID] = cbFunc;
  cb = 'cbfunc' + UID;
 }   
 var url = '';
 if (window.document.forms.length > 0) {
  url = window.document.forms['mainform'].getAttribute('dsCallTransport');
 }else{
  url = gbi('mainreportform').getAttribute('dsCallTransport');
 } 
        var arr2 = new Map(); for (var k in arr) {if (typeof(arr[k])!='function') arr2.put(k,arr[k]);};
 var item = {servicename : p, servicemethod : d, functionname: cb, income : arr2, frameUUID : gbi('UUIDField').value};  
 Wicket.Log.info("Send ajax request with params: " + p + ", " + d + ", " + cb); 
 wicketAjaxPost(url, ajaxBobyFromObject(item), function(){},  function(){});    
}
*/

function dsCall1111(p, d, arr, cb) {
if (window.document != null && window.document.forms["mainform"] != null) {
 var UID = new Date().getTime();
 var cbFunc = eval(cb);
 if (cbFunc) {window["cbfunc" + UID] = cbFunc; cb = "cbfunc" + UID;}
 var url = window.document.forms["mainform"].getAttribute("dsCallTransport");
 var arr2 = conv2dsCall(arr);
 var item = {servicename: p,servicemethod: d,functionname: cb,income: arr2};
 wicketAjaxPost(url, ajaxBobyFromObject(item), function () {}, function () {});
}
}
function dsCall(p, d, arr, cb) {
 var UID = new Date().getTime();
 var cbFunc = eval(cb);
 if (cbFunc) {
  window['cbfunc' + UID] = cbFunc;
  cb = 'cbfunc' + UID;
 }
 var url = '';
 if (window.document.forms.length > 0) {
  url = window.document.forms['mainform'].getAttribute('dsCallTransport');
 }else{
  url = gbi('mainreportform').getAttribute('dsCallTransport');
 }
 var arr2 = conv2dsCall(arr);
 var item = {servicename : p, servicemethod : d, functionname: cb, income : arr2, frameUUID : gbi('UUIDField').value};
 Wicket.Log.info("Send ajax request with params: " + p + ", " + d + ", " + cb);
 wicketAjaxPost(url, ajaxBobyFromObject(item), function(){},  function(){});
}


function conv2dsCall(arr){var arr2;
if (typeof(arr) == "object" && arr != null){
 arr2 = (arr.length)?getNewList():getNewMap();
 for (var k in arr) {
  if (typeof(arr[k])!="function") 
   if (typeof(arr[k])=="object") {arr2.put(k,conv2dsCall(arr[k]))} else {arr2.put(k,arr[k]);};
 }
} else {arr2 = arr};
return arr2
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
prepareVal=function(obj){
    var res=null;    
    if (obj instanceof Object){
      var isMap=false;
      
        for (var ar in obj){
          if (obj.hasOwnProperty(ar) && (ar+"").search(/[^0-9]/gi)>-1 && typeof(obj[ar])+""!="function"){
            isMap=true;
            break;
          }
        }
      
      if (isMap){
        res=getNewMap();
        for (var ar in obj){
          if (obj.hasOwnProperty(ar) && typeof(obj[ar])+""!="function"){
            res.put(ar,prepareVal(obj[ar]));
          }
        }
      }else{
        res=getNewList();
        var dd=obj.length;
        for (var i=0;i<dd;i++){
          res.add(prepareVal(obj[i]));
        }          
      }
      return res;
    }
    return obj;
}
//////////////////////////////////////////////////////////////////////////////
hasClass=function (ele, cls) {
        return (nvl(ele.className,"")).match(new RegExp('(\\s|^)' + cls + '(\\s|$)'));
}
//////////////////////////////////////////////////////////////////////////////
addClass=function (ele, cls) {
     if (!this.hasClass(ele, cls)) ele.className += " " + cls;
}
//////////////////////////////////////////////////////////////////////////////
toogleClass=function (ele, cls1,cls2) {
    if (hasClass(ele,cls1)){
      removeClass(ele,cls1);
      addClass(ele,cls2);      
   }else{
      removeClass(ele,cls2);
      addClass(ele,cls1);      
   } 
}
//////////////////////////////////////////////////////////////////////////////
removeClass=function (ele, cls) {
    if (hasClass(ele, cls)) {
       var reg = new RegExp('(\\s|^)' + cls + '(\\s|$)');
       ele.className = (nvl(ele.className,"")).replace(reg, ' ');
    }
}
////////////////////////////////////////////////////////////////////////////////
changeTableSortOrder=function (idTable, order) {
    return false;
}
////////////////////////////////////////////////////////////////////////////////
closeVisLMnu=function () {
    var lm = gbi("lmTD");
    if (lm) {
        if (lm.style.display != "none") {
            lm.style.display = "none";
            gbi("lm_close_btn").style.backgroundPosition = "6";
            //setCookie("clozedLM", true);
        }
    }
    try {
        callOnResize();
    } catch (e) {
    }
}
////////////////////////////////////////////////////////////////////////////////
resizeElement=function (Data,rootWidth,rootHeight){

  var dataWidth=getWidth(Data["id"]);
  var dataHeight=getHeight(Data["id"]);
  var marginbtm=Data["margin-bottom"];

  if (Data["width"]){
      dataWidth= (Data["width"].indexOf("%")>-1) ? stringToNumeric(Data["width"].replace("%",""))/100*rootWidth : stringToNumeric(Data["width"]);
      if (dataWidth!=getWidth(Data["id"])){setWidth(Data["id"],dataWidth);}
    }   
    if (Data["height"]){
      dataHeight= (Data["height"].indexOf("%")>-1) ? stringToNumeric(Data["height"].replace("%",""))/100*rootHeight : stringToNumeric(Data["height"]);
      dataHeight= marginbtm ? dataHeight-stringToNumeric(marginbtm) : dataHeight;
      if (dataHeight!=getHeight(Data["id"])){setHeight(Data["id"],dataHeight);}   
  }
  if (Data["bottom"]){
    setCoordY(Data["id"],rootHeight-dataHeight-stringToNumeric(Data["bottom"]));
  }
  if (Data["right"]){
    setCoordX(Data["id"],rootWidth-dataWidth-stringToNumeric(Data["right"]));
  }
  
  var rect={"width":dataWidth,"height":dataHeight}
    if (Data["childs"]){
      var dd=Data["childs"].length;
    for (var i=0;i<dd;i++){
           var childEl=Data["childs"][i];
       var rect=resizeElement(childEl,dataWidth,dataHeight);
       if (childEl["display"]=="block"){
        dataHeight-=rect["height"];
       }
    }
  }
  return rect;
}
////////////////////////////////////////////////////////////////////////////////
resizeWindow=function(data,rootWidth,rootHeight){
  resizeElement(data[0],rootWidth,rootHeight); 
}
////////////////////////////////////////////////////////////////////////////////
resizeForm=function(){

       if (resizeFlag==false){
    resizeFlag=true;
    var minWidth=800;
    var minHeight=670;

    setPageBodyContainerWidth(minWidth);
    setFormHeight(minHeight);
    resizeElement(resizeData[0],minWidth,minHeight);

    var mainformWidth,mainformHeight;

    if (is7==true){
      var bodyEl=Ext.get(Ext.query("BODY")[0]);
      mainformWidth=bodyEl.getWidth();
      mainformHeight=bodyEl.getHeight();
    }else{
      var whiteSheet=Ext.query("TABLE[class=whiteSheet]")[0];
      mainformWidth=whiteSheet.clientWidth||whiteSheet.offsetWidth;
      mainformHeight=whiteSheet.clientHeight||whiteSheet.offsetHeight;
    }

    var fWidth=  mainformWidth<minWidth ? minWidth : mainformWidth;
    var fHeight = mainformHeight<minHeight ? minHeight : mainformHeight;
    setPageBodyContainerWidth(fWidth);
    setFormHeight(fHeight);
    setWidth("DTRedactor",fWidth);
    setHeight("DTRedactor",fHeight);
    resizeElement(resizeData[0],fWidth,fHeight);
    resizeFlag=false;
   }
}
////////////////////////////////////////////////////////////////////////////////
createSimpleModal2=function  (id, popUpStyle,closable,resizable,resizeFunction,modal) {
  closable= closable==null ? true : closable;
  modal= modal==null ? true : modal;
  var minWidth= resizable==null ? null : 300;
  resizable= resizable==null ? false : resizable;

  var widthPnl=getWidth(id)+ (Ext.isIE ? 17 : 15);
  var heightPnl=null;
  if (closable==true) {
    heightPnl=getHeight(id)+  (Ext.isIE ? 34 : 33); 
  }else{
    heightPnl=getHeight(id)+(Ext.isIE ? 15 : 17)
  }
  
  var xcoord= Ext.isIE ? 0 : 7;
  var ycoord= Ext.isIE ? 0 : 1;
  setCoordX(id,xcoord);
  setCoordY(id,ycoord);
  var win = new Ext.Window({
                "width":widthPnl,
                "height":heightPnl,
                "resizable":resizable,
                "contentEl":id,
                "closable":closable,
                "closeAction":'hide',
                "minWidth":minWidth,
                "modal": modal,
                "plain": true});
  if (resizeFunction){
     win.on("bodyresize",resizeFunction);
  }
  win.hide();
  return win;
}
////////////////////////////////////////////////////////////////////////////////
crmodal=function (str, id, hid, popUpStyle) {
    if (!popUpStyle) {
        popUpStyle = "popUpStyle";
    }
    var rs = self.document.readyState;
    if (self.HTMLElement) {
        rs = "loaded";
    }
    if (/loaded|complete/.test(rs)) {
        var htm = self.document.getElementsByTagName("html")[0];
        var bod = self.document.getElementsByTagName("body")[0];
        var dd = getLikeElements("DIV", "class", popUpStyle);
        if (dd.length < 1) {
            bod.style.overflow = "hidden";
            htm.scrollbars = "0";
            bod.style.height = "100%";
            htm.style.height = "100%";
        }
        var scrollX = getScrollLeft();
        var scrollY = getScrollTop();
        if (gbi("tipaModal" + id)) {
            return;
        }
        var lb = self.document.createElement("div");
        lb.style.position = "absolute";
        setScroll(scrollX, scrollY);
        lb.style.left = scrollX;
        lb.style.top = scrollY;
        lb.id = "tipaModal" + id;
        lb.style.width = "100%";
        lb.style.height = "100%";
        lb.style.zIndex = 10000;
        lb.className = popUpStyle;

        if (hid == "hid") {
            lb.style.display = "none";
        } else {
            hidAllSel(id);
        }
        lb.innerHTML = str;
        bod.appendChild(lb);
        if (gbi(id + "btn")) {
            addHandler(gbi(id + "btn"), "click", function () {closemodal(id);});
        }
        if (hid != "hid") {
            setFocus("tipaModal" + id);
        }
    } else {
        setTimeout(function () {crmodal(str, id, hid);}, 500);
    }
}
////////////////////////////////////////////////////////////////////////////////
if (is7){
  showElement=function (id){
    try{var gwtel=getGWTElementById(id);
      if(gwtel!=null){
        setGWTVisible(gwtel,true);
        return true
      }
    }catch(e){}
    var el=gbi(id);
    if(el){
      Ext.get(el).stopFx(true)
      Ext.get(el).show(true);
      el.style.display="";
      if(el.tagName=="IMG"){
        Ext.get(el.parentNode).stopFx(true)
        Ext.get(el.parentNode).show(true);
        el.parentNode.style.display=""
      }
      if(el.tagName=="DIV" && el.parentNode.id=="PageBodyContainer"){
          Ext.get(el.parentNode).stopFx(true)
          Ext.get(el.parentNode).show(true);
        el.parentNode.parentNode.style.display="";
        showElement(gbi("formCaptionLabel"));
      }else{
        if(el.tagName=="DIV" && el.id=="formCaptionLabel"){
          el.style.display=el.innerText==""?"none":"";
        }
      }
      if(el.tagtype&&el.tagtype=="table"){
        eval(id.replace(/\./g,"_")).setVisible(true);
      }
    }
    if(gbi(id+".parent")){
      showElement(id+".parent");
    }
    fixTabVisualPosition();
    var inners=Ext.query("[id^="+id+"]");
    var innersLength=inners.length;
    for(var i=0;i<inners.length;i++){
      var fullid=inners[i].id;
      var elid=fullid.replace(/[\.]/g,"_");
      if(isVisible(fullid)){
        eval("try{"+elid+".setHeight("+elid+".height);"+elid+".updateBox("+elid+".getBox());}catch(e){}")
      }
    }
  }
}else{
  showElement=function (id) {
      var el = gbi(id);
      if (el) {
        Ext.get(el).stopFx(true)
  	    Ext.get(el).show(true);
          el.style.display = '';
          if(Ext.isIE) {
  			el.style.visibility='';
  		}
          if (el.tagName == 'IMG'){ 
         Ext.get(el.parentNode).stopFx(true)
  		   Ext.get(el.parentNode).show(true);
  		   el.parentNode.style.display = '';
  		}   

          // Show formCaption 
          if (el.tagName == "DIV" && el.parentNode.id == "PageBodyContainer") {
              el.parentNode.parentNode.style.display = '';
              showElement(gbi("formCaptionLabel"));
          } else if (el.tagName == "DIV" && el.id == "formCaptionLabel") {
              // do not show empty form caption
              el.style.display = el.innerText==''?'none':'';
          } 
          
          if (el.tagtype&& el.tagtype== 'table') {eval(id.replace(/\./g,"_")).setVisible(true);}
      }
      if (gbi(id + '.parent.popUp')) {
  		id = id + '.parent.popUp'
          var popUpStyle = 'popUpStyle';
  		var htm = self.document.getElementsByTagName('html')[0];
          var bod = self.document.getElementsByTagName('body')[0];
          var dd = getLikeElements('DIV', 'class', popUpStyle);
          if (dd.length == 0) {
              bod.style.overflow = 'hidden';
              htm.style.overflow = 'hidden';
              htm.scrollbars = '0';
              bod.style.height = '100%';
              htm.style.height = '100%';
          }
  		
  		
  		var scrollX = getScrollLeft();
          var scrollY = getScrollTop();
          gbi(id).style.left = scrollX;
          gbi(id).style.top = scrollY;
          var dd = Ext.DomQuery.select("div.popUpStyle");
          if (dd.length < 1) hidAllSel();
  		showElement(id);
      }
      if (gbi(id + '.parent')) showElement(id + '.parent');
      fixTabVisualPosition();
      var inners;
      try {
          inners = Ext.query("[id^="+id+"]");
      } catch(e) {
      	inners = [];
      }
  	var innersLength=inners.length;
  	for(var i = 0 ; i < innersLength; i++){
  		var fullid = inners[i].id;
  		var elid = fullid.replace(/[\.]/g,'_');
  		if(isVisible(fullid)) {
  			eval("try{"+elid+".setHeight("+elid+".height);" +elid+".updateBox("+elid+".getBox());}catch(e){}");
  		}
  	}
  }
}

////////////////////////////////////////////////////////////////////////////////
getAbsolutePosition = function (el) {
	var rEl = { x:  stringToNumeric(el.offsetLeft || el.style.left), 
                y:  stringToNumeric(el.offsetTop || el.style.top)};
    if (el.parentNode && el.id!="mainform" && el.parentNode.tagName!="BODY") {
        var tmp = getAbsolutePosition(el.parentNode);
		rEl.x =rEl.x+ tmp.x;
		rEl.y =rEl.y+ tmp.y;
	}
	return rEl ;
}
////////////////////////////////////////////////////////////////////////////////
function destroySimpleModal2(id){
   if (gbi(id+'.parent.popUp')){
      var idxDot=id.lastIndexOf(".");
      if (idxDot==-1){idxDot=id.length;}else{idxDot;}
      var parentid=id.substring(0,idxDot);
      if (parentid!=id){
         var el=gbi(id);
         var parentEl=gbi(parentid);
         parentEl.appendChild(el);
         setCoordX(id,el.getAttribute("oldx"));
         setCoordY(id,el.getAttribute("oldy"));

         var popupel=gbi(id+'.parent.popUp');
         popupel.parentNode.removeChild(popupel);
         removeClass(el,"shadall");
         removeClass(el,"poprama");
		 removeClass(el,"css3");
         //refreshCSS3(el);
		 var htm = self.document.getElementsByTagName('html')[0];
         var bod = self.document.getElementsByTagName('body')[0];
         var dd = getLikeElements('DIV', 'class', 'popUpStyle');

         if (dd.length == 0) {
             bod.style.overflow = 'auto';
             htm.style.overflow = 'auto';
         }
      }
	  
   }
}
////////////////////////////////////////////////////////////////////////////////
checkElements=function(list){
  var resultFlag=true;
  for (var i=0;i<list.length;i++){
    var el=list[i];
    lgr(gbi(el));
    lgr(gbi(el).getAttribute("tagtype"));
    
    if ((gbi(el).tagName=="SELECT" && is7==false) || (gbi(el).getAttribute("tagtype")=="combobox" && is7==true)){
      var selComboValue=getComboSelectedValue(el);
      if (selComboValue=="" || selComboValue==null || selComboValue=="0"){
        setErrorClass(el,true);
        resultFlag=false;    
      } 
    }else 
    if  (gbi(el).getAttribute("tagtype")=="table"){
      if (getRowsCount(el)==0){
        setErrorClass(el,true);
        resultFlag=false;        
      }
    }else{
      if (getValue(el)=="" || getValue(el)==null || hasClass(gbi(el),"error")){
        setErrorClass(el,true);
        resultFlag=false;
      }
    }
  }
  return resultFlag;
}
////////////////////////////////////////////////////////////////////////////////
cloneObj=function (obj){
    if(obj == null || typeof(obj) != 'object')
        return obj;
    var temp = new obj.constructor();
    for(var key in obj)
        temp[key] = cloneObj(obj[key]);
    return temp;
}
////////////////////////////////////////////////////////////////////////////////
function preventSelection(element){
  var preventSelection = false;

  function addHandler(element, event, handler){
    if (element.attachEvent) 
      element.attachEvent('on' + event, handler);
    else 
      if (element.addEventListener) 
        element.addEventListener(event, handler, false);
  }
  function removeSelection(){
    if (window.getSelection) { window.getSelection().removeAllRanges(); }
    else if (document.selection && document.selection.clear)
      document.selection.clear();
  }
  function killCtrlA(event){
    var event = event || window.event;
    var sender = event.target || event.srcElement;

    if (sender.tagName.match(/INPUT|TEXTAREA/i))
      return;

    var key = event.keyCode || event.which;
    if (event.ctrlKey && key == 'A'.charCodeAt(0))  // 'A'.charCodeAt(0) можно заменить на 65
    {
      removeSelection();

      if (event.preventDefault) 
        event.preventDefault();
      else
        event.returnValue = false;
    }
  }

  // не даем выделять текст мышкой
  addHandler(element, 'mousemove', function(){
    if(preventSelection)
      removeSelection();
  });
  addHandler(element, 'mousedown', function(event){
    var event = event || window.event;
    var sender = event.target || event.srcElement;
    preventSelection = !sender.tagName.match(/INPUT|TEXTAREA/i);
  });

  // борем dblclick
  // если вешать функцию не на событие dblclick, можно избежать
  // временное выделение текста в некоторых браузерах
  addHandler(element, 'mouseup', function(){
    if (preventSelection)
      removeSelection();
    preventSelection = false;
  });

  // борем ctrl+A
  // скорей всего это и не надо, к тому же есть подозрение
  // что в случае все же такой необходимости функцию нужно 
  // вешать один раз и на document, а не на элемент
  addHandler(element, 'keydown', killCtrlA);
  addHandler(element, 'keyup', killCtrlA);
}

function addMenuItem(menuObj, nameValue, childrenValue, enableValue, typeValue, tagValue, scriptValue, validateValue){
  //определяем значения по умолчанию
  if (!nameValue) nameValue=""; 
  if (!childrenValue) childrenValue="";
  if (!enableValue) enableValue="true";
  if (!typeValue) typeValue="";
  if (!tagValue) tagValue="";
  if (!scriptValue) scriptValue="";
  if (!validateValue) validateValue="false";

  //создаем пункт меню
  var map = getNewMap();//получаем пустой map 
  map.put("name", nameValue);
  if (childrenValue!=="")
    map.put("children", childrenValue)
  map.put("enabled", enableValue); 
  map.put("type", typeValue);
  map.put("tag", tagValue);
  map.put("script", scriptValue);
  map.put("validate", validateValue);
  menuObj.add(map);
}

function tableDisable(id){
  var tblStr = id.replace(/\./g, "_");
  var tbl = eval(tblStr);
  tbl.disable();
}

function tableEnable(id){
  var tblStr = id.replace(/\./g, "_");
  var tbl = eval(tblStr);
  tbl.enable();
}


