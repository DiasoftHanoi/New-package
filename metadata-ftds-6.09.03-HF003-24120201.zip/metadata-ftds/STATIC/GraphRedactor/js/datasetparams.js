/////////////////////////////////////////////////////////////////
DatasetParamDialogConstructor=function(){
	var datasetParamDialog=new Object();
	datasetParamDialog.curoper="none";
 	datasetParamDialog.viewTableName=EI["dbDataTable"];
 	datasetParamDialog.selectedDatasetParamID=null;
  datasetParamDialog.selectedDatasetParamName=null;
  
  datasetParamDialog.window=createSimpleModal2(EI["datasetParamPnl"]);
  /////////////////////////////////////////////////////////////////////////////
  datasetParamDialog.getDatasetParamByParams=function(params,callback){
    lgr("datasetParamDialog.getDatasetParamByParams");
    callback = callback==null ? "datasetParamDialog.fillDatasetParam" : callback; 
    if (callback=="datasetParamDialog.fillDatasetParam"){
      clearTable(datasetParamDialog.viewTableName);
      datasetParamDialog.selectedDatasetParamID=null;
      datasetParamDialog.checkRibbonControls();
      disableElement(datasetParamDialog.viewTableName);
    }
    params= params!=null ? params : getNewMap();
    params['ORDERBY']= params['ORDERBY']==null ? "SYSNAME" :params['ORDERBY'];
    dsCall("[dmsws]","ruleDatasetParamGetListByParams",params,callback)
  }
  ////////////////////////////////////////////////////////////////////
  datasetParamDialog.fillDatasetParam=function(p){
    lgr("datasetParamDialog.fillDatasetParam");
    enableElement(datasetParamDialog.viewTableName);
    var p=p["Result"];
    if (p!=null && p!==""){
      var dd=p.length;
      for (var i=0;i<dd;i++){
        addRow(datasetParamDialog.viewTableName,p[i]);
      }
    }
  }
  ////////////////////////////////////////////////////////////////////
  datasetParamDialog.selectDatasetParam=function(){
    lgr("datasetParamDialog.selectDatasetParam");
    var sel=getSelectedRow(datasetParamDialog.viewTableName);
    if (sel!=="" && sel!=null){
      ribbonMenu.switchToTabByIndex(2); // Выбирает закладку риббон меню с группами
      datasetParamDialog.selectedDatasetParamID=sel["DATASETPARAMID"];
      datasetParamDialog.selectedDatasetParamName=sel["SYSNAME"];
      datasetParamDialog.checkRibbonControls();
    }  
  }
  ////////////////////////////////////////////////////////////////////
  datasetParamDialog.checkRibbonControls=function(){
    lgr("datasetParamDialog.checkRibbonControls");    
    if (datasetParamDialog.selectedDatasetParamID==null){
      gbi('edit-datasetParam-btn').disable();
      gbi('del-datasetParam-btn').disable();  
    }else{
      gbi('edit-datasetParam-btn').enable();
      gbi('del-datasetParam-btn').enable();    
    }
  }
  ////////////////////////////////////////////////////////////////////
  datasetParamDialog.addDatasetParamDialogShow=function(){
    lgr("datasetParamDialog.addDatasetParamDialogShow");
    hideElement(EI["datasetParamPnl"]);
    datasetParamDialog.window.show(datasetParamDialog.window);
    datasetParamDialog.window.setTitle("Добавление нового параметра");
    datasetParamDialog.curoper="add";
    datasetDialog.getDatasetByParams(null,"datasetParamDialog.onAfterGetDatasetByParams");
  }
  ////////////////////////////////////////////////////////////////////
  datasetParamDialog.onAfterGetDatasetByParams=function(p){
    lgr("datasetParamDialog.onAfterGetDatasetByParams");
    if (p["Status"]=="OK"){
      var p=p["Result"];
      if (p!=null && p!==""){
        var dd=p.length;
        clearComboOptions(EI["cmParamDataset"]);
        if (is7==false){
          addComboOption(EI["cmParamDataset"],"","");
        }
        for (var i=0;i<dd;i++){
          addComboOption(EI["cmParamDataset"],p[i]["DATASETID"],p[i]["FULLNAME"]);
        }
        datasetParamDialog.datasetParamDialogShow();
      }
    }else{
      showAlert("Ошибка получения списка входных множеств");
    }
  }

  ////////////////////////////////////////////////////////////////////
  datasetParamDialog.datasetParamDialogShow=function(){
    lgr("datasetParamDialog.datasetParamDialogShow");
    if (datasetParamDialog.curoper=="add"){
      if (datasetDialog.selectedDatasetID!=null){
        setComboOptionByValue(EI["cmParamDataset"],datasetDialog.selectedDatasetID);
      }
      lgr('showElement(EI["datasetParamPnl"])');
      showElement(EI["datasetParamPnl"]);
    }else if (datasetParamDialog.curoper=="edit"){
      datasetParamDialog.getDatasetParamByParams({"DATASETPARAMID":datasetParamDialog.selectedDatasetParamID},"datasetParamDialog.onAfterGeteditDatasetParamDialogShow");     
    }else{
      showAlert("Ошибка типа операции");
    }
  }
  ////////////////////////////////////////////////////////////////////
  datasetParamDialog.datasetParamDialogHide=function(){
    lgr("datasetParamDialog.datasetParamDialogHide");
    datasetParamDialog.curoper="none";
    datasetParamDialog.window.hide();
    hideElement(EI["datasetParamPnl"]);
  }

  ////////////////////////////////////////////////////////////////////
  datasetParamDialog.applyChanges=function(){
    lgr("datasetParamDialog.applyChanges");
    if (datasetParamDialog.checkParams()){
      datasetParamDialog[datasetParamDialog.curoper](); 
    }else{
      showAlert("Не заполнены все обязательные поля");
    }
  }
  ////////////////////////////////////////////////////////////////////
  datasetParamDialog.checkParams=function(){
    lgr("datasetParamDialog.checkParams");
    var returnFlag=checkElements([EI["cmParamDataset"],EI["edParamSysName"],EI["cmParamValueType"],EI["cmParamType"]]);
    return returnFlag;  
  }
  ////////////////////////////////////////////////////////////////////
  datasetParamDialog.add=function(){
    lgr("datasetParamDialog.add");
    var params=getNewMap();
    params["DATASETID"]=getComboSelectedValue(EI["cmParamDataset"]);
    params["PARAMTYPE"]=stringToNumeric(getComboSelectedValue(EI["cmParamType"]))-1;
    params["PARAMVALUETYPE"]=getComboSelectedValue(EI["cmParamValueType"]);
    params["SYSNAME"]=getValue(EI["edParamSysName"]);
    params["FULLNAME"]=getValue(EI["edDescription"]);
    params["ISREQUIRED"]=getValue(EI["cbIsRequired"])==true ? parseInt(1) : parseInt(0);
    disableElement(EI["datasetParamPnl"]);
    dsCall("[dmsws]","ruleDatasetParamCreate",params,"datasetParamDialog.onAfterAddDatasetParam") 
  }
  ////////////////////////////////////////////////////////////////////
  datasetParamDialog.onAfterAddDatasetParam=function(p){
  lgr("datasetParamDialog.onAfterAddDatasetParam");
  enableElement(EI["datasetParamPnl"]);
    if (p["Status"]=="OK"){
      toggleDatasetPanel(true);
      datasetParamDialog.getDatasetParamByParams({"DATASETID":datasetDialog.selectedDatasetID});
      datasetParamDialog.datasetParamDialogHide();
    }else{
      showError("Внимание! Произошла ошибка при сохранении нового параметра");
    }
  } 
  ////////////////////////////////////////////////////////////////////
  datasetParamDialog.editDatasetParamDialogShow=function(){
    lgr("datasetParamDialog.editDatasetParamDialogShow");
    if (gbi("edit-datasetParam-btn").isEnabled()) {
      datasetParamDialog.window.setTitle("Редактирование параметра");
      datasetParamDialog.window.show(datasetParamDialog.window);
      datasetParamDialog.curoper="edit";
      datasetDialog.getDatasetByParams(null,"datasetParamDialog.onAfterGetDatasetByParams");
    }
  }
  ////////////////////////////////////////////////////////////////////
  datasetParamDialog.onAfterGeteditDatasetParamDialogShow=function(p){
    lgr("datasetParamDialog.onAfterGeteditDatasetParamDialogShow");
    lgr(p);
    if (p['Status']=="OK"){
      p=p["Result"];
      if (p!=="" && p!=null){
        if (p.length==1){
          setComboOptionByValue(EI["cmParamDataset"],p[0]["DATASETID"]);
          setComboOptionByValue(EI["cmParamType"],(stringToNumeric(p[0]["PARAMTYPE"])+1)+"");
          setComboOptionByValue(EI["cmParamValueType"],p[0]["PARAMVALUETYPE"]);
          setValue(EI["edParamSysName"],p[0]["SYSNAME"]);
          setValue(EI["edDescription"],p[0]["FULLNAME"]);
          setValue(EI["cbIsRequired"],stringToNumeric(p[0]["ISREQUIRED"]));
          showElement(EI["datasetParamPnl"]);
        }else{
          showError("Ошибка получения данных по выбранному параметру");
        }
      }
    }else{
      showError("Ошибка получения данных по выбранному параметру");
    }
  }
  ////////////////////////////////////////////////////////////////////
  datasetParamDialog.edit=function(){
    lgr("datasetParamDialog.edit");
    var params=getNewMap();
    params["DATASETPARAMID"]=datasetParamDialog.selectedDatasetParamID;
    params["DATASETID"]=getComboSelectedValue(EI["cmParamDataset"]);
    params["PARAMTYPE"]=stringToNumeric(getComboSelectedValue(EI["cmParamType"]))-1;
    params["PARAMVALUETYPE"]=getComboSelectedValue(EI["cmParamValueType"]);
    params["SYSNAME"]=getValue(EI["edParamSysName"]);
    params["FULLNAME"]=getValue(EI["edDescription"]);
    params["ISREQUIRED"]=getValue(EI["cbIsRequired"])==true ? parseInt(1) : parseInt(0);
    disableElement(EI["datasetParamPnl"]);
    dsCall("[dmsws]","ruleDatasetParamModify",params,"datasetParamDialog.onAfterEditDatasetParam") 
  }
  ////////////////////////////////////////////////////////////////////
  datasetParamDialog.onAfterEditDatasetParam=function(p){
    lgr("datasetParamDialog.onAfterEditDatasetParam");
    enableElement(EI["datasetParamPnl"]);
    if (p["Status"]=="OK"){
      toggleDatasetPanel(true);
      datasetParamDialog.getDatasetParamByParams({"DATASETID":datasetDialog.selectedDatasetID});
      datasetParamDialog.datasetParamDialogHide();
    }else{
      showError("Внимание! Произошла ошибка при редактировании параметра");
    }
  }
  ////////////////////////////////////////////////////////////////////
  datasetParamDialog.delDatasetParamDialogShow=function(){
    lgr("datasetParamDialog.delDatasetParamDialogShow");      
    if (gbi("del-datasetParam-btn").isEnabled()) {
      //datasetParamDialog.getDatasetParamByParams({"DATASETID":datasetParamDialog.selectedDatasetParamID},"datasetParamDialog.onAfterGetDatasetParam");
      if (confirm("Вы уверены что хотите удалить выбранный параметр - "+datasetParamDialog.selectedDatasetParamName+"?")){
        datasetParamDialog.curoper="del";
        datasetParamDialog[datasetParamDialog.curoper](); 
      }
    }
  }
  ////////////////////////////////////////////////////////////////////
  datasetParamDialog.del=function(){
    lgr("datasetParamDialog.del");
    var params=getNewMap();
    params["DATASETPARAMID"]=datasetParamDialog.selectedDatasetParamID;
    dsCall("[dmsws]","ruleDatasetParamDelete",params,"datasetParamDialog.onAfterDelDatasetParam"); 
  }
  ////////////////////////////////////////////////////////////////////
  datasetParamDialog.onAfterDelDatasetParam=function(p){
    lgr("datasetParamDialog.onAfterDelDatasetParam");
    if (p["Status"]=="OK"){
      toggleDatasetPanel(true);
      datasetParamDialog.getDatasetParamByParams({"DATASETID":datasetDialog.selectedDatasetID});
      datasetParamDialog.datasetParamDialogHide();
    }else{
      showError("Внимание! Произошла ошибка при удалении параметра");
    }
  }
  ////////////////////////////////////////////////////////////////////
  return datasetParamDialog;
}

datasetParamDialog=DatasetParamDialogConstructor();