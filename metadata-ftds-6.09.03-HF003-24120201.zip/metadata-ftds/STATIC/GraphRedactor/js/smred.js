checkPnl = function(cursor) {
	var coord = cursor.xy;
	var form = Ext.get("GraphRedactor");
	var coord1 = form.getXY();

	var mouseLocalX = (coord[0] - coord1[0]);
	var leftPnl = Ext.get(EI["leftPnl"]);
	var datasetPnl = Ext.get(EI["datasetPnl"]);
	var logSchemePnl = Ext.get(EI["logSchemePnl"]);

	if (mouseLocalX < 150 || hasClass(gbi(EI["lbToggleLeftPnl"]), "left-arrow")) { // && ){
		if (hideLeftPnl == false) {
			leftPnl.stopFx(true);
			leftPnl.shift({
				opacity: 1,
				easing: 'easeBoth'
			});
			hideElement(EI["canvasHeaderPnl"]);
			hideLeftPnl = true;
		}
	} else {
		if (hideLeftPnl == true) {
			leftPnl.stopFx(true);
			leftPnl.shift({
				opacity: 0,
				easing: 'easeBoth'
			});
			showElement(EI["canvasHeaderPnl"]);
			hideLeftPnl = false;
		}
	}

	if (mouseLocalX < 150 || hasClass(gbi(EI["lbToggleDatasetPnl"]), "left-arrow")) { // && ){
		if (hideDatasetPnl == false) {
			datasetPnl.stopFx(true);
			datasetPnl.shift({
				opacity: 1,
				easing: 'easeBoth'
			});
			hideDatasetPnl = true;
		}
	} else {
		if (hideDatasetPnl == true) {
			datasetPnl.stopFx(true);
			datasetPnl.shift({
				opacity: 0,
				easing: 'easeBoth'
			});
			hideDatasetPnl = false;
		}
	}

	if (mouseLocalX < 150 || hasClass(gbi(EI["lbToggleLogSchemePnl"]), "left-arrow")) { // && ){
		if (hideLogSchemePnl == false) {
			logSchemePnl.stopFx(true);
			logSchemePnl.shift({
				opacity: 1,
				easing: 'easeBoth'
			});
			hideLogSchemePnl = true;
		}
	} else {
		if (hideLogSchemePnl == true) {
			logSchemePnl.stopFx(true);
			logSchemePnl.shift({
				opacity: 0,
				easing: 'easeBoth'
			});
			hideLogSchemePnl = false;
		}
	}
}

isCtrl = false;
document.onkeydown = function(e) {
	e = e || event;
	var keyCode = e.keyCode ? e.keyCode : e.which ? e.which : null;
	if (keyCode == 17) isCtrl = true;
	if (keyCode == 27) graphRedactor.escapeEvent();

}
document.onkeyup = function(e) {
	e = e || event;
	var keyCode = e.keyCode ? e.keyCode : e.which ? e.which : null;
	if (keyCode == 17) isCtrl = false;
}

addClass(gbi(EI["canvas"]), "canvas-container-100");
addClass(gbi(EI["topPnl"]), "topPnl");
addClass(gbi(EI["scalePnl"]),"noborder");

var tabs = [{
	"title": "Основные элементы",
	"id": "elementsTab",
	"sections": [{
		"title": "Состояния",
		"buttons": [{
			"title": "Добавить",
			"help": "Эта кнопка вызывает диалог создания нового состояния",
			"img": "newGroup.png",
			"type": "large",
			"id": "add-state-btn",
			"click": graphRedactor.createState
		}, {
			"title": "Изменить",
			"help": "Эта кнопка вызывает диалог изменения выбранного состояния",
			"img": "editGroup.png",
			"type": "large",
			"id": "edit-state-btn",
			"click": console.log('b')
		}, {
			"title": "Удалить",
			"help": "Эта кнопка вызывает удаление выбранного состояния",
			"img": "delGroup.png",
			"type": "large",
			"id": "del-state-btn",
			"click": console.log('c')
		}]
	}, {
		"title": "Переходы",
		"buttons": [{
			"title": "Добавить",
			"help": "Эта кнопка вызывает диалог создания нового перехода",
			"img": "newGroup.png",
			"type": "large",
			"id": "add-trans-btn",
			"click": console.log('a1')
		}, {
			"title": "Изменить",
			"help": "Эта кнопка вызывает диалог изменения выбранного перехода",
			"img": "editGroup.png",
			"type": "large",
			"id": "edit-trans-btn",
			"click": console.log('b1')
		}, {
			"title": "Удалить",
			"help": "Эта кнопка вызывает удаление выбранного перехода",
			"img": "delGroup.png",
			"type": "large",
			"id": "del-trans-btn",
			"click": console.log('c1')
		}]
	}]
}];

resizeData = [{
	"id": EI["wrapper"],
	"width": "100%",
	"height": "100%",
	"display": "block",
	"childs": [{
		"id": EI["scalePnl"],
		"right": "20",
		"bottom": "20",
		"display": "inline"
	}, {
		"id": EI["topPnl"],
		"width": "100%",
		"display": "block"
	}, {
		"id": EI["canvasScroller"],
		"width": "100%",
		"height": "100%",
		"display": "block",
		"childs": [{
			"id": EI["canvas"],
			"display": "block"
		}]
	}]
}];

//создание риббон меню		
ribbonMenu = createRibbon(EI["topPnl"], "Редактор машины состояний FLEXTERA ver. 0.1 alpha", tabs, js.rootUrl + "GraphRedactor/img/ribbon");