onshowFnc = function() {
	hideElement(EI["indPanel"]);
	Ext.get("GraphRedactor").on('mousemove', function(cursor) {
		checkPnl(cursor);
		graphRedactor.checkAddNode(cursor)
	}, this, {
		stopPropagation: false
	});
	Ext.get(EI["canvas"]).on({
		'click': {
			fn: graphRedactor.canvasClick,
			scope: this,
			stopEvent: true
		},
		'mousedown': {
			fn: graphRedactor.canvasMouseDown,
			scope: this,
			stopEvent: true
		},
		'mouseup': {
			fn: graphRedactor.canvasMouseUp,
			scope: this //,
			//stopEvent :true
		},
		'mousemove': {
			fn: graphRedactor.canvasMouseMove,
			scope: this //,
			//stopEvent :true
		}
	});

	preventSelection(gbi(EI["canvas"]));

	var extTabs = Ext.query("DIV[tagtype=tabHeader]");
	if (extTabs.length > 0) {
		extTabs[0].style.paddingTop = "1px";
	}

	var whiteSheet = Ext.query("TABLE[class=whiteSheet]");
	if (whiteSheet.length > 0) {
		whiteSheet[0].setAttribute("cellpadding", 0);
		whiteSheet[0].setAttribute("cellspacing", 0);
	}

	resizeFlag = false;
	closeVisLMnu();

	try {

		groupDialog.checkRibbonControls();
		ruleDialog.checkRibbonControls();
		datasetDialog.checkRibbonControls();
		datasetParamDialog.checkRibbonControls();
		graphRedactor.checkRevertRibbon();
		graphRedactor.checkNodeAction();
	} catch (e) {}

	showElement(EI["wrapper"]);
	graphRedactor.slider.setValue(100);
}