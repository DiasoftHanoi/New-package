/////////////////////////////////////////////////////////////////
RuleDialogConstructor=function(){
	var ruleDialog=new Object();
	ruleDialog.curoper="none";
 	ruleDialog.viewTableName=EI["tbPolicyRules"];
 	ruleDialog.selectedRuleID=null;
  ruleDialog.selectedRuleName=null;
  ruleDialog.window=createSimpleModal2(EI["rulePanel"]);
  ////////////////////////////////////////////////////////////////////
  ruleDialog.addRuleDialogShow=function(){
    lgr("ruleDialog.addRuleDialogShow");
    ruleDialog.window.show(ruleDialog.window);
    ruleDialog.window.setTitle(getResourceBundle("JS_RULEEDITOR_RULES_1"));
    ruleDialog.curoper="add";
    hideElement(EI["rulePanel"]);
    groupDialog.getGroupsByParams(null,"ruleDialog.onAfterGetGroupsByParams");
  }
  ////////////////////////////////////////////////////////////////////
  ruleDialog.editRuleDialogShow=function(){
    lgr("ruleDialog.editRuleDialogShow");
    if (gbi("edit-rule-btn").isEnabled()) {
      hideElement(EI["rulePanel"]);
      ruleDialog.window.show(ruleDialog.window);
      ruleDialog.window.setTitle(getResourceBundle("JS_RULEEDITOR_RULES_2"));
      ruleDialog.curoper="edit";
      groupDialog.getGroupsByParams(null,"ruleDialog.onAfterGetGroupsByParams");
    }
  }
  ////////////////////////////////////////////////////////////////////
  ruleDialog.delRuleDialogShow=function(){
    lgr("ruleDialog.delRuleDialogShow");
    if (gbi("delete-rule-btn").isEnabled()) {
      ruleNodeDialog.getRuleNodesByParams({"RULEID":ruleDialog.selectedRuleID},"ruleDialog.onAfterGetRuleNodes");
    }
  }
  ////////////////////////////////////////////////////////////////////
  ruleDialog.ruleDialogShow=function(){
    lgr("ruleDialog.ruleDialogShow");
    if (ruleDialog.curoper=="add"){
      if (groupDialog.selectedGroupID!=null){
        setComboOptionByValue(EI["cmRuleGroup"],groupDialog.selectedGroupID);
      }
      
      showElement(EI["rulePanel"]);
    }else if (ruleDialog.curoper=="edit"){
      ruleDialog.getRulesByParams({"RULEID":ruleDialog.selectedRuleID},"ruleDialog.onAfterGeteditRuleDialogShow");     
    }else{
      showAlert(getResourceBundle("JS_RULEEDITOR_COMMON_1"));
    }
  }
  /////////////////////////////////////////////////////////////////////////////
  ruleDialog.getRulesByParams=function(params,callback){
    lgr("ruleDialog.getRulesByParams");
    callback = callback==null ? "ruleDialog.fillRules" : callback; 
    if (callback=="ruleDialog.fillRules"){
      clearTable(ruleDialog.viewTableName);
      ruleDialog.selectedRuleID=null;
      ruleDialog.selectedRuleName=null;
      ruleDialog.checkRibbonControls();
      disableElement(ruleDialog.viewTableName);
    }
    params= params!=null ? params : getNewMap();
    params['ORDERBY']= params['ORDERBY']==null ? "NAME" :params['ORDERBY'];
    dsCall("[dmsws]","ruleGetListByParams",params,callback)
  }
  ////////////////////////////////////////////////////////////////////
  ruleDialog.fillRules=function(p){
    lgr("ruleDialog.fillRules");
    enableElement(ruleDialog.viewTableName);
    var p=p["Result"];
    if (p!=null && p!==""){
      var dd=p.length;
      for (var i=0;i<dd;i++){
        addRow(ruleDialog.viewTableName,p[i]);
      }
    }
  }
  ////////////////////////////////////////////////////////////////////
  ruleDialog.checkRibbonControls=function(){
    lgr("ruleDialog.checkRibbonControls");
    if (ruleDialog.selectedRuleID==null){
      gbi('edit-rule-btn').disable();
      gbi('delete-rule-btn').disable(); 
      gbi('load-rule-btn').disable(); 
   }else{
      gbi('edit-rule-btn').enable();
      gbi('delete-rule-btn').enable();       
      gbi('load-rule-btn').enable(); 
    }
  }
  ////////////////////////////////////////////////////////////////////
  ruleDialog.ruleDialogHide=function(){
    lgr("ruleDialog.ruleDialogHide");
    ruleDialog.curoper="none";
    ruleDialog.window.hide();
    hideElement(EI["rulePanel"]);
    gbi('add-rule-btn').enable();
    if (ruleDialog.curoper=="edit"){
      gbi('edit-rule-btn').enable();    
    }
  }  
  ////////////////////////////////////////////////////////////////////
  ruleDialog.selectRule=function(){
    lgr("ruleDialog.selectRule");
    var selRule=getSelectedRow(ruleDialog.viewTableName);
    if (selRule!=="" && selRule!=null){
      ribbonMenu.switchToTabByIndex(1);
      ruleDialog.selectedRuleID=selRule["RULEID"];
      ruleDialog.selectedRuleName=selRule["NAME"];
      ruleDialog.checkRibbonControls();
    }  
  }
  ////////////////////////////////////////////////////////////////////
  ruleDialog.applyChanges=function(){
    lgr("ruleDialog.applyChanges");
    if (ruleDialog.checkParams()){
        ruleDialog[ruleDialog.curoper](); 
    }else{
        showAlert(getResourceBundle("JS_RULEEDITOR_COMMON_2"));
    }
  }
  ////////////////////////////////////////////////////////////////////
  ruleDialog.checkParams=function(){
    lgr("ruleDialog.checkParams");
    var returnFlag=checkElements([EI["edRuleSysName"],EI["edRuleName"],EI["cmRuleGroup"],EI["cmRuleDataset"]]);
    return returnFlag;  
  }
  ////////////////////////////////////////////////////////////////////
  ruleDialog.add=function(){
    lgr("ruleDialog.add");
    var params=getNewMap();
    params["SYSNAME"]=getValue(EI["edRuleSysName"]);
    params["NAME"]=getValue(EI["edRuleName"]);
    params["DESCRIPTION"]=getValue(EI["edRuleDescription"]);
    params["RULEGROUPID"]=getComboSelectedValue(EI["cmRuleGroup"]);
    params["DATASETID"]=getComboSelectedValue(EI["cmRuleDataset"]);
    disableElement(EI["rulePanel"]);
    dsCall("[dmsws]","ruleCreate",params,"ruleDialog.onAfterAddRule") 
  }
  ////////////////////////////////////////////////////////////////////
  ruleDialog.edit=function(){
    lgr("ruleDialog.edit");
    var params=getNewMap();
    params["SYSNAME"]=getValue(EI["edRuleSysName"]);
    params["NAME"]=getValue(EI["edRuleName"]);
    params["DESCRIPTION"]=getValue(EI["edRuleDescription"]);
    params["RULEGROUPID"]=getComboSelectedValue(EI["cmRuleGroup"]);
    params["DATASETID"]=getComboSelectedValue(EI["cmRuleDataset"]);
    params["RULEID"]=ruleDialog.selectedRuleID;
    disableElement(EI["rulePanel"]);
    dsCall("[dmsws]","ruleModify",params,"ruleDialog.onAfterEditRule"); 
  }
  ////////////////////////////////////////////////////////////////////
  ruleDialog.onAfterEditRule=function(p){
    lgr("ruleDialog.onAfterEditRule");
    enableElement(EI["rulePanel"]);
    if (p["Status"]=="OK"){
      toggleLeftPanel(true);
      ruleDialog.getRulesByParams({"RULEGROUPID":groupDialog.selectedGroupID});
      ruleDialog.ruleDialogHide();
    }else{
      showError(getResourceBundle("JS_RULEEDITOR_RULES_3"));
    }
  }
  ////////////////////////////////////////////////////////////////////
  ruleDialog.onAfterGeteditRuleDialogShow=function(p){
    lgr("ruleDialog.onAfterGeteditRuleDialogShow");
    if (p['Status']=="OK"){
      p=p["Result"];
      if (p!=="" && p!=null){
        if (p.length==1){
          setValue(EI["edRuleSysName"],p[0]["SYSNAME"]);
          setValue(EI["edRuleName"],p[0]["NAME"]);
          setComboOptionByValue(EI["cmRuleGroup"],p[0]["RULEGROUPID"]);
          setComboOptionByValue(EI["cmRuleDataset"],p[0]["DATASETID"]);
          setValue(EI["edRuleDescription"],p[0]["DESCRIPTION"]);
          showElement(EI["rulePanel"]);
        }else{
          showError(getResourceBundle("JS_RULEEDITOR_RULES_4"));
        }
      }
    }else{
      showError(getResourceBundle("JS_RULEEDITOR_RULES_4"));
    }
  }
  ////////////////////////////////////////////////////////////////////
  ruleDialog.onAfterAddRule=function(p){
    lgr("ruleDialog.onAfterAddRule");
    enableElement(EI["rulePanel"]);
    if (p["Status"]=="OK"){
      toggleLeftPanel(true);
      ruleDialog.getRulesByParams({"RULEGROUPID":groupDialog.selectedGroupID});
      ruleDialog.ruleDialogHide();
    }else{
      showError(getResourceBundle("JS_RULEEDITOR_RULES_5"));
    }
  } 
  ////////////////////////////////////////////////////////////////////
  ruleDialog.onAfterGetGroupsByParams=function(p){
    lgr("ruleDialog.onAfterGetGroupsByParams");
    if (p["Status"]=="OK"){
      var p=p["Result"];
      if (p!=null && p!==""){
        var dd=p.length;
        clearComboOptions(EI["cmRuleGroup"]);
        if (is7==false){
          addComboOption(EI["cmRuleGroup"],"","");
        }
        for (var i=0;i<dd;i++){
          addComboOption(EI["cmRuleGroup"],p[i]["RULEGROUPID"],p[i]["NAME"]);
        }
        datasetDialog.getDatasetByParams(null,"ruleDialog.onAfterGetDatasetByParams");
      }
    }else{
      showAlert(getResourceBundle("JS_RULEEDITOR_RULES_6"));
    }
  }
  ////////////////////////////////////////////////////////////////////
  ruleDialog.onAfterGetDatasetByParams=function(p){
    lgr("ruleDialog.onAfterGetDatasetByParams");
    if (p["Status"]=="OK"){
      var p=p["Result"];
      if (p!=null && p!==""){
        var dd=p.length;
        clearComboOptions(EI["cmRuleDataset"]);
        if (is7==false){
          addComboOption(EI["cmRuleDataset"],"","");
        }
        for (var i=0;i<dd;i++){
          addComboOption(EI["cmRuleDataset"],p[i]["DATASETID"],p[i]["FULLNAME"]);
        }
        ruleDialog.ruleDialogShow();
      }
    }else{
      showAlert(getResourceBundle("JS_RULEEDITOR_RULES_7"));
    }
  }
  ////////////////////////////////////////////////////////////////////
  ruleDialog.onAfterGetRuleNodes=function(p){
    lgr("ruleDialog.onAfterGetRuleNodes");
    if (p['Status']=="OK"){
      p=p["Result"];
      if (p!=null && p!==""){
        var dd=p.length;
        if (dd==0){
            if (confirm(getResourceBundle("JS_RULEEDITOR_RULES_8")+" - "+ruleDialog.selectedRuleName+"?")){
                  ruleDialog.curoper="del";
                  ruleDialog[ruleDialog.curoper]();  
              } 
        }else{
          showAlert(getResourceBundle("JS_RULEEDITOR_RULES_9"));
        }
      }
    }else{
      showError(getResourceBundle("JS_RULEEDITOR_RULES_10"));     
    }
  }
	////////////////////////////////////////////////////////////////////
 	ruleDialog.del=function(){
    lgr("ruleDialog.del");
    var params=getNewMap();
   	params["RULEID"]=ruleDialog.selectedRuleID;
   	dsCall("[dmsws]","ruleDelete",params,"ruleDialog.onAfterDelRule") 
 	}
 	////////////////////////////////////////////////////////////////////
 	ruleDialog.onAfterDelRule=function(p){
    lgr("ruleDialog.onAfterDelRule");
   	if (p["Status"]=="OK"){
   		toggleLeftPanel(true);
   		ruleDialog.getRulesByParams({"RULEGROUPID":groupDialog.selectedGroupID});
   		ruleDialog.curoper="none";
   	}else{
   		showError(getResourceBundle("JS_RULEEDITOR_RULES_11"));
    }
 	}
  ////////////////////////////////////////////////////////////////////
  return ruleDialog;
}

ruleDialog=RuleDialogConstructor();