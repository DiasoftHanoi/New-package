Ext.ribbon=function(id) {
		if (!id) {
			if (this.attr('id')) {
				id = this.attr('id');
			}
		}
		
		var that = function() { 
			return thatRet;
		};
		
		var thatRet = that;
		that.selectedTabIndex = -1;
		var tabNames = [];
		var ribObj = null;

		////////////////////////////////////////////////////		
		that.goToBackstage = function() {
			addClass(ribObj,"backstage");
		}
		////////////////////////////////////////////////////		
		that.returnFromBackstage = function() {
			removeClass(ribObj,"backstage");
		}
		////////////////////////////////////////////////////
		that.enable = function() {
			if (hasClass(this,'ribbon-button')) {
				if (this[0] && this[0].enable) {
					this[0].enable();
				}	
			}else {
				Ext.each(Ext.query('.ribbon-button',this),function(item,index,allItems) {item.enable();});
			}				
		}
		////////////////////////////////////////////////////
		that.disable = function() {
			if (hasClass(this,'ribbon-button')) {
				if (this[0] && this[0].disable) {
					this[0].disable();
				}	
			}else {
				Ext.each(Ext.query('.ribbon-button',this),function(item,index,allItems) {item.disable();});				
			}				
		}
		////////////////////////////////////////////////////
		that.isEnabled = function() {
			if (this[0] && this[0].isEnabled) {
				return this[0].isEnabled();
			} else {
				return true;
			}
		}
		//////////////////////////////////////////////////
		that.hide=function(){
			this.style.display="none";
		}
		////////////////////////////////////////////////////
		that.show=function(){
			this.style.display="block";
		}
		////////////////////////////////////////////////////
		that.init = function(id) {
			if (!id) {
				id = 'ribbon';
			}

			Ext.query("*",Ext.query("#ribbon")).length;

			Ext.each(Ext.query("*",Ext.query("#ribbon")),function(item,index,allItems){
	           				                                item.hide=that.hide;
                            	                            item.show=that.show;
                            	                            item.disable=that.disable;
															item.enable=that.enable;
															item.isEnabled=that.isEnabled;


			});

			ribObj = Ext.query('#'+id)[0];
			var header = Ext.query('#ribbon-tab-header-strip',ribObj);

			var ribbonTabList=Ext.query(".ribbon-tab",ribObj);
			Ext.each(ribbonTabList,	function(item,index,allItems) {
										var id = this.getAttribute('id');
										if (id == undefined || id == null){
											id = 'tab-'+index;
											this.setAttribute('id', id);
										}
										tabNames[index] = id;
			
										var isBackstage = hasClass(this,"file");
										var thisTabHeader =  Ext.query('#ribbon-tab-header-'+index)[0]//           header.find('#ribbon-tab-header-'+index)[0]//;
				
										if (isBackstage) {
											addClass(thisTabHeader,"file");
							
											Ext.get(thisTabHeader).on("click",function() {
																	that.switchToTabByIndex(index);
																	that.goToBackstage();
																});
										}else{
											if (that.selectedTabIndex==-1) {
												that.selectedTabIndex = index;
												addClass(thisTabHeader,"sel");
											}
											Ext.get(thisTabHeader).on("click",function() {
																				that.returnFromBackstage();
																				that.switchToTabByIndex(index);
																	});
										}
										this.hide();
									});
			var ribbonButtonList=Ext.query(".ribbon-button",ribObj);
			Ext.each(ribbonButtonList,	function(item,index,allItems) {
											var el = item;
											el.enable = function() {
												removeClass(el,"disabled");

											}
											el.disable = function() {
												addClass(el,"disabled");
												removeClass(el,el.getAttribute("hoverCls"));
											}
											el.isEnabled = function() {
												return !hasClass(el,'disabled');
											}
								
											if (Ext.query('.ribbon-hot',el).length==0){
												Ext.each(Ext.query('.ribbon-normal',el),function(item,index,allItems){addClass(item,'ribbon-hot')});
											}

											if (Ext.query('.ribbon-disabled',el).length==0){
												Ext.each(Ext.query('.ribbon-normal',el),function(item,index,allItems){addClass(item,'ribbon-implicit-disabled')});
											}

											var helpText=Ext.query('.button-help',el);

											if (helpText.length>0){
												helpText=helpText[0].innerHTML;
												new Ext.ToolTip({
        														target: el,
        														width:200,
        														html: helpText,
        														anchor: 'top',
        														anchorOffset: 10
    														});
											}
										});

			Ext.each(Ext.query("DIV",ribObj),function(item,index,allItems){item.setAttribute("unselectable","on")});
			Ext.each(Ext.query("SPAN",ribObj),function(item,index,allItems){item.setAttribute("unselectable","on")});
			ribObj.setAttribute("unselectable","on");
			that.switchToTabByIndex(that.selectedTabIndex);
		}
		
		that.switchToTabByIndex = function(index) {
			var headerStrip =  Ext.query("#ribbon-tab-header-strip")[0];
			Ext.each(Ext.query('.ribbon-tab-header',headerStrip),function(item,index,allItems){removeClass(item,"sel");});
			Ext.each(Ext.query('#ribbon-tab-header-'+index,headerStrip),function(item,index,allItems){addClass(item,"sel");});
			Ext.each(Ext.query("#ribbon .ribbon-tab",ribObj),function(item,index,allItems){item.hide();});
			Ext.each(Ext.query("#ribbon #"+tabNames[index],ribObj),function(item,index,allItems){item.show();});
			Ext.each(Ext.query('#ribbon .ribbon-tab',ribObj),function(item,index,allItems){item.hide()});
			Ext.each(Ext.query('#ribbon #'+tabNames[index],ribObj),function(item,index,allItems){item.show()});
		}
		that.init(id);
	return that;
}	

//////////////////////////////////////////////////////////////////////////////
createRibbon=function (root,title,tabs,srcSource){
	var ribbonEl=createNewRibbonEl({"rootEl":gbi(root),"tagName":"DIV","id":"ribbon"});
	createNewRibbonEl({"rootEl":ribbonEl,"tagName":"SPAN","cls":"ribbon-window-title","innerHtml":title});
	var ribbonHeaderEl=createNewRibbonEl({"rootEl":ribbonEl,"tagName":"DIV","id":"ribbon-tab-header-strip"});

	var dd=tabs.length;
	for (var i=0;i<dd;i++){

		var tab=tabs[i];

		var ribbonTabHeaderEl=createNewRibbonEl({"rootEl":ribbonHeaderEl, "tagName":"DIV", "id":"ribbon-tab-header-"+i, "cls":"ribbon-tab-header", "hoverCls":"ribbon-tab-header-hover"});
		createNewRibbonEl({"rootEl":ribbonTabHeaderEl,"tagName":"SPAN","cls":"ribbon-title","innerHtml":tab["title"]});
		var tabEl=createNewRibbonEl({"rootEl":ribbonEl,"tagName":"DIV","cls":"ribbon-tab","id":tab["id"]});

		var isBackstage = hasClass(tabEl,"file");

		if (isBackstage) {
			addClass(ribbonTabHeaderEl,"file");
		}
		
		var sections=nvl(tab["sections"],[]);
		var ddj=sections.length;
		for (var j=0;j<ddj;j++){
			var section=sections[j];
			var sectionEl=createNewRibbonEl({"rootEl":tabEl,"tagName":"DIV","cls":"ribbon-section"});

			createNewRibbonEl({"rootEl":sectionEl,"tagName":"SPAN","cls":"section-title","innerHtml":section["title"]});
			var buttons=nvl(section["buttons"],[]);
			var ddk=buttons.length
			for (var k=0;k<ddk;k++){
			   var button=buttons[k];
			   //var evnts=null;
			   //evnts["disable"]=disableRibbonBtn;
			   var buttonEl=createNewRibbonEl({"rootEl":sectionEl,"tagName":"DIV","cls":"ribbon-button ribbon-button-"+button["type"],"id":button["id"], "hoverCls":"ribbon-button-hover","click":button["click"]});
			   createNewRibbonEl({"rootEl":buttonEl,"tagName":"SPAN","cls":"button-help","innerHtml":button["help"]});
			   createNewRibbonEl({"rootEl":buttonEl,"tagName":"IMG", "cls":"ribbon-icon ribbon-normal","src":srcSource+"/normal/"+button["img"]});
			   createNewRibbonEl({"rootEl":buttonEl,"tagName":"IMG", "cls":"ribbon-icon ribbon-hot","src":srcSource+"/hot/"+button["img"]});
			   createNewRibbonEl({"rootEl":buttonEl,"tagName":"IMG", "cls":"ribbon-icon ribbon-disabled","src":srcSource+"/disabled/"+button["img"]});
			   createNewRibbonEl({"rootEl":buttonEl,"tagName":"SPAN","cls":"button-title","innerHtml":button["title"]});
			}
			createNewRibbonEl({"rootEl":tabEl,"tagName":"DIV","cls":"ribbon-section-sep"});
		}
	}
	return Ext.ribbon("ribbon");
   //$('#ribbon').ribbon();
}
///////////////////////////////////////
createNewRibbonEl=function(prms){ //rootEl,tagName,cls,innerHtml,id,src,evnts
	var el=document.createElement(prms["tagName"]);
	if (prms["evnts"]){
		var evnts=prms["evnts"];
		lgr("createNewRibbonEl");
		lgr(prms["id"]);
		lgr(evnts);
		lgr(evnts["disable"]);
		el.disable=evnts["disable"];
		lgr(el.disable);
	}

	if (prms["hoverCls"]) {
		el.setAttribute("hoverCls",prms["hoverCls"]);
		Ext.get(el).on('mouseover',function(){ if (!this.hasClass("disabled")){this.addClass(this.getAttribute("hoverCls"));}});
		Ext.get(el).on('mouseout',function(){this.removeClass(this.getAttribute("hoverCls"));});
	}
	
	if (prms["click"]){
		Ext.get(el).on("click",prms["click"]);
	}

	if (prms["id"]){el.id=prms["id"];}
	if (prms["cls"]){addClass(el,prms["cls"]);}
	if (prms["innerHtml"]){el.innerHTML=prms["innerHtml"];}
	if (prms["src"]){el.src=prms["src"];}
	
	prms["rootEl"].appendChild(el);
	return el;
}
//////////////////////////////////////////////////////////////////////////////

