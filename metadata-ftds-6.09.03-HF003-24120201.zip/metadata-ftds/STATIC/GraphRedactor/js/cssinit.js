crDynEl=function (tag, p, parent){ 
   if (!parent){return false;}
   p['width'] = p['width']||'100%'; 
   p['height'] = p['height']||'100%'; 
   var el = document.createElement(tag); 
   var onev = {}; 
   for (var k in p){ 
      if (/^on/i.test(k)){ 
	     addHandler(el, k.replace(/^on/i,''), p[k])
	   } else{
 	     if (typeof(p[k])!='function'){
            switch (k) {
				case 'style':el.style.cssText = p[k];break; case 'class':el.setAttribute('className',p[k]);el.setAttribute('class',p[k]);break;
				default: el.setAttribute(k,p[k])
			}
		  }
	   }
	}
	parent.appendChild(el);
	return true;
}
////////////////////////////////////////////////////////////////////////////////

if (!Ext.isIE){
  var stylelink = Ext.query("[href='/webclient/css/style.css']")[0];
  if (stylelink){
  	stylelink.setAttribute("href","/webclient/pages/static/GraphRedactor/css/style.css");
  }
}

crDynEl('link', {'rel':'stylesheet','type':'text/css', 'href': js.rootUrl+"GraphRedactor/css/GraphRedactor.css"}, Ext.query('HEAD')[0]);
crDynEl('link', {'rel':'stylesheet','type':'text/css', 'href': js.rootUrl+"GraphRedactor/css/ribbon.css"}, Ext.query('HEAD')[0]);


Ext.each(Ext.query("*[name=barvalue]"),function(item){Ext.get(this).addClass("barvalue")});