/////////////////////////////////////////////////////////////////
nmlz=function(value){
  var incr=graphRedactor.incr;
  return Math.round((value)/incr)*incr;
}
/////////////////////////////////////////////////////////////////
sortByOrderNo=function(a,b){
  if (stringToNumeric(a["ORDERNO"])<stringToNumeric(b["ORDERNO"])){
    return -1;
  }
  if (stringToNumeric(a["ORDERNO"])>stringToNumeric(b["ORDERNO"])){
    return 1;
  }
  return 0;
}

/////////////////////////////////////////////////////////////////

graphConstructor=function(){
	var graphRedactor = new Object();
  
  graphRedactor.changeList=getNewList();
  graphRedactor.onChangeMove=false;

  graphRedactor.showAddNodeHintFlag=false;
  graphRedactor.showAddNodeFunction=null;
  graphRedactor.showAddNodeCoord=null;
  graphRedactor.selNodeID=null;

  graphRedactor.curoper="none";


  graphRedactor.openedDialogType=null;


  graphRedactor.canvasWidth = 1600*4; //Ширина канвы
  graphRedactor.canvasHeight = 500*4; // Высота канвы
  graphRedactor.canvas = EI["canvas"]; //Ид канвы


  setWidth(graphRedactor.canvas,graphRedactor.canvasWidth);
  setHeight(graphRedactor.canvas,graphRedactor.canvasHeight);

  graphRedactor.r = Raphael(graphRedactor.canvas, graphRedactor.canvasWidth, graphRedactor.canvasHeight); // Полотно
  graphRedactor.set = graphRedactor.r.set(); // Сет всех элементов на канве
  graphRedactor.multiDragSet = graphRedactor.r.set(); // Сет выделенных элементов
  graphRedactor.scaleIndex=1; // Индекс масштабирования
  graphRedactor.incr=10; //Инкремент сетки канвы
  graphRedactor.isCtrl = false;  // Признак нажат ли контрол
  graphRedactor.loadedRuleData=[];
  graphRedactor.loadedNodeCoordList=[];
  graphRedactor.testDatasetMode=false;

  graphRedactor.isCanvasElementClicked=false;
  graphRedactor.curCommitNodeID=null;

  var animDelay= Ext.isIE==true ? 1 : 300;
  graphRedactor.revealAnim = Raphael.animation({"opacity":1,"fill-opacity": 0.7}, animDelay); // Анимация при отображении загрузки узлов
  graphRedactor.multiSelectAnim = Raphael.animation({"stroke-width": 2, stroke: "red"}, animDelay); // Анимация при выделении мультидрага
  graphRedactor.multiUnselectAnim= Raphael.animation({"stroke-width": 1, stroke: "black"}, animDelay); // Анимация при выделении мультидрага 
  graphRedactor.selectBox=null; //Бокс выделения
  graphRedactor.loadedSubRules=null; // субправила
  graphRedactor.LoadedRuleNodes=null;
  graphRedactor.loadedRuleDatasetParams=null;
  graphRedactor.nodeCoordToSave=[]; //координаты для сохранения перемещения

  graphRedactor.changeCount=0;


  graphRedactor.textStyles={
                              "common":{"fill":"#FFFFFF","font-weight":"bold","font-size":"11px"}
                            };


  graphRedactor.escapeList=[];

  graphRedactor.nodeTypes=[];                                       //Список типов узлов



  graphRedactor.nodeTypes[5]="Interval";

  graphRedactor.nodeVisual=[];  // Мэп для быстрого обращения к узлам по ИД
  graphRedactor.linkVisual=[];  // Мэп для быстрого обращения к линкам по ИД узлов (nodeid - ИД дочернего узла)
  



  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.hideOpenDialog=function(){
    lgr("graphRedactor.hideOpenDialog");
    if (graphRedactor["hide"+graphRedactor.openedDialogType+"Dialog"]){
      graphRedactor["hide"+graphRedactor.openedDialogType+"Dialog"]();
    }
    graphRedactor.openedDialogType=null;
    graphRedactor.curoper="none";
    graphRedactor.checkNodeAction();
  }
   ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.saveCoordSetting=function(){
    var nodeCoordList=getNewList();
    for (var ar in graphRedactor.nodeVisual){ 
      if (Raphael.is(graphRedactor.nodeVisual[ar],"function")==false && graphRedactor.nodeVisual.hasOwnProperty(ar)){
        var nodeSet=graphRedactor.nodeVisual[ar];
        var bbox=nodeSet.getBBox();
        var coordMap=getNewMap();
        coordMap.put("x",bbox["x"]);
        coordMap.put("y",bbox["y"]);
        coordMap.put("nodeid",nodeSet["nodeid"]);
        nodeCoordList.add(coordMap);
      }
    }
    var prms=getNewMap();
    prms["SYSNAMETYPE"]="DTRedactorCoord";
    prms["SYSNAMECONSTANT"]=graphRedactor.loadedRuleData["RULEGROUPSYSNAME"]+"#"+graphRedactor.loadedRuleData["SYSNAME"];
    prms["DESCRIPTION"]="DTRedactor Rule coordinates";
    prms["MODULE"]="Scoring";
    
    var PARAMS=getNewMap();
    PARAMS.put("nodeCoordList",nodeCoordList);
    prms["PARAMS"]=PARAMS;
    dsCall("[frontws2]","settingsSave",prms,"graphRedactor.onAfterSaveCoordSetting");
  }  
   //////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.onAfterSaveCoordSetting=function(p){
    lgr("graphRedactor.onAfterSaveCoordSetting");
    if (p["Status"]=="OK"){
      ruleNodeDialog.loadwindow.hide();
      hideElement(EI["loadRuleNodesPanel"]);
      graphRedactor.changeList=[];
      graphRedactor.checkRevertRibbon();
    }else{
      showAlert(getResourceBundle("JS_RULEEDITOR_GRAPHS_1"));
    }
  }
   //////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.applyChangeList=function(){
    if (gbi("apply-changes-btn").isEnabled()) {
      lgr("!@#!@#");
      lgr(cloneObj(graphRedactor.changeList[0]));
      lgr("graphRedactor.applyChangeList");
      graphRedactor.curCommitNodeID=null;
      setValue(EI["WLabel12"],getResourceBundle("JS_RULEEDITOR_GRAPHS_2"));
      setValue(EI["loadNodesProgress"],"0.00");
      ruleNodeDialog.loadwindow.show(ruleNodeDialog.loadwindow);
      showElement(EI["loadRuleNodesPanel"]);
      graphRedactor.changeCount=graphRedactor.changeList.length;
      graphRedactor.applyChangeIter();
      //graphRedactor.saveCoordSetting();
    }
  }

   ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.applyChangeIter=function(){
    lgr("graphRedactor.applyChangeIter");
    
    if (graphRedactor.changeList.length>0){
      //var prms=graphRedactor.changeList.splice(0,1)[0];
      var prms=cloneObj(graphRedactor.changeList[0]);

      lgr(prms);

      var optype=prms["optype"];
      var type=prms["type"];
      lgr(type);
      if (type=="nodeMove"){
        graphRedactor.changeList.splice(0,1);
        graphRedactor.applyChangeIter();
      }else
      if (type=="addNode"){
        var end=prms["end"];
        graphRedactor.curCommitNodeID=end["RULENODEID"];
        ruleNodeDialog.add(end,"graphRedactor.onAfterAddNode");
      }else
      if (type=="editNode"){
        var end=prms["end"];
        graphRedactor.curCommitNodeID=end["RULENODEID"];
        ruleNodeDialog.edit(end,"graphRedactor.onAfterEditNode");
      }else
      if (type=="deleteNode"){
        if (optype=="multiple"){
          //graphRedactor.deleteNodeList=prms["list"];
          graphRedactor.deleteNodeMultiple();
        }
      }    
    }else{
      //showAlert("операция завершена");
      graphRedactor.saveCoordSetting();
    }
  }
   ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.deleteNodeMultiple=function(){
    lgr("graphRedactor.deleteNodeMultiple");
    //var prms=graphRedactor.deleteNodeList.splice(0,1)[0];
    var prms=cloneObj(graphRedactor.changeList[0]["list"][0]);

    lgr(prms)
    if (prms!=null){
      var begin=prms["begin"];
      if (begin!=null){
        ruleNodeDialog.del(begin,"graphRedactor.onAfterDeleteNodeMultiple");
      }
    }else{
      graphRedactor.changeList.splice(0,1);
      graphRedactor.applyChangeIter(); 
    }
  }
   ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.onAfterDeleteNodeMultiple=function(p){
    lgr("graphRedactor.onAfterDeleteNodeMultiple");
    if (p["Status"]=="OK"){
      lgr(p);
      (graphRedactor.changeList[0]["list"]).splice(0,1);
      graphRedactor.deleteNodeMultiple();
    }else{
      showAlert(getResourceBundle("JS_RULEEDITOR_GRAPHS_3"));
    }    
  }
   ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.onAfterAddNode=function(p){
    lgr("graphRedactor.onAfterAddNode");
    if (p["Status"]=="OK"){
      p=p["Result"];
      lgr(p);
      var RULENODEID=nvl(p["RULENODEID"],[]);
      lgr(RULENODEID);
      graphRedactor.convertNodeID(RULENODEID,graphRedactor.curCommitNodeID);
      graphRedactor.curCommitNodeID=null;
      graphRedactor.changeList.splice(0,1);
      graphRedactor.applyChangeIter();
    }else{
      showAlert(getResourceBundle("JS_RULEEDITOR_GRAPHS_4"));
    }
  }
   ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.onAfterEditNode=function(p){
    lgr("graphRedactor.onAfterEditNode");
    if (p["Status"]=="OK"){
      lgr(p["Status"]);
      graphRedactor.changeList.splice(0,1);
      graphRedactor.applyChangeIter();
    }else{
      showAlert(getResourceBundle("JS_RULEEDITOR_GRAPHS_5"));
    }
  }
   ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.convertNodeID=function(newid,oldid){
    lgr("graphRedactor.convertNodeID"+" newid="+newid+" oldid="+oldid);
    
    var dd=graphRedactor.LoadedRuleNodes.length;
    for (var i=0;i<dd;i++){
      var node=graphRedactor.LoadedRuleNodes[i];
      lgr(node);
      if (node["RULENODEID"]==oldid){
        lgr('node["RULENODEID"]==oldid');
        node["RULENODEID"]=newid;

        var nodeSet=graphRedactor.nodeVisual["ID"+oldid];
        nodeSet.nodeid=newid;
        var dd2=nodeSet.length;

        lgr("cubNodeSet cycle");
        lgr(nodeSet);
        lgr(dd2);
        
        for (var j=0;j<dd2;j++){
          lgr("j="+j);          
          lgr(nodeSet);
          var nodeEl=nodeSet[j];
          lgr(nodeEl);
          nodeEl.nodeid=newid;
        }
        graphRedactor.nodeVisual["ID"+newid]=graphRedactor.nodeVisual["ID"+oldid];
        delete graphRedactor.nodeVisual["ID"+oldid];

        var linkSet=graphRedactor.linkVisual["ID"+oldid];
        linkSet["nodeid"]=newid;
        graphRedactor.linkVisual["ID"+newid]=graphRedactor.linkVisual["ID"+oldid];
        delete graphRedactor.linkVisual["ID"+oldid];
      }
      if (node["PARENTRULENODEID"]==oldid){
        lgr('node["PARENTRULENODEID"]==oldid');
        node["PARENTRULENODEID"]=newid;

        var curNodeID=node["RULENODEID"];

        var nodeSet=graphRedactor.nodeVisual["ID"+curNodeID];
        nodeSet.parentid=newid;
        var dd2=nodeSet.length;
        for (var j=0;j<dd2;j++){
          var nodeEl=nodeSet[j];
          nodeEl.parentid=newid;
        }        
        var linkSet=graphRedactor.linkVisual["ID"+curNodeID];
        linkSet["parentid"]=newid;
      }
    }

    dd=graphRedactor.changeList.length;
    for (var i=0;i<dd;i++){
      var change=graphRedactor.changeList[i];
      var optype=change["optype"];
      if (optype=="multiple"){
        var list=change["list"];
        var dd2=list.length;
        for (var j=0;j<dd2;j++){
          var multiChange=list[j];
          var begin=nvl(multiChange["begin"],[]);
          var end=nvl(multiChange["end"],[]);
          begin["RULENODEID"]= begin["RULENODEID"]==oldid ? newid : begin["RULENODEID"];
          begin["PARENTRULENODEID"]= begin["PARENTRULENODEID"]==oldid ? newid : begin["PARENTRULENODEID"];
          end["RULENODEID"]= end["RULENODEID"]==oldid ? newid : end["RULENODEID"];
          end["PARENTRULENODEID"]= end["PARENTRULENODEID"]==oldid ? newid : end["PARENTRULENODEID"];          
        }
      }else{

        var begin=nvl(change["begin"],[]);
        var end=nvl(change["end"],[]);
        begin["RULENODEID"]= begin["RULENODEID"]==oldid ? newid : begin["RULENODEID"];
        begin["PARENTRULENODEID"]= begin["PARENTRULENODEID"]==oldid ? newid : begin["PARENTRULENODEID"];
        end["RULENODEID"]= end["RULENODEID"]==oldid ? newid : end["RULENODEID"];
        end["PARENTRULENODEID"]= end["PARENTRULENODEID"]==oldid ? newid : end["PARENTRULENODEID"];
      }
    }
  }
   ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.nodeMoveRevert=function (prms){
    lgr("graphRedactor.nodeMoveRevert");
    var begin=prms["begin"];
    var end=prms["end"];

    var dd=begin.length;
    for (var i=0;i<dd;i++){
      var prm=begin[i];
      var nodeSet=graphRedactor.nodeVisual["ID"+prm["nodeid"]];
      var cbox=nodeSet.getBBox();
      nodeSet.translate(prm["x"]-cbox["x"],prm["y"]-cbox["y"]);
      graphRedactor.linkRepaint([nodeSet]);   
    }
  }
   ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.editNodeRevert=function (params){
    lgr("graphRedactor.editNodeRevert");
    var begin=params["begin"];
    var end=params["end"];
    var selNodeID=end["RULENODEID"];
    var parentNodeID=end["PARENTRULENODEID"];
    var parentNodeID2=begin["PARENTRULENODEID"];
    
    var dd=graphRedactor.LoadedRuleNodes.length;    
    for (var i=0;i<dd;i++){
      var Node=graphRedactor.LoadedRuleNodes[i];
      if (Node["RULENODEID"]+""==selNodeID+""){
        graphRedactor.LoadedRuleNodes[i]=begin;
        break;
      }
    }
    graphRedactor.refreshNode(selNodeID);
    graphRedactor.refreshNode(parentNodeID);
    graphRedactor.refreshLinkPosition(parentNodeID);
    if (parentNodeID2!=parentNodeID){
      graphRedactor.refreshNode(parentNodeID2);
      graphRedactor.refreshLinkPosition(parentNodeID2);
    }
  }
   ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.deleteNodeRevert=function(params){
    lgr("graphRedactor.deleteNodeRevert");
    var optype=params["optype"];
    if (optype=="multiple"){
      var list=params["list"];
      var dd=list.length;
      for (var i=0;i<dd;i++){
        var begin=list[i]["begin"];
        var end=list[i]["end"];
        var nodeType= graphRedactor.nodeTypes[begin["NODETYPE"]];
        var coord=begin["coord"];
        graphRedactor.LoadedRuleNodes.add(begin);
        if (graphRedactor["create"+nodeType]){
          graphRedactor["create"+nodeType](begin,{"x":coord["x"],"y":coord["y"],"nodeType":graphRedactor.nodeTypes[begin["NODETYPE"]]});
        }
      }
      for (var i=0;i<dd;i++){
        lgr(list[i]["begin"]["RULENODEID"]);
        var begin=list[i]["begin"];
        var end=list[i]["end"];
        graphRedactor.createLink(begin["RULENODEID"],begin["PARENTRULENODEID"],0);
      }
      for (var i=0;i<dd;i++){
        lgr(list[i]["begin"]["RULENODEID"]);
        var begin=list[i]["begin"];
        var end=list[i]["end"];        
        graphRedactor.refreshLinkPosition(begin["PARENTRULENODEID"]);
        graphRedactor.refreshNode(begin["PARENTRULENODEID"]);
      }
    }
  }
   ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.addNodeRevert=function (params){
    lgr("graphRedactor.addNodeRevert");
    var begin=params["begin"];
    var end=params["end"];
    var selNodeID=end["RULENODEID"];
    var parentNodeID=end["PARENTRULENODEID"];

    var dd=graphRedactor.LoadedRuleNodes.length;  
    for (var i=0;i<dd;i++){
      var Node=graphRedactor.LoadedRuleNodes[i];
      if (Node["RULENODEID"]+""==selNodeID+""){
        graphRedactor.LoadedRuleNodes.splice(i,1);
        break;
      }
    }

    lgr(graphRedactor.nodeVisual);
    lgr(graphRedactor.linkVisual);

    graphRedactor.nodeVisual["ID"+selNodeID].remove();
    delete graphRedactor.nodeVisual["ID"+selNodeID];
    graphRedactor.linkVisual["ID"+selNodeID]["inText"].remove();
    graphRedactor.linkVisual["ID"+selNodeID]["outText"].remove();
    graphRedactor.linkVisual["ID"+selNodeID]["path"].remove();
    delete graphRedactor.linkVisual["ID"+selNodeID];

    lgr(graphRedactor.nodeVisual);
    lgr(graphRedactor.linkVisual);

    
    graphRedactor.refreshNode(parentNodeID);
    graphRedactor.refreshLinkPosition(parentNodeID);
  }
   ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.undoAction=function(){
    if (gbi("undo-action-btn").isEnabled()) {
      if (graphRedactor.changeList.length>0){
        var undoAction=graphRedactor.changeList.pop();
        if (graphRedactor[undoAction["type"]+"Revert"]){
          graphRedactor[undoAction["type"]+"Revert"](undoAction);  
        }else{
          showAlert(getResourceBundle("JS_RULEEDITOR_GRAPHS_6")+" "+undoAction["type"]+"Revert");
        }
      }else{
        showAlert(getResourceBundle("JS_RULEEDITOR_GRAPHS_7"));
      }
      graphRedactor.checkRevertRibbon();
    }
  }
   ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.checkRevertRibbon=function(){
    if (graphRedactor.changeList.length>0){
      gbi('undo-action-btn').enable();
      gbi('apply-changes-btn').enable();
    }else{
      gbi('undo-action-btn').disable();
      gbi('apply-changes-btn').disable();
    }
  }
  ////////////// Функция установки масштаба ///////////////////////////////////////////////////////
  graphRedactor.setScale=function(value){
    lgr(1);
    graphRedactor.r.setViewBox(0, 0, graphRedactor.canvasWidth*100/value, graphRedactor.canvasHeight*100/value, true); // Задаем масштаб полотну
    lgr(2);
    setWidth(EI["canvas"],graphRedactor.canvasWidth*value/100);
    lgr(3);
    setHeight(EI["canvas"],graphRedactor.canvasHeight*value/100);
    lgr(4);
    graphRedactor.scaleIndex=value/100;
    lgr(5);
    for (var i=25;i<=200;i+=25){
      lgr("i="+i);
      lgr(gbi);
      lgr(graphRedactor.canvas);
      lgr(gbi(graphRedactor.canvas));
      lgr(removeClass);
      
      
      removeClass(gbi(graphRedactor.canvas),"canvas-container-"+i); //Удаляем все классы канвы

    }
    lgr(6);
    addClass(gbi(graphRedactor.canvas),"canvas-container-"+parseInt(value)); //Устанавливаем класс ля выбранного масштаба
    lgr(7);
  }
   /////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.mergeObjects=function(obj1,obj2){
    for (var ar in obj1){
      obj2[ar]=obj1[ar];
    }
    return obj2;
  }
   /////////////////////////////////////////////////////////////////////////////////////
   graphRedactor.createNode=function(prms){
    lgr("graphRedactor.createNode");
    var incr=graphRedactor.incr;
    var minWidth=nvl(prms["minWidth"],4*incr);
    var minHeight=nvl(prms["minHeight"],2*incr);
    
    var text=graphRedactor.r.text(0,0,prms["title"])
    text.attr(prms["titleStyle"]);
    text.elType="text";
    var txtBox=text.getBBox();
    var rectHeight=nvl(prms["rectHeight"],nmlz(txtBox.height));
    var rectWidth=nvl(prms["rectWidth"],nmlz(txtBox.width+incr));
    rectHeight= rectHeight < minHeight ? minHeight : rectHeight;
    rectHeight= rectHeight%(2*incr)!=0 ? rectHeight+incr : rectHeight;
    rectWidth= rectWidth < minWidth ? minWidth : rectWidth;
    var rect=graphRedactor.r.rect(0,0,rectWidth, rectHeight,3);
    var rectBox=rect.getBBox();
    text.attr({"x":rectBox.width/2, "y":incr});
    rect.attr({"fill":"90-"+prms["colorStart"]+"-"+prms["colorEnd"]});
    rect.elType="container";
    
    var nodeSet=graphRedactor.r.set();
    nodeSet.push(rect);
    nodeSet.push(text);
    text.toFront();
    nodeSet.attr({"cursor":"pointer","opacity":0});
    
    rect.nodeid=prms["nodeid"];
    rect.parentid=prms["parentid"];
    text.nodeid=prms["nodeid"];
    text.parentid=prms["parentid"];

    
    nodeSet.nodeid= prms["nodeid"];
    nodeSet.parentid= prms["parentid"];
    graphRedactor.nodeVisual["ID"+prms["nodeid"]]=nodeSet;

    nodeSet.nodeType=prms["nodeType"];    
    nodeSet.dblclick(graphRedactor["show"+nodeSet.nodeType+"Dialog"]);
    nodeSet.drag(graphRedactor.move, graphRedactor.dragger, graphRedactor.up,nodeSet,nodeSet,nodeSet);
    //nodeSet.click(graphRedactor.stopPropagation);
    //nodeSet.mousedown(graphRedactor.stopPropagation);
    nodeSet.animate(graphRedactor.revealAnim.delay(100*prms["idxAnimate"]));
    nodeSet.translate(prms["x"],prms["y"]);
    graphRedactor.set.push(nodeSet);
    return nodeSet;
  }
   /////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.repaintNode=function(prms,nodeid){
    lgr("graphRedactor.repaintNode");
    var incr=graphRedactor.incr;
    var minWidth=nvl(prms["minWidth"],4*incr);
    var minHeight=nvl(prms["minHeight"],2*incr);
    
    var nodeSet=null;
    var text=null;
    var rect=null;
    if (nodeid!=null){
      nodeSet=graphRedactor.nodeVisual["ID"+nodeid];
      var dd=nodeSet.length;
      lgr(dd);
      for (var i=0;i<dd;i++){
        var el=nodeSet[i];
        lgr(el.elType);
        if (el.elType=="text"){text=el;}
        if (el.elType=="container"){rect=el;}
      }
    }
    
    text.attr({"text":prms["title"]});
    text.attr(prms["titleStyle"]);
    var txtBox=text.getBBox();
    var rectHeight=nvl(prms["rectHeight"],nmlz(txtBox.height));
    var rectWidth=nvl(prms["rectWidth"],nmlz(txtBox.width+incr));
    rectHeight= rectHeight < minHeight ? minHeight : rectHeight;
    rectHeight= rectHeight%(2*incr)!=0 ? rectHeight+incr : rectHeight;
    rectWidth= rectWidth < minWidth ? minWidth : rectWidth;
    rect.attr({"width":rectWidth,"height":rectHeight});
    var rectBox=rect.getBBox();
    text.attr({"x":rectBox.width/2, "y":incr});
    rect.attr({"fill":"90-"+prms["colorStart"]+"-"+prms["colorEnd"]});
    text.toFront();
    rect.nodeid=nvl(prms["nodeid"],rect.nodeid);
    rect.parentid=nvl(prms["parentid"],rect.parentid);
    text.nodeid=nvl(prms["nodeid"],text.nodeid);
    text.parentid=nvl(prms["parentid"],text.parentid);
    nodeSet.nodeid=nvl(prms["nodeid"],nodeSet.nodeid);
    nodeSet.parentid= nvl(prms["parentid"],nodeSet.parentid);
    graphRedactor.nodeVisual["ID"+nodeid]=nodeSet;
    return nodeSet;
  }
   /////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.refreshNode=function(nodeid){
    lgr("graphRedactor.refreshNode");
    lgr(nodeid);
    var node=graphRedactor.nodeVisual["ID"+nodeid];
    if (node){
      var dd=graphRedactor.LoadedRuleNodes.length;
      var obj=null;
      for (var i=0;i<dd;i++){
        obj=graphRedactor.LoadedRuleNodes[i];
        if (obj["RULENODEID"]==nodeid){
          break;
        }
      }
      graphRedactor["repaint"+node.nodeType](obj);
    }
  }

  /////////////////////////////////////////////////////////////////
  graphRedactor.createInterval=function(obj,prms){
    lgr("graphRedactor.createCollection");
    prms=nvl(prms,[]);
    prms=graphRedactor.mergeObjects(prms,{
                  "colorStart":"#3E0095",
                  "colorEnd":"6A00FF",
                  "title":"INTERVAL",
                  "titleStyle": graphRedactor.textStyles["common"],
                  "nodeid":obj["RULENODEID"],
                  "parentid":obj["PARENTRULENODEID"],
                  "minHeight": 4*incr
               });

    var incr=graphRedactor.incr;
    var nodeSet=graphRedactor.createNode(prms); 
    return nodeSet;
  }
  /////////////////////////////////////////////////////////////////
  graphRedactor.getCoordByNodeID=function(nodeid){
    lgr("graphRedactor.getCoordByNodeID");
    var dd=graphRedactor.loadedNodeCoordList.length;
    for (var i=0;i<dd;i++){
      var coord=graphRedactor.loadedNodeCoordList[i];
      if (coord["nodeid"]+""==nodeid+""){
        return coord;
      }
    }
    return [];
  }
  /////////////////////////////////////////////////////////////////
  graphRedactor.generateNodeCoord=function(nodeList){
    lgr("graphRedactor.generateNodeCoord");
    var coordList=getNewList();
    var resultCoord=getNewMap();
    resultCoord.put("nodeid","0");
    resultCoord.put("x",180);
    resultCoord.put("y",140);
    graphRedactor.globalGenCoordY=140;

    coordList.add(resultCoord);
    coordList=graphRedactor.createCoordIter(coordList,resultCoord);
    return coordList;  
  }
  /////////////////////////////////////////////////////////////////
  graphRedactor.createCoordIter=function(coordList,parentCoord){
    lgr("graphRedactor.createCoordIter - nodeid="+parentCoord["nodeid"]);
    var childNodes=graphRedactor.getNodesByParentID(parentCoord["nodeid"]);
    var dd=childNodes.length;
    for (var i=0;i<dd;i++){
      var childNode=childNodes[i];
      var coordMap=getNewMap();
      coordMap.put("nodeid",childNode["RULENODEID"]);
      coordMap.put("x",parentCoord["x"]+200+(dd-i)*10);
      graphRedactor.globalGenCoordY+= i==0 ? 0 : 40;
      coordMap.put("y",graphRedactor.globalGenCoordY);
      coordList.add(coordMap);
      coordList=graphRedactor.createCoordIter(coordList,coordMap);
    }
    return coordList;
  }
  /////////////////////////////////////////////////////////////////
  graphRedactor.generateGraph=function(){
    lgr("graphRedactor.generateGraph");
    setValue(EI["zCanvasHeader"],graphRedactor.loadedRuleData["NAME"]+" ("+graphRedactor.loadedRuleData["SYSNAME"]+")");
    showElement(EI["canvasHeaderPnl"]);
    graphRedactor.LoadedRuleNodes=nvl(ruleNodeDialog.LoadedRuleNodes,getNewList());
    var resultNode=getNewMap();
    resultNode.put("RULENODEID","0");
    resultNode.put("NODETYPE","99");
    resultNode.put("PARENTRULENODEID","-1");
    graphRedactor.LoadedRuleNodes.add(resultNode);
    var dd=graphRedactor.LoadedRuleNodes.length;
    //var resCoord=graphRedactor.getCoordByNodeID("0");
    //graphRedactor["createResult"](null,{"x":resCoord["x"],"y":resCoord["y"],"idxAnimate":0});
    gbi(EI["canvasScroller"]).scrollTop=0
    gbi(EI["canvasScroller"]).scrollLeft=0

    if (graphRedactor.loadedNodeCoordList==null){
      graphRedactor.loadedNodeCoordList=graphRedactor.generateNodeCoord();
    }


    for (var i=0;i<dd;i++){
      var ruleNode=graphRedactor.LoadedRuleNodes[i];
      lgr(ruleNode);

      var nodeSet=null;
      var coord=graphRedactor.getCoordByNodeID(ruleNode["RULENODEID"]);
      if (graphRedactor["create"+graphRedactor.nodeTypes[ruleNode["NODETYPE"]]]){
        nodeSet=graphRedactor["create"+graphRedactor.nodeTypes[ruleNode["NODETYPE"]]](ruleNode,{"x":coord["x"],"y":coord["y"],"idxAnimate":i,"nodeType":graphRedactor.nodeTypes[ruleNode["NODETYPE"]]});
      }else{
        nodeSet=graphRedactor.createNode({
                                          "colorStart":"#888",
                                          "colorEnd":"#888",
                                          "title":ruleNode["RULENODEID"],
                                          "titleStyle": graphRedactor.textStyles["common"],
                                          "nodeid":ruleNode["RULENODEID"],
                                          "parentid":ruleNode["PARENTRULENODEID"],
                                          "minHeight": 4*incr,
                                          "x":coord["x"],
                                          "y":coord["y"],
                                          "idxAnimate":i,
                                          "nodeType":graphRedactor.nodeTypes[ruleNode["NODETYPE"]]
                                        });
      }
    }
    graphRedactor.generateLinks("0");
  }
  ////////////// Получение дочерних узлов по родительскому ИД, отсортированным по полю ORDERNO///////////////////////////////////////////////////
  graphRedactor.getNodesByParentID=function(parentid){
    var resultnodes=[];
    var dd=ruleNodeDialog.LoadedRuleNodes.length;
    for (var i=0;i<dd;i++){
      var ruleNode=ruleNodeDialog.LoadedRuleNodes[i];
      if (ruleNode["PARENTRULENODEID"]+""==parentid+""){
        resultnodes.push(ruleNode);
      }
    }
    resultnodes=resultnodes.sort(sortByOrderNo);
    return resultnodes;
  }
   //////////////////////////////////////////////////////////////////////////////////////////////
   graphRedactor.getNodeByID=function(parentid){
    var resultnodes=[];
    var dd=ruleNodeDialog.LoadedRuleNodes.length;
    for (var i=0;i<dd;i++){
      var ruleNode=ruleNodeDialog.LoadedRuleNodes[i];
      if (ruleNode["RULENODEID"]+""==parentid+""){
        return ruleNode;
      }
    }
  }
   /////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.getNextOrderByNo=function(parentid){
    var nodes=graphRedactor.getNodesByParentID(parentid);
    var dd=nodes.length;
    maxorderNo=0;
    for (var i=0;i<dd;i++){
      var curOrderNo=stringToNumeric(nodes[i]["ORDERNO"]);
      if (curOrderNo>maxorderNo){
        maxorderNo=curOrderNo;
      }
    }
    return maxorderNo;
  }
   ///////////////////////////////////////////////////////////////////////////////////////////////

  ////////////// Функция создания пути по точкам ///////////////////////////////////////////////////
  graphRedactor.createPath=function (pb,cb,x1,y1,x2,y2){
    var coordList=[];
    var curx=x1;
    var cury=y1;
    coordList.push({"x":curx,"y":cury});
    if (x1<x2){
      if (y1!=y2){
        coordList.push({"x":(x2+x1)/2,"y":y1});
        coordList.push({"x":(x2+x1)/2,"y":y2});         
      }
    }else
    if (x1>x2){
      coordList.push({"x":x1,"y":((y1+y2)/2)}); 
      coordList.push({"x":x2,"y":((y1+y2)/2)}); 
    } 
    coordList.push({"x":x2,"y":y2});         
    return coordList;
  }
  /////////////////////////////////////////////////////////////////
  graphRedactor.createLink =function(childNodeId,parentid,index){
    lgr("graphRedactor.createLink");
    var incr=graphRedactor.incr; 
    var parentBBox=graphRedactor.nodeVisual["ID"+parentid].getBBox(); // получаем визуальное предстваление родительского узла
    var childBox=graphRedactor.nodeVisual["ID"+childNodeId].getBBox(); // получаем визуальное предстваление дочернего узла

    var x1=parentBBox.x2;
    var y1=parentBBox.y+incr+index*incr   //(parentBBox.y2+parentBBox.y)/2;
    var x2=childBox.x;
    var y2=(childBox.y2+childBox.y)/2;

    graphRedactor.r.setStart(); // Создаем группу для линка

    var linkNodes=graphRedactor.createPath(parentBBox,childBox,x1+incr,y1,x2-incr,y2);   

    var pathString="M"+x1+","+y1;
    for (var j=0;j<linkNodes.length;j++){
      var linkNode=linkNodes[j];
      pathString+= "L"+linkNode["x"]+","+linkNode["y"];
    }
    pathString+="L"+x2+","+y2;

    var path=graphRedactor.r.path(pathString); // создаем линк
    var inText=graphRedactor.r.text(x1+5,y1-6,"in").attr({"font-size":10});
    var outText=graphRedactor.r.text(x2-3,y2-6,"out").attr({ "font-size":10 , "text-anchor":"end"});

    var linkSet=graphRedactor.r.setFinish();
    linkSet.toBack();

    var linkVisual=[];
    linkVisual["path"]=path;
    linkVisual["inText"]=inText;
    linkVisual["outText"]=outText;
    linkVisual["inIndex"]=index+1;
    linkVisual["nodeid"]=childNodeId;
    linkVisual["parentid"]=parentid;    

    graphRedactor.linkVisual["ID"+ childNodeId]=linkVisual;
    graphRedactor.set.push(linkSet);
  } 
  /////////////////////////////////////////////////////////////////
  graphRedactor.generateLinks=function (parentid,nonRecurseFlag){
    lgr("graphRedactor.generateLinks")
    var nodes=graphRedactor.getNodesByParentID(parentid);  
    var dd=nodes.length;
    for (var i=0;i<dd;i++){
      var childNodeId=nodes[i]["RULENODEID"];
      graphRedactor.createLink(childNodeId,parentid,i);

      if (nonRecurseFlag==null){
        graphRedactor.generateLinks(nodes[i]["RULENODEID"]);
      }
    }
  }
  /////////////////////////////////////////////////////////////////
  /////////////////////////////////////////////////////////////////
  graphRedactor.linkRepaint=function(list){
  

    var koef=Ext.isIE==true ? (1/graphRedactor.scaleIndex) : 1; 
    var incr=graphRedactor.incr*1/koef;
    for (var i=0;i<list.length;i++){
      var nodeSet=list[i];
      var nodeBBox=nodeSet.getBBox();  
      var nodeId=nodeSet.nodeid;
      var childNodes=graphRedactor.getNodesByParentID(nodeId);
      for (var j=0;j<childNodes.length;j++){
        var childNodeId=childNodes[j]["RULENODEID"];
      
        var linkVisual=graphRedactor.linkVisual["ID"+childNodeId];
        if (linkVisual)
          var inIndex=stringToNumeric(linkVisual["inIndex"]);

        var childBox=graphRedactor.nodeVisual["ID"+childNodeId].getBBox();

        var x1=nodeBBox.x2*koef;
        var y1=(nodeBBox.y+inIndex*incr)*koef;   
        var x2=childBox.x*koef;
        var y2=(childBox.y2+childBox.y)/2*koef;

        var linkNodes=graphRedactor.createPath(nodeBBox,childBox,x1+incr,y1,x2-incr,y2);
        var pathString="M"+x1+","+y1;
        for (var k=0;k<linkNodes.length;k++){
          var linkNode=linkNodes[k];
          pathString+= "L"+linkNode["x"]+","+linkNode["y"];
        }
        pathString+="L"+x2+","+y2;

      
        if (linkVisual){
          linkVisual["path"].attr({"path":pathString});
          linkVisual["inText"].attr({"x":x1+5,"y":y1-6});
          linkVisual["outText"].attr({"x":x2-3,"y":y2-6});
        }
      }

      var linkVisual=graphRedactor.linkVisual["ID"+nodeId];
      if (linkVisual){
        var inIndex=stringToNumeric(linkVisual["inIndex"]);
        parentBBox=graphRedactor.nodeVisual["ID"+linkVisual["parentid"]].getBBox();

        var x1=parentBBox.x2*koef;
        var y1=(parentBBox.y+inIndex*incr)*koef;   
        var x2=nodeBBox.x*koef;
        var y2=(nodeBBox.y2+nodeBBox.y)/2*koef;


        var linkNodes=graphRedactor.createPath(nodeBBox,childBox,x1+incr,y1,x2-incr,y2);

        var pathString="M"+x1+","+y1;
        for (var k=0;k<linkNodes.length;k++){
          var linkNode=linkNodes[k];
          pathString+= "L"+linkNode["x"]+","+linkNode["y"];
        }
        pathString+="L"+x2+","+y2;

        linkVisual["path"].attr({"path":pathString});
        linkVisual["inText"].attr({"x":x1+5,"y":y1-6});
        linkVisual["outText"].attr({"x":x2-3,"y":y2-6});
      }
    }
  }
  /////////////////////////////////////////////////////////////////
  graphRedactor.stopPropagation=function(event){
    lgr(event);
    event.stopPropagation ? event.stopPropagation() : (event.cancelBubble=true);
  }
   ////////////////////////////////////////////////////////////////////////////////
  graphRedactor.checkDraggerValid=function(id,checkBbox){
    //lgr("graphRedactor.checkdraggerValid "+id);
    for (var ar in graphRedactor.nodeVisual){
      var nodeVisual=graphRedactor.nodeVisual[ar];
      //lgr(nodeVisual);
      if (ar!="ID"+id && typeof(nodeVisual)+""!="function" && graphRedactor.nodeVisual.hasOwnProperty(ar)){
        var box=nodeVisual.getBBox();
        if (Raphael.isBBoxIntersect(box,checkBbox)){
          return false;
        }
      }
    }
    return true;
  }
   ////////////////////////////////////////////////////////////////////////////////
  graphRedactor.checkNodeInMultiSet=function(nodeSet){
    var dd=graphRedactor.multiDragSet.length;
    for (var i=0;i<dd;i++){
      var multinode=graphRedactor.multiDragSet[i];
      if (multinode.nodeid+""==nodeSet.nodeid+""){
        return true;
      }
    }
    return false;
  }
   /////////////////////////////////////////////////////////////////////////////////
  graphRedactor.selectLink=function(nodeid){
    lgr("graphRedactor.selectLink");
    var linkSet=graphRedactor.linkVisual["ID"+nodeid];
    if (linkSet){
       linkSet["path"].animate(graphRedactor.multiSelectAnim);  
    }
  }
   /////////////////////////////////////////////////////////////////////////////////
  graphRedactor.unSelectLink=function(nodeid){
    lgr("graphRedactor.unSelectLink");
    var linkSet=graphRedactor.linkVisual["ID"+nodeid];
    if (linkSet){
       linkSet["path"].animate(graphRedactor.multiUnselectAnim);  
    } 
  }    
   ////////////////////////////////////////////////////////////////////////////////
  graphRedactor.selectMultiNodes=function(list){
    lgr("graphRedactor.selectMultiNodes");
    var dd=list.length;
    for (var i=0;i<dd;i++){
      var nodeSet=list[i];
      var dd2=nodeSet.length;
      for (var j=0;j<dd2;j++){
        var nodeEl=nodeSet[j];
        if (nodeEl.elType=="container"){
          nodeEl.animate(graphRedactor.multiSelectAnim);
          graphRedactor.selectLink(nodeSet.nodeid);
        }
      }
      graphRedactor.multiDragSet.push(nodeSet);
    }
    graphRedactor.checkNodeAction();
  }
   ////////////////////////////////////////////////////////////////////////////////
  graphRedactor.unselectMultiNodes=function(list){
    lgr("graphRedactor.unselectMultiNodes");
    var dd=list.length;
    for (var i=0;i<dd;i++){
      var nodeSet=list[i];
      lgr(nodeSet);
      var dd2=nodeSet.length;
      for (var j=0;j<dd2;j++){
        var nodeEl=nodeSet[j];
        if (nodeEl.elType=="container"){
          nodeEl.animate(graphRedactor.multiUnselectAnim);
          graphRedactor.unSelectLink(nodeSet.nodeid);
        }
      }
      graphRedactor.multiDragSet.exclude(nodeSet);
      if (dd>list.length){
        dd=list.length;
        i=i-1;
      }
    }
    graphRedactor.checkNodeAction();
  }
   ////////////////////////////////////////////////////////////////////////////////
  graphRedactor.dragger = function (x,y) {
    lgr("graphRedactor.dragger");
    graphRedactor.isCanvasElementClicked=true;
    if (graphRedactor.curoper=="none"){
      if (isCtrl){
        if (graphRedactor.checkNodeInMultiSet(this)==false){
          graphRedactor.selectMultiNodes([this]);
        }else{
          graphRedactor.unselectMultiNodes([this]);
        }
      }else{
        if (graphRedactor.checkNodeInMultiSet(this)==false){
          graphRedactor.unselectMultiNodes(graphRedactor.multiDragSet);
          graphRedactor.selectMultiNodes([this]);
        }
      }
      hndl=true;
      //lgr(this);

      graphRedactor.saveNodeMove();
      graphRedactor.multiDragSet.ox=x;
      graphRedactor.multiDragSet.oy=y;
      graphRedactor.multiDragSet.dx=0;
      graphRedactor.multiDragSet.dy=0;

      this.ox = x;
      this.oy = y;
      this.dx = 0;
      this.dy = 0;
      this.attr({cursor: 'url("/webclient/pages/static/GraphRedactor/handc.cur"),pointer'});
      addClass(gbi(graphRedactor.canvas),"canvas-grabber");
      this.animate({"fill-opacity": 1}, 300);
    }
  }
   ////////////////////////////////////////////////////////////////////////////////
  graphRedactor.saveNodeMove=function(){
    graphRedactor.nodeCoordToSave=[];
    var dd=graphRedactor.multiDragSet.length;
    for (var i=0;i<dd;i++){
      var nodeSet=graphRedactor.multiDragSet[i];
      var bbox=nodeSet.getBBox();
      graphRedactor.nodeCoordToSave.push({"x":bbox.x,"y":bbox.y,"nodeid":nodeSet["nodeid"]});
    }
  }
   ////////////////////////////////////////////////////////////////////////////////
  graphRedactor.saveNodeMoveChange=function(){
    graphRedactor.changeList.push({"type":"nodeMove","begin":graphRedactor.nodeCoordToSave});
    graphRedactor.checkRevertRibbon();
  }
   ////////////////////////////////////////////////////////////////////////////////
  graphRedactor.move = function (dx, dy,x,y) {
    //lgr("graphRedactor.move");
    if (graphRedactor.curoper=="none"){    
      dx=dx*1/graphRedactor.scaleIndex;
      dy=dy*1/graphRedactor.scaleIndex;

      var obj=this;
      var incr=graphRedactor.incr;

      hndl=false;
      curdx=0;
      curdy=0;
      
      if (graphRedactor.multiDragSet.length>0){
        obj=graphRedactor.multiDragSet;
        var box=obj.getBBox();

        curdx=Math.round((dx-stringToNumeric(obj.dx))/incr)*incr;
        curdy=Math.round((dy-stringToNumeric(obj.dy))/incr)*incr;   

        if ( box.x+curdx>=incr && 
            box.y+curdy>=incr && 
            box.x2+curdx<=graphRedactor.canvasWidth &&
            box.y2+curdy<=graphRedactor.canvasHeight &&
            (curdx!=0 || curdy!=0)){
            obj.dx=Math.round((dx)/incr)*incr;
            obj.dy=Math.round((dy)/incr)*incr;   
            obj.translate(curdx, curdy);
            graphRedactor.linkRepaint(obj);      
            graphRedactor.onChangeMove=true;
        }

      }else{

        if (Math.abs(obj.dx-dx) > incr || Math.abs(obj.dy-dy) > incr){
          var box=obj.getBBox();
          curdx=Math.round((dx-obj.dx)/incr)*incr;
          curdy=Math.round((dy-obj.dy)/incr)*incr;
          
          if ( box.x+curdx>=0 && 
              box.y+curdy>=0 && 
              box.x2+curdx<=graphRedactor.canvasWidth &&
              box.y2+curdy<=graphRedactor.canvasHeight){

              
            if (graphRedactor.checkDraggerValid(obj.nodeid,{"x":box.x+curdx,"y":box.y+curdy,"x2": box.x2+curdx,"y2": box.y2+curdy})){
              obj.dx=Math.round((dx)/incr)*incr;
              obj.dy=Math.round((dy)/incr)*incr;
              obj.translate(curdx, curdy);  
            }else 
            if (graphRedactor.checkDraggerValid(obj.nodeid, {"x":box.x+curdx,"y":box.y,"x2": box.x2+curdx,"y2": box.y2})){
              obj.dx=Math.round((dx)/incr)*incr;
              obj.translate(curdx, 0); 
            } else 
            if (graphRedactor.checkDraggerValid(obj.nodeid, {"x":box.x,"y":box.y+curdy,"x2":box.x2,"y2":box.y2+curdy})){
              obj.dy=Math.round((dy)/incr)*incr;
              obj.translate(0, curdy);         
            }
          }
        }
      }
      obj.toFront();
      graphRedactor.r.safari();
    }
  }
   ////////////////////////////////////////////////////////////////////////////////
  graphRedactor.up = function () {
    lgr("graphRedactor.up");
    setTimeout("graphRedactor.isCanvasElementClicked=false;",10);
    if (graphRedactor.curoper=="none"){
      this.animate({"fill-opacity": 0.7}, 300);
      this.attr({cursor: 'url("/webclient/pages/static/GraphRedactor/hand.cur"),pointer'});
      
      if (graphRedactor.onChangeMove==true){
        graphRedactor.saveNodeMoveChange();  
        graphRedactor.onChangeMove=false;
      }
      removeClass(gbi(graphRedactor.canvas),"canvas-grabber");
    }
  }
  /////////////// Функция нажатия на канву (срабатывает после отпускания мыши)///////////////////////////////////////////////
  graphRedactor.canvasClick=function(cursor){
    lgr("graphRedactor.canvasClick");
    if (graphRedactor.isCanvasElementClicked==true){
      graphRedactor.isCanvasElementClicked=false;
    }else{
      toggleLeftPanel(false); //Скрываем боковую панель правил
      toggleDatasetPanel(false); //Скрываем боковую панель датасетов
      toggleLogSchemePanel(false); //Скрываем боковую панель лог схем
      
      if (!isCtrl && graphRedactor.curoper=="none"){
        graphRedactor.unselectMultiNodes(graphRedactor.multiDragSet.items); // Если не нажат контрол, то снимаем выделение со всех элементов канвы
      }
    }
  }
  ///////////////// Функция нажатия на канву ////////////////////////////////////////////////////
  graphRedactor.canvasMouseDown=function(cursor){
    lgr("graphRedactor.canvasMouseDown");
    lgr("graphRedactor.isCanvasElementClicked="+graphRedactor.isCanvasElementClicked);
    if (graphRedactor.isCanvasElementClicked!=true){
      if (graphRedactor.curoper=="none"){
        graphRedactor.isMousedown=true;
      }else{
        var canvasCoord=Ext.get(EI["canvas"]).getXY(); 
        var coord=[];
        coord["x"]=nmlz(cursor.xy[0]-canvasCoord[0]);
        coord["y"]=nmlz(cursor.xy[1]-canvasCoord[1]);
      
        graphRedactor.showAddNodeCoord=coord; 
        graphRedactor.showAddNodeHintFlag=false;
        hideElement(EI["addNodeHint"]);
        graphRedactor.showAddNodeFunction();
      }
    }
  }
  ////////////// Функция движения мыши поверх канвы///////////////////////////////////////////////////////
  graphRedactor.canvasMouseMove=function(cursor){
    if (graphRedactor.curoper=="none"){
      var canvasCoord=Ext.get(graphRedactor.canvas).getXY(); //получаем координаты канвы
      var scaleIdx=graphRedactor.scaleIndex;
      var canvasCursor={"x":(cursor.xy[0]-canvasCoord[0])/scaleIdx,"y":(cursor.xy[1]-canvasCoord[1])/scaleIdx}; // Получаем координаты курсора относительно канвы
      if (graphRedactor.isMousedown==true){
        if (graphRedactor.selectBox==null){
          graphRedactor.selectBox=graphRedactor.r.rect(canvasCursor["x"]/scaleIdx,canvasCursor["y"]/scaleIdx,0,0,0); // Создаем бокс выделения если его нет
          graphRedactor.selectBox.attr({"opacity":0.1,"fill":"0000aa","stroke-dasharray":"-.","stroke-width":2,"stroke":"000055"}); //Стиль для бокс выделения
          graphRedactor.selectBox.ox=canvasCursor["x"]; // Координаты начала бокса выделения
          graphRedactor.selectBox.oy=canvasCursor["y"]; // Координаты начала бокса выделения
        }else{
          var ox=graphRedactor.selectBox.ox; // Изменяем геометрию уже существующего бокса выделения по координатам курсора
          var oy=graphRedactor.selectBox.oy;
          var x= canvasCursor["x"]<ox ? canvasCursor["x"] : ox;
          var y= canvasCursor["y"]<oy ? canvasCursor["y"] : oy;
          var width= Math.abs(canvasCursor["x"]-ox);
          var height=Math.abs(canvasCursor["y"]-oy);
          var selectBBox=graphRedactor.selectBox.getBBox();
          graphRedactor.selectBox.attr({"width":width,"height":height,"x":x,"y":y});
        }
      }
    }
  }
  ////////////// Функция отпускания мыши ///////////////////////////////////////////////////////
  graphRedactor.canvasMouseUp=function(cursor){
    lgr("graphRedactor.canvasMouseUp");
    if (graphRedactor.isCanvasElementClicked!=true){
      graphRedactor.isMousedown=false;
       if (graphRedactor.selectBox){
          graphRedactor.unselectMultiNodes(graphRedactor.multiDragSet); // Убираем выделение со всех выбранных элементов
          var selectBBox=graphRedactor.selectBox.getBBox(); // Получаем рамку бокса выделения
          for (var ar in graphRedactor.nodeVisual){   // Сравниваем со всеми объектами их рамки с рамкой бокса выделения на пересечения
            var nodeVisual=graphRedactor.nodeVisual[ar];
            if (ar!="ID"+id && typeof(nodeVisual)+""!="function" && graphRedactor.nodeVisual.hasOwnProperty(ar)){
              var box=nodeVisual.getBBox();
              if (Raphael.isBBoxIntersect(box,selectBBox)){
                  graphRedactor.selectMultiNodes([nodeVisual]); //Выделяем эемент
              }
            }
          }        
          graphRedactor.selectBox.remove(); //Удаляем бокс выделения
          graphRedactor.selectBox=null;
       }
    }
  }
   ////////////////////////////////////////////////////////////////////////////////
  graphRedactor.checkAddNode=function(cursor){
    if (graphRedactor.showAddNodeHintFlag){
      var canvasCoord=Ext.get(EI["DTRedactor"]).getXY(); 
      setCoordX(EI["addNodeHint"],cursor.xy[0]-canvasCoord[0]+10);
      setCoordY(EI["addNodeHint"],cursor.xy[1]-canvasCoord[1]+10);    
    }
  }
   ////////////////////////////////////////////////////////////////////////////////
  graphRedactor.refreshLinkPosition=function(nodeid){
    if (graphRedactor.nodeVisual["ID"+nodeid]){
      var nodes=graphRedactor.getNodesByParentID(nodeid);
      var dd=nodes.length; 
      for (var i=0;i<dd;i++){
        graphRedactor.linkVisual["ID"+nodes[i]["RULENODEID"]]["inIndex"]=i+1;  
      }
      graphRedactor.linkRepaint([graphRedactor.nodeVisual["ID"+nodeid]]); 
    }
  }
   ////////////////////////////////////////////////////////////////////////////////
  graphRedactor.escapeEvent=function(){
    graphRedactor.isCanvasElementClicked=false;
    graphRedactor.curoper="none";
    graphRedactor.showAddNodeHintFlag=false;
    hideElement(EI["addNodeHint"]);

    graphRedactor.unselectMultiNodes(graphRedactor.multiDragSet.items);
    var dd=graphRedactor.escapeList.length;
    for (var i=0;i<dd;i++){
      graphRedactor.escapeList[i]();
    }
  }
   ////////////////////////////////////////////////////////////////////////////////
  graphRedactor.deleteNode=function(nodeid){
    lgr("graphRedactor.deleteNode");
    var nodeData=null;
    var dd=graphRedactor.LoadedRuleNodes.length;
    for (var i=0;i<dd;i++){
      var ruleNode=graphRedactor.LoadedRuleNodes[i];
      if (ruleNode["RULENODEID"]+""==nodeid+""){
        nodeData=ruleNode;
        graphRedactor.LoadedRuleNodes.splice(i,1);
        break;
      }
    }
    if (graphRedactor.nodeVisual["ID"+nodeid]) {
      var parentNodeID=graphRedactor.nodeVisual["ID"+nodeid]["parentid"];
      nodeData.put("coord",graphRedactor.nodeVisual["ID"+nodeid].getBBox());
      graphRedactor.nodeVisual["ID"+nodeid].remove();
      delete graphRedactor.nodeVisual["ID"+nodeid];
      graphRedactor.linkVisual["ID"+nodeid]["inText"].remove();
      graphRedactor.linkVisual["ID"+nodeid]["outText"].remove();
      graphRedactor.linkVisual["ID"+nodeid]["path"].remove();
      delete graphRedactor.linkVisual["ID"+nodeid];
      graphRedactor.refreshNode(parentNodeID);
      graphRedactor.refreshLinkPosition(parentNodeID);
    }
    return nodeData;
  }
   ////////////////////////////////////////////////////////////////////////////////
  graphRedactor.deleteNodeDialog=function(){
    lgr("graphRedactor.deleteNodeDialog");
    var dd=graphRedactor.multiDragSet.length;
    var selectedNodeIds=getNewList();
    var hasChildsFlag=false;
    for (var i=0;i<dd;i++){
        var selNode=graphRedactor.multiDragSet[i];
        if (selNode["nodeid"]+""!="0"){
        selectedNodeIds.add(selNode["nodeid"]);
        var selNode=graphRedactor.multiDragSet[i];
        var childNodes=graphRedactor.getNodesByParentID(selNode["nodeid"]);
        if(childNodes.length>0){
          hasChildsFlag=true;
          var dd2=childNodes.length;
          for (var j=0;j<dd2;j++){
            var childNode=childNodes[j];
            selectedNodeIds.add(childNode["RULENODEID"]);
          }
        }
      }
    }
    if (hasChildsFlag==false || showConfirm(getResourceBundle("JS_RULEEDITOR_GRAPHS_8"))){
      var changeMap=getNewMap();
      changeMap.put("optype","multiple");
      changeMap.put("type","deleteNode");
      var changeList=getNewList();
      var dd=selectedNodeIds.size();
      for (var i=0;i<dd;i++){
        var nodeData=graphRedactor.deleteNode(selectedNodeIds.get(i));
        if (nodeData!=null){
          var map=getNewMap();
          map.put("begin",nodeData);
          map.put("end",[]);
          changeList.add(map); 
        }
      }
      changeMap.put("list",changeList);
      graphRedactor.multiDragSet.clear(); 
      graphRedactor.changeList.push(changeMap);      
    }
    graphRedactor.checkRevertRibbon();
  }
   ////////////////////////////////////////////////////////////////////////////////
  graphRedactor.generateContexMenu=function(){
    lgr("graphRedactor.generateContexMenu");
    var menu = getNewList();

    var changeFlag= graphRedactor.changeList.length>0 ? "true" : "false";
    var addNodeFlag=graphRedactor.checkNodeAction()+"";
    var delNodeFlag="false";
    var reloadFlag="false";
    var logFlag="false";

    if (graphRedactor.multiDragSet.length==1){
      var re = new RegExp("[A-Za-z]");
      if (re.test(graphRedactor.multiDragSet[0]["nodeid"]+"")==false){
        logFlag="true";
      }
    }

    addMenuItem(menu,getResourceBundle("JS_RULEEDITOR_GRAPHS_9"),"",changeFlag,"SCRIPT","", "graphRedactor.undoAction()","");
    addMenuItem(menu,getResourceBundle("JS_RULEEDITOR_GRAPHS_10"),"",changeFlag,"SCRIPT","", "graphRedactor.applyChangeList()","");
    if (nvl(graphRedactor.loadedRuleData,[])["RULEID"]!=null){
      reloadFlag="true";
    }
    addMenuItem(menu,"----------------------------------","","false");
    addMenuItem(menu,getResourceBundle("JS_RULEEDITOR_GRAPHS_11"),"",reloadFlag,"SCRIPT","", "graphRedactor.reloadRule()","");
    addMenuItem(menu,getResourceBundle("JS_RULEEDITOR_GRAPHS_12"),"",reloadFlag,"SCRIPT","", "testDatasetDialog.dialogShow()","");
    addMenuItem(menu,getResourceBundle("JS_RULEEDITOR_GRAPHS_13"),"",logFlag,"SCRIPT","", "logSchemeDialog.logDialogShow()","");
    addMenuItem(menu,"----------------------------------","","false");
    var submenu=getNewList();
    addMenuItem(submenu,getResourceBundle("JS_RULEEDITOR_GRAPHS_14"),"",addNodeFlag,"SCRIPT","", "graphRedactor.addOperationClick()",""); 
    addMenuItem(submenu,getResourceBundle("JS_RULEEDITOR_GRAPHS_15"),"",addNodeFlag,"SCRIPT","", "graphRedactor.addMatrixClick()",""); 
    addMenuItem(submenu,getResourceBundle("JS_RULEEDITOR_GRAPHS_16"),"",addNodeFlag,"SCRIPT","", "graphRedactor.addParameterClick()","");
    addMenuItem(submenu,getResourceBundle("JS_RULEEDITOR_GRAPHS_17"),"",addNodeFlag,"SCRIPT","", "graphRedactor.addRuleClick()","");
    addMenuItem(submenu,getResourceBundle("JS_RULEEDITOR_GRAPHS_18"),"",addNodeFlag,"SCRIPT","", "graphRedactor.addConstantClick()","");
    addMenuItem(submenu,getResourceBundle("JS_RULEEDITOR_GRAPHS_19"),"",addNodeFlag,"SCRIPT","", "graphRedactor.addCollectionClick()","");
    addMenuItem(submenu,getResourceBundle("JS_RULEEDITOR_GRAPHS_20"),"",addNodeFlag,"SCRIPT","", "graphRedactor.addIntervalClick()","");
    addMenuItem(submenu,getResourceBundle("JS_RULEEDITOR_GRAPHS_21"),"",addNodeFlag,"SCRIPT","", "graphRedactor.addCaseClick()","");
    addMenuItem(menu,getResourceBundle("JS_RULEEDITOR_GRAPHS_22"),submenu,addNodeFlag);

    var dd=graphRedactor.multiDragSet.length;
    if (dd>0){
      delNodeFlag="true";
      for (var i=0;i<dd;i++){
        var nodeSet=graphRedactor.multiDragSet[i];
        if (nodeSet["nodeid"]=="0"){
          delNodeFlag="false";
        }
      }
    }
    addMenuItem(menu,getResourceBundle("JS_RULEEDITOR_GRAPHS_23"),"",delNodeFlag,"SCRIPT","", "graphRedactor.deleteNodeDialog()","");  

    return menu;
  }
   ////////////////////////////////////////////////////////////////////////////////
  graphRedactor.checkNodeAction=function(){
    lgr("graphRedactor.checkNodeAction");

    var nodeActionList=["add-operation-btn",
                        "add-matrix-btn",
                        "add-parameter-btn",
                        "add-subrule-btn",
                        "add-constant-btn",
                        "add-collection-btn",
                        "add-interval-btn",
                        "add-case-btn"];
    var dd=nodeActionList.length;

    for (var i=0;i<dd;i++){
      gbi(nodeActionList[i]).disable(); 
    }
    if (graphRedactor.multiDragSet.length==1){
      var nodeType=graphRedactor.multiDragSet[0]["nodeType"];
      var nodeid=graphRedactor.multiDragSet[0]["nodeid"];
      var childNodeCount=(graphRedactor.getNodesByParentID(nodeid)).length;
      lgr(nodeType);
      if (graphRedactor[nodeType+"MaxInputCount"](nodeid)>childNodeCount){
	    var currentNode = graphRedactor.getNodeByID(nodeid); 
	    if(currentNode["OPERATIONGROUPSYSNAME"]=="WHEN"){
		  gbi("add-operation-btn").enable(); 
		}
		else if(currentNode["OPERATIONGROUPSYSNAME"]=="INT"){
		  for (var i=0;i<dd;i++){
		    gbi("add-parameter-btn").enable(); 
			gbi("add-interval-btn").enable();  
          }
		}
		else if(currentNode["OPERATIONGROUPSYSNAME"]=="CASE"){
		  for (var i=0;i<dd;i++){
		    gbi("add-subrule-btn").enable(); 
			gbi("add-case-btn").enable();  
          }
		}
		else if(currentNode["OPERATIONGROUPSYSNAME"]=="GRP"){
		  for (var i=0;i<dd;i++){
		    if(nodeActionList[i]!="add-interval-btn" && nodeActionList[i]!="add-case-btn") 
              gbi(nodeActionList[i]).enable(); 
          }
		}
		else if(currentNode["OPERATIONGROUPSYSNAME"]=="CHK" || currentNode["OPERATIONGROUPSYSNAME"]=="CALC"){
		  for (var i=0;i<dd;i++){
		    if(nodeActionList[i]!="add-collection-btn" && nodeActionList[i]!="add-interval-btn" && nodeActionList[i]!="add-case-btn") 
              gbi(nodeActionList[i]).enable(); 
          }
		}
		else{
          for (var i=0;i<dd;i++){
            gbi(nodeActionList[i]).enable(); 
          }
		}
        return true;        
      }
    }
    return false;
  }
  ////////////////////////////////////////////////////////////////////////////////
  graphRedactor.reloadRule=function(){
    lgr("graphRedactor.reloadRule");
    ruleNodeDialog.loadRuleNodeDialogShow({"selectedRuleID":graphRedactor.loadedRuleData["RULEID"]});
  }

  ////////////////////////////////////////////////////////////////////////////////
  graphRedactor.isAllChildrenType = function (children, type){
    for(var i=0; i<children.size(); i++){
      if(children[i]['NODETYPE']==type)
        return false;
	}
    return true;
  }
  
  graphRedactor.validateRule = function () {
    if (nvl(graphRedactor.LoadedRuleNodes,[]).length>0){
      var msg = "";
      var tree = graphRedactor.getNodesByParentID("0");
      if (tree.length != 1) {
         msg = getResourceBundle("JS_RULEEDITOR_GRAPHS_24")+" \n";
      } else {
        msg = graphRedactor.validateSubTree(tree[0]);
      }
      if (msg == ""){
        showInfo(getResourceBundle("JS_RULEEDITOR_GRAPHS_25"));
        return true;
      }else{
        showError(msg);   
        return false;
      }
    }else{
      showAlert(getResourceBundle("JS_RULEEDITOR_GRAPHS_26"));
    }
  }

  ////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.validateSubTree = function(node) {
    var nodeType = graphRedactor.nodeTypes[node['NODETYPE']];
    var children = graphRedactor.getNodesByParentID(node["RULENODEID"]);
    var ruleNodeID=nodeType;
    var result = "";
    if (nodeType == "Operation") {        
      if (!children || children.length == 0){
        result += getResourceBundle("JS_RULEEDITOR_GRAPHS_27")+" '" + ruleNodeID + "' "+getResourceBundle("JS_RULEEDITOR_GRAPHS_28")+" \n";          
      }else{
        var operType=graphRedactor.getOperation(node["VALUEID"])["SYSNAME"];
        if (operType=="SUBTRACT" || operType=="MULTIPLICATION" || 
            operType=="DIVISION" || operType=="INVOLUTION" || 
            operType=="IN"){
            if (children.length != 2){
              result += getResourceBundle("JS_RULEEDITOR_GRAPHS_27")+" '" + ruleNodeID + " " + operType + "' "+getResourceBundle("JS_RULEEDITOR_GRAPHS_29")+" \n";   
            }
        }
		if (operType=="LARGER"  ||  operType=="LARGEROREQUAL" || 
            operType=="EQUAL"   ||  operType=="NOTEQUAL" ||
            operType=="SMALLER" ||  operType=="SMALLEROREQUAL"){
            if (children.length != 2 && children.length != 3){
              result += getResourceBundle("JS_RULEEDITOR_GRAPHS_27")+" '" + ruleNodeID + " " + operType + "' "+getResourceBundle("JS_RULEEDITOR_GRAPHS_34")+" \n";   
            }
        }
        if (operType=="INT" && children.length < 2){
          result += getResourceBundle("JS_RULEEDITOR_GRAPHS_27")+" '" + ruleNodeID + "' "+getResourceBundle("JS_RULEEDITOR_GRAPHS_30")+" \n";    
        }
        if (operType=="INT" && graphRedactor.nodeTypes[children[0]["NODETYPE"]]=="Interval"){
          result += getResourceBundle("JS_RULEEDITOR_GRAPHS_31")+" '" + ruleNodeID + "' \n"; 
        }
        if (operType=="INT" && graphRedactor.nodeTypes[children[0]["NODETYPE"]]=="Interval"){
          result += getResourceBundle("JS_RULEEDITOR_GRAPHS_31")+" '" + ruleNodeID + "' \n"; 
        }     
        if (operType=="IN" && graphRedactor.nodeTypes[children[1]["NODETYPE"]]!="Collection"){
          lgr(children);          
          result += getResourceBundle("JS_RULEEDITOR_GRAPHS_32")+" '" +ruleNodeID + "' \n"
        }
        if (operType=="CASE" && children.length < 2){
          result += getResourceBundle("JS_RULEEDITOR_GRAPHS_27")+" '" + ruleNodeID + "' "+getResourceBundle("JS_RULEEDITOR_GRAPHS_30")+" \n";     
        }
        if (operType=="CASE" && graphRedactor.nodeTypes[children[0]["NODETYPE"]]=="CASE"){

          result +=getResourceBundle("JS_RULEEDITOR_GRAPHS_33")+ " '" + node['Name'] + "' \n"      
        }
        if (operType=="WHEN" && !graphRedactor.isAllChildrenType(children, 1)){
          result +=getResourceBundle("JS_RULEEDITOR_GRAPHS_35")+ " '" + node['Name'] + "' \n"      
        }
      }
      if (children.length>0){
        for (var i = 0; i < children.length; i++) {

          result += graphRedactor.validateSubTree(children[i]);
        } 
      }
    }    
    return result;   
  }
  ///////////////////////////////////////////////////////////////////////////////////////

  graphRedactor.slider = new Ext.Slider({   //Слайдер для масштабирования картинки (не работает если скрыт на оншове. Необходимо задавать значение по умолчанию после открытия формы)
    renderTo: EI['scalePnl'],
    width: 300,
    increment: 25,
    minValue: 25,
    maxValue: 200,
      listeners: {
        change:   function(slider,value) {
               lgr(value);
               graphRedactor.setScale(stringToNumeric(value));  
              }
            }

  });

  return graphRedactor;

}


graphRedactor=graphConstructor();

