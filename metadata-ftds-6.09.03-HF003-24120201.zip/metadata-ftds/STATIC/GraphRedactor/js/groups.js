/////////////////////////////////////////////////////////////////
GroupDialogConstructor=function(){
	var groupDialog=new Object();
	groupDialog.curoper="none";
  	groupDialog.viewTableName=EI["tbPolicyRuleGroups"];
  	groupDialog.selectedGroupID=null;
    groupDialog.window=createSimpleModal2(EI["groupPanel"]);
	////////////////////////////////////////////////////////////////////
	groupDialog.addGroupDialogShow=function(){
		lgr("groupDialog.addGroupDialogShow");
    groupDialog.window.setTitle("Добавление новой группы правил");
    groupDialog.curoper="add";
    groupDialog.window.show(groupDialog.window);
    showElement(EI["groupPanel"]);
	}
 	////////////////////////////////////////////////////////////////////
 	groupDialog.delGroupDialogShow=function(){
      lgr("groupDialog.delGroupDialogShow");
    	if (gbi("del-group-btn").isEnabled()) {
       	   ruleDialog.getRulesByParams({"RULEGROUPID":groupDialog.selectedGroupID},"groupDialog.onAfterGetRules");
    	}
 	}
	////////////////////////////////////////////////////////////////////
	groupDialog.editGroupDialogShow=function(){
    lgr("groupDialog.editGroupDialogShow");
		if (gbi("edit-group-btn").isEnabled()) {
			groupDialog.window.setTitle("Редактирование группы правил");
			groupDialog.curoper="edit";
			groupDialog.getGroupsByParams({"RULEGROUPID":groupDialog.selectedGroupID},"groupDialog.onAfterGeteditGroupDialogShow");
		}
	}
	////////////////////////////////////////////////////////////////////
	groupDialog.groupDialogHide=function(){
    lgr("groupDialog.groupDialogHide");
		groupDialog.curoper="none";
    groupDialog.window.hide(groupDialog.window);
	}
	////////////////////////////////////////////////////////////////////
	groupDialog.getGroupsByParams=function(params,callback){
    lgr("groupDialog.getGroupsByParams");
		callback = callback==null ? "groupDialog.fillGroups" : callback; 
		if (callback=="groupDialog.fillGroups"){
			clearTable(groupDialog.viewTableName);
    		groupDialog.selectedGroupID=null;
    		groupDialog.checkRibbonControls();
			disableElement(groupDialog.viewTableName);
		}
    	params= params!=null ? params : getNewMap();
    	params['ORDERBY']= params['ORDERBY']==null ? "NAME" :params['ORDERBY'];
		dsCall("[dmsws]","ruleGroupGetListByParams",params,callback)
	}
 	////////////////////////////////////////////////////////////////////
 	groupDialog.add=function(){
    lgr("groupDialog.add");
   	var params=getNewMap();
   	params["SYSNAME"]=getValue(EI["edGroupSysName"]);
   	params["NAME"]=getValue(EI["edGroupName"]);
   	params["DESCRIPTION"]=getValue(EI["edGroupDescription"]);
   	disableElement(EI["groupPanel"]);
   	dsCall("[dmsws]","ruleGroupCreate",params,"groupDialog.onAfterAddGroup") 
 	}
 	////////////////////////////////////////////////////////////////////
 	groupDialog.edit=function(){
    lgr("groupDialog.edit");
    var params=getNewMap();
    params["SYSNAME"]=getValue(EI["edGroupSysName"]);
    params["NAME"]=getValue(EI["edGroupName"]);
    params["DESCRIPTION"]=getValue(EI["edGroupDescription"]);
    params["RULEGROUPID"]=groupDialog.selectedGroupID;
    disableElement(EI["groupPanel"]);
    dsCall("[dmsws]","ruleGroupModify",params,"groupDialog.onAfterEditGroup") 
 	}
 	////////////////////////////////////////////////////////////////////
 	groupDialog.del=function(){
	  lgr("groupDialog.del");
    var params=getNewMap();
    params["RULEGROUPID"]=groupDialog.selectedGroupID;
    dsCall("[dmsws]","ruleGroupDelete",params,"groupDialog.onAfterDelGroup") 
 	}
 	////////////////////////////////////////////////////////////////////
 	groupDialog.onAfterEditGroup=function(p){
    lgr("groupDialog.onAfterEditGroup");
		enableElement(EI["groupPanel"]);
    if (p["Status"]=="OK"){
    	toggleLeftPanel(true);
    	groupDialog.getGroupsByParams();
    	groupDialog.groupDialogHide();
    	groupDialog.curoper="none";
    }else{
    	showError("Внимание! Произошла ошибка при редактировании группы правил");
	  }
 	}
 	////////////////////////////////////////////////////////////////////
 	groupDialog.onAfterAddGroup=function(p){
    lgr("groupDialog.onAfterAddGroup");
		enableElement(EI["groupPanel"]);
    if (p["Status"]=="OK"){
    	toggleLeftPanel(true);
    	groupDialog.getGroupsByParams();
    	groupDialog.groupDialogHide();
    	groupDialog.curoper="none";
    }else{
    	showError("Внимание! Произошла ошибка при сохранении новой группы правил");
	  }
 	} 
 	////////////////////////////////////////////////////////////////////
 	groupDialog.onAfterDelGroup=function(p){
    lgr("groupDialog.onAfterDelGroup");
    if (p["Status"]=="OK"){
    	toggleLeftPanel(true);
    	groupDialog.getGroupsByParams();
    	groupDialog.curoper="none";
    }else{
    	showError("Внимание! Произошла ошибка при удалении группы правил");
	  }
 	}
  ////////////////////////////////////////////////////////////////////
  groupDialog.onAfterGeteditGroupDialogShow=function(p){
    lgr("groupDialog.onAfterGeteditGroupDialogShow");
    if (p['Status']=="OK"){
      p=p["Result"];
      if (p!=="" && p!=null){
        if (p.length==1){
          setValue(EI["edGroupSysName"],p[0]["SYSNAME"]);
          setValue(EI["edGroupName"],p[0]["NAME"]);
          setValue(EI["edGroupDescription"],p[0]["DESCRIPTION"]);
          groupDialog.window.show(groupDialog.window);
          showElement(EI["groupPanel"]);
        }else{
          showError("Ошибка получения данных по выбранной группе правил");
        }
      }
    }else{
      showError("Ошибка получения данных по выбранной группе правил");
    }
  }
  ////////////////////////////////////////////////////////////////////
  groupDialog.onAfterGetRules=function(p){
    lgr("groupDialog.onAfterGetRules");
    if (p['Status']=="OK"){
      p=p["Result"];
      if (p!=null && p!==""){
        var dd=p.length;
        if (dd==0){
            if (confirm("Вы уверены что хотите удалить выбранную группу - "+groupDialog.selectedGroupName+"?")){
                  groupDialog.curoper="del";
                  groupDialog[groupDialog.curoper]();  
              } 
        }else{
          showAlert("Внимание! В выбранной группе на удаление есть правила. Удаление невозможно!");
        }
      }
    }else{
      showError("Ошибка получения правил по группе правил.");     
    }
  }
 	////////////////////////////////////////////////////////////////////
 	groupDialog.checkParams=function(){
    lgr("groupDialog.checkParams");
	  var returnFlag=checkElements([EI["edGroupSysName"],EI["edGroupName"]]);
	  return returnFlag;  
 	}
 	////////////////////////////////////////////////////////////////////
 	groupDialog.applyChanges=function(){
    lgr("groupDialog.applyChanges");
	  if (groupDialog.checkParams()){
     	groupDialog[groupDialog.curoper](); 
    }else{
    	showAlert("Не заполнены все обязательные поля");
    }
 	}
 	////////////////////////////////////////////////////////////////////
	groupDialog.selectGroup=function(){
    lgr("groupDialog.selectGroup");
    var selGroup=getSelectedRow(groupDialog.viewTableName);
    if (selGroup!=="" && selGroup!=null){
      ribbonMenu.switchToTabByIndex(0);
      groupDialog.selectedGroupID=selGroup["RULEGROUPID"];
     	groupDialog.selectedGroupName=selGroup["NAME"];
     	ruleDialog.getRulesByParams({"RULEGROUPID":selGroup["RULEGROUPID"]});
     	groupDialog.checkRibbonControls();
    }  
	}
  ////////////////////////////////////////////////////////////////////
	groupDialog.checkRibbonControls=function(){
    lgr("groupDialog.checkRibbonControls");
    if (groupDialog.selectedGroupID==null){
     	gbi('edit-group-btn').disable();
     	gbi('del-group-btn').disable();  
    }else{
     	gbi('edit-group-btn').enable();
     	gbi('del-group-btn').enable();       
    }
 	}
	/////////////////////////////////////////////////////////////////////////////
	groupDialog.fillGroups=function(p){
    lgr("groupDialog.fillGroups");
	  enableElement(groupDialog.viewTableName);
	  var p=p["Result"];
	  if (p!=null && p!==""){
		  var dd=p.length;
		  for (var i=0;i<dd;i++){
		  	addRow(groupDialog.viewTableName,p[i]);
		  }
	  }
	}
  /////////////////////////////////////////////////////////////////////////////
  return groupDialog;
}

groupDialog=GroupDialogConstructor();