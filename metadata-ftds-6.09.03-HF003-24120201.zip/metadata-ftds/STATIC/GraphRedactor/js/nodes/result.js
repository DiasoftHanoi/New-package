  graphRedactor.nodeTypes[99]="Result";


  ////////////// Функция создания узла типа Результат ///////////////////////////////////////////////////
  graphRedactor.createResult=function(obj,prms){
    lgr("graphRedactor.createResult");
    var incr=graphRedactor.incr;   
    var inputNodeList=graphRedactor.getNodesByParentID(obj["RULENODEID"]);
    var inputNodeHeight= inputNodeList.length % 2 == 0 ? inputNodeList.length+2 : inputNodeList.length+1;
    var rectHeight=nmlz(inputNodeHeight*incr);
    rectHeight = rectHeight<2*incr ? 2*incr : rectHeight;

    prms=nvl(prms,[]);
    prms=graphRedactor.mergeObjects(prms,{
                  "colorStart":"#900000",
                  "colorEnd":"ff0000",
                  "title":"RESULT",
                  "titleStyle": graphRedactor.textStyles["common"],
                  "nodeid":"0",
                  "parentid":"-1",
                  "rectHeight":rectHeight,
                  "minWidth":6*incr
               });
    var nodeSet=graphRedactor.createNode(prms);  

    return nodeSet;
  }

  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.repaintResult=function(obj,prms){
    lgr("graphRedactor.repaintResult");
    var incr=graphRedactor.incr;
    var inputNodeList=graphRedactor.getNodesByParentID(obj["RULENODEID"]);
    var inputNodeHeight= inputNodeList.length % 2 == 0 ? inputNodeList.length+2 : inputNodeList.length+1;
    var rectHeight=nmlz(inputNodeHeight*incr);
    rectHeight = rectHeight<2*incr ? 2*incr : rectHeight;

    prms=nvl(prms,[]);
    prms=graphRedactor.mergeObjects(prms,{
                  "colorStart":"#900000",
                  "colorEnd":"ff0000",
                  "title":"RESULT",
                  "titleStyle": graphRedactor.textStyles["common"],
                  "nodeid":"0",
                  "parentid":"-1",
                  "rectHeight":rectHeight,
                  "minWidth":6*incr
               });
    var nodeSet=graphRedactor.repaintNode(prms,obj["RULENODEID"]); 
    return nodeSet;
  } 
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.ResultMaxInputCount=function(nodeid){
    return 1;
  }