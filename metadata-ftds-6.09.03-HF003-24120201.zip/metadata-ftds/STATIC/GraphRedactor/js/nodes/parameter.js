  graphRedactor.nodeTypes[1]="Parameter";

  graphRedactor.ParameterDialog=createSimpleModal2(EI["parameterPanel"]);
  graphRedactor.ParameterDialog.on("hide",graphRedactor.hideOpenDialog,this,{stopPropagation:false});


  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.addParameterClick=function(){
    lgr("graphRedactor.addParameterClick");
    if (gbi("add-parameter-btn").isEnabled()){
      graphRedactor.showAddNodeHintFlag=true;
      gbi(EI["addNodeHint"]).className="";
      addClass(gbi(EI["addNodeHint"]),"parameterHint");
      showElement(EI["addNodeHint"]);
      graphRedactor.showAddNodeFunction=graphRedactor.showParameterDialog;
      graphRedactor.curoper="add";
    }
  }

  ///////////////////////////////////////////////////////////////////////////////////////////////////////
 graphRedactor.showParameterDialog=function (opentype){
    lgr("graphRedactor.showParameterDialog");

      if (this.nodeid){graphRedactor.curoper="edit";} ///Определяем что был выбран узел для редактирвоания

      clearComboOptions(EI["cmParameter"]);
      if (is7==false){
        addComboOption(EI["cmParameter"],"","");
      }
      var dd=graphRedactor.loadedRuleDatasetParams.length;
      for (var i=0;i<dd;i++){
        var dataset=graphRedactor.loadedRuleDatasetParams[i];
        addComboOption(EI["cmParameter"],dataset["DATASETPARAMID"],dataset["SYSNAME"]);
      }

      if (graphRedactor.curoper=="edit"){
        var dd=graphRedactor.LoadedRuleNodes.length;
        var selectedNode=null;
        var selNodeID=this.nodeid;
        for (var i=0;i<dd;i++){
          var Node=graphRedactor.LoadedRuleNodes[i];
          if (Node["RULENODEID"]+""==selNodeID+""){
            selectedNode=Node;
            break;
          }
        }
        graphRedactor.selNodeID=selNodeID;
        setValue(EI["edParameterOrder"],selectedNode["ORDERNO"]);
        setComboOptionByValue(EI["cmParameter"],selectedNode["VALUEID"]);


        var defValue=selectedNode["DEFAULTVALUE"];
        
        var param=graphRedactor.getParameterNameByID(selectedNode["VALUEID"]);
        
        if (param["PARAMVALUETYPE"]=="java.util.Date" && defValue!=null && defValue!==""){
          defValue= (parseInt(defValue)+""!="NaN") ? changeDate((new Date(0,0,0)),stringToNumeric(defValue)-1) : defValue;
        }
        setCheckBoxChecked(EI["cbIsDefault"],selectedNode["ISUSEDEFAULT"]);
        setValue(EI["edDefaultParameterValue"],defValue);

        graphRedactor.ParameterDialog.setTitle("Редактирование узла параметра");
      }
      if (graphRedactor.curoper=="add"){
        var parentid=graphRedactor.multiDragSet[0]["nodeid"];
        setValue(EI["edParameterOrder"],stringToNumeric(graphRedactor.getNextOrderByNo(parentid))+1);
        setComboOptionByValue(EI["cmParameter"],"");
        setCheckBoxChecked(EI["cbIsDefault"],false);
        setValue(EI["edDefaultParameterValue"],"");
        graphRedactor.ParameterDialog.setTitle("Добавление узла параметра");
      }
      graphRedactor.checkParamDefaultValue();
      graphRedactor.openedDialogType="Parameter";
      graphRedactor.ParameterDialog.show(graphRedactor.ParameterDialog);
      showElement(EI["parameterPanel"]);
  }
  //////////// Функция создания узла типа параметр/////////////////////////////////////////////////////
  graphRedactor.createParameter=function(obj,prms){
    lgr("graphRedactor.createParameter");
    var param=graphRedactor.getParameterNameByID(obj["VALUEID"]);
    var nodeValue=param["SYSNAME"] ;

    prms=nvl(prms,[]);
    prms=graphRedactor.mergeObjects(prms,{
                  "colorStart":"#003030",
                  "colorEnd":"009F9F",
                  "title":nodeValue,
                  "titleStyle": graphRedactor.textStyles["common"],
                  "nodeid":obj["RULENODEID"],
                  "parentid":obj["PARENTRULENODEID"]
               });
    var nodeSet=graphRedactor.createNode(prms); 
    return nodeSet;
  }
  /////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.getParameterNameByID=function(id){
    lgr("graphRedactor.getParameterNameByID");

    var dd=graphRedactor.loadedRuleDatasetParams.length;
    for (var i=0;i<dd;i++){
      var param=graphRedactor.loadedRuleDatasetParams[i];
      //lgr(param);
      if (id+""==param["DATASETPARAMID"]+""){
        return param;
      }
    }
    return [];
  }
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.hideParameterDialog=function(){
    lgr("graphRedactor.hideParameterDialog");
    graphRedactor.ParameterDialog.hide();
    hideElement(EI["parameterPanel"]);
  }

  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.applyChangesParameter=function(){
    lgr("graphRedactor.applyChangesParameter");
    if (graphRedactor.checkParameterParams()){
        graphRedactor[graphRedactor.curoper+"Parameter"]();
        graphRedactor.curoper="none";
        hideElement(EI["parameterPanel"]);
        graphRedactor.ParameterDialog.hide();  
        graphRedactor.checkRevertRibbon();
    }else{
        showAlert("Не заполнены все обязательные поля");
    }
  }
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.addParameter=function(){
    lgr("graphRedactor.addParameter");
      var newNode=getNewMap();
      newNode.put("DEFAULTVALUE",getValue(EI["edDefaultParameterValue"]));
      newNode.put("ISUSEDEFAULT", checkBoxChecked(EI["cbIsDefault"])==true ? parseInt(1) : parseInt(0)); 
      newNode.put("NODETYPE","1");      
      newNode.put("NODEVALUE",null);  
      newNode.put("ORDERNO",getValue(EI["edParameterOrder"]));
      newNode.put("PARENTRULENODEID",graphRedactor.multiDragSet[0]["nodeid"]);
      newNode.put("RULEID",graphRedactor.loadedRuleData["RULEID"]);
      newNode.put("RULENODEID",Raphael.createUUID());
      newNode.put("VALUEID",getComboSelectedValue(EI["cmParameter"]));
      lgr(newNode);
      graphRedactor.LoadedRuleNodes.add(newNode);
      var coord=graphRedactor.showAddNodeCoord;

      graphRedactor.changeList.push({"type":"addNode","begin":[],"end":newNode});

      graphRedactor.createParameter(newNode,{"x":coord["x"],"y":coord["y"],"idxAnimate":0,"nodeType": "Parameter" });
      graphRedactor.createLink(newNode["RULENODEID"],newNode["PARENTRULENODEID"]);
      graphRedactor.refreshLinkPosition(newNode["PARENTRULENODEID"]);
      graphRedactor.refreshNode(newNode["PARENTRULENODEID"]);
  }
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.repaintParameter=function(obj,prms){
    lgr("graphRedactor.repaintParameter");
    var incr=graphRedactor.incr;
    var param=graphRedactor.getParameterNameByID(obj["VALUEID"]);
    var nodeValue=param["SYSNAME"] ;

    prms=nvl(prms,[]);
    prms=graphRedactor.mergeObjects(prms,{
                  "colorStart":"#003030",
                  "colorEnd":"009F9F",
                  "title":nodeValue,
                  "titleStyle": graphRedactor.textStyles["common"],
                  "nodeid":obj["RULENODEID"],
                  "parentid":obj["PARENTRULENODEID"]
               });
    var nodeSet=graphRedactor.repaintNode(prms,obj["RULENODEID"]); 
    return nodeSet;
  }  
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.editParameter=function(prms){
    lgr("graphRedactor.editParameter"); 
    prms=nvl(prms,[]);
    var newNode=getNewMap();
    newNode.put("DEFAULTVALUE",getValue(EI["edDefaultParameterValue"]));
    newNode.put("ISUSEDEFAULT", checkBoxChecked(EI["cbIsDefault"])==true ? parseInt(1) : parseInt(0)); 
    newNode.put("NODETYPE","1");       
    newNode.put("NODEVALUE",null);  
    newNode.put("ORDERNO",getValue(EI["edParameterOrder"]));
    newNode.put("PARENTRULENODEID",nvl(prms["PARENTRULENODEID"],graphRedactor.nodeVisual["ID"+graphRedactor.selNodeID].parentid));
    newNode.put("RULENODEID",graphRedactor.selNodeID);
    newNode.put("VALUEID",getComboSelectedValue(EI["cmParameter"]));
    lgr(newNode);
    var dd=graphRedactor.LoadedRuleNodes.length;
    var selNodeID=graphRedactor.selNodeID;
    var begin=null;
    for (var i=0;i<dd;i++){
      var Node=graphRedactor.LoadedRuleNodes[i];
      if (Node["RULENODEID"]+""==selNodeID+""){
        begin=cloneObj(Node);
        graphRedactor.LoadedRuleNodes[i]=newNode;
        break;
      }
    }
    var end=newNode;
    graphRedactor.changeList.push({"type":"editNode","begin":begin,"end":end});
    graphRedactor.checkRevertRibbon();
    graphRedactor.refreshLinkPosition(newNode["PARENTRULENODEID"]);
    graphRedactor.refreshNode(newNode["RULENODEID"]);
    graphRedactor.refreshNode(newNode["PARENTRULENODEID"]);
  }

  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.checkParamDefaultValue=function(){
    lgr("graphRedactor.checkParamDefaultValue");
    if (checkBoxChecked(EI["cbIsDefault"])){ 
       enableElement(EI["edDefaultParameterValue"]);
    } else {  
       disableElement(EI["edDefaultParameterValue"]);
       setValue(EI["edDefaultParameterValue"], "");
    }
  }
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.checkParameterParams=function(){
    var checkList=[EI["edParameterOrder"],EI["cmParameter"]];
    if (checkBoxChecked(EI["cbIsDefault"])){
      checkList.push(EI["edDefaultParameterValue"]);
    }  
    return checkElements(checkList);
  }
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.ParameterMaxInputCount=function(nodeid){
    return 0;
  }