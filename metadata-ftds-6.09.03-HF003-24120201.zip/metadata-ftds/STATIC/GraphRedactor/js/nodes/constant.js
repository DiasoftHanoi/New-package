  graphRedactor.nodeTypes[3]="Constant";

  graphRedactor.ConstantDialog=createSimpleModal2(EI["constantPanel"]);
  graphRedactor.ConstantDialog.on("hide",graphRedactor.hideOpenDialog,this,{stopPropagation:false});


  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.addConstantClick=function(){
    lgr("graphRedactor.addConstantClick");
    if (gbi("add-constant-btn").isEnabled()){
      graphRedactor.showAddNodeHintFlag=true;
      gbi(EI["addNodeHint"]).className="";
      addClass(gbi(EI["addNodeHint"]),"constantHint");
      showElement(EI["addNodeHint"]);
      graphRedactor.showAddNodeFunction=graphRedactor.showConstantDialog;
      graphRedactor.curoper="add";
    }
  }

  ///////////////////////////////////////////////////////////////////////////////////////////////////////
 graphRedactor.showConstantDialog=function (opentype){
    lgr("graphRedactor.showConstantDialog");

      if (this.nodeid){graphRedactor.curoper="edit";} ///Определяем что был выбран узел для редактирвоания

      if (graphRedactor.curoper=="edit"){
        var dd=graphRedactor.LoadedRuleNodes.length;
        var selectedNode=null;
        var selNodeID=this.nodeid;
        for (var i=0;i<dd;i++){
          var Node=graphRedactor.LoadedRuleNodes[i];
          if (Node["RULENODEID"]+""==selNodeID+""){
            selectedNode=Node;
            break;
          }
        }
        var NODEVALUE=selectedNode["NODEVALUE"];
        graphRedactor.selNodeID=selNodeID;
        setValue(EI["edConstantOrder"],selectedNode["ORDERNO"]);

        var nodeValue=NODEVALUE["VALUE"];
        var nodeValueType=NODEVALUE["VALUETYPE"];

        if (nodeValueType=="java.util.Date"){
          nodeValue=convertDate(nodeValue);
        }

        setComboOptionByValue(EI["cmConstantType"],nodeValueType);
    	  setValue(EI["edConstantValue"], (nodeValue=="" ? "_" : nodeValue));
        graphRedactor.ConstantDialog.setTitle("Редактирование узла константы");
      }
      if (graphRedactor.curoper=="add"){
        var parentid=graphRedactor.multiDragSet[0]["nodeid"];
        setValue(EI["edConstantOrder"],stringToNumeric(graphRedactor.getNextOrderByNo(parentid))+1);
        setComboOptionByValue(EI["cmConstantType"],"");
    	  setValue(EI["edConstantValue"],"");
        graphRedactor.ConstantDialog.setTitle("Добавление узла константы");
      }
      graphRedactor.openedDialogType="Constant";
      graphRedactor.ConstantDialog.show(graphRedactor.ConstantDialog);
      showElement(EI["constantPanel"]);
  }
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.hideConstantDialog=function(){
    lgr("graphRedactor.hideConstantDialog");
    graphRedactor.ConstantDialog.hide();
    hideElement(EI["constantPanel"]);
  }

  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.applyChangesConstant=function(){
    lgr("graphRedactor.applyChangesConstant");
    if (graphRedactor.checkConstantParams()){
        graphRedactor[graphRedactor.curoper+"Constant"]();
        graphRedactor.curoper="none";
        hideElement(EI["constantPanel"]);
        graphRedactor.ConstantDialog.hide();  
        graphRedactor.checkRevertRibbon();
    }else{
        showAlert("Не заполнены все обязательные поля");
    }
  }
  //////////// Функция создания узла типа константа/////////////////////////////////////////////////////
  graphRedactor.createConstant=function(obj,prms){
    lgr("graphRedactor.createConstant");
    var nodeValueMap=(obj["NODEVALUE"]);

    var nodeValue=nodeValueMap["VALUE"];
    var nodeValueType=nodeValueMap["VALUETYPE"];

    if (nodeValueType=="java.util.Date"){
      nodeValue=convertDate(nodeValue);
    }

    prms=nvl(prms,[]);
    prms=graphRedactor.mergeObjects(prms,{
                  "colorStart":"#007000",
                  "colorEnd":"00Df00",
                  "title":nodeValue,
                  "titleStyle": graphRedactor.textStyles["common"],
                  "nodeid":obj["RULENODEID"],
                  "parentid":obj["PARENTRULENODEID"]
               });


    var nodeSet=graphRedactor.createNode(prms); 
    lgr(nodeSet);
    return nodeSet;
  }


  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.addConstant=function(){
    lgr("graphRedactor.addConstant");
    var newNode=getNewMap();
    newNode.put("DEFAULTVALUE",null);
    newNode.put("ISUSEDEFAULT", null); 
    newNode.put("NODETYPE","3");  
    var NODEVALUE=getNewMap();
    var VALUE=getValue(EI["edConstantValue"]);
    var VALUETYPE=getComboSelectedValue(EI["cmConstantType"]);
    if (VALUE=="_" && VALUETYPE=="java.lang.String"){
      VALUE= "";  
    }
    
    NODEVALUE.put("VALUE",VALUE);  
    NODEVALUE.put("VALUETYPE",VALUETYPE);  
      
    newNode.put("NODEVALUE",NODEVALUE);  
    newNode.put("ORDERNO",getValue(EI["edConstantOrder"]));
    newNode.put("PARENTRULENODEID",graphRedactor.multiDragSet[0]["nodeid"]);
    newNode.put("RULEID",graphRedactor.loadedRuleData["RULEID"]);
    newNode.put("RULENODEID",Raphael.createUUID());
    newNode.put("VALUEID",null);
    lgr(newNode);
    graphRedactor.LoadedRuleNodes.add(newNode);
    var coord=graphRedactor.showAddNodeCoord;

    graphRedactor.changeList.push({"type":"addNode","begin":[],"end":newNode});

    graphRedactor.createConstant(newNode,{"x":coord["x"],"y":coord["y"],"idxAnimate":0,"nodeType": "Constant" });
    graphRedactor.createLink(newNode["RULENODEID"],newNode["PARENTRULENODEID"]);
    graphRedactor.refreshLinkPosition(newNode["PARENTRULENODEID"]);
    graphRedactor.refreshNode(newNode["PARENTRULENODEID"]);
  }

  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.repaintConstant=function(obj,prms){

    lgr("graphRedactor.repaintConstant");
    var nodeValueMap=(obj["NODEVALUE"]);
    var nodeValue=nodeValueMap["VALUE"];
    var nodeValueType=nodeValueMap["VALUETYPE"];

    if (nodeValueType=="java.util.Date"){
      nodeValue=convertDate(nodeValue);
    }

    prms=nvl(prms,[]);
    prms=graphRedactor.mergeObjects(prms,{
                  "colorStart":"#007000",
                  "colorEnd":"00Df00",
                  "title":nodeValue,
                  "titleStyle": graphRedactor.textStyles["common"],
                  "nodeid":obj["RULENODEID"],
                  "parentid":obj["PARENTRULENODEID"]
               });

    var nodeSet=graphRedactor.repaintNode(prms,obj["RULENODEID"]);     
    return nodeSet;
  }  
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.editConstant=function(prms){
    lgr("graphRedactor.editConstant"); 
    prms=nvl(prms,[]);
    var newNode=getNewMap();
    newNode.put("DEFAULTVALUE",null);
    newNode.put("ISUSEDEFAULT", null); 
    newNode.put("NODETYPE","3");  
    var NODEVALUE=getNewMap();

    var VALUE=getValue(EI["edConstantValue"]);
    var VALUETYPE=getComboSelectedValue(EI["cmConstantType"]);
    if (VALUE=="_" && VALUETYPE=="java.lang.String"){
      VALUE= "";  
    }
    
    NODEVALUE.put("VALUE",VALUE);  
    NODEVALUE.put("VALUETYPE",VALUETYPE);  

      
    newNode.put("NODEVALUE",NODEVALUE);  
    newNode.put("ORDERNO",getValue(EI["edConstantOrder"]));
    newNode.put("PARENTRULENODEID",nvl(prms["PARENTRULENODEID"],graphRedactor.nodeVisual["ID"+graphRedactor.selNodeID].parentid));
    newNode.put("RULEID",graphRedactor.loadedRuleData["RULEID"]);
    newNode.put("RULENODEID",graphRedactor.selNodeID);
    newNode.put("VALUEID",null);
    lgr(newNode);

    var dd=graphRedactor.LoadedRuleNodes.length;
    var selNodeID=graphRedactor.selNodeID;
    var begin=null;
    for (var i=0;i<dd;i++){
      var Node=graphRedactor.LoadedRuleNodes[i];
      if (Node["RULENODEID"]+""==selNodeID+""){
        begin=cloneObj(Node);
        graphRedactor.LoadedRuleNodes[i]=newNode;
        break;
      }
    }

    var end=newNode;
    graphRedactor.changeList.push({"type":"editNode","begin":begin,"end":end});
    graphRedactor.checkRevertRibbon();
    graphRedactor.refreshLinkPosition(newNode["PARENTRULENODEID"]);
    graphRedactor.refreshNode(newNode["RULENODEID"]);
    graphRedactor.refreshNode(newNode["PARENTRULENODEID"]);
  }
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.checkConstantParams=function(){
    var checkList=[EI["edConstantOrder"],EI["cmConstantType"],EI["edConstantValue"]];
    return checkElements(checkList);  
  }
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.ConstantMaxInputCount=function(nodeid){
    return 0;
  }
