  graphRedactor.nodeTypes[7]="Case";

  graphRedactor.CaseDialog=createSimpleModal2(EI["casePanel"]);
  graphRedactor.CaseDialog.on("hide",graphRedactor.hideOpenDialog,this,{stopPropagation:false});


  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.addCaseClick=function(){
    lgr("graphRedactor.addCaseClick");
    if (gbi("add-case-btn").isEnabled()){
      graphRedactor.showAddNodeHintFlag=true;
      gbi(EI["addNodeHint"]).className="";
      addClass(gbi(EI["addNodeHint"]),"caseHint");
      showElement(EI["addNodeHint"]);
      graphRedactor.showAddNodeFunction=graphRedactor.showCaseDialog;
      graphRedactor.curoper="add";
    }
  }

  ///////////////////////////////////////////////////////////////////////////////////////////////////////
 graphRedactor.showCaseDialog=function (opentype){
    lgr("graphRedactor.showCaseDialog");

      if (this.nodeid){graphRedactor.curoper="edit";} ///Определяем что был выбран узел для редактирвоания

      clearComboOptions(EI["cmCaseRule"]);
      if (is7==false){
        addComboOption(EI["cmCaseRule"],"","");
      }
      var dd=graphRedactor.loadedSubRules.length;
      for (var i=0;i<dd;i++){
        var subrule=graphRedactor.loadedSubRules[i];
        if (subrule["RULEID"]!=graphRedactor.loadedRuleData["RULEID"]){
          addComboOption(EI["cmCaseRule"],subrule["RULEID"],subrule["NAME"]+" ("+subrule["SYSNAME"]+")");
        }
      }

      if (graphRedactor.curoper=="edit"){
        var dd=graphRedactor.LoadedRuleNodes.length;
        var selectedNode=null;
        var selNodeID=this.nodeid;
        for (var i=0;i<dd;i++){
          var Node=graphRedactor.LoadedRuleNodes[i];
          if (Node["RULENODEID"]+""==selNodeID+""){
            selectedNode=Node;
            break;
          }
        }
        graphRedactor.selNodeID=selNodeID;
        setValue(EI["edCaseOrder"],selectedNode["ORDERNO"]);

        var NODEVALUE=selectedNode["NODEVALUE"];
        var RULEID=NODEVALUE["RULEID"];
        var VALUE=NODEVALUE["VALUE"];
        var VALUETYPE=NODEVALUE["VALUETYPE"];

        setValue(EI["edCaseResult"],VALUE);
        setComboOptionByValue(EI["cmCaseRule"],RULEID);
        graphRedactor.CaseDialog.setTitle("Редактирование узла условного выполнения правила");
      }
      if (graphRedactor.curoper=="add"){
        var parentid=graphRedactor.multiDragSet[0]["nodeid"];
        setValue(EI["edCaseOrder"],stringToNumeric(graphRedactor.getNextOrderByNo(parentid))+1);
        setComboOptionByValue(EI["cmCaseRule"],"");
        graphRedactor.CaseDialog.setTitle("Добавление узла условного выполнения правила");
      }
      graphRedactor.openedDialogType="Case";
      graphRedactor.CaseDialog.show(graphRedactor.CaseDialog);
      showElement(EI["casePanel"]);
  }
  

  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.hideCaseDialog=function(){
    lgr("graphRedactor.hideCaseDialog");
    graphRedactor.CaseDialog.hide();
    hideElement(EI["casePanel"]);
  }

  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.applyChangesCase=function(){
    lgr("graphRedactor.applyChangesCase");
    if (graphRedactor.checkCaseParams()){
        graphRedactor[graphRedactor.curoper+"Case"]();
        graphRedactor.curoper="none";
        hideElement(EI["casePanel"]);
        graphRedactor.CaseDialog.hide();  
        graphRedactor.checkRevertRibbon();
    }else{
        showAlert("Не заполнены все обязательные поля");
    }
  }
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.addCase=function(){
    lgr("graphRedactor.addCase");
    var newNode=getNewMap();
    newNode.put("DEFAULTVALUE",null);
    newNode.put("ISUSEDEFAULT", parseInt(0)); 
    newNode.put("NODETYPE","7");      
    var NODEVALUE=getNewMap();
    NODEVALUE.put("RULEID",getComboSelectedValue(EI["cmCaseRule"]));
    NODEVALUE.put("VALUE",getValue(EI["edCaseResult"]));
    NODEVALUE.put("VALUETYPE","java.lang.Double");
    newNode.put("NODEVALUE",NODEVALUE); 
    newNode.put("ORDERNO",getValue(EI["edCaseOrder"]));
    newNode.put("PARENTRULENODEID",graphRedactor.multiDragSet[0]["nodeid"]);
    newNode.put("RULEID",graphRedactor.loadedRuleData["RULEID"]);
    newNode.put("RULENODEID",Raphael.createUUID());
    newNode.put("VALUEID",null);
    lgr(newNode);
    graphRedactor.LoadedRuleNodes.add(newNode);
    var coord=graphRedactor.showAddNodeCoord;

    graphRedactor.changeList.push({"type":"addNode","begin":[],"end":newNode});

    graphRedactor.createCase(newNode,{"x":coord["x"],"y":coord["y"],"idxAnimate":0,"nodeType": "Case" });
    graphRedactor.createLink(newNode["RULENODEID"],newNode["PARENTRULENODEID"]);
    graphRedactor.refreshLinkPosition(newNode["PARENTRULENODEID"]);
    graphRedactor.refreshNode(newNode["PARENTRULENODEID"]);
  }
  ////////////// Функция создания узла типа Результат ///////////////////////////////////////////////////
  graphRedactor.createCase=function(obj,prms){
    lgr("graphRedactor.createCase");
    var incr=graphRedactor.incr;  
    var NODEVALUE=  obj["NODEVALUE"];
    var VALUE=NODEVALUE["VALUE"];
    var caseRule=graphRedactor.getSubRuleByID(NODEVALUE["RULEID"]);
    prms=nvl(prms,[]);
    prms=graphRedactor.mergeObjects(prms,{
                  "colorStart":"AA4F00",
                  "colorEnd":"602B00",
                  "title":"CASE ("+VALUE+") "+caseRule["SYSNAME"],
                  "titleStyle": graphRedactor.textStyles["common"],
                  "nodeid":obj["RULENODEID"],
                  "parentid":obj["PARENTRULENODEID"]
               });    
    var nodeSet=graphRedactor.createNode(prms);     
    return nodeSet;
  }

  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.repaintCase=function(obj,prms){
    lgr("graphRedactor.repaintCase");
    var incr=graphRedactor.incr;    
    var NODEVALUE=  obj["NODEVALUE"];
    var VALUE=NODEVALUE["VALUE"];

    var caseRule=graphRedactor.getSubRuleByID(NODEVALUE["RULEID"]);
    prms=nvl(prms,[]);
    prms=graphRedactor.mergeObjects(prms,{
                  "colorStart":"AA4F00",
                  "colorEnd":"602B00",
                  "title":"CASE ("+VALUE+") "+caseRule["SYSNAME"],
                  "titleStyle": graphRedactor.textStyles["common"],
                  "nodeid":obj["RULENODEID"],
                  "parentid":obj["PARENTRULENODEID"]
               });    
    var nodeSet=graphRedactor.repaintNode(prms,obj["RULENODEID"]);     
    return nodeSet;
  }  
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.editCase=function(prms){
    lgr("graphRedactor.editCase"); 
    prms=nvl(prms,[]);
    var newNode=getNewMap();
    newNode.put("DEFAULTVALUE",null);
    newNode.put("ISUSEDEFAULT", parseInt(0)); 
    newNode.put("NODETYPE","7");       

    var NODEVALUE=getNewMap();
    NODEVALUE.put("RULEID",getComboSelectedValue(EI["cmCaseRule"]));
    NODEVALUE.put("VALUE",getValue(EI["edCaseResult"]));
    NODEVALUE.put("VALUETYPE","java.lang.Double");
    newNode.put("NODEVALUE",NODEVALUE);

 
    newNode.put("ORDERNO",getValue(EI["edCaseOrder"]));
    newNode.put("PARENTRULENODEID",nvl(prms["PARENTRULENODEID"],graphRedactor.nodeVisual["ID"+graphRedactor.selNodeID].parentid));
    newNode.put("RULENODEID",graphRedactor.selNodeID);
    newNode.put("VALUEID",null);
    lgr(newNode);
    var dd=graphRedactor.LoadedRuleNodes.length;
    var selNodeID=graphRedactor.selNodeID;
    var begin=null;
    for (var i=0;i<dd;i++){
      var Node=graphRedactor.LoadedRuleNodes[i];
      if (Node["RULENODEID"]+""==selNodeID+""){
        begin=cloneObj(Node);
        graphRedactor.LoadedRuleNodes[i]=newNode;
        break;
      }
    }
    var end=newNode;
    graphRedactor.changeList.push({"type":"editNode","begin":begin,"end":end});
    graphRedactor.checkRevertRibbon();
    graphRedactor.refreshLinkPosition(newNode["PARENTRULENODEID"]);
    graphRedactor.refreshNode(newNode["RULENODEID"]);
    graphRedactor.refreshNode(newNode["PARENTRULENODEID"]);
  }

  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.checkCaseParams=function(){
    var checkList=[EI["edCaseOrder"],EI["cmCaseRule"],EI["edCaseResult"]];
    return checkElements(checkList);
  }
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.CaseMaxInputCount=function(nodeid){
    return 0;
  }