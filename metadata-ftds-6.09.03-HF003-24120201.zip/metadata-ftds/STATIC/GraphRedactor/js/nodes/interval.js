  graphRedactor.nodeTypes[5]="Interval";

  graphRedactor.IntervalDialog=createSimpleModal2(EI["intervalPanel"]);
  graphRedactor.IntervalDialog.on("hide",graphRedactor.hideOpenDialog,this,{stopPropagation:false});


  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.addIntervalClick=function(){
    lgr("graphRedactor.addIntervalClick");
    if (gbi("add-interval-btn").isEnabled()){
      graphRedactor.showAddNodeHintFlag=true;
      gbi(EI["addNodeHint"]).className="";
      addClass(gbi(EI["addNodeHint"]),"intervalHint");
      showElement(EI["addNodeHint"]);
      graphRedactor.showAddNodeFunction=graphRedactor.showIntervalDialog;
      graphRedactor.curoper="add";
    }
  }

  ///////////////////////////////////////////////////////////////////////////////////////////////////////
 graphRedactor.showIntervalDialog=function (opentype){
    lgr("graphRedactor.showIntervalDialog");

      if (this.nodeid){graphRedactor.curoper="edit";} ///Определяем что был выбран узел для редактирвоания

      if (graphRedactor.curoper=="edit"){
        var dd=graphRedactor.LoadedRuleNodes.length;
        var selectedNode=null;
        var selNodeID=this.nodeid;
        for (var i=0;i<dd;i++){
          var Node=graphRedactor.LoadedRuleNodes[i];
          if (Node["RULENODEID"]+""==selNodeID+""){
            selectedNode=Node;
            break;
          }
        }
        var NODEVALUE=selectedNode["NODEVALUE"];
        graphRedactor.selNodeID=selNodeID;
        setValue(EI["edIntervalOrder"],selectedNode["ORDERNO"]);
        setValue(EI["edIntervalResult"],NODEVALUE["VALUE"]);
        setValue(EI["edIntervalLow"],NODEVALUE["LOWVALUE"]);
    	  setValue(EI["edIntervalHigh"],NODEVALUE["TOPVALUE"]);
        graphRedactor.IntervalDialog.setTitle("Редактирование узла интервала");
      }
      if (graphRedactor.curoper=="add"){
        var parentid=graphRedactor.multiDragSet[0]["nodeid"];
        setValue(EI["edIntervalOrder"],stringToNumeric(graphRedactor.getNextOrderByNo(parentid))+1);
        setValue(EI["edIntervalResult"],"");
        setValue(EI["edIntervalLow"],"");
        setValue(EI["edIntervalHigh"],"");      
        graphRedactor.IntervalDialog.setTitle("Добавление узла интервала");
      }
      graphRedactor.openedDialogType="Interval";
      graphRedactor.IntervalDialog.show(graphRedactor.IntervalDialog);
      showElement(EI["intervalPanel"]);
  }
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.hideIntervalDialog=function(){
    lgr("graphRedactor.hideIntervalDialog");
    graphRedactor.IntervalDialog.hide();
    hideElement(EI["intervalPanel"]);
  }
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.applyChangesInterval=function(){
    lgr("graphRedactor.applyChangesInterval");
    if (graphRedactor.checkIntervalParams()){
        graphRedactor[graphRedactor.curoper+"Interval"]();
        graphRedactor.curoper="none";
        hideElement(EI["intervalPanel"]);
        graphRedactor.IntervalDialog.hide();  
        graphRedactor.checkRevertRibbon();
    }else{
        showAlert("Не заполнены все обязательные поля");
    }
  }

  //////////// Функция создания узла типа константа/////////////////////////////////////////////////////
  graphRedactor.createInterval=function(obj,prms){
    lgr("graphRedactor.createInterval");
    var nodeValueMap=(obj["NODEVALUE"]);
    var lowValue=nodeValueMap["LOWVALUE"];
    var topValue=nodeValueMap["TOPVALUE"];
    var value=nodeValueMap["VALUE"];


    prms=nvl(prms,[]);
    prms=graphRedactor.mergeObjects(prms,{
                  "colorStart":"#AD0096",
                  "colorEnd":"FF00DC",
                  "title":lowValue+"..."+topValue+"->"+value,
                  "titleStyle": graphRedactor.textStyles["common"],
                  "nodeid":obj["RULENODEID"],
                  "parentid":obj["PARENTRULENODEID"]
               });


    var nodeSet=graphRedactor.createNode(prms); 
    lgr(nodeSet);
    return nodeSet;
  }


  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.addInterval=function(){
    lgr("graphRedactor.addInterval");
    var newNode=getNewMap();
    newNode.put("DEFAULTVALUE",null);
    newNode.put("ISUSEDEFAULT", null); 
    newNode.put("NODETYPE","5");  
    var NODEVALUE=getNewMap();
    
    NODEVALUE.put("VALUE",getValue(EI["edIntervalResult"]));  
    NODEVALUE.put("LOWVALUE",getValue(EI["edIntervalLow"]));  
    NODEVALUE.put("TOPVALUE",getValue(EI["edIntervalHigh"]));  
     
    newNode.put("NODEVALUE",NODEVALUE);  
    newNode.put("ORDERNO",getValue(EI["edIntervalOrder"]));
    newNode.put("PARENTRULENODEID",graphRedactor.multiDragSet[0]["nodeid"]);
    newNode.put("RULEID",graphRedactor.loadedRuleData["RULEID"]);
    newNode.put("RULENODEID",Raphael.createUUID());
    newNode.put("VALUEID",null);
    lgr(newNode);
    graphRedactor.LoadedRuleNodes.add(newNode);
    var coord=graphRedactor.showAddNodeCoord;

    graphRedactor.changeList.push({"type":"addNode","begin":[],"end":newNode});

    graphRedactor.createInterval(newNode,{"x":coord["x"],"y":coord["y"],"idxAnimate":0,"nodeType": "Interval" });
    graphRedactor.createLink(newNode["RULENODEID"],newNode["PARENTRULENODEID"]);
    graphRedactor.refreshLinkPosition(newNode["PARENTRULENODEID"]);
    graphRedactor.refreshNode(newNode["PARENTRULENODEID"]);
  }

  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.repaintInterval=function(obj,prms){

    lgr("graphRedactor.repaintInterval");
    var nodeValueMap=(obj["NODEVALUE"]);
    var lowValue=nodeValueMap["LOWVALUE"];
    var topValue=nodeValueMap["TOPVALUE"];
    var value=nodeValueMap["VALUE"];


    prms=nvl(prms,[]);
    prms=graphRedactor.mergeObjects(prms,{
                  "colorStart":"#AD0096",
                  "colorEnd":"FF00DC",
                  "title":lowValue+"..."+topValue+"->"+value,
                  "titleStyle": graphRedactor.textStyles["common"],
                  "nodeid":obj["RULENODEID"],
                  "parentid":obj["PARENTRULENODEID"]
               });

    var nodeSet=graphRedactor.repaintNode(prms,obj["RULENODEID"]);     
    return nodeSet;
  }  
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.editInterval=function(prms){
    lgr("graphRedactor.editInterval"); 
    prms=nvl(prms,[]);
    var newNode=getNewMap();
    newNode.put("DEFAULTVALUE",null);
    newNode.put("ISUSEDEFAULT", null); 
    newNode.put("NODETYPE","5");  
    var NODEVALUE=getNewMap();
    NODEVALUE.put("VALUE",getValue(EI["edIntervalResult"]));  
    NODEVALUE.put("LOWVALUE",getValue(EI["edIntervalLow"]));  
    NODEVALUE.put("TOPVALUE",getValue(EI["edIntervalHigh"]));  
      
    newNode.put("NODEVALUE",NODEVALUE);  
    newNode.put("ORDERNO",getValue(EI["edIntervalOrder"]));
    newNode.put("PARENTRULENODEID",nvl(prms["PARENTRULENODEID"],graphRedactor.nodeVisual["ID"+graphRedactor.selNodeID].parentid));
    newNode.put("RULEID",graphRedactor.loadedRuleData["RULEID"]);
    newNode.put("RULENODEID",graphRedactor.selNodeID);
    newNode.put("VALUEID",null);
    lgr(newNode);

    var dd=graphRedactor.LoadedRuleNodes.length;
    var selNodeID=graphRedactor.selNodeID;
    var begin=null;
    for (var i=0;i<dd;i++){
      var Node=graphRedactor.LoadedRuleNodes[i];
      if (Node["RULENODEID"]+""==selNodeID+""){
        begin=cloneObj(Node);
        graphRedactor.LoadedRuleNodes[i]=newNode;
        break;
      }
    }

    var end=newNode;
    graphRedactor.changeList.push({"type":"editNode","begin":begin,"end":end});
    graphRedactor.checkRevertRibbon();
    graphRedactor.refreshLinkPosition(newNode["PARENTRULENODEID"]);
    graphRedactor.refreshNode(newNode["RULENODEID"]);
    graphRedactor.refreshNode(newNode["PARENTRULENODEID"]);
  }

  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.checkIntervalParams=function(){
    var checkList=[EI["edIntervalOrder"],EI["edIntervalLow"],EI["edIntervalHigh"],EI["edIntervalResult"]];
    return checkElements(checkList);
  }
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.IntervalMaxInputCount=function(nodeid){
    return 0;
  }