  graphRedactor.nodeTypes[0]="Operation";

  graphRedactor.OperationDialog=createSimpleModal2(EI["operationPanel"]);
  graphRedactor.OperationDialog.on("hide",graphRedactor.hideOpenDialog,this,{stopPropagation:false});


  graphRedactor.operationTypes=[{"type":"CALC","name":"Арифметическая операция"},
                                {"type":"GRP","name":"Групповая операция"},
                                {"type":"INT","name":"Проверка попадания в заданный интервал"},
                                {"type":"CHK","name":"Условная операция"},
                                {"type":"CASE","name":"Операция ветвления"},
								{"type":"WHEN","name":"Список условий"}];

  graphRedactor.operationList=getInputParams("operationList");      // Список операций 


  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.showOperationDialog=function (opentype){
    lgr("graphRedactor.showOperationDialog");
    if (this.nodeid){graphRedactor.curoper="edit";} ///Определяем что был выбран узел для редактирвоания

	getNodeMap = function(id){
	  var dd=graphRedactor.LoadedRuleNodes.length;
      var selectedNode=null;
      for (var i=0;i<dd;i++){
        var Node=graphRedactor.LoadedRuleNodes[i];
        if (Node["RULENODEID"]+""==id+""){
          selectedNode=Node;
          break;
        }
      }
	  return selectedNode;
	}

    if (graphRedactor.curoper=="edit"){
      var selNodeID=this.nodeid;
	  var selectedNode=getNodeMap(selNodeID);

      graphRedactor.selNodeID=selNodeID;
      setValue(EI["edOperationOrder"],selectedNode["ORDERNO"]);
      lgr("selectedNode[ValueID]="+selectedNode["VALUEID"]);
      var selOperation=graphRedactor.getOperation(selectedNode["VALUEID"]);
      setComboOptionByValue(EI["cmOperationType"],selOperation["GROUPSYSNAME"]);
      if (is7) {graphRedactor.setOperationByGroupSysName();}
      if (selOperation["GROUPSYSNAME"]=="INT" || selOperation["GROUPSYSNAME"]=="WHEN"){
	     lgr(selectedNode);
        setValue(EI["edDefaultValue"],selectedNode["DEFAULTVALUE"]);
		setValue(EI["cmType"],selectedNode["NODEVALUE"]["VALUETYPE"]);
      }
	  
      setComboOptionByValue(EI["cmOperation"],selectedNode["VALUEID"]+"");
      if (selOperation["SYSNAME"]=="DIVISION"){
        setValue(EI["edOverflowValue"],selectedNode["DEFAULTVALUE"]);
      }
      graphRedactor.OperationDialog.setTitle("Редактирование узла операции");
    }
    if (graphRedactor.curoper=="add"){
      var parentid=graphRedactor.multiDragSet[0]["nodeid"];
	  setValue(EI["edOperationOrder"],stringToNumeric(graphRedactor.getNextOrderByNo(parentid))+1);
	  var selectedNode=getNodeMap(parentid);
	  var selOperation=graphRedactor.getOperation(selectedNode["VALUEID"]);
	  if (selOperation["SYSNAME"]=="WHEN"){
		setComboOptionByValue(EI["cmOperationType"], "CHK");
		disableElement(EI["cmOperationType"]);
      }
	  else{
   	    enableElement(EI["cmOperationType"]);
        setComboOptionByValue(EI["cmOperationType"],"");
	  }
      setValue(EI["edDefaultValue"],"");
	  setValue(EI["cmType"],"");
      setValue(EI["edOverflowValue"],"");
      graphRedactor.OperationDialog.setTitle("Добавление узла операции");
    }
    graphRedactor.openedDialogType="Operation";
    graphRedactor.OperationDialog.show(graphRedactor.OperationDialog);
    showElement(EI["operationPanel"]);
  }
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.hideOperationDialog=function(){
    lgr("graphRedactor.hideOperationDialog");
    graphRedactor.OperationDialog.hide();
    hideElement(EI["operationPanel"]);
  }
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.setOperation=function(){
    var oper = graphRedactor.getOperation(getComboSelectedValue(EI["cmOperation"]));
    if (oper["SYSNAME"] == "DIVISION") {
      showElement(EI["lbOverflowValue"]);
      showElement(EI["edOverflowValue"]);
    } else { 
      hideElement(EI["lbOverflowValue"]);
      hideElement(EI["edOverflowValue"]);
    }
  }
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.setOperationByGroupSysName=function(){
    lgr("graphRedactor.setOperationByGroupSysName");
    clearComboOptions(EI["cmOperation"]);
    var groupSysName=getComboSelectedValue(EI["cmOperationType"]);
    lgr(groupSysName);


    if (groupSysName == "INT" || groupSysName == "WHEN") {
      hideElement(EI["pnlOperation"]); 
      showElement(EI["pnlInterval"]); 
      //setValue("CRDPolicyRuleOper.MainPanel.pnlInterval.edDefaultValue", getInputParam("DEFAULTVALUE"));  
	  if(groupSysName == "WHEN") setRequired(EI["edDefaultValue"], true);
    } else if (groupSysName == "CASE") {
      hideElement(EI["pnlOperation"]); 
      //setRequired("CRDPolicyRuleOper.MainPanel.pnlOperation.cmOperation", false);
      hideElement(EI["pnlInterval"]); 
      setValue(EI["edDefaultValue"], "");     
    } else {
      hideElement(EI["pnlInterval"]);   
      showElement(EI["pnlOperation"]);  
    }

    var dd=graphRedactor.operationList.length;
    if (is7==false){
      addComboOption(EI["cmOperation"],"","");
    }
    var addCount=0;
    lgr(graphRedactor.operationList);
    for (var i=0;i<dd;i++){
      var operation=graphRedactor.operationList[i];
      if (operation["GROUPSYSNAME"]==groupSysName){
        addComboOption(EI["cmOperation"],operation["OPERATIONID"],nvl(operation["NAME"],operation["SYSNAME"]));
        addCount++;
      }
    }
    if (addCount==1){
      setComboOptionByIndex(EI["cmOperation"],(is7 ? 0 : 1));
    }else{
      setComboOptionByValue(EI["cmOperation"],"");
    }
  }
  //////////////////////////////////////////////////////////////////////////////////
  graphRedactor.getOperationTypeByID=function(typeid){
    var dd=graphRedactor.operationList.length;
    for (var i=0;i<dd;i++){
      var operation=graphRedactor.operationList[i];
      if (operation["OPERATIONID"]==typeid){
        return operation;
      }
    }    
    return [];
  }
  //////////// Функция получения типа операции по ИД /////////////////////////////////////////////////////
  graphRedactor.getOperation=function(typeid){
    lgr("graphRedactor.getOperation");
    var dd=graphRedactor.operationList.length;
    var refOperType=getNewMap();
    refOperType["SUM"]="SUM";
    refOperType["SUBTRACT"]="SUB";
    refOperType["MULTIPLICATION"]="MUL";
    refOperType["DIVISION"]="DIV";
    refOperType["INVOLUTION"]="POW";
    refOperType["MIN"]="MIN";
    refOperType["MAX"]="MAX";
    refOperType["INT"]="INT";
    refOperType["LARGER"]=">";
    refOperType["LARGEROREQUAL"]=">=";
    refOperType["EQUAL"]="==";
    refOperType["SMALLER"]="<";
    refOperType["SMALLEROREQUAL"]="<=";
    refOperType["NOTEQUAL"]="!=";
    refOperType["IN"]="IN";
    refOperType["CASE"]="CASE";
    refOperType["CONCAT"]="CNCT";
	refOperType["WHEN"]="WHEN";


    for (var i=0;i<dd;i++){
      var operation=graphRedactor.operationList[i];
      if (operation["OPERATIONID"]+""==typeid+""){
        operation["REFTYPE"]=refOperType[operation["SYSNAME"]];
        return operation;
      }
    }
    return [];
  }
  ////////////// Функция создания узла типа операция ///////////////////////////////////////////////////
  graphRedactor.createOperation=function(obj,prms){
    lgr("graphRedactor.createOperation");
    var incr=graphRedactor.incr;
    var selOperation=graphRedactor.getOperation(obj["VALUEID"]);
    var nodeValue=selOperation["REFTYPE"];
    var inputNodeList=graphRedactor.getNodesByParentID(obj["RULENODEID"]);

    var inputNodeHeight= inputNodeList.length % 2 == 0 ? inputNodeList.length+2 : inputNodeList.length+1;
    var rectHeight=nmlz(inputNodeHeight*incr);
    rectHeight = rectHeight<2*incr ? 2*incr : rectHeight;

    prms=nvl(prms,[]);
    prms=graphRedactor.mergeObjects(prms,{
                  "colorStart":"#000090",
                  "colorEnd":"0000ff",
                  "title":nodeValue,
                  "titleStyle": graphRedactor.textStyles["common"],
                  "nodeid":obj["RULENODEID"],
                  "parentid":obj["PARENTRULENODEID"],
                  "rectHeight":rectHeight,
                  "minWidth": 4*incr
               });
    var nodeSet=graphRedactor.createNode(prms); 
    return nodeSet;
  }
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.repaintOperation=function(obj,prms){
    lgr("graphRedactor.repaintOperation");
    var incr=graphRedactor.incr;
    var selOperation=graphRedactor.getOperation(obj["VALUEID"]);
    var nodeValue=selOperation["REFTYPE"];
    var inputNodeList=graphRedactor.getNodesByParentID(obj["RULENODEID"]);

    var inputNodeHeight= inputNodeList.length % 2 == 0 ? inputNodeList.length+2 : inputNodeList.length+1;
    var rectHeight=nmlz(inputNodeHeight*incr);
    rectHeight = rectHeight<2*incr ? 2*incr : rectHeight;

    prms=nvl(prms,[]);
    prms=graphRedactor.mergeObjects(prms,{
                  "colorStart":"#000090",
                  "colorEnd":"0000ff",
                  "title":nodeValue,
                  "titleStyle": graphRedactor.textStyles["common"],
                  "nodeid":obj["RULENODEID"],
                  "parentid":obj["PARENTRULENODEID"],
                  "rectHeight":rectHeight,
                  "minWidth": 4*incr
               });
    var nodeSet=graphRedactor.repaintNode(prms,obj["RULENODEID"]); 
    return nodeSet;
  }  



  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.addOperationClick=function(){
    lgr("graphRedactor.addOperationClick");
    if (gbi("add-operation-btn").isEnabled()){
      graphRedactor.showAddNodeHintFlag=true;
      gbi(EI["addNodeHint"]).className="";
      addClass(gbi(EI["addNodeHint"]),"operationHint");
      showElement(EI["addNodeHint"]);
      graphRedactor.showAddNodeFunction=graphRedactor.showOperationDialog;
      graphRedactor.curoper="add";
    }
  }
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.applyChangesOperation=function(){
    lgr("graphRedactor.applyChangesOperation");
    if (graphRedactor.checkOperationParams()){
        graphRedactor[graphRedactor.curoper+"Operation"]();
        graphRedactor.curoper="none";
        hideElement(EI["operationPanel"]);
        graphRedactor.OperationDialog.hide();  
        graphRedactor.checkRevertRibbon();
    }else{
        showAlert("Не заполнены все обязательные поля");
    }
  }

  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.addOperation=function(){
    var newNode=getNewMap();
    newNode.put("DEFAULTVALUE", "");
    newNode.put("ISUSEDEFAULT","0"); //not user for operation
    newNode.put("NODETYPE","0");       // type operation
    newNode.put("NODEVALUE",getNewMap());  
    newNode.put("OPERATIONGROUPSYSNAME",getComboSelectedValue(EI["cmOperationType"]));
    newNode.put("ORDERNO",getValue(EI["edOperationOrder"]));
    newNode.put("PARENTRULENODEID",graphRedactor.multiDragSet[0]["nodeid"]);
    newNode.put("RULEID",graphRedactor.loadedRuleData["RULEID"]);
    newNode.put("RULENODEID",Raphael.createUUID());
    newNode.put("VALUEID",getComboSelectedValue(EI["cmOperation"]));
    lgr(newNode);
    graphRedactor.LoadedRuleNodes.add(newNode);
    var coord=graphRedactor.showAddNodeCoord;
    

    graphRedactor.changeList.push({"type":"addNode","begin":[],"end":newNode});

    graphRedactor.createOperation(newNode,{"x":coord["x"],"y":coord["y"],"idxAnimate":0,"nodeType": "Operation" });
    graphRedactor.createLink(newNode["RULENODEID"],newNode["PARENTRULENODEID"]);
    graphRedactor.refreshLinkPosition(newNode["PARENTRULENODEID"]);
    graphRedactor.refreshNode(newNode["PARENTRULENODEID"]);
  }
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.editOperation=function(prms){
    lgr("graphRedactor.editOperation"); 
    prms=nvl(prms,[]);
    var newNode=getNewMap();
    var selOperation=graphRedactor.getOperation(getComboSelectedValue["cmOperation"]);
    var DEFAULTVALUE="";
    if (selOperation["SYSNAME"]=="DIVISION"){
      DEFAULTVALUE=getValue(EI["edOverflowValue"]);
    }
    if (getComboSelectedValue(EI["cmOperationType"])=="INT" || getComboSelectedValue(EI["cmOperationType"])=="WHEN"){
      DEFAULTVALUE=getValue(EI["edDefaultValue"]);
    }
    newNode.put("DEFAULTVALUE",DEFAULTVALUE);
    newNode.put("ISUSEDEFAULT","0"); //not user for operation
    newNode.put("NODETYPE","0");       // type operation
    newNode.put("NODEVALUE",getNewMap());  
    newNode.put("OPERATIONGROUPSYSNAME",getComboSelectedValue(EI["cmOperationType"]));
    newNode.put("ORDERNO",getValue(EI["edOperationOrder"]));
    newNode.put("PARENTRULENODEID",nvl(prms["PARENTRULENODEID"],graphRedactor.nodeVisual["ID"+graphRedactor.selNodeID].parentid));
    newNode.put("RULENODEID",graphRedactor.selNodeID);
    newNode.put("VALUEID",getComboSelectedValue(EI["cmOperation"]));
    lgr(newNode);
    
    var dd=graphRedactor.LoadedRuleNodes.length;
    var selNodeID=graphRedactor.selNodeID;
    var begin=null;
    for (var i=0;i<dd;i++){
      var Node=graphRedactor.LoadedRuleNodes[i];
      if (Node["RULENODEID"]+""==selNodeID+""){
        begin=cloneObj(Node);
        graphRedactor.LoadedRuleNodes[i]=newNode;
        break;
      }
    }
    var end=newNode;

    graphRedactor.changeList.push({"type":"editNode","begin":begin,"end":end});
    graphRedactor.checkRevertRibbon();
    graphRedactor.refreshLinkPosition(newNode["PARENTRULENODEID"]);
    graphRedactor.refreshNode(newNode["RULENODEID"]);
    graphRedactor.refreshNode(newNode["PARENTRULENODEID"]);
  }

  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.checkOperationParams=function(){
    var checkList=[EI["edOperationOrder"],EI["cmOperationType"]];
    var selOperationType=getComboSelectedValue(EI["cmOperationType"]);
    if (selOperationType!="INT"){checkList.push(EI["cmOperation"]);}
    var selOperation=graphRedactor.getOperation(getComboSelectedValue(EI["cmOperation"]))["SYSNAME"];
    lgr(selOperation)
    if (selOperation=="DIVISION"){
      checkList.push(EI["edOverflowValue"]);
    }
    if (selOperation=="INT" || selOperation=="WHEN"){
         checkList.push(EI["edDefaultValue"]);
    }
    return checkElements(checkList);  
  }
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.OperationMaxInputCount=function(nodeid){
    lgr("graphRedactor.OperationMaxInputCount");
    lgr(nodeid);
    var dd=graphRedactor.LoadedRuleNodes.length;
    var ruleNode=[];
    for (var i=0;i<dd;i++){
      var ruleNode=graphRedactor.LoadedRuleNodes[i];
      if (ruleNode["RULENODEID"]==nodeid){
        break;
      }
    }

    var UNLIMITE=999;

    var refInputCount=getNewMap();
    refInputCount["SUM"]=UNLIMITE;
    refInputCount["SUBTRACT"]=2;
    refInputCount["MULTIPLICATION"]=UNLIMITE;
    refInputCount["DIVISION"]=2;
    refInputCount["INVOLUTION"]=2;
    refInputCount["MIN"]=UNLIMITE;
    refInputCount["MAX"]=UNLIMITE;
    refInputCount["INT"]=UNLIMITE;
    refInputCount["LARGER"]=4;
    refInputCount["LARGEROREQUAL"]=4;
    refInputCount["EQUAL"]=4;
    refInputCount["SMALLER"]=4;
    refInputCount["SMALLEROREQUAL"]=4;
    refInputCount["NOTEQUAL"]=4;
    refInputCount["IN"]=4;
    refInputCount["CASE"]=UNLIMITE;
    refInputCount["CONCAT"]=UNLIMITE;
	refInputCount["WHEN"]=UNLIMITE;



    return nvl(refInputCount[graphRedactor.getOperation(ruleNode["VALUEID"])["SYSNAME"]],0);
  }