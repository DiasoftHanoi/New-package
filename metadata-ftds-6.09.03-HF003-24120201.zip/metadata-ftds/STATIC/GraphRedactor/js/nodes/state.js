graphRedactor.nodeTypes[99] = "State";
  
/*
 * Функция создания узла типа Состояние
 */
graphRedactor.createState = function(prms) {
    lgr("graphRedactor.createState");
    var incr = graphRedactor.incr;

    prms = nvl(prms, []);
    prms = graphRedactor.mergeObjects(prms, {
      "colorStart": "#900000",
      "colorEnd": "ff0000",
      "title": "STATE",
      "titleStyle": graphRedactor.textStyles["common"],
      "nodeid": "0",
      "parentid": "-1",
      "rectHeight": 30,
      "minWidth": 6 * incr
    });
    var nodeSet = graphRedactor.createNode(prms);
    return nodeSet;
}

graphRedactor.repaintState = function(prms) {
    lgr("graphRedactor.repaintState");
    var incr = graphRedactor.incr;

    prms = nvl(prms, []);
    prms = graphRedactor.mergeObjects(prms, {
      "colorStart": "#900000",
      "colorEnd": "ff0000",
      "title": "STATE",
      "titleStyle": graphRedactor.textStyles["common"],
      "nodeid": "0",
      "parentid": "-1",
      "rectHeight": 30,
      "minWidth": 6 * incr
    });
    var nodeSet = graphRedactor.repaintNode(prms);
    return nodeSet;
}

graphRedactor.ResultMaxInputCount = function(nodeid) {
    return 1;
}