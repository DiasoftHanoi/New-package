  graphRedactor.nodeTypes[4]="Collection";

  graphRedactor.CollectionDialog=createSimpleModal2(EI["collectionPanel"]);
  graphRedactor.CollectionDialog.on("hide",graphRedactor.hideOpenDialog,this,{stopPropagation:false});
  
  graphRedactor.CollectionAction=null;

  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.addCollectionClick=function(){
    lgr("graphRedactor.addCollectionClick");
    if (gbi("add-collection-btn").isEnabled()){
      graphRedactor.showAddNodeHintFlag=true;
      gbi(EI["addNodeHint"]).className="";
      addClass(gbi(EI["addNodeHint"]),"collectionHint");
      showElement(EI["addNodeHint"]);
      graphRedactor.showAddNodeFunction=graphRedactor.showCollectionDialog;
      graphRedactor.curoper="add";
    }
  }

  ///////////////////////////////////////////////////////////////////////////////////////////////////////
 graphRedactor.showCollectionDialog=function (opentype){
    lgr("graphRedactor.showCollectionDialog");

      if (this.nodeid){graphRedactor.curoper="edit";} ///Определяем что был выбран узел для редактирвоания

      if (graphRedactor.curoper=="edit"){
        var dd=graphRedactor.LoadedRuleNodes.length;
        var selectedNode=null;
        var selNodeID=this.nodeid;
        for (var i=0;i<dd;i++){
          var Node=graphRedactor.LoadedRuleNodes[i];
          if (Node["RULENODEID"]+""==selNodeID+""){
            selectedNode=Node;
            break;
          }
        }

        var NODEVALUE=selectedNode["NODEVALUE"];
        graphRedactor.selNodeID=selNodeID;
        setValue(EI["edCollectionOrder"],selectedNode["ORDERNO"]);
        setComboOptionByValue(EI["cmCollectionType"],NODEVALUE["VALUETYPE"]);
    	  var VALUE=nvl(NODEVALUE["VALUE"],[]);
        var dd2=VALUE.length;
        lgr("ended2323it")      
        clearTable(EI["tbCollection"]);
        for (var i=0;i<dd2;i++){
          addRow(EI["tbCollection"],{"VALUE":VALUE[i]});
        }
        graphRedactor.CollectionDialog.setTitle("Редактирование узла коллекции");

      }
      if (graphRedactor.curoper=="add"){
        var parentid=graphRedactor.multiDragSet[0]["nodeid"];
        setValue(EI["edCollectionOrder"],stringToNumeric(graphRedactor.getNextOrderByNo(parentid))+1);
        setComboOptionByValue(EI["cmCollectionType"],"");
    	  clearTable(EI["tbCollection"]);  
        graphRedactor.CollectionDialog.setTitle("Добавление узла коллекции");
      }

      graphRedactor.openedDialogType="Collection";

      graphRedactor.CollectionDialog.show(graphRedactor.CollectionDialog);
      showElement(EI["collectionPanel"]);
  }
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.hideCollectionDialog=function(){
    lgr("graphRedactor.hideCollectionDialog");
    graphRedactor.CollectionDialog.hide();
    hideElement(EI["collectionPanel"])
  }
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.applyChangesCollection=function(){
    lgr("graphRedactor.applyChangesCollection");
    if (graphRedactor.checkCollectionParams()){
        graphRedactor[graphRedactor.curoper+"Collection"]();
        graphRedactor.curoper="none";
        hideElement(EI["collectionPanel"]);
        graphRedactor.CollectionDialog.hide();  
        graphRedactor.checkRevertRibbon();
    }else{
        showAlert("Не заполнены все обязательные поля");
    }
  }
  /////////////////////////////////////////////////////////////////
  graphRedactor.createCollection=function(obj,prms){
    lgr("graphRedactor.createCollection");
    var incr=graphRedactor.incr;
    prms=nvl(prms,[]);
    prms=graphRedactor.mergeObjects(prms,{
                  "colorStart":"#5219FF",
                  "colorEnd":"7D4FFF",
                  "title":"COLLECTION",
                  "titleStyle": graphRedactor.textStyles["common"],
                  "nodeid":obj["RULENODEID"],
                  "parentid":obj["PARENTRULENODEID"]
               });
    var nodeSet=graphRedactor.createNode(prms); 
    return nodeSet;
  }
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.addCollection=function(){
    lgr("graphRedactor.addCollection");
    var newNode=getNewMap();
    newNode.put("DEFAULTVALUE",null);
    newNode.put("ISUSEDEFAULT", null); 
    newNode.put("NODETYPE","4");  
    var NODEVALUE=getNewMap();
    

    var VALUE=getNewList();
    var dd=getRowsCount(EI["tbCollection"]);
    for (var i=0;i<dd;i++){
      VALUE.add(getCellText(EI["tbCollection"],i,"VALUE"));
    }
    NODEVALUE.put("VALUE",VALUE);  
    NODEVALUE.put("VALUETYPE",getComboSelectedValue(EI["cmCollectionType"]));  
      
    newNode.put("NODEVALUE",NODEVALUE);  
    newNode.put("ORDERNO",getValue(EI["edCollectionOrder"]));
    newNode.put("PARENTRULENODEID",graphRedactor.multiDragSet[0]["nodeid"]);
    newNode.put("RULEID",graphRedactor.loadedRuleData["RULEID"]);
    newNode.put("RULENODEID",Raphael.createUUID());
    newNode.put("VALUEID",null);
    lgr(newNode);
    graphRedactor.LoadedRuleNodes.add(newNode);
    var coord=graphRedactor.showAddNodeCoord;

    graphRedactor.changeList.push({"type":"addNode","begin":[],"end":newNode});

    graphRedactor.createCollection(newNode,{"x":coord["x"],"y":coord["y"],"idxAnimate":0,"nodeType": "Collection" });
    graphRedactor.createLink(newNode["RULENODEID"],newNode["PARENTRULENODEID"]);
    graphRedactor.refreshLinkPosition(newNode["PARENTRULENODEID"]);
    graphRedactor.refreshNode(newNode["PARENTRULENODEID"]);
  }

  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.repaintCollection=function(obj,prms){
    lgr("graphRedactor.repaintCollection");
    var incr=graphRedactor.incr;
    prms=nvl(prms,[]);
    prms=graphRedactor.mergeObjects(prms,{
                  "colorStart":"#5219FF",
                  "colorEnd":"7D4FFF",
                  "title":"COLLECTION",
                  "titleStyle": graphRedactor.textStyles["common"],
                  "nodeid":obj["RULENODEID"],
                  "parentid":obj["PARENTRULENODEID"]
               });
    var nodeSet=graphRedactor.repaintNode(prms,prms["nodeid"]); 
    return nodeSet;
  }

  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.editCollection=function(prms){
    lgr("graphRedactor.editCollection"); 
    prms=nvl(prms,[]);
    var newNode=getNewMap();
    newNode.put("DEFAULTVALUE",null);
    newNode.put("ISUSEDEFAULT", null); 
    newNode.put("NODETYPE","4");  
    var NODEVALUE=getNewMap();

    NODEVALUE.put("VALUETYPE",getComboSelectedValue(EI["cmCollectionType"]));  

    var VALUE=getNewList();
    var dd=getRowsCount(EI["tbCollection"]);
    for (var i=0;i<dd;i++){
      VALUE.add(getCellText(EI["tbCollection"],i,"VALUE"));
    }
    NODEVALUE.put("VALUE",VALUE);  

    newNode.put("NODEVALUE",NODEVALUE);  
    newNode.put("ORDERNO",getValue(EI["edCollectionOrder"]));
    newNode.put("PARENTRULENODEID",nvl(prms["PARENTRULENODEID"],graphRedactor.nodeVisual["ID"+graphRedactor.selNodeID].parentid));
    newNode.put("RULEID",graphRedactor.loadedRuleData["RULEID"]);
    newNode.put("RULENODEID",graphRedactor.selNodeID);
    newNode.put("VALUEID",null);
    lgr(newNode);

    var dd=graphRedactor.LoadedRuleNodes.length;
    var selNodeID=graphRedactor.selNodeID;
    var begin=null;
    for (var i=0;i<dd;i++){
      var Node=graphRedactor.LoadedRuleNodes[i];
      if (Node["RULENODEID"]+""==selNodeID+""){
        begin=cloneObj(Node);
        graphRedactor.LoadedRuleNodes[i]=newNode;
        break;
      }
    }

    var end=newNode;
    graphRedactor.changeList.push({"type":"editNode","begin":begin,"end":end});
    graphRedactor.checkRevertRibbon();
    graphRedactor.refreshLinkPosition(newNode["PARENTRULENODEID"]);
    graphRedactor.refreshNode(newNode["RULENODEID"]);
    graphRedactor.refreshNode(newNode["PARENTRULENODEID"]);
  }

  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.addCollectionValueDialogShow=function(type){
    lgr("graphRedactor.addCollectionValueDialogShow");
    if (type=="EDIT"){
      var row = getSelectedRow(EI["tbCollection"]);
      if (row != null) {
        setValue(EI["edCollectionValue"], row.get("VALUE"));
        //hideElement(EI["tbCollection"]);
        showElement(EI["collectionValuePnl"]);
        hideElement(EI["lbAddCollection"]);
        hideElement(EI["lbEditCollection"]);
        hideElement(EI["lbDelCollection"]);
        hideElement(EI["imgAddCollection"]);
        hideElement(EI["imgEditCollection"]);
        hideElement(EI["imgDelCollection"]);
        graphRedactor.CollectionAction=type;
      } else{
        alert("Выберите параметр из таблицы");  
      }
    }else
    if (type=="ADD"){
      setValue(EI["edCollectionValue"], "");
      //hideElement(EI["tbCollection"]);
      showElement(EI["collectionValuePnl"]);
      hideElement(EI["lbAddCollection"]);
      hideElement(EI["lbEditCollection"]);
      hideElement(EI["lbDelCollection"]);
      hideElement(EI["imgAddCollection"]);
      hideElement(EI["imgEditCollection"]);
      hideElement(EI["imgDelCollection"]);
      graphRedactor.CollectionAction=type;
    }
  }

  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.applyChangeCollectionValue=function(){ 
    lgr("graphRedactor.applyChangeCollectionValue");
    var value = getValue(EI["edCollectionValue"]);
    if (value != "" && value != null) {
      if (graphRedactor.CollectionAction == "ADD") {
        addRow(EI["tbCollection"], {"VALUE":value});
        try {setSelectedRow(EI["tbCollection"], getRowsCount(EI["tbCollection"])-1);}catch(e){}
        graphRedactor.CollectionAction=null;
        hideElement(EI["collectionValuePnl"]);  
        showElement(EI["tbCollection"]);
        showElement(EI["lbAddCollection"]);
        showElement(EI["lbEditCollection"]);
        showElement(EI["lbDelCollection"]);
        showElement(EI["imgAddCollection"]);
        showElement(EI["imgEditCollection"]);
        showElement(EI["imgDelCollection"]);
      } else if (graphRedactor.CollectionAction == "EDIT") {
        var row=getSelectedRow(EI["tbCollection"]);
        updateSelectedRow(EI["tbCollection"], {"VALUE":value});
      }
        hideElement(EI["collectionValuePnl"]);  
        showElement(EI["tbCollection"]); 
        showElement(EI["lbAddCollection"]);
        showElement(EI["lbEditCollection"]);
        showElement(EI["lbDelCollection"]);
        showElement(EI["imgAddCollection"]);
        showElement(EI["imgEditCollection"]);
        showElement(EI["imgDelCollection"]);
    }else{
      showAlert("Введите значение");
    }
  }

  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.deleteCollectionValue=function(){ 
    var row = getSelectedRow(EI["tbCollection"]);
    if (row != null) {
      deleteSelectedRow(EI["tbCollection"], true);
    }else{
      alert("Выберите параметр из таблицы"); 
    }
  }
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.addCollectionValueDialogHide=function(){
      setValue(EI["edCollectionValue"], "");
      showElement(EI["tbCollection"]);
      hideElement(EI["collectionValuePnl"]);
      showElement(EI["lbAddCollection"]);
      showElement(EI["lbEditCollection"]);
      showElement(EI["lbDelCollection"]);
      showElement(EI["imgAddCollection"]);
      showElement(EI["imgEditCollection"]);
      showElement(EI["imgDelCollection"]);
      graphRedactor.CollectionAction=null;    
  }
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.checkCollectionParams=function(){
    var checkList=[EI["edCollectionOrder"],EI["cmCollectionType"],EI["tbCollection"]];
    return checkElements(checkList);
  }
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.CollectionMaxInputCount=function(nodeid){
    return 0;
  }