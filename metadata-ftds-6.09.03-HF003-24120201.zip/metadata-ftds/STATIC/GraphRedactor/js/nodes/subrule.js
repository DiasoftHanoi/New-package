  graphRedactor.nodeTypes[2]="Rule";

  graphRedactor.RuleDialog=createSimpleModal2(EI["subRulePanel"]);
  graphRedactor.RuleDialog.on("hide",graphRedactor.hideOpenDialog,this,{stopPropagation:false});


  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.addRuleClick=function(){
    lgr("graphRedactor.addRuleClick");
    if (gbi("add-subrule-btn").isEnabled()){
      graphRedactor.showAddNodeHintFlag=true;
      gbi(EI["addNodeHint"]).className="";
      addClass(gbi(EI["addNodeHint"]),"ruleHint");
      showElement(EI["addNodeHint"]);
      graphRedactor.showAddNodeFunction=graphRedactor.showRuleDialog;
      graphRedactor.curoper="add";
    }
  }

  ///////////////////////////////////////////////////////////////////////////////////////////////////////
 graphRedactor.showRuleDialog=function (opentype){
    lgr("graphRedactor.showRuleDialog");

      if (this.nodeid){graphRedactor.curoper="edit";} ///Определяем что был выбран узел для редактирвоания

      clearComboOptions(EI["cmRule"]);
      if (is7==false){
        addComboOption(EI["cmRule"],"","");
      }
      var dd=graphRedactor.loadedSubRules.length;
      for (var i=0;i<dd;i++){
        var subrule=graphRedactor.loadedSubRules[i];
        if (subrule["RULEID"]!=graphRedactor.loadedRuleData["RULEID"]){
          addComboOption(EI["cmRule"],subrule["RULEID"],subrule["NAME"]+" ("+subrule["SYSNAME"]+")");
        }
      }

      if (graphRedactor.curoper=="edit"){
        var dd=graphRedactor.LoadedRuleNodes.length;
        var selectedNode=null;
        var selNodeID=this.nodeid;
        for (var i=0;i<dd;i++){
          var Node=graphRedactor.LoadedRuleNodes[i];
          if (Node["RULENODEID"]+""==selNodeID+""){
            selectedNode=Node;
            break;
          }
        }
        graphRedactor.selNodeID=selNodeID;
        setValue(EI["edSubRuleOrder"],selectedNode["ORDERNO"]);
        setComboOptionByValue(EI["cmRule"],selectedNode["VALUEID"]);
        graphRedactor.RuleDialog.setTitle("Редактирование узла вызова правила");
      }
      if (graphRedactor.curoper=="add"){
        var parentid=graphRedactor.multiDragSet[0]["nodeid"];
        setValue(EI["edSubRuleOrder"],stringToNumeric(graphRedactor.getNextOrderByNo(parentid))+1);
        setComboOptionByValue(EI["cmRule"],"");
        graphRedactor.RuleDialog.setTitle("Добавление узла вызова правила");
      }
      graphRedactor.openedDialogType="Rule";
      graphRedactor.RuleDialog.show(graphRedactor.RuleDialog);
      showElement(EI["subRulePanel"]);
  }


  /////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.getSubRuleByID=function(id){
    lgr("graphRedactor.getSubRuleByID");
    var dd=graphRedactor.loadedSubRules.length;
    for (var i=0;i<dd;i++){
      var subRule=graphRedactor.loadedSubRules[i];
      if (id+""==subRule["RULEID"]+""){
        return subRule;
      }
    }
    return [];
  }

  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.hideRuleDialog=function(){
    lgr("graphRedactor.hideRuleDialog");
    graphRedactor.RuleDialog.hide();
    hideElement(EI["subRulePanel"]);
  }

  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.applyChangesRule=function(){
    lgr("graphRedactor.applyChangesRule");
    if (graphRedactor.checkRuleParams()==true){
        lgr("entered");
        graphRedactor[graphRedactor.curoper+"Rule"]();
        graphRedactor.curoper="none";
        hideElement(EI["subRulePanel"]);
        graphRedactor.RuleDialog.hide();  
        graphRedactor.checkRevertRibbon();
    }else{
        showAlert("Не заполнены все обязательные поля");
    }
  }
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.addRule=function(){
    lgr("graphRedactor.addRule");
    var newNode=getNewMap();
    newNode.put("DEFAULTVALUE",null);
    newNode.put("ISUSEDEFAULT", null); 
    newNode.put("NODETYPE","2");      
    newNode.put("NODEVALUE",getNewMap());  
    newNode.put("ORDERNO",getValue(EI["edSubRuleOrder"]));
    newNode.put("PARENTRULENODEID",graphRedactor.multiDragSet[0]["nodeid"]);
    newNode.put("RULEID",graphRedactor.loadedRuleData["RULEID"]);
    newNode.put("RULENODEID",Raphael.createUUID());
    newNode.put("VALUEID",getComboSelectedValue(EI["cmRule"]));
    lgr(newNode);
    graphRedactor.LoadedRuleNodes.add(newNode);
    var coord=graphRedactor.showAddNodeCoord;

    graphRedactor.changeList.push({"type":"addNode","begin":[],"end":newNode});

    graphRedactor.createRule(newNode,{"x":coord["x"],"y":coord["y"],"idxAnimate":0,"nodeType": "Rule" });
    graphRedactor.createLink(newNode["RULENODEID"],newNode["PARENTRULENODEID"]);
    graphRedactor.refreshLinkPosition(newNode["PARENTRULENODEID"]);
    graphRedactor.refreshNode(newNode["PARENTRULENODEID"]);
  }
  ////////////// Функция создания узла типа Результат ///////////////////////////////////////////////////
  graphRedactor.createRule=function(obj,prms){
    lgr("graphRedactor.createRule");
    var incr=graphRedactor.incr;    
    var subRule=graphRedactor.getSubRuleByID(obj["VALUEID"]);
    prms=nvl(prms,[]);
    prms=graphRedactor.mergeObjects(prms,{
                  "colorStart":"#95003E",
                  "colorEnd":"FF006A",
                  "title":subRule["SYSNAME"],
                  "titleStyle": graphRedactor.textStyles["common"],
                  "nodeid":obj["RULENODEID"],
                  "parentid":obj["PARENTRULENODEID"]
               });    
    var nodeSet=graphRedactor.createNode(prms);     
    return nodeSet;
  }

  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.repaintRule=function(obj,prms){
    lgr("graphRedactor.repaintRule");
    var incr=graphRedactor.incr;    
    var subRule=graphRedactor.getSubRuleByID(obj["VALUEID"]);
    prms=nvl(prms,[]);
    prms=graphRedactor.mergeObjects(prms,{
                  "colorStart":"#95003E",
                  "colorEnd":"FF006A",
                  "title":subRule["SYSNAME"],
                  "titleStyle": graphRedactor.textStyles["common"],
                  "nodeid":obj["RULENODEID"],
                  "parentid":obj["PARENTRULENODEID"]
               });    
    var nodeSet=graphRedactor.repaintNode(prms,obj["RULENODEID"]);     
    return nodeSet;
  }  
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.editRule=function(prms){
    lgr("graphRedactor.editRule"); 
    prms=nvl(prms,[]);
    var newNode=getNewMap();
    newNode.put("DEFAULTVALUE",null);
    newNode.put("ISUSEDEFAULT", null); 
    newNode.put("NODETYPE","2");       
    newNode.put("NODEVALUE",getNewMap());  
    newNode.put("ORDERNO",getValue(EI["edSubRuleOrder"]));
    newNode.put("PARENTRULENODEID",nvl(prms["PARENTRULENODEID"],graphRedactor.nodeVisual["ID"+graphRedactor.selNodeID].parentid));
    newNode.put("RULENODEID",graphRedactor.selNodeID);
    newNode.put("VALUEID",getComboSelectedValue(EI["cmRule"]));

    var dd=graphRedactor.LoadedRuleNodes.length;
    var selNodeID=graphRedactor.selNodeID;
    var begin=null;
    for (var i=0;i<dd;i++){
      var Node=graphRedactor.LoadedRuleNodes[i];
      if (Node["RULENODEID"]+""==selNodeID+""){
        begin=cloneObj(Node);
        graphRedactor.LoadedRuleNodes[i]=newNode;
        break;
      }
    }
    var end=newNode;
    graphRedactor.changeList.push({"type":"editNode","begin":begin,"end":end});
    graphRedactor.checkRevertRibbon();
    graphRedactor.refreshNode(newNode["RULENODEID"]);
    graphRedactor.refreshLinkPosition(newNode["PARENTRULENODEID"]);
    graphRedactor.refreshNode(newNode["PARENTRULENODEID"]);
  }
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.checkRuleParams=function(){
    var checkList=[EI["edSubRuleOrder"],EI["cmRule"]];
    return checkElements(checkList);
  }
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.RuleMaxInputCount=function(nodeid){
    return 0;
  }