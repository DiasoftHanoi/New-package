  graphRedactor.nodeTypes[6]="Matrix";

	graphRedactor.MatrixParamDialog=createSimpleModal2(EI["MatrixParamPanel"]);
 	graphRedactor.matrixCondValueDialog=createSimpleModal2(EI["matrixCondValue"],null,true,true,function(el,width,height){resizeWindow(graphRedactor.resizeMatrixCondValue,width,height);
 																														  graphRedactor.refreshColMatrixWidth();});

  graphRedactor.MatrixParamDialog.on("hide",graphRedactor.hideOpenDialog,this,{stopPropagation:false});
  graphRedactor.matrixCondValueDialog.on("hide",graphRedactor.hideOpenDialog,this,{stopPropagation:false});


  graphRedactor.initMatrixParams=function(){
 	  lgr("graphRedactor.initMatrixParams");
    graphRedactor.selMatrixParams=getNewList();
 	  graphRedactor.selMatrixConditions=getNewMap();
 	  graphRedactor.selMatrixConditionValues=getNewList();
 	  graphRedactor.selMatrixMaxParamID=0;
 	  graphRedactor.selMatrixMaxParamCount=10;

 	  graphRedactor.selMatrixMaxParamConditionID=0;
 	  graphRedactor.MatrixParamAction=null;
 	  graphRedactor.MatrixParamConditionAction=null;
 	  graphRedactor.selMatrixParamID=null;
 	  graphRedactor.selMatrixParamConditionID=null;
    graphRedactor.selMatrixRuleNodeID=null;
  }
  graphRedactor.initMatrixParams();
 	graphRedactor.resizeMatrixCondValue=[
	                     								{"id": EI["matrixCondValue"],
	 							                       "width":"100%",
	 							                       "height":"100%",
	 							                       "display":"block",
	 							                       "childs":[

											                           {"id":EI["tbCondValue"],
				 							                            "width":"100%",
				 							                            "display":"inline",
				 							                            "height":"100%",
				 							                            "margin-bottom":"42"
											                           },
											                           {"id": EI["btmCondPanel"],
				 							                            "height":"42",
	   		 							                            "right":"0",
		  	 							                            "bottom":"0",
				 							                            "display":"inline"
											                           },
                                                 {"id" :EI["helpMatrixContPnl"],
                                                  "bottom":"0",
                                                  "display":"inline"
                                                 }
			  							                          ]
								                      }
									                    ];

  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.showMatrixDialog=function(){
    lgr("graphRedactor.showMatrixDialog");
    graphRedactor.initMatrixParams();
    if (this.nodeid){graphRedactor.curoper="edit";} ///Определяем что был выбран узел для редактирвоания
    selectedNode=getNewList();
	clearComboOptions(EI["cbRule"]);
	for (var i=0;i<graphRedactor.loadedSubRules.length;i++){
		addComboOption(EI["cbRule"], graphRedactor.loadedSubRules[i]["RULEID"], graphRedactor.loadedSubRules[i]["SYSNAME"]);
	}
    lgr(graphRedactor.curoper);
    if (graphRedactor.curoper=="edit"){
      var dd=graphRedactor.LoadedRuleNodes.length;
      var selNodeID=this.nodeid;
      for (var i=0;i<dd;i++){
        var Node=graphRedactor.LoadedRuleNodes[i];
        if (Node["RULENODEID"]+""==selNodeID+""){
          selectedNode=Node;
          graphRedactor.curoper="edit";
          graphRedactor.MatrixParamDialog.setTitle("Редактирование матричного решения");
          graphRedactor.matrixCondValueDialog.setTitle("Редактирование матричного решения");
          break;
        }
      }  
      graphRedactor.selNodeID=selNodeID;
      setValue(EI["edMatrixOrder"],selectedNode["ORDERNO"]);
    }
    if (graphRedactor.curoper=="add"){
      var parentid=graphRedactor.multiDragSet[0]["nodeid"];
      graphRedactor.MatrixParamDialog.setTitle("Добавление матричного решения");
      graphRedactor.matrixCondValueDialog.setTitle("Добавление матричного решения");
      setValue(EI["edMatrixOrder"],stringToNumeric(graphRedactor.getNextOrderByNo(parentid))+1);
    }
    var NODEVALUE=nvl(selectedNode["NODEVALUE"],[]);
    var PARAMETERS=nvl(NODEVALUE["PARAMETERS"],[]);
    var CELLS=nvl(NODEVALUE["CELLS"],[]);

    graphRedactor.selMatrixMaxParamID=0;
    graphRedactor.selMatrixParams=cloneObj(PARAMETERS);
    graphRedactor.selMatrixConditionValues=cloneObj(CELLS);

    dd=graphRedactor.selMatrixParams.length;
    clearTable(EI["tbMatrixParameters"]);
    clearTable(EI["tbMatrixParamConditions"]);

    for (var i=0;i<dd;i++){
      var paramMap = getNewMap();
      paramMap.put("ID", graphRedactor.selMatrixParams[i]["ID"]);  
      var id = parseInt(paramMap.get("ID"));
      if (id > graphRedactor.selMatrixMaxParamID){
        graphRedactor.selMatrixMaxParamID = id;
      }
      paramMap.put("PARAMSYSNAME", graphRedactor.selMatrixParams[i]["PARAMSYSNAME"]);
	  var DATASETPARAMID = graphRedactor.selMatrixParams[i]["DATASETPARAMID"];
      paramMap.put("DATASETPARAMID", graphRedactor.selMatrixParams[i]["DATASETPARAMID"]);
      paramMap.put("RULEID", graphRedactor.selMatrixParams[i]["RULEID"]);
      paramMap.put("DEFAULTVALUE", graphRedactor.selMatrixParams[i]["DEFAULTVALUE"]);
      paramMap.put("PARAMTYPE", ((DATASETPARAMID == "") || (DATASETPARAMID == null)) ? "Правило" : "Параметр");
      graphRedactor.selMatrixConditions["P"+paramMap.get("ID")]=graphRedactor.selMatrixParams[i]["CONDITIONS"];
      addRow(EI["tbMatrixParameters"],paramMap);
    }
	
    disableElement(EI["lbEditMatrixParam"]);
    disableElement(EI["lbDeleteMatrixParam"]);
    disableElement(EI["imgEditMatrixParam"]);
    disableElement(EI["imgDeleteMatrixParam"]);

    graphRedactor.openedDialogType="Matrix";
    graphRedactor.MatrixParamDialog.show(graphRedactor.MatrixParamDialog);
    showElement(EI["MatrixParamPanel"]);  
  }
	
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.hideMatrixDialog=function(){
    lgr("graphRedactor.hideMatrixDialog");
    hideElement(EI["matrixCondValue"]);
    graphRedactor.matrixCondValueDialog.hide();   

    hideElement(EI["MatrixParamPanel"]);
    graphRedactor.MatrixParamDialog.hide();   
  }
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.addMatrixClick=function(){
    lgr("graphRedactor.addMatrixClick");
    if (gbi("add-matrix-btn").isEnabled()){
      graphRedactor.initMatrixParams();
      graphRedactor.showAddNodeHintFlag=true;
      gbi(EI["addNodeHint"]).className="";
      addClass(gbi(EI["addNodeHint"]),"matrixHint");
      showElement(EI["addNodeHint"]);
      graphRedactor.showAddNodeFunction=graphRedactor.showMatrixDialog;
      graphRedactor.curoper="add";
    }
  }
 	////////////// Функция создания узла типа матрица ///////////////////////////////////////////////////
 	graphRedactor.createMatrix=function(obj,prms){
    lgr("graphRedactor.createMatrix");
    var incr=graphRedactor.incr;
    prms=nvl(prms,[]);
    prms=graphRedactor.mergeObjects(prms,{
                                          "colorStart":"#953E00",
                                          "colorEnd":"FF6A00",
                                          "title":"MATRIX",
                                          "titleStyle": graphRedactor.textStyles["common"],
                                          "nodeid":obj["RULENODEID"],
                                          "parentid":obj["PARENTRULENODEID"],
                                          "minHeight": 4*incr
                                          });
   	var nodeSet=graphRedactor.createNode(prms); 
   	return nodeSet;
 	}

  ///////////////////////////////////////////////////////////////////////////////////////////////////////
    graphRedactor.repaintMatrix=function(obj,prms){
    }  
 	///////////////////////////////////////////////////////////////////////////////////////////////////////
	graphRedactor.selectMatrixParameter=function(){
 		enableElement(EI["lbEditMatrixParam"]);
 		enableElement(EI["lbDeleteMatrixParam"]);
 		enableElement(EI["imgEditMatrixParam"]);
 		enableElement(EI["imgDeleteMatrixParam"]);
 		var row = getSelectedRow(EI["tbMatrixParameters"]);
 		if (row != null && row!=="") {
	 		clearTable(EI["tbMatrixParamConditions"]);
 			var paramId = row.get("ID");
	 		var conditions = graphRedactor.selMatrixConditions["P"+paramId];
 			graphRedactor.selMatrixMaxParamConditionID= parseInt("0");
 			if (conditions) {
  				for (var i = 0; i< conditions.length; i++) {
		  			var cond = cloneObj(conditions[i]);
  					var id = parseInt(cond.get("ID"));
	  				if (id > graphRedactor.selMatrixMaxParamConditionID){
				  		graphRedactor.selMatrixMaxParamConditionID= id;
		  			}
            if (cond.get("LOWVALUE")=="") {cond.put("LOWVALUE","_")};
            if (cond.get("TOPVALUE")=="") {cond.put("TOPVALUE","_")};
		  			var map = getNewMap();
	  				map.put("PARAMID", cond.get("PARAMID")); 
	  				map.put("ID", cond.get("ID")); 
	  				map.put("LOWVALUE", cond.get("LOWVALUE")); 
	  				map.put("TOPVALUE", cond.get("TOPVALUE"));  
	  				map.put("CONDITION", graphRedactor.getCondition(cond));
	  				addRow(EI["tbMatrixParamConditions"], map); 
	 			}
			}
		}  
	}
 	///////////////////////////////////////////////////////////////////////////////////////////////////////
 	graphRedactor.deleteMatrixParameter=function(){ 
    var row = getSelectedRow(EI["tbMatrixParameters"]);
    if (row != null) {
 	  	deleteSelectedRow(EI["tbMatrixParameters"], true);
      var selID=row.get("ID");
      var dd=graphRedactor.selMatrixParams.length;
      for (var i=0;i<dd;i++){
        var param=graphRedactor.selMatrixParams[i];
        if (param["ID"]==selID){
          graphRedactor.selMatrixParams.splice(i,1);
          break;
        }
      }

   		var paramKey = "P"+String(row.get("ID"));
      delete graphRedactor.selMatrixConditions[paramKey];
   		clearTable(EI["tbMatrixParamConditions"]);
   		graphRedactor.selMatrixMaxParamConditionID=parseInt("0");
   		disableElement(EI["lbEditMatrixParam"]);
   		disableElement(EI["lbDeleteMatrixParam"]);
   		disableElement(EI["imgEditMatrixParam"]);
   		disableElement(EI["imgDeleteMatrixParam"]);
   	}else{
   		alert("Выберите параметр из таблицы"); 
   	}
 	}
 	///////////////////////////////////////////////////////////////////////////////////////////////////////
 	graphRedactor.deleteMatrixParameterCondition=function(){ 
    var row = getSelectedRow(EI["tbMatrixParamConditions"]);
    if (row != null) {
 	  	deleteSelectedRow(EI["tbMatrixParamConditions"], true);
   		var paramId = String(row.get("PARAMID"));
   		var condId = String(row.get("ID"));
   		graphRedactor.deleteCondition(paramId, condId);
   		disableElement(EI["lbEditC"]);
   		disableElement(EI["lbDeleteC"]);
  	} else{
   		alert("Выберите условие из таблицы");
   	}
   	if (graphRedactor.selMatrixConditions.length == 0){
   		disableElement(EI["ButtonAdd"]);
   	}else {
   		enableElement(EI["ButtonAdd"]);
   	}
 	}
 	///////////////////////////////////////////////////////////////////////////////////////////////////////
 	graphRedactor.applyChangeMatrixParameter=function(){ 
   	lgr("graphRedactor.applyChangeMatrixParameter");
   	var param = getComboSelectedValue(EI["cmMatrixParamType"]);
	var rule = getComboSelectedValue(EI["cbRule"]);
	var operandType = getComboSelectedValue(EI["cbOperandType"]);
	
	if (operandType == "PARAM" && (param == "" || param == "0")){
		showAlert("Выберите параметр");
		return;
	}	
	if (operandType == "RULE" && (rule == "" || rule == null)){
		showAlert("Выберите правило");
		return;
	}
	
	var map = getNewMap();
	map.put("PARAMTYPE", operandType == "PARAM" ? "Параметр" : "Правило");
	
	map.put("DEFAULTVALUE", getValue(EI["edDefMatrixParamValue"]));
	
	if (operandType == "PARAM"){
		map.put("DATASETPARAMID", param);
		map.put("PARAMSYSNAME", getComboSelectedText(EI["cmMatrixParamType"]));
	} else {
		map.put("RULEID", rule);
		map.put("PARAMSYSNAME", getComboSelectedText(EI["cbRule"]));
	}
	if (graphRedactor.MatrixParamAction == "ADD") {
		var counter = graphRedactor.getNextId(graphRedactor.selMatrixMaxParamID);
		map.put("ID", counter);
		graphRedactor.selMatrixMaxParamID=counter;
		addRow(EI["tbMatrixParameters"], map);
		map.put("CONDITIONS",getNewList());
		graphRedactor.selMatrixConditions["P"+String(counter)]=map["CONDITIONS"];
		graphRedactor.selMatrixParams.add(map);

		try {setSelectedRow(EI["tbMatrixParameters"], getRowsCount(EI["tbMatrixParameters"])-1);}catch(e){}
		clearTable(EI["tbMatrixParamConditions"]);
		graphRedactor.selMatrixMaxParamConditionID=parseInt("0");
		setValue(EI["edFromBound"], "");
		setValue(EI["edToBound"], "");
		graphRedactor.MatrixParamConditionAction=null;
		hideElement(EI["pnlIntervalEdit"]);  
		showElement(EI["pnlIntervalList"]); 

	} else {

	var row=getSelectedRow(EI["tbMatrixParameters"]);

	var dd=graphRedactor.selMatrixParams.length;
	for (var i=0;i<dd;i++){
	  var param=graphRedactor.selMatrixParams[i];
	  if (param.get("ID")==row.get("ID")){
		if (map.get("DATASETPARAMID")!="" && map.get("DATASETPARAMID")!=null){
			param.put("DATASETPARAMID",map.get("DATASETPARAMID"));
		} else {
			delete param["DATASETPARAMID"];
			delete map["DATASETPARAMID"];
		}
		if (map.get("RULEID")!="" && map.get("RULEID")!=null){
			param.put("RULEID",map.get("RULEID"));
		} else {
			delete param["RULEID"];
			delete map["RULEID"];
		}
		param.put("PARAMSYSNAME",map.get("PARAMSYSNAME"));
		param.put("DEFAULTVALUE",map.get("DEFAULTVALUE"));
		var CONDITIONS= param.get("CONDITIONS");
		var dd2=CONDITIONS.length;
		for (var j=0;j<dd2;j++){
		  var condition=CONDITIONS.get(j);
		  condition.put("DATASETPARAMID",map.get("DATASETPARAMID"));
		  condition.put("PARAMSYSNAME",map.get("PARAMSYSNAME"));
		  condition.put("DEFAULTVALUE",map.get("DEFAULTVALUE"));
		}
	  break;  
	  }
	}
		updateSelectedRow(EI["tbMatrixParameters"], map);
	}
	hideElement(EI["pnlMatrixParameterEdit"]);  
	showElement(EI["pnlMatrixParameterList"]);
	enableElement(EI["lbEditMatrixParam"]);
	enableElement(EI["lbDeleteMatrixParam"]);
	enableElement(EI["imgEditMatrixParam"]);
	enableElement(EI["imgDeleteMatrixParam"]); 
  }
	///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.applyChangeMatrixConditionParameter=function(){
   	lgr("graphRedactor.applyChangeMatrixConditionParameter");
    var fromB = getValue(EI["edFromBound"]);
   	var toB = getValue(EI["edToBound"]);
   	if (fromB != "" || toB != "") {
   		var map = getNewMap();
   		map.put("LOWVALUE", fromB);
   		map.put("TOPVALUE", toB);
   		map.put("INTERVALTYPE", getComboSelectedValue(EI["cbInterval"]));
   		map.put("CONDITION", graphRedactor.getCondition(map));
   		var paramId = graphRedactor.selMatrixParamID;
   		if (graphRedactor.MatrixParamConditionAction == "ADD") {    
     		var counter = graphRedactor.getNextId(graphRedactor.selMatrixMaxParamConditionID);
     		map.put("ID", counter);  
     		map.put("PARAMID", paramId);
     		graphRedactor.selMatrixMaxParamConditionID=counter;
     		addRow(EI["tbMatrixParamConditions"], map);
     		setSelectedRow(EI["tbMatrixParamConditions"], getRowsCount(EI["tbMatrixParamConditions"])-1);
        lgr(cloneObj(graphRedactor.selMatrixConditions)); 
     		graphRedactor.addCondition(paramId, cloneObj(map));
        lgr(cloneObj(graphRedactor.selMatrixConditions));
  		} else {
     		updateSelectedRow(EI["tbMatrixParamConditions"], map);
     		var condId = graphRedactor.selMatrixParamConditionID; 
     		graphRedactor.updateCondition(paramId, condId, cloneObj(map));
   		}
   		graphRedactor.addMatrixConditionDialogHide();
   	} else{
   		showAlert("Введите условие");  
   	}
   	enableElement(EI["ButtonAdd"]);
 	}
 	///////////////////////////////////////////////////////////////////////////////////////////////////////
 	graphRedactor.getNextId=function(id) {
   	return stringToNumeric(stringToNumeric(id)+1);
 	}
 	///////////////////////////////////////////////////////////////////////////////////////////////////////
 	graphRedactor.addCondition=function(paramId, map) {
    lgr("graphRedactor.addCondition");
   	if (map["LOWVALUE"]=="_"){map["LOWVALUE"]=""};
    if (map["TOPVALUE"]=="_"){map["TOPVALUE"]=""};

    var conditions = graphRedactor.selMatrixConditions["P"+String(paramId)];
   	map.put("CONDITION", "");
   	if (conditions) {
      lgr("has conditions");
     	conditions.add(map);
   	} else {
     	lgr("conditions is null");
      conditions = getNewList();
     	conditions.add(map);
     	graphRedactor.selMatrixConditions["P"+String(paramId)]= conditions;
   	}
 	}
 	///////////////////////////////////////////////////////////////////////////////////////////////////////
 	graphRedactor.updateCondition=function(paramId, condId, map) {
    lgr("graphRedactor.updateCondition");

    if (map["LOWVALUE"]=="_"){map["LOWVALUE"]=""};
    if (map["TOPVALUE"]=="_"){map["TOPVALUE"]=""};

   	var conditions = graphRedactor.selMatrixConditions["P"+String(paramId)];
   	if (conditions) {
   		for (var n = 0; n < conditions.length; n++) {
      	var cond = conditions.get(n);
     		if (String(condId) == String(cond.get("ID"))) {
       		cond.put("LOWVALUE", map.get("LOWVALUE"));
     			cond.put("TOPVALUE", map.get("TOPVALUE"));
     			cond.put("CONDITION", "");
     			break;    
     		}
   		}
  	}
 	}
 	///////////////////////////////////////////////////////////////////////////////////////////////////////
 	graphRedactor.deleteCondition=function (paramId, condId) {
    lgr("graphRedactor.deleteCondition");
   	var conditions = graphRedactor.selMatrixConditions["P"+String(paramId)];
   	if (conditions) {
   		for (var n = 0; n < conditions.length; n++) {
     		var cond = conditions.get(n);
     		if (String(condId) == String(cond.get("ID"))) {
     			conditions.splice(n, 1);
     			break;    
     		}
   		}
  	}
    var dd= graphRedactor.selMatrixParams.length;
    for (var i=0;i<dd;i++){
      var param=graphRedactor.selMatrixParams[i];
      if (param.get("ID")==paramId){
          CONDITIONS=param.get("CONDITIONS");
          var dd2=CONDITIONS.length;
          for (var j=0;j<dd2;j++){
            var cond=CONDITIONS.get(j);
            if (cond.get("ID")==condId){
              CONDITIONS.splice(j,1);
              break;
            }
          }
          break;
      }
    }    
	}
	///////////////////////////////////////////////////////////////////////////////////////////////////////
 	graphRedactor.getCondition=function(cr) {
		var INTERVALTYPE = cr.get("INTERVALTYPE");
		if (INTERVALTYPE == null || INTERVALTYPE==""){
			INTERVALTYPE = 1;
		}
		switch (INTERVALTYPE+""){
			case "0": return "( "+cr.get("LOWVALUE").toString().trim()+" , "+cr.get("TOPVALUE").toString().trim()+" )";
			case "1": return "( "+cr.get("LOWVALUE").toString().trim()+" , "+cr.get("TOPVALUE").toString().trim()+" ]";
			case "2": return "[ "+cr.get("LOWVALUE").toString().trim()+" , "+cr.get("TOPVALUE").toString().trim()+" )";
			case "3": return "[ "+cr.get("LOWVALUE").toString().trim()+" , "+cr.get("TOPVALUE").toString().trim()+" ]";
			default : return "";
		}
 	}
	

 	///////////////////////////////////////////////////////////////////////////////////////////////////////
	graphRedactor.listAddAll=function(list1,list2){
   	var dd=list2.size();
   	for (var i=0;i<dd;i++){
     	list1.add(list2[i]);
   	}
	}
	///////////////////////////////////////////////////////////////////////////////////////////////////////
 	graphRedactor.addMatrixParameterDialogShow=function(type){
   	if (type=="EDIT"){
   		var row = getSelectedRow(EI["tbMatrixParameters"]);
   		if (row != null) {
     		setComboOptionByText(EI["cbOperandType"], row.get("PARAMTYPE"));
			if (row.get("PARAMTYPE") == "Параметр"){
				setComboOptionByValue(EI["cmMatrixParamType"], row.get("DATASETPARAMID"));
			} else {
				setComboOptionByValue(EI["cbRule"], row.get("RULEID"));
			}
     		setValue(EI["edDefMatrixParamValue"], row.get("DEFAULTVALUE"));
     		hideElement(EI["pnlMatrixParameterList"]);
     		showElement(EI["pnlMatrixParameterEdit"]);
     		graphRedactor.MatrixParamAction=type;
   		} else{
     		alert("Выберите параметр из таблицы");  
   		}
   	}else
   	if (type=="ADD"){
   		setComboOptionByValue(EI["cbOperandType"], "PARAM");
   		setComboOptionByValue(EI["cmMatrixParamType"], "");
		setComboOptionByValue(EI["cbRule"], "");
   		setValue(EI["edDefMatrixParamValue"], "");
   		hideElement(EI["pnlMatrixParameterList"]);
   		showElement(EI["pnlMatrixParameterEdit"]);
   		graphRedactor.MatrixParamAction=type;
   	}
 	}
 	///////////////////////////////////////////////////////////////////////////////////////////////////////
 	graphRedactor.addMatrixConditionDialogShow=function(type){
   	var param = getSelectedRow(EI["tbMatrixParameters"]);
   	if (param != null) {
   		graphRedactor.selMatrixParamID=param.get("ID");
   		graphRedactor.MatrixParamConditionAction=type;
   		if (type=="ADD"){
     		//setValue("CRDPolicyRuleMtx.MainPanel.pnlIntervalEdit.edId", "");
     		setValue(EI["edFromBound"], "");
     		setValue(EI["edToBound"], "");
			setComboOptionByValue(EI["cbInterval"], 1);
     		hideElement(EI["pnlIntervalList"]);
     		showElement(EI["pnlIntervalEdit"]);
     		disableElement(EI["pnlMatrixParameterList"]);
     		disableElement(EI["pnlMatrixParameterEdit"]);
     		disableElement(EI["tbMatrixParameters"]);
     		setFocus(EI["edFromBound"]);
   		}
   		if (type=="EDIT"){
     		var row = getSelectedRow(EI["tbMatrixParamConditions"]);
     		if (row != null) {
     			graphRedactor.selMatrixParamConditionID=row.get("ID")
     			setValue(EI["edFromBound"], row.get("LOWVALUE"));
     			setValue(EI["edToBound"], row.get("TOPVALUE"));
				setComboOptionByValue(EI["cbInterval"], row["INTERVALTYPE"] || 1);
     			hideElement(EI["pnlIntervalList"]);
     			showElement(EI["pnlIntervalEdit"]);
     			setFocus(EI["edFromBound"]);
     		} else{
     			alert("Выберите условие из таблицы");
    		}
   		}
  	} else {
   		alert("Выберите параметр из таблицы");
  	}
 	}
 	///////////////////////////////////////////////////////////////////////////////////////////////////////
 	graphRedactor.addMatrixParameterDialogHide=function(){
   	setComboOptionByValue(EI["cbOperandType"], "PARAM");
   	setComboOptionByValue(EI["cmMatrixParamType"], null);
   	setComboOptionByValue(EI["cbRule"], "");
   	setValue(EI["edDefMatrixParamValue"], "");
   	graphRedactor.MatrixParamAction=null;
   	showElement(EI["pnlMatrixParameterList"]);
   	hideElement(EI["pnlMatrixParameterEdit"]);
 	}
 	///////////////////////////////////////////////////////////////////////////////////////////////////////
 	graphRedactor.addMatrixConditionDialogHide=function(){
   	graphRedactor.MatrixParamConditionAction=null;
   	showElement(EI["pnlIntervalList"]);
   	hideElement(EI["pnlIntervalEdit"]);
   	setValue(EI["edFromBound"], "");
   	setValue(EI["edToBound"], "");
   	enableElement(EI["pnlMatrixParameterList"]);
   	enableElement(EI["pnlMatrixParameterEdit"]);
   	enableElement(EI["tbMatrixParameters"]);
 	}
 	///////////////////////////////////////////////////////////////////////////////////////////////////////
	graphRedactor.formMatrix=function (ind, parametersList, conditionList) {
   	var cellConditionList = getNewList();
   	if (ind < parametersList.size()) {
     	var parameter = parametersList.get(ind);
     	var conditions = conditionList.get("P"+parameter.get("ID"));
     	var innerConditions = graphRedactor.formMatrix(ind+1, parametersList, conditionList);
     	if (conditions != null) {
       	var dd=conditions.size();
        for (var i = 0; i < dd; i++) {
         	var condition = conditions.get(i);
         	condition.put("PARAMSYSNAME", parameter.get("PARAMSYSNAME")); 
			if (parameter.get("DATASETPARAMID")!="" && parameter.get("DATASETPARAMID")!=null){
				condition.put("DATASETPARAMID", parameter.get("DATASETPARAMID"));
			}
			if (parameter.get("RULEID")!="" && parameter.get("RULEID")!=null){
				condition.put("RULEID", parameter.get("RULEID"));
			}
         	condition.put("DEFAULTVALUE", parameter.get("DEFAULTVALUE"));
         	var dd2=innerConditions.size();
          for (var j = 0; j < dd2; j++) {
           	var cellConditions = getNewList();
           	cellConditions.add(condition);
           	graphRedactor.listAddAll(cellConditions,innerConditions.get(j));
           	cellConditionList.add(cellConditions);
         	}    
       	}
     	} else {
       	return innerConditions;
    	}
   	} else {
     	var cellConditions = getNewList();
     	cellConditionList.add(cellConditions);
   	}
   	return cellConditionList;  
	}
 	///////////////////////////////////////////////////////////////////////////////////////////////////////
	graphRedactor.findCellValue=function(conditions, filledCellConditionList) {
   	if (filledCellConditionList != null) {
    	var dd=filledCellConditionList.size();
      for (var i = 0; i < dd; i++) {
       	var cell = filledCellConditionList.get(i);
       	if (cell != null && graphRedactor.isEqualConditions(conditions, cell.get("CONDITIONS"))) {
         	return cell.get("VALUE");
       	}
     	}
  	}
   	return "";
	}
 	///////////////////////////////////////////////////////////////////////////////////////////////////////
	graphRedactor.isEqualConditions=function(conditions1, conditions2) {
  	if (conditions1 == null || conditions2 == null)
      return false;
  	if (conditions1.size() != conditions2.size())
     	return false;
    var result = true;
   	var dd=conditions1.size();
    for (var i = 0; i < dd; i++) {
     	var isFind = false;
     	var dd2=conditions2.size();
      for (var j = 0; j < dd2; j++) {
       	if (conditions1.get(i).get("ID") == conditions2.get(j).get("ID")
         	&& conditions1.get(i).get("PARAMID") == conditions2.get(j).get("PARAMID")) {
           	isFind = true;
           	break;
       	}
     	}
     	if (!isFind) {
       	result = false;
       	break;
    	}
   	}
   	return result;
	}
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
	graphRedactor.toMatrixParams=function(){
    var curoper=graphRedactor.curoper;
		hideElement(EI["matrixCondValue"]);
 		graphRedactor.matrixCondValueDialog.hide();
    graphRedactor.openedDialogType="Matrix";    		
    graphRedactor.curoper=curoper;
 		showElement(EI["MatrixParamPanel"]);  
 		graphRedactor.MatrixParamDialog.show(graphRedactor.MatrixParamDialog);
	}
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.toMatrixCondValue=function(){
    if (graphRedactor.selMatrixConditions.size() == 0){
      showAlert("На параметры не заданы условия!")
    }else{
      var curoper=graphRedactor.curoper;
      hideElement(EI["MatrixParamPanel"]);  
      graphRedactor.MatrixParamDialog.hide();
      graphRedactor.curoper=curoper;

      graphRedactor.openedDialogType="Matrix";

      var paramCondIter=[];
      graphRedactor.refreshColMatrixWidth();

      var filledCellConditionList = graphRedactor.selMatrixConditionValues;
      var cellConditionList = getNewList();
      var conditions = graphRedactor.formMatrix(0, graphRedactor.selMatrixParams, graphRedactor.selMatrixConditions);

      for (var i = 0; i < conditions.size(); i++) {
        if (conditions.get(i).size() > 0) {
          var map = getNewMap();
          map.put("ID", parseInt(i+1));
          var cellValue = graphRedactor.findCellValue(conditions.get(i), filledCellConditionList);
          if (cellValue != "") target = "EDIT";
          map.put("VALUE", cellValue);
          map.put("CONDITIONS", conditions.get(i));
          cellConditionList.add(map);
        } 
      }

      graphRedactor.selMatrixConditionValues=cellConditionList;
      clearTable(EI["tbCondValue"]);
      var dd3=cellConditionList.size();
      for (var i=0;i<dd3;i++){
        var cellCondition=cellConditionList[i];
        var map=getNewMap();
            
        map["ID"]=cellCondition["ID"];
        var cellCondValue = cellCondition["VALUE"]=="" ? "_" : cellCondition["VALUE"];
        map["CONDVALUE"]="<input id=\""+EI["tbCondValue"]+".inputValue"+cellCondition["ID"]+"\" style=\"width:100%\" value=\""+cellCondValue+"\">";
        var CONDITIONS=cellCondition["CONDITIONS"];
        var dd4=CONDITIONS.size();
        for (var j=0;j<dd4;j++){
          var cond=CONDITIONS[j];
          map["PARAM"+(j+1)]=graphRedactor.getCondition(cond);
        }
        addtr(EI["tbCondValue"],map);
      }
      showElement(EI["matrixCondValue"]);
      graphRedactor.matrixCondValueDialog.show(graphRedactor.matrixCondValueDialog);
    }
  }
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
	graphRedactor.refreshColMatrixWidth=function(){
		var dd=graphRedactor.selMatrixMaxParamCount;
   	var dd2=graphRedactor.selMatrixParams.length;
     	
   	var colValueWidth=getColumnWidth(EI["tbCondValue"], "CONDVALUE");
   	var colWidth=parseInt((getWidth(EI["tbCondValue"])-colValueWidth-35)/(dd2));
     	
   	for (var i=0;i<dd;i++){
     	if (dd2>i){
     		setColumnVisible(EI["tbCondValue"],"PARAM"+(i+1),true);
     		setTableColumnHeader(EI["tbCondValue"], "PARAM"+(i+1), graphRedactor.selMatrixParams[i]["PARAMSYSNAME"]);
     		setColumnWidth(EI["tbCondValue"],"PARAM"+(i+1), colWidth);
     	}else{
     		setColumnVisible(EI["tbCondValue"],"PARAM"+(i+1),false);
     		setTableColumnHeader(EI["tbCondValue"], "PARAM"+(i+1), "PARAM"+(i+1));
     		setColumnWidth(EI["tbCondValue"],"PARAM"+(i+1), 100);
     	}
   	}
	}

  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.applyChangesMatrix=function(){
    lgr("graphRedactor.applyChangesMatrix");
    if (graphRedactor.checkMatrixParams()){
        graphRedactor[graphRedactor.curoper+"Matrix"]();
        hideElement(EI["matrixCondValue"]);
        graphRedactor.matrixCondValueDialog.hide();  
    }else{
        showAlert("Не заполнены все обязательные поля");
    }
  }
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.fillMatrixCellsValue=function(conditions){
    var dd=getRowsCount(EI["tbCondValue"]);
    for (var i=0;i<dd;i++){
      var valueid=getCellText(EI["tbCondValue"], i, "ID");
      var value=getValue(EI["tbCondValue"]+".inputValue"+valueid);
      value= value=="_" ? "" : value;
      var dd2=conditions.size();
      for (var j=0;j<dd2;j++){
        var condition=conditions[j];
        if (condition["ID"]==valueid){
          condition["VALUE"]=value;
          //break;
        }
		if (condition["DATASETPARAMID"] == "" || condition["DATASETPARAMID"] == null){
			delete condition["DATASETPARAMID"];
		}		
		if (condition["RULEID"] == "" || condition["RULEID"] == null){
			delete condition["RULEID"];
		}
      }
    } 
    return conditions; 
  }
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.checkMatrixParams=function(){
    var dd=getRowsCount(EI["tbCondValue"]);
    if (dd==0){
      return false;
    }
    for (var i=0;i<dd;i++){
      var valueid=getCellText(EI["tbCondValue"], i, "ID");
      var value=getValue(EI["tbCondValue"]+".inputValue"+valueid);
      if (value==""){
        setErrorClass(EI["tbCondValue"]+".inputValue"+valueid,true);
        return false;
      }else{
        setErrorClass(EI["tbCondValue"]+".inputValue"+valueid,false);
      }
    } 
    return true;    
  }
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.editMatrix=function(){
    lgr("graphRedactor.editMatrix"); 
    var dd=graphRedactor.LoadedRuleNodes.length;
    var selectedNode=getNewMap();
    var selNodeID=graphRedactor.selNodeID;
    for (var i=0;i<dd;i++){
      var Node=graphRedactor.LoadedRuleNodes[i];
      if (Node["RULENODEID"]+""==selNodeID+""){
        selectedNode=Node;
        break;
      }
    }
    var begin=cloneObj(selectedNode);
    lgr(selectedNode)
    selectedNode["ORDERNO"]=getValue(EI["edMatrixOrder"]);
    selectedNode["NODEVALUE"]["PARAMETERS"]=graphRedactor.selMatrixParams;
    selectedNode["NODEVALUE"]["CELLS"]=graphRedactor.fillMatrixCellsValue(graphRedactor.selMatrixConditionValues);
    var end=selectedNode;

    graphRedactor.changeList.push({"type":"editNode","begin":begin,"end":end});
    graphRedactor.checkRevertRibbon();
    graphRedactor.refreshLinkPosition(selectedNode["PARENTRULENODEID"]);
    graphRedactor.refreshNode(selectedNode["RULENODEID"]);
    graphRedactor.refreshNode(selectedNode["PARENTRULENODEID"]);
  }  
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.addMatrix=function(){
    lgr("graphRedactor.addMatrix"); 
    var newNode=getNewMap();
    newNode.put("DEFAULTVALUE",null);
    newNode.put("ISUSEDEFAULT","0"); //not user for operation
    newNode.put("NODETYPE","6");       // type operation
    newNode.put("ORDERNO",getValue(EI["edMatrixOrder"]));
    newNode.put("PARENTRULENODEID",graphRedactor.multiDragSet[0]["nodeid"]);
    newNode.put("RULEID",graphRedactor.loadedRuleData["RULEID"]);
    newNode.put("RULENODEID",Raphael.createUUID());
    newNode.put("VALUEID",null);
    newNode.put("NODEVALUE",getNewMap()); 
    newNode.get("NODEVALUE").put("PARAMETERS",graphRedactor.selMatrixParams)
    newNode.get("NODEVALUE").put("CELLS",graphRedactor.fillMatrixCellsValue(graphRedactor.selMatrixConditionValues));
    lgr(newNode);
    graphRedactor.LoadedRuleNodes.add(newNode);
    var coord=graphRedactor.showAddNodeCoord;
    

    graphRedactor.changeList.push({"type":"addNode","begin":[],"end":newNode});
    graphRedactor.checkRevertRibbon();
    graphRedactor.createMatrix(newNode,{"x":coord["x"],"y":coord["y"],"idxAnimate":0,"nodeType": "Matrix" });
    graphRedactor.createLink(newNode["RULENODEID"],newNode["PARENTRULENODEID"]);
    graphRedactor.refreshLinkPosition(newNode["PARENTRULENODEID"]);
    graphRedactor.refreshNode(newNode["PARENTRULENODEID"]);
  }
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  graphRedactor.MatrixMaxInputCount=function(nodeid){
    return 0;
  }