LogSchemeDialogConstructor=function(){
	var logSchemeDialog=new Object();
	
	logSchemeDialog.viewTableName=EI["tbPolicyLogTypes"];
	logSchemeDialog.selectedLogSchemeID=null;
	logSchemeDialog.selectedLogSchemeName=null;
  logSchemeDialog.window=createSimpleModal2(EI["logSchemePanel"]);
  logSchemeDialog.logWindow=createSimpleModal2(EI["logPanel"]);  
  logSchemeDialog.logDialogWindow=createSimpleModal2(EI["logDialogPanel"]);  
  logSchemeDialog.selectedRuleNodeID=null;
  logSchemeDialog.selectedNodeLogID=null;

  logSchemeDialog.curoper="none";
  logSchemeDialog.logcuroper="none";
	//////////////////////////////////////////////////
	logSchemeDialog.selectLogScheme=function(){
		lgr("logSchemeDialog.selectLogScheme");
	    var selLog=getSelectedRow(logSchemeDialog.viewTableName);
    	if (selLog!=="" && selLog!=null){
      	ribbonMenu.switchToTabByIndex(3); // Выбирает закладку риббон меню с лог схемами
        logSchemeDialog.selectedLogSchemeID=selLog["LOGSCHEMEID"];
     		
     		logSchemeDialog.selectedLogSchemeName=selLog["NAME"];
     		logSchemeDialog.checkRibbonControls();
    	}  
	}

  	////////////////////////////////////////////////////////////////////
	logSchemeDialog.checkRibbonControls=function(){
    	lgr("logSchemeDialog.checkRibbonControls");
    	if (logSchemeDialog.selectedLogSchemeID==null){
     		gbi('edit-logscheme-btn').disable();
     		gbi('del-logscheme-btn').disable();  
    	}else{
     		gbi('edit-logscheme-btn').enable();
     		gbi('del-logscheme-btn').enable();       
    	}
 	}
  	////////////////////////////////////////////////////////////////////
 	logSchemeDialog.editLogSchemeDialogShow=function(){
 		lgr("logSchemeDialog.editLogSchemeDialogShow");
 		if (gbi("edit-logscheme-btn").isEnabled()) {
			logSchemeDialog.window.setTitle("Редактирование схемы логирования");
			logSchemeDialog.curoper="edit";
			logSchemeDialog.getLogSchemeByParams({"LOGSCHEMEID":logSchemeDialog.selectedLogSchemeID},"logSchemeDialog.onAfterGetLogSchemeByParams");
		}
	}
	////////////////////////////////////////////////////////////////////
	logSchemeDialog.getLogSchemeByParams=function(params,callback){
    lgr("logSchemeDialog.getLogSchemeByParams");
		callback = callback==null ? "logSchemeDialog.fillLogScheme" : callback; 
		if (callback=="logSchemeDialog.fillLogScheme"){
			clearTable(logSchemeDialog.viewTableName);
    		logSchemeDialog.selectedLogSchemeID=null;
    		logSchemeDialog.checkRibbonControls();
			disableElement(logSchemeDialog.viewTableName);
		}
    	params= params!=null ? params : getNewMap();
    	params['ORDERBY']= params['ORDERBY']==null ? "NAME" :params['ORDERBY'];
		dsCall("[dmsws]","ruleLogSchemeGetListByParams",params,callback)
	}
	///////////////////////////////////////////////////////////////////
	logSchemeDialog.fillLogScheme=function(p){
    lgr("logSchemeDialog.fillLogScheme");
	  enableElement(logSchemeDialog.viewTableName);
	  clearComboOptions(EI["cmResultLogScheme"]);
    addComboOption(EI["cmResultLogScheme"], "systemLog", "Системный лог");
    var p=p["Result"];
	  if (p!=null && p!==""){
		  var dd=p.length;
		  for (var i=0;i<dd;i++){
		  	addRow(logSchemeDialog.viewTableName,p[i]);
        addComboOption(EI["cmResultLogScheme"],p[i]["SYSNAME"],p[i]["NAME"]);
		  }
	  }else{
      showAlert("ОШибка загрузки схем логирования");
    }
	}
	////////////////////////////////////////////////////////////////////
	logSchemeDialog.addLogSchemeDialogShow=function(){
		lgr("logSchemeDialog.LogSchemeDialogShow");
    	logSchemeDialog.window.setTitle("Добавление новой схемы логирования");
    	logSchemeDialog.curoper="add";
    	logSchemeDialog.window.show(logSchemeDialog.window);
    	showElement(EI["logSchemePanel"]);
	}
	///////////////////////////////////////////////////////////////////
 	logSchemeDialog.delLogSchemeDialogShow=function(){
    lgr("logSchemeDialog.delLogSchemeDialogShow");
  	if (gbi("del-logscheme-btn").isEnabled()) {
      if (logSchemeDialog.selectedLogSchemeID!=null){
     	  logSchemeDialog.getLogListByParams({"LOGSCHEMEID":logSchemeDialog.selectedLogSchemeID},"logSchemeDialog.onAfterGetLogListByParams");
      }
  	}
 	}
  ///////////////////////////////////////////////////////////////////
  logSchemeDialog.getLogListByParams=function(params,callback){
    lgr("logSchemeDialog.getLogListByParams");
    callback = callback==null ? "logSchemeDialog.onAfterGetLogListByParams" : callback; 
    if (callback=="logSchemeDialog.onAfterGetLogListByParams"){
    }
      params= params!=null ? params : getNewMap();
      params['ORDERBY']= params['ORDERBY']==null ? "RULENODELOGID" :params['ORDERBY'];
    dsCall("[dmsws]","ruleNodeLogGetListByParams",params,callback)    
  }
  ////////////////////////////////////////////////////////////////////
  logSchemeDialog.onAfterGetLogListByParams=function(p){
    lgr("logSchemeDialog.onAfterGetLogListByParams");
    if (p['Status']=="OK"){
      p=p["Result"];
      if (p!=null && p!==""){
        var dd=p.length;
        if (dd==0){
            if (confirm("Вы уверены что хотите удалить выбранную схему логирования - "+logSchemeDialog.selectedLogSchemeName+"?")){
                  logSchemeDialog.curoper="del";
                  logSchemeDialog[logSchemeDialog.curoper]();  
              } 
        }else{
          showAlert("Внимание! В выбранной схеме логирования есть записи. Удаление невозможно!");
        }
      }
    }else{
      showError("Ошибка получения записей по схеме логирования.");     
    }
  }    
	////////////////////////////////////////////////////////////////////
 	logSchemeDialog.onAfterGetLogSchemeByParams=function(p){
   	lgr("logSchemeDialog.onAfterGetLogSchemeByParams");
   	if (p['Status']=="OK"){
     		p=p["Result"];
     		if (p!=="" && p!=null){
       		if (p.length==1){
         			setValue(EI["edLogSchemeSysName"],p[0]["SYSNAME"]);
         			setValue(EI["edLogSchemeName"],p[0]["NAME"]);
         			logSchemeDialog.window.show(logSchemeDialog.window);
         			showElement(EI["logSchemePanel"]);
       		}else{
         			showError("Ошибка получения данных по выбранной схеме логирования");
       		}
     		}
   	}else{
     		showError("Ошибка получения данных по выбранной схеме логирования");
   	}
 	}
 	////////////////////////////////////////////////////////////////////
	logSchemeDialog.logSchemeWindowHide=function(){
    	lgr("logSchemeDialog.logSchemeWindowHide");
      logSchemeDialog.window.hide();
    	hideElement(EI["logSchemePanel"]);		
	}
	///////////////////////////////////////////////////////////////////
 	logSchemeDialog.checkParams=function(){
    lgr("logSchemeDialog.checkParams");
	  var returnFlag=checkElements([EI["edLogSchemeSysName"],EI["edLogSchemeName"]]);
	  return returnFlag;  
 	}
 	////////////////////////////////////////////////////////////////////
 	logSchemeDialog.applyChanges=function(){
    	lgr("logSchemeDialog.applyChanges");
	  	if (logSchemeDialog.checkParams()){
	     	logSchemeDialog[logSchemeDialog.curoper](); 
	    }else{
    		showAlert("Не заполнены все обязательные поля");
    	}
 	}
 	////////////////////////////////////////////////////////////////////
 	logSchemeDialog.edit=function(){
    	lgr("logSchemeDialog.edit");
    	var params=getNewMap();
    	params["SYSNAME"]=getValue(EI["edLogSchemeSysName"]);
    	params["NAME"]=getValue(EI["edLogSchemeName"]);
    	params["LOGSCHEMEID"]=logSchemeDialog.selectedLogSchemeID;
    	disableElement(EI["logSchemePanel"]);
    	dsCall("[dmsws]","ruleLogSchemeModify",params,"logSchemeDialog.onAfterEditLogScheme") 
 	}
 	 ////////////////////////////////////////////////////////////////////
 	logSchemeDialog.del=function(){
	  lgr("logSchemeDialog.del");
	    var params=getNewMap();
	    params["LOGSCHEMEID"]=logSchemeDialog.selectedLogSchemeID;
	    dsCall("[dmsws]","ruleLogSchemeDelete",params,"logSchemeDialog.onAfterDelLogScheme"); 
 	}
 	 ////////////////////////////////////////////////////////////////////
 	logSchemeDialog.add=function(){
	    lgr("logSchemeDialog.add");
	   	var params=getNewMap();
    	params["SYSNAME"]=getValue(EI["edLogSchemeSysName"]);
    	params["NAME"]=getValue(EI["edLogSchemeName"]);
    	disableElement(EI["logSchemePanel"]);
	   	dsCall("[dmsws]","ruleLogSchemeCreate",params,"logSchemeDialog.onAfterAddLogScheme") 
 	}

 	////////////////////////////////////////////////////////////////////
 	logSchemeDialog.onAfterEditLogScheme=function(p){
    lgr("logSchemeDialog.onAfterEditLogScheme");
		enableElement(EI["logSchemePanel"]);
    if (p["Status"]=="OK"){
    	toggleLogSchemePanel(true);
    	logSchemeDialog.getLogSchemeByParams();
    	logSchemeDialog.logSchemeWindowHide();
    	logSchemeDialog.curoper="none";
    }else{
    	showError("Внимание! Произошла ошибка при редактировании схемы логирования");
	  }
 	}
  ///////////////////////////////////////////////////////////////////////
  logSchemeDialog.onAfterDelLogScheme=function(p){
    lgr("logSchemeDialog.onAfterDelLogScheme");
    enableElement(EI["logSchemePanel"]);
    if (p["Status"]=="OK"){
      toggleLogSchemePanel(true);
      logSchemeDialog.getLogSchemeByParams();
      logSchemeDialog.curoper="none";
    }else{
      showError("Внимание! Произошла ошибка при редактировании схемы логирования");
    }    
  }
 	////////////////////////////////////////////////////////////////////
 	logSchemeDialog.onAfterAddLogScheme=function(p){
    lgr("logSchemeDialog.onAfterAddLogScheme");
		enableElement(EI["logSchemePanel"]);
    if (p["Status"]=="OK"){
    	toggleLogSchemePanel(true);
    	logSchemeDialog.getLogSchemeByParams();
    	logSchemeDialog.logSchemeWindowHide();
    	logSchemeDialog.curoper="none";
    }else{
    	showError("Внимание! Произошла ошибка при сохранении новой схемы логирования");
	  }
 	} 
 	////////////////////////////////////////////////////////////////////
 /*
 	logSchemeDialog.onAfterDelGroup=function(p){
    lgr("logSchemeDialog.onAfterDelGroup");
    if (p["Status"]=="OK"){
    	toggleLogSchemePanel(true);
    	logSchemeDialog.getLogSchemeByParams();
    	logSchemeDialog.curoper="none";
    }else{
    	showError("Внимание! Произошла ошибка при удалении схемы логирования");
	  }
 	}
  */
  ////////////////////////////////////////////////////////////////////
  logSchemeDialog.logDialogShow=function(){
    lgr("logSchemeDialog.logDialogShow");
    hideElement(EI["logPanel"]);
    logSchemeDialog.selectedRuleNodeID=graphRedactor.multiDragSet[0]["nodeid"];
    logSchemeDialog.logWindow.show(logSchemeDialog.logWindow);
    logSchemeDialog.getLogSchemeByParams([],"logSchemeDialog.fillLogSchemeDialog");
  }
  ////////////////////////////////////////////////////////////////
  logSchemeDialog.logSchemeDialogHide=function(){
    lgr("logSchemeDialog.logSchemeDialogHide");
    hideElement(EI["logPanel"]);
    logSchemeDialog.logWindow.hide(); 
  }
  //////////////////////////////////////////////////////////////////
  logSchemeDialog.fillLogSchemeDialog=function(p){
    lgr("logSchemeDialog.fillLogSchemeDialog");
    clearComboOptions(EI["cmLogType"]);
    clearComboOptions(EI["cmLogSchemeDialog"]);
    addComboOption(EI["cmLogType"],"","");
    addComboOption(EI["cmLogSchemeDialog"],"","");
    var p=p["Result"];
    if (p!=null && p!==""){
      var dd=p.length;
      for (var i=0;i<dd;i++){
        addComboOption(EI["cmLogType"],p[i]["LOGSCHEMEID"],p[i]["NAME"]+" ("+p[i]["SYSNAME"]+")");
        addComboOption(EI["cmLogSchemeDialog"],p[i]["LOGSCHEMEID"],p[i]["NAME"]+" ("+p[i]["SYSNAME"]+")");
      }
      setComboOptionByValue(EI["cmLogType"],"");
      showElement(EI["logPanel"]);
    }else{
      showAlert("Ошибка загрузки схем логирования");
    }
  }
  //////////////////////////////////////////////////////////////////
  logSchemeDialog.changeNodeLog=function(){
    lgr("logSchemeDialog.changeNodeLog");
    var logSchemeID=getComboSelectedValue(EI["cmLogType"]);
    logSchemeDialog.selectedNodeLogID=null;

    setComboOptionByValue(EI["cmLogSchemeDialog"],logSchemeID);
    if (logSchemeID=="" || logSchemeID=="0") logSchemeID=null;
    clearTable(EI["tbPolicyLogTexts"]);
    tableDisable(EI["tbPolicyLogTexts"]);
    disableElement(EI["cmLogType"]);
    logSchemeDialog.getLogListByParams({"LOGSCHEMEID":logSchemeID,"RULENODEID":logSchemeDialog.selectedRuleNodeID},"logSchemeDialog.fillRuleNodes");
  }
  ////////////////////////////////////////////////////////////////////
  logSchemeDialog.fillRuleNodes=function(p){
    lgr("logSchemeDialog.fillRuleNodes");
    var p=p["Result"];
    if (p!=null && p!==""){
      var dd=p.length;
      for (var i=0;i<dd;i++){
        addRow(EI["tbPolicyLogTexts"],p[i]);
      }
    }else{
      showAlert("Ошибка загрузки логирования узла");
    }
    tableEnable(EI["tbPolicyLogTexts"]);
    enableElement(EI["cmLogType"]);    
  }
  /////////////////////////////////////////////////////////////////
  logSchemeDialog.logDialogHide=function(){
    lgr("logSchemeDialog.logDialogHide");    
    logSchemeDialog.logDialogWindow.hide();    
    hideElement(EI["logDialogPanel"]);
    logSchemeDialog.logWindow.show(logSchemeDialog.logWindow);    
    showElement(EI["logPanel"]);
  }

  /////////////////////////////////////////////////////////////////
  logSchemeDialog.addLogDialogShow=function(){
    lgr("logSchemeDialog.addLogDialogShow");
    logSchemeDialog.logcuroper="add";
    logSchemeDialog.selectedNodeLogID=null;
    
    disableElement(EI["lbEditLog"]);
    disableElement(EI["imgEditLog"]);
    disableElement(EI["lbDelLog"]);
    disableElement(EI["imgDelLog"]);

    setValue(EI["edLogText"],"");
    logSchemeDialog.logWindow.hide();
    hideElement(EI["logPanel"]);
    logSchemeDialog.logDialogWindow.setTitle("Добавление сообщения");
    logSchemeDialog.logDialogWindow.show(logSchemeDialog.logDialogWindow);
    showElement(EI["logDialogPanel"]);
  }
  /////////////////////////////////////////////////////////////////
  logSchemeDialog.editLogDialogShow=function(){
    lgr("logSchemeDialog.editLogDialogShow");    
    logSchemeDialog.logcuroper="edit"; 
    if (logSchemeDialog.selectedNodeLogID!=null){
      logSchemeDialog.logWindow.hide();
      hideElement(EI["logPanel"]);
      logSchemeDialog.logDialogWindow.setTitle("Редактирование сообщения");
      hideElement(EI["logDialogPanel"]);
      logSchemeDialog.logDialogWindow.show(logSchemeDialog.logDialogWindow); 
      logSchemeDialog.getLogListByParams({"RULENODELOGID":logSchemeDialog.selectedNodeLogID},"logSchemeDialog.onAfterGetLogByID");  
    }else{
      showAlert("Внимание! Не выбрано сообщение.");
    }
  }

  /////////////////////////////////////////////////////////////////
  logSchemeDialog.delLogDialogShow=function(){ 
    lgr("logSchemeDialog.delLogDialogShow");     
    if (confirm("Вы уверены что хотите удалить выбранное сообщение")){
      logSchemeDialog.logcuroper="del"; 
      logSchemeDialog[logSchemeDialog.logcuroper+"NodeLog"](); 
    }
  }
  ////////////////////////////////////////////////////////////////////
  logSchemeDialog.selectLog=function(){
    lgr("logSchemeDialog.selectLog");
    var selLog=getSelectedRow(EI["tbPolicyLogTexts"]);
    if (selLog!=="" && selLog!=null){
      logSchemeDialog.selectedNodeLogID=selLog["RULENODELOGID"];

      enableElement(EI["lbEditLog"]);
      enableElement(EI["imgEditLog"]);
      enableElement(EI["lbDelLog"]);
      enableElement(EI["imgDelLog"]);
    }  
  }
  /////////////////////////////////////////////////////////////////////////
  logSchemeDialog.onAfterGetLogByID=function(p){
    lgr("logSchemeDialog.onAfterGetLogByID");
    if (p["Status"]=="OK"){
      p=p["Result"];
      p=nvl(p[0],[]);
      setComboOptionByValue(EI["cmLogSchemeDialog"],p["LOGSCHEMEID"]);
      setValue(EI["edLogText"],p["LOGMESSAGE"]);      
      showElement(EI["logDialogPanel"]);

    }else{
      showAlert("Ошибка загрузки сообщения");
    }
  }
  /////////////////////////////////////////////////////////////////////////
  logSchemeDialog.applyChangesNodeLog=function()  {
    lgr("logSchemeDialog.applyChangesNodeLog");
    if (logSchemeDialog.checkNodeLogParams()){
      logSchemeDialog[logSchemeDialog.logcuroper+"NodeLog"](); 
    }else{
      showAlert("Не заполнены все обязательные поля");
    }
  }
  //////////////////////////////////////////////////////////////////////////
  logSchemeDialog.checkNodeLogParams=function(){
    lgr("logSchemeDialog.checkNodeLogParams");
    return  checkElements([EI["cmLogSchemeDialog"],EI["edLogText"]]);
  }
   ////////////////////////////////////////////////////////////////////
  logSchemeDialog.addNodeLog=function(){
      lgr("logSchemeDialog.addNodeLog");
      var params=getNewMap();
      params["RULENODEID"]=logSchemeDialog.selectedRuleNodeID;
      params["LOGSCHEMEID"]=getComboSelectedValue(EI["cmLogSchemeDialog"]);
      params["LOGMESSAGE"]=getValue(EI["edLogText"]);
      disableElement(EI["logDialogPanel"]);
      dsCall("[dmsws]","ruleNodeLogCreate",params,"logSchemeDialog.onAfterAddNodeLog") 
  }  
  ////////////////////////////////////////////////////////////////////
  logSchemeDialog.editNodeLog=function(){
      lgr("logSchemeDialog.editNodeLog");
      var params=getNewMap();
      params["RULENODELOGID"]=logSchemeDialog.selectedNodeLogID;
      params["RULENODEID"]=logSchemeDialog.selectedRuleNodeID;
      params["LOGSCHEMEID"]=getComboSelectedValue(EI["cmLogSchemeDialog"]);
      params["LOGMESSAGE"]=getValue(EI["edLogText"]);
      disableElement(EI["logDialogPanel"]);
      dsCall("[dmsws]","ruleNodeLogModify",params,"logSchemeDialog.onAfterEditNodeLog") 
  }
   ////////////////////////////////////////////////////////////////////
  logSchemeDialog.delNodeLog=function(){
    lgr("logSchemeDialog.delNodeLog");
      var params=getNewMap();
      params["RULENODELOGID"]=logSchemeDialog.selectedNodeLogID;
      dsCall("[dmsws]","ruleNodeLogDelete",params,"logSchemeDialog.onAfterDelNodeLog"); 
  }

  ////////////////////////////////////////////////////////////////////
  logSchemeDialog.onAfterAddNodeLog=function(p){
    lgr("logSchemeDialog.onAfterAddNodeLog");
    enableElement(EI["logDialogPanel"]);
    if (p["Status"]=="OK"){
      logSchemeDialog.logDialogHide();
      setComboOptionByValue(EI["cmLogType"], getComboSelectedValue(EI["cmLogSchemeDialog"]));
    }else{
      showError("Внимание! Произошла ошибка при добавлении сообщения");
    }
  }
  ///////////////////////////////////////////////////////////////////////
  logSchemeDialog.onAfterEditNodeLog=function(p){
    lgr("logSchemeDialog.onAfterEditNodeLog");
    enableElement(EI["logDialogPanel"]);
    if (p["Status"]=="OK"){
      logSchemeDialog.logDialogHide();
      setComboOptionByValue(EI["cmLogType"], getComboSelectedValue(EI["cmLogSchemeDialog"]));
    }else{
      showError("Внимание! Произошла ошибка при редактировании сообщения");
    }    
  }
  ////////////////////////////////////////////////////////////////////
  logSchemeDialog.onAfterDelNodeLog=function(p){
    lgr("logSchemeDialog.onAfterDelNodeLog");
    enableElement(EI["logDialogPanel"]);
    if (p["Status"]=="OK"){
      logSchemeDialog.logDialogHide();
      setComboOptionByValue(EI["cmLogType"], getComboSelectedValue(EI["cmLogSchemeDialog"]));
    }else{
      showError("Внимание! Произошла ошибка при удалении сообщения");
    }
  }
  ////////////////////////////////////////////////////////////////////



	return logSchemeDialog;
}

logSchemeDialog=LogSchemeDialogConstructor();