/////////////////////////////////////////////////////////////////
DatasetDialogConstructor=function(){
	var datasetDialog=new Object();
	datasetDialog.curoper="none";
 	datasetDialog.viewTableName=EI["tbPolicyDatasets"];
 	datasetDialog.selectedDatasetID=null;
  datasetDialog.window=createSimpleModal2(EI["datasetPanel"]);
  /////////////////////////////////////////////////////////////////////////////
  datasetDialog.getDatasetByParams=function(params,callback){
    lgr("datasetDialog.getDatasetByParams");
    callback = callback==null ? "datasetDialog.fillDataset" : callback; 
    if (callback=="datasetDialog.fillDataset"){
      clearTable(datasetDialog.viewTableName);
      datasetDialog.selectedDatasetID=null;
      datasetDialog.checkRibbonControls();
      disableElement(datasetDialog.viewTableName);
    }
    params= params!=null ? params : getNewMap();
    params['ORDERBY']= params['ORDERBY']==null ? "FULLNAME" :params['ORDERBY'];
    dsCall("[dmsws]","ruleDatasetGetListByParams",params,callback)
  }
  ////////////////////////////////////////////////////////////////////
  datasetDialog.fillDataset=function(p){
    lgr("datasetDialog.fillDataset");
    enableElement(datasetDialog.viewTableName);
    var p=p["Result"];
    if (p!=null && p!==""){
      var dd=p.length;
      for (var i=0;i<dd;i++){
        addRow(datasetDialog.viewTableName,p[i]);
      }
    }
  }
  ////////////////////////////////////////////////////////////////////
  datasetDialog.checkRibbonControls=function(){
    lgr("datasetDialog.checkRibbonControls");    
    if (datasetDialog.selectedDatasetID==null){
      gbi('edit-dataset-btn').disable();
      gbi('del-dataset-btn').disable();  
      gbi('import-dataset-btn').disable();  

    }else{
      gbi('edit-dataset-btn').enable();
      gbi('del-dataset-btn').enable();    
      gbi('import-dataset-btn').enable();  
   
    }
  }
  ////////////////////////////////////////////////////////////////////
  datasetDialog.addDatasetDialogShow=function(){
    lgr("datasetDialog.addDatasetDialogShow");
    datasetDialog.window.setTitle("Добавление нового входного множества параметров");
    datasetDialog.curoper="add";
    datasetDialog.window.show(datasetDialog.window);
    showElement(EI["datasetPanel"]);
  }
  ////////////////////////////////////////////////////////////////////
  datasetDialog.editDatasetDialogShow=function(){
    lgr("datasetDialog.editDatasetDialogShow");
    if (gbi("edit-dataset-btn").isEnabled()) {
      datasetDialog.window.setTitle("Редактирование входного множества параметров");
      hideElement(EI["datasetPanel"]);
      datasetDialog.window.show(datasetDialog.window);
      datasetDialog.curoper="edit";
      datasetDialog.getDatasetByParams({"DATASETID":datasetDialog.selectedDatasetID},"datasetDialog.onAfterGeteditDatasetDialogShow");
    }
  }
  ////////////////////////////////////////////////////////////////////
  datasetDialog.applyChanges=function(){
    lgr("datasetDialog.applyChanges");
    if (datasetDialog.checkParams()){
      datasetDialog[datasetDialog.curoper](); 
    }else{
      showAlert("Не заполнены все обязательные поля");
    }
  }
  ////////////////////////////////////////////////////////////////////
  datasetDialog.checkParams=function(){
    lgr("datasetDialog.checkParams");
    var returnFlag=checkElements([EI["edDatasetSysName"],EI["edDatasetName"]]);
    return returnFlag;  
  }
  ////////////////////////////////////////////////////////////////////
  datasetDialog.add=function(){
    lgr("datasetDialog.add");
    var params=getNewMap();
    params["SYSNAME"]=getValue(EI["edDatasetSysName"]);
    params["FULLNAME"]=getValue(EI["edDatasetName"]);
    disableElement(EI["datasetPanel"]);
    dsCall("[dmsws]","ruleDatasetCreate",params,"datasetDialog.onAfterAddDataset") 
  }
  ////////////////////////////////////////////////////////////////////
  datasetDialog.onAfterAddDataset=function(p){
  lgr("datasetDialog.onAfterAddDataset");
  enableElement(EI["datasetPanel"]);
    if (p["Status"]=="OK"){
      toggleDatasetPanel(true);
      datasetDialog.getDatasetByParams();
      datasetDialog.datasetDialogHide();
    }else{
      showError("Внимание! Произошла ошибка при сохранении нового множества параметров");
    }
  } 
  ////////////////////////////////////////////////////////////////////
  datasetDialog.datasetDialogHide=function(){
    lgr("datasetDialog.datasetDialogHide");
    datasetDialog.curoper="none";
    datasetDialog.window.hide();
    hideElement(EI["rulePanel"]);
  }  
  ////////////////////////////////////////////////////////////////////
  datasetDialog.selectDataset=function(){
    lgr("datasetDialog.selectDataset");
    var sel=getSelectedRow(datasetDialog.viewTableName);
    if (sel!=="" && sel!=null){
      ribbonMenu.switchToTabByIndex(2); // Выбирает закладку риббон меню с группами
      datasetDialog.selectedDatasetID=sel["DATASETID"];
      datasetDialog.selectedDatasetName=sel["FULLNAME"];
      datasetParamDialog.getDatasetParamByParams({"DATASETID":sel["DATASETID"]});
      datasetDialog.checkRibbonControls();
    }  
  }
  ////////////////////////////////////////////////////////////////////
  datasetDialog.onAfterGeteditDatasetDialogShow=function(p){
    lgr("datasetDialog.onAfterGeteditDatasetDialogShow");
    if (p['Status']=="OK"){
      p=p["Result"];
      if (p!=="" && p!=null){
        if (p.length==1){
          setValue(EI["edDatasetSysName"],p[0]["SYSNAME"]);
          setValue(EI["edDatasetName"],p[0]["FULLNAME"]);
          showElement(EI["datasetPanel"]);
        }else{
          showError("Ошибка получения данных по выбранной группе правил");
        }
      }
    }else{
      showError("Ошибка получения данных по выбранной группе правил");
    }
  }
  ////////////////////////////////////////////////////////////////////
  datasetDialog.edit=function(){
    lgr("datasetDialog.edit");
    var params=getNewMap();
    params["SYSNAME"]=getValue(EI["edDatasetSysName"]);
    params["FULLNAME"]=getValue(EI["edDatasetName"]);
    params["DATASETID"]=datasetDialog.selectedDatasetID;
    disableElement(EI["datasetPanel"]);
    dsCall("[dmsws]","ruleDatasetModify",params,"datasetDialog.onAfterEditDataset") 
  }
  ////////////////////////////////////////////////////////////////////
  datasetDialog.onAfterEditDataset=function(p){
    lgr("datasetDialog.onAfterEditDataset");
    enableElement(EI["datasetPanel"]);
    if (p["Status"]=="OK"){
      toggleDatasetPanel(true);
      datasetDialog.getDatasetByParams();
      datasetDialog.datasetDialogHide();
      datasetDialog.curoper="none";
    }else{
      showError("Внимание! Произошла ошибка при редактировании множества входных параметров");
    }
  }

  ////////////////////////////////////////////////////////////////////
  datasetDialog.delDatasetDialogShow=function(){
    lgr("datasetDialog.delDatasetDialogShow");      
    if (gbi("del-dataset-btn").isEnabled()) {
      datasetParamDialog.getDatasetParamByParams({"DATASETID":datasetDialog.selectedDatasetID},"datasetDialog.onAfterGetDatasetParam");
    }
  }


  ////////////////////////////////////////////////////////////////////
  datasetDialog.onAfterGetDatasetParam=function(p){
    lgr("datasetDialog.onAfterGetDatasetParam");
    if (p['Status']=="OK"){
      p=p["Result"];
      if (p!=null && p!==""){
        var dd=p.length;
        if (dd==0){
            if (confirm("Вы уверены что хотите удалить выбранное множество входных параметров - "+datasetDialog.selectedDatasetName+"?")){
                  datasetDialog.curoper="del";
                  datasetDialog[datasetDialog.curoper]();  
              } 
        }else{
          showAlert("Внимание! В выбранном множестве параметров на удаление есть параметры. Удаление невозможно!");
        }
      }
    }else{
      showError("Ошибка получения параметров по выбранному множеству параметров.");     
    }
  }
  ////////////////////////////////////////////////////////////////////
  datasetDialog.del=function(){
    lgr("datasetDialog.del");
    var params=getNewMap();
    params["DATASETID"]=datasetDialog.selectedDatasetID;
    dsCall("[dmsws]","ruleDatasetDelete",params,"datasetDialog.onAfterDelDataset"); 
  }
  ////////////////////////////////////////////////////////////////////
  datasetDialog.onAfterDelDataset=function(p){
    lgr("datasetDialog.onAfterDelDataset");
    if (p["Status"]=="OK"){
      toggleDatasetPanel(true);
      datasetDialog.getDatasetByParams();
      datasetDialog.curoper="none";
    }else{
      showError("Внимание! Произошла ошибка при удалении множества входных параметров");
    }
  }





/*
  ////////////////////////////////////////////////////////////////////
  datasetDialog.onAfterGetGroupsByParams=function(p){
    if (p["Status"]=="OK"){
      var p=p["Result"];
      if (p!=null && p!==""){
        var dd=p.length;
        clearComboOptions(EI["cmGroup"]);
        addComboOption(EI["cmGroup"],"","");
        for (var i=0;i<dd;i++){
          addComboOption(EI["cmGroup"],p[i]["RULEGROUPID"],p[i]["NAME"]);
        }
        //ruleParamDialog.getRuleParamByParams(null,"datasetDialog.onAfterGetRuleParams");
        createSimpleModal2(EI["rulePanel"]);
      }
    }else{
      showAlert("Ошибка получения списка групп правил");
    }
  }



*/










   return datasetDialog;
}

datasetDialog=DatasetDialogConstructor();