//////////////////////////////////////////////////////////////////////////////
toggleLeftPanel=function(flag){
   	lgr("toggleLeftPanel");
   	var wdth=0;
   	var hgh=0;
	var commonOpacity=0;
   	var clbFunction=null;
   	var zindx=null;
   	if ((hasClass(gbi(EI["lbToggleLeftPnl"]),"left-arrow") && flag==null )|| flag==false){
    	wdth=150;
     	hgh=23;
     	commonOpacity=0;
     	zindx=3;
     	clbFunction=function(){hideElement(EI["leftPnlContainer"])};
   	}else{
    	wdth=450;
     	hgh=500;
     	showElement(EI["leftPnlContainer"]);
     	commonOpacity=1;
     	zindx=10;
     	clbFunction=function(){};
     	toggleDatasetPanel(false);
     	toggleLogSchemePanel(false);
   	}

   	Ext.get(EI["leftPnl"]).stopFx(true);
   	Ext.get(EI["leftPnlContainer"]).stopFx(true);
   	Ext.get(EI["leftPnl"]).shift({ width: wdth, height:hgh, easing: 'easeBoth',zIndex:zindx });
   	Ext.get(EI["leftPnlContainer"]).shift({ opacity: commonOpacity, width: wdth, height:hgh, easing: 'easeBoth', callback: clbFunction });
   	if  ((hasClass(gbi(EI["lbToggleLeftPnl"]),"right-arrow") && flag==true) || 
    	flag==null || 
    	(hasClass(gbi(EI["lbToggleLeftPnl"]),"left-arrow") && flag==false)){
      	toogleClass(gbi(EI["lbToggleLeftPnl"]),"left-arrow","right-arrow");
   	}
}
//////////////////////////////////////////////////////////////////////////////
toggleDatasetPanel=function(flag){
	lgr("toggleDatasetPanel");
   	var wdth=0;
   	var hgh=0;
   	var commonOpacity=0;
   	var clbFunction=null;
   	var zindx=null;
   	if ((hasClass(gbi(EI["lbToggleDatasetPnl"]),"left-arrow") && flag==null )|| flag==false){
    	wdth=150;
     	hgh=23;
     	commonOpacity=0;
     	zindx=3;
     	clbFunction=function(){hideElement(EI["datasetPnlContainer"])};
   	}else{
    	wdth=450;
     	hgh=500;
     	zindx=10;
     	toggleLeftPanel(false);
     	toggleLogSchemePanel(false);
     	showElement(EI["datasetPnlContainer"]);
     	commonOpacity=1;
     	clbFunction=function(){};
   	}  
   	Ext.get(EI["datasetPnl"]).stopFx(true);
    Ext.get(EI["datasetPnlContainer"]).stopFx(true);
  	Ext.get(EI["datasetPnl"]).shift({ width: wdth, height:hgh, easing: 'easeBoth',zIndex:zindx });
   	Ext.get(EI["datasetPnlContainer"]).shift({ opacity: commonOpacity, width: wdth, height:hgh, easing: 'easeBoth', callback: clbFunction });
   	if  ((hasClass(gbi(EI["lbToggleDatasetPnl"]),"right-arrow") && flag==true) || 
        flag==null || 
        (hasClass(gbi(EI["lbToggleDatasetPnl"]),"left-arrow") && flag==false)){
    	toogleClass(gbi(EI["lbToggleDatasetPnl"]),"left-arrow","right-arrow");
   	}	
}
//////////////////////////////////////////////////////////////////////////////
toggleLogSchemePanel=function(flag){
	lgr("toggleLogSchemePanel");
   	var wdth=0;
   	var hgh=0;
   	var commonOpacity=0;
   	var clbFunction=null;
   	var zindx=null;
   	if ((hasClass(gbi(EI["lbToggleLogSchemePnl"]),"left-arrow") && flag==null )|| flag==false){
    	wdth=150;
     	hgh=23;
     	commonOpacity=0;
     	zindx=3;
     	clbFunction=function(){hideElement(EI["logSchemePanelContainer"])};
   	}else{
    	wdth=450;
     	hgh=222;
     	zindx=10;
     	toggleLeftPanel(false);
     	toggleDatasetPanel(false);
     	showElement(EI["logSchemePanelContainer"]);
     	commonOpacity=1;
     	clbFunction=function(){};
   	}  
   	Ext.get(EI["logSchemePnl"]).stopFx(true);
    Ext.get(EI["logSchemePanelContainer"]).stopFx(true);
  	Ext.get(EI["logSchemePnl"]).shift({ width: wdth, height:hgh, easing: 'easeBoth',zIndex:zindx });
   	Ext.get(EI["logSchemePanelContainer"]).shift({ opacity: commonOpacity, width: wdth, height:hgh, easing: 'easeBoth', callback: clbFunction });
   	if  ((hasClass(gbi(EI["lbToggleLogSchemePnl"]),"right-arrow") && flag==true) || 
        flag==null || 
        (hasClass(gbi(EI["lbToggleLogSchemePnl"]),"left-arrow") && flag==false)){
    	toogleClass(gbi(EI["lbToggleLogSchemePnl"]),"left-arrow","right-arrow");
   	}	
}




//////////////////////////////////////////////////////////////////////////////
checkPnl=function(cursor){
   var coord=cursor.xy;
   var form=Ext.get("DTRedactor");
   var coord1=form.getXY();

   var mouseLocalX=(coord[0]-coord1[0]);
   var leftPnl=Ext.get(EI["leftPnl"]);
   var datasetPnl=Ext.get(EI["datasetPnl"]);
   var logSchemePnl=Ext.get(EI["logSchemePnl"]);

   if (mouseLocalX<150 || hasClass(gbi(EI["lbToggleLeftPnl"]),"left-arrow") ){// && ){
      if (hideLeftPnl==false){
         leftPnl.stopFx(true);
         leftPnl.shift({ opacity: 1, easing: 'easeBoth' });
         hideElement(EI["canvasHeaderPnl"]);
         hideLeftPnl=true;
      }
   }else{
     if (hideLeftPnl==true){ 
     	leftPnl.stopFx(true);
        leftPnl.shift({ opacity: 0, easing: 'easeBoth' });
        showElement(EI["canvasHeaderPnl"]);
        hideLeftPnl=false;
     }
   }

	if (mouseLocalX<150 || hasClass(gbi(EI["lbToggleDatasetPnl"]),"left-arrow") ){// && ){
    	if (hideDatasetPnl==false){
      		datasetPnl.stopFx(true);
        	datasetPnl.shift({ opacity: 1, easing: 'easeBoth' });
        	hideDatasetPnl=true;
      	}
   	}else{	
     	if (hideDatasetPnl==true){
        	datasetPnl.stopFx(true); 
        	datasetPnl.shift({ opacity: 0, easing: 'easeBoth' });
         	hideDatasetPnl=false;
     	}
   	}

	if (mouseLocalX<150 || hasClass(gbi(EI["lbToggleLogSchemePnl"]),"left-arrow") ){// && ){
    	if (hideLogSchemePnl==false){
      		logSchemePnl.stopFx(true);
        	logSchemePnl.shift({ opacity: 1, easing: 'easeBoth' });
        	hideLogSchemePnl=true;
      	}
   	}else{	
     	if (hideLogSchemePnl==true){
        	logSchemePnl.stopFx(true); 
        	logSchemePnl.shift({ opacity: 0, easing: 'easeBoth' });
         	hideLogSchemePnl=false;
     	}
   	}
}

isCtrl = false; 
document.onkeydown=function(e){ 
    e = e || event;
    var keyCode = e.keyCode ? e.keyCode : e.which ? e.which : null;
	if(keyCode == 17) isCtrl=true; 
	if(keyCode == 27) graphRedactor.escapeEvent();

}
document.onkeyup=function(e){ 
    e = e || event;
	var keyCode = e.keyCode ? e.keyCode : e.which ? e.which : null;
	if(keyCode == 17) isCtrl=false; 
} 


addClass(gbi(EI["leftHeaderPnl"]),"small-rounded-top header-pnl");
addClass(gbi(EI["leftHeaderPnl2"]),"header-pnl");
addClass(gbi(EI["leftPnl"]),"small_rounded shadow pnl");
addClass(gbi(EI["datasetPnl"]),"small_rounded shadow pnl");
addClass(gbi(EI["logSchemePnl"]),"small_rounded shadow pnl");

addClass(gbi(EI["lbToggleLeftPnl"]),"left-arrow");
addClass(gbi(EI["lbToggleDatasetPnl"]),"left-arrow");
addClass(gbi(EI["lbToggleLogSchemePnl"]),"left-arrow");


//addClass(gbi(EI["btnLeftPnl"]),"cursor-pointer");
addClass(gbi(EI["canvas"]),"canvas-container-100");
addClass(gbi(EI["topPnl"]),"topPnl");


var greyBorderPanel=["groupPanel","rulePanel","datasetPanel","datasetParamPnl","loadRuleNodesPanel",
					 "operationPanel","MatrixParamPanel","matrixCondValue","parameterPanel","subRulePanel",
					 "constantPanel","collectionPanel","intervalPanel","casePanel","ruleResultPanel","testDataSetPnl","logSchemePanel"];

var dd=greyBorderPanel.length;
for (var i=0;i<dd;i++){
	addClass(gbi(EI[greyBorderPanel[i]]),"grey-border");	
}

addClass(gbi(EI["canvasScroller"]),"noborder");
addClass(gbi(EI["canvasHeaderPnl"]),"noborder");
addClass(gbi(EI["addNodeHint"]),"noborder");
addClass(gbi(EI["scalePnl"]),"noborder");

gbi(EI["addNodeHint"]).style.border=0;


var tabs=[
			{"title":getResourceBundle("JS_RULEEDITOR_MENU_2"),
			 "id":"groupRuleTab",
			 "sections":[
						{"title":getResourceBundle("JS_RULEEDITOR_MENU_3"),
						 "buttons":[
									{"title":getResourceBundle("JS_RULEEDITOR_MENU_4")+"<br>"+getResourceBundle("JS_RULEEDITOR_MENU_5"),
									 "help":getResourceBundle("JS_RULEEDITOR_MENU_6"),
									 "img":"newGroup.png",
									 "type":"large",
									 "id":"add-group-btn",
									 "click":groupDialog.addGroupDialogShow
									},
									{"title":getResourceBundle("JS_RULEEDITOR_MENU_7")+"<br>"+getResourceBundle("JS_RULEEDITOR_MENU_5"),
									 "help":getResourceBundle("JS_RULEEDITOR_MENU_8"),
									 "img":"editGroup.png",
									 "type":"large",
									 "id":"edit-group-btn",
									 "click":groupDialog.editGroupDialogShow
									},
									{"title":getResourceBundle("JS_RULEEDITOR_MENU_9")+"<br>"+getResourceBundle("JS_RULEEDITOR_MENU_5"),
									 "help":getResourceBundle("JS_RULEEDITOR_MENU_10"),
									 "img":"delGroup.png",
									 "type":"large",
									 "id":"del-group-btn",
									 "click":groupDialog.delGroupDialogShow
									}
						 ]
						}
			 ]
			},
			{"title":getResourceBundle("JS_RULEEDITOR_MENU_11"),
			 "id":"ruleTab",
			 "sections":[
						{"title":getResourceBundle("JS_RULEEDITOR_MENU_11"),
						 "buttons":[
									{"title":getResourceBundle("JS_RULEEDITOR_MENU_4")+"<br>"+getResourceBundle("JS_RULEEDITOR_MENU_12"),
									 "help":getResourceBundle("JS_RULEEDITOR_MENU_13"),
									 "img":"addRule.png",
									 "type":"large",
                   					 "id":"add-rule-btn",
                   					 "click":ruleDialog.addRuleDialogShow 
									},
									{"title":getResourceBundle("JS_RULEEDITOR_MENU_7")+"<br>"+getResourceBundle("JS_RULEEDITOR_MENU_12"),
									 "help":getResourceBundle("JS_RULEEDITOR_MENU_14"),
									 "img":"editRule.png",
									 "type":"large",
                   					 "id":"edit-rule-btn",
                   					 "click":ruleDialog.editRuleDialogShow
									},
									{"title":getResourceBundle("JS_RULEEDITOR_MENU_9")+"<br>"+getResourceBundle("JS_RULEEDITOR_MENU_12"),
									 "help":getResourceBundle("JS_RULEEDITOR_MENU_15"),
									 "img":"deleteRule.png",
									 "type":"large",
                   					 "id":"delete-rule-btn",
                   					 "click":ruleDialog.delRuleDialogShow
									},
									{"title":getResourceBundle("JS_RULEEDITOR_MENU_16")+"<br>"+getResourceBundle("JS_RULEEDITOR_MENU_17"),
									 "help":getResourceBundle("JS_RULEEDITOR_MENU_18"),
									 "img":"loadRule.png",
									 "type":"large",
									 "id": "load-rule-btn",
									 "click":ruleNodeDialog.loadRuleNodeDialogShow
									}
						 ]
						},
						{"title":getResourceBundle("JS_RULEEDITOR_MENU_19"),
						 "buttons":[
									{"title":getResourceBundle("JS_RULEEDITOR_MENU_20")+"<br>SQL",
									 "help":getResourceBundle("JS_RULEEDITOR_MENU_21"),
									 "img":"exportSQL.png",
									 "type":"large",
									 "id":"exportSQL-rule-btn",
									 "click":exportDataDialog.initSQL
									},
									{"title":getResourceBundle("JS_RULEEDITOR_MENU_20")+"<br>ORACLE",
									 "help":getResourceBundle("JS_RULEEDITOR_MENU_22"),
									 "img":"exportORA.png",
									 "type":"large",
									 "id":"exportORACLE-rule-btn",
									 "click":exportDataDialog.initORACLE
									}						
						 ]
						},
						{"title":getResourceBundle("JS_RULEEDITOR_MENU_23"),
						 "buttons":[
									{"title":getResourceBundle("JS_RULEEDITOR_MENU_24")+"<br>"+getResourceBundle("JS_RULEEDITOR_MENU_25"),
									 "help":getResourceBundle("JS_RULEEDITOR_MENU_26"),
									 "img":"run.png",
									 "type":"large",
									 "id":"run-rule-btn",
									 "click":testDatasetDialog.dialogShow
									},
									{"title":getResourceBundle("JS_RULEEDITOR_MENU_27")+"<br>"+getResourceBundle("JS_RULEEDITOR_MENU_28"),
									 "help":getResourceBundle("JS_RULEEDITOR_MENU_29"),
									 "img":"validate.png",
									 "type":"large",
									 "id":"validate-rule-btn",
									 "click":graphRedactor.validateRule
									},
									{"title":getResourceBundle("JS_RULEEDITOR_MENU_31")+"<br>"+getResourceBundle("JS_RULEEDITOR_MENU_32"),
									 "help":getResourceBundle("JS_RULEEDITOR_MENU_33"),
									 "img":"undo.png",
									 "type":"large",
									 "id":"undo-action-btn",
									 "click":graphRedactor.undoAction
									},
									{"title":getResourceBundle("JS_RULEEDITOR_MENU_34")+"<br>"+getResourceBundle("JS_RULEEDITOR_MENU_35"),
									 "help":getResourceBundle("JS_RULEEDITOR_MENU_36"),
									 "img":"apply.png",
									 "type":"large",
									 "id":"apply-changes-btn",
									 "click":graphRedactor.applyChangeList
									}

						
						 ]
						}
			 ]
			},
			{"title":getResourceBundle("JS_RULEEDITOR_MENU_37"),
			 "id":"datasetTab",
			 "sections":[
						{"title":getResourceBundle("JS_RULEEDITOR_MENU_3"),
						 "buttons":[
									{"title":getResourceBundle("JS_RULEEDITOR_MENU_4")+"<br>"+getResourceBundle("JS_RULEEDITOR_MENU_38"),
									 "help":getResourceBundle("JS_RULEEDITOR_MENU_39"),
									 "img":"addDataset.png",
									 "type":"large",
									 "id":"add-dataset-btn",
									 "click":datasetDialog.addDatasetDialogShow
									},
									{"title":getResourceBundle("JS_RULEEDITOR_MENU_7")+"<br>"+getResourceBundle("JS_RULEEDITOR_MENU_38"),
									 "help":getResourceBundle("JS_RULEEDITOR_MENU_40"),
									 "img":"editDataset.png",
									 "type":"large",
									 "id":"edit-dataset-btn",
									 "click":datasetDialog.editDatasetDialogShow
									},
									{"title":getResourceBundle("JS_RULEEDITOR_MENU_9")+"<br>"+getResourceBundle("JS_RULEEDITOR_MENU_38"),
									 "help":getResourceBundle("JS_RULEEDITOR_MENU_41"),
									 "img":"delDataset.png",
									 "type":"large",
									 "id":"del-dataset-btn",
									 "click":datasetDialog.delDatasetDialogShow
									},
									{"title":getResourceBundle("JS_RULEEDITOR_MENU_42")+"<br>"+getResourceBundle("JS_RULEEDITOR_MENU_43"),
									 "help":getResourceBundle("JS_RULEEDITOR_MENU_44"),
									 "img":"impDataset.png",
									 "type":"large",
									 "id":"import-dataset-btn"
									}

						 ]
						},
						{"title":getResourceBundle("JS_RULEEDITOR_MENU_45"),
						 "buttons":[
									{"title":getResourceBundle("JS_RULEEDITOR_MENU_4")+"<br>"+getResourceBundle("JS_RULEEDITOR_MENU_46"),
									 "help":getResourceBundle("JS_RULEEDITOR_MENU_47"),
									 "img":"addDataset.png",
									 "type":"large",
									 "id":"add-datasetParam-btn",
									 "click":datasetParamDialog.addDatasetParamDialogShow
									},
									{"title":getResourceBundle("JS_RULEEDITOR_MENU_7")+"<br>"+getResourceBundle("JS_RULEEDITOR_MENU_46"),
									 "help":getResourceBundle("JS_RULEEDITOR_MENU_48"),
									 "img":"editDataset.png",
									 "type":"large",
									 "id":"edit-datasetParam-btn",
									 "click":datasetParamDialog.editDatasetParamDialogShow
									},
									{"title":getResourceBundle("JS_RULEEDITOR_MENU_9")+"<br>"+getResourceBundle("JS_RULEEDITOR_MENU_46"),
									 "help":getResourceBundle("JS_RULEEDITOR_MENU_49"),
									 "img":"delDataset.png",
									 "type":"large",
									 "id":"del-datasetParam-btn",
									 "click":datasetParamDialog.delDatasetParamDialogShow
									}
						 ]
						}
			 ]
			},
			{"title":getResourceBundle("JS_RULEEDITOR_MENU_50"),
			 "id":"logSchemeTab",
			 "sections":[
						{"title":getResourceBundle("JS_RULEEDITOR_MENU_3"),
						 "buttons":[
									{"title":getResourceBundle("JS_RULEEDITOR_MENU_4")+"<br>"+getResourceBundle("JS_RULEEDITOR_MENU_51"),
									 "help":getResourceBundle("JS_RULEEDITOR_MENU_52"),
									 "img":"addLogScheme.png",
									 "type":"large",
									 "id":"add-logscheme-btn",
									 "click":logSchemeDialog.addLogSchemeDialogShow
									},
									{"title":getResourceBundle("JS_RULEEDITOR_MENU_7")+"<br>"+getResourceBundle("JS_RULEEDITOR_MENU_51"),
									 "help":getResourceBundle("JS_RULEEDITOR_MENU_53"),
									 "img":"editLogScheme.png",
									 "type":"large",
									 "id":"edit-logscheme-btn",
									 "click":logSchemeDialog.editLogSchemeDialogShow
									},
									{"title":getResourceBundle("JS_RULEEDITOR_MENU_9")+"<br>"+getResourceBundle("JS_RULEEDITOR_MENU_51"),
									 "help":getResourceBundle("JS_RULEEDITOR_MENU_54"),
									 "img":"delLogScheme.png",
									 "type":"large",
									 "id":"del-logscheme-btn",
									 "click":logSchemeDialog.delLogSchemeDialogShow
									}
						 ]
						}
						]
			},



			{"title":getResourceBundle("JS_RULEEDITOR_MENU_55"),
			 "id":"nodeTab",
			 "sections":[
						{"title":getResourceBundle("JS_RULEEDITOR_MENU_3"),
						 "buttons":[
									{"title":getResourceBundle("JS_RULEEDITOR_MENU_4")+"<br>"+getResourceBundle("JS_RULEEDITOR_MENU_56"),
									 "help":getResourceBundle("JS_RULEEDITOR_MENU_57"),
									 "img":"addOperation.png",
									 "type":"large",
									 "id":"add-operation-btn",
									 "click":graphRedactor.addOperationClick
									},
									{"title":getResourceBundle("JS_RULEEDITOR_MENU_4")+"<br>"+getResourceBundle("JS_RULEEDITOR_MENU_58"),
									 "help":getResourceBundle("JS_RULEEDITOR_MENU_59"),
									 "img":"addMatrix.png",
									 "type":"large",
									 "id":"add-matrix-btn",
									 "click":graphRedactor.addMatrixClick
									},
									{"title":getResourceBundle("JS_RULEEDITOR_MENU_4")+"<br>"+getResourceBundle("JS_RULEEDITOR_MENU_60"),
									 "help":getResourceBundle("JS_RULEEDITOR_MENU_61"),
									 "img":"addParameter.png",
									 "type":"large",
									 "id":"add-parameter-btn",
									 "click":graphRedactor.addParameterClick
									},
									{"title":getResourceBundle("JS_RULEEDITOR_MENU_4")+"<br>"+getResourceBundle("JS_RULEEDITOR_MENU_62"),
									 "help":getResourceBundle("JS_RULEEDITOR_MENU_63"),
									 "img":"addSubRule.png",
									 "type":"large",
									 "id":"add-subrule-btn",
									 "click":graphRedactor.addRuleClick
									},
									{"title":getResourceBundle("JS_RULEEDITOR_MENU_4")+"<br>"+getResourceBundle("JS_RULEEDITOR_MENU_64"),
									 "help":getResourceBundle("JS_RULEEDITOR_MENU_65"),
									 "img":"addConstant.png",
									 "type":"large",
									 "id":"add-constant-btn",
									 "click":graphRedactor.addConstantClick
									},
									{"title":getResourceBundle("JS_RULEEDITOR_MENU_4")+"<br>"+getResourceBundle("JS_RULEEDITOR_MENU_66"),
									 "help":getResourceBundle("JS_RULEEDITOR_MENU_67"),
									 "img":"addCollection.png",
									 "type":"large",
									 "id":"add-collection-btn",
									 "click":graphRedactor.addCollectionClick
									},
									{"title":getResourceBundle("JS_RULEEDITOR_MENU_4")+"<br>"+getResourceBundle("JS_RULEEDITOR_MENU_68"),
									 "help":getResourceBundle("JS_RULEEDITOR_MENU_69"),
									 "img":"addInterval.png",
									 "type":"large",
									 "id":"add-interval-btn",
									 "click":graphRedactor.addIntervalClick
									},
									{"title":getResourceBundle("JS_RULEEDITOR_MENU_4")+"<br>"+getResourceBundle("JS_RULEEDITOR_MENU_70"),
									 "help":getResourceBundle("JS_RULEEDITOR_MENU_71"),
									 "img":"addCase.png",
									 "type":"large",
									 "id":"add-case-btn",
									 "click":graphRedactor.addCaseClick
									 }
									//,
									// {"title":"Редактировать<br>узел",
									//  "help":"Эта кнопка вызывает диалог изменения выбранного узла правила",
									//  "img":"editGroup.png",
									//  "type":"large",
									//  "id":"edit-rulenode-btn"
									// },
									// {"title":"Удалить<br>узел",
									//  "help":"Эта кнопка вызывает удаление выбранного узла (узлов) правила",
									//  "img":"delGroup.png",
									//  "type":"large",
									//  "id":"del-rulenode-btn"
									// }
						 ]
						}
			 ]
			}			
		];


resizeData=[
			{"id": EI["wrapper"],
			 "width":"100%",
			 "height":"100%",
			 "display":"block",
			 "childs":[
						{"id":EI["scalePnl"],
						 "right":"20",
						 "bottom":"20",
						 "display":"inline"
						},
						{"id":EI["topPnl"],
						 "width":"100%",
						 "display":"block"
						},
						{"id":EI["canvasScroller"],
						 "width":"100%",
						 "height":"100%",
						 "display":"block",
						 "childs":[
						 			{"id":EI["canvas"],
						 			 "display":"block"
						 			}
						 ]
						}
					  ]
				}
			];

				

//Create ribbon menu		
ribbonMenu=createRibbon(EI["topPnl"],getResourceBundle("JS_RULEEDITOR_MENU_1"),tabs, js.rootUrl+"GraphRedactor/img/ribbon");
