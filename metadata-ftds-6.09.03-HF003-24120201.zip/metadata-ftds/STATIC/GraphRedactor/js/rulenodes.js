/////////////////////////////////////////////////////////////////
RuleNodeDialogConstructor=function(){
	var ruleNodeDialog=new Object();
	ruleNodeDialog.curoper="none";
 	
 	ruleNodeDialog.selectedRuleID=null;
  ruleNodeDialog.selectedRuleName=null;
  ruleNodeDialog.curLoadNodeIndex=null;
  ruleNodeDialog.RuleNodes=null;
  ruleNodeDialog.LoadedRuleNodes=[];
  
  ruleNodeDialog.loadwindow=createSimpleModal2(EI["loadRuleNodesPanel"],null,false);
  
  /////////////////////////////////////////////////////////////////////////////
  ruleNodeDialog.getRuleNodesByParams=function(params,callback){
    lgr("ruleNodeDialog.getRuleNodesByParams");    
    callback = callback==null ? "ruleNodeDialog.fillRuleNodes" : callback; 
    if (callback=="ruleNodeDialog.fillRuleNodes"){
      ruleNodeDialog.selectedRuleNodeID=null;
    }
    params= params!=null ? params : getNewMap();
    params['ORDERBY']= params['ORDERBY']==null ? "RULENODEID" :params['ORDERBY'];
    dsCall("[dmsws]","ruleNodeGetListByParams",params,callback)
  }
  ////////////////////////////////////////////////////////////////////
  ruleNodeDialog.loadRuleNodeDialogShow=function(params){
    lgr("ruleNodeDialog.loadRuleNodeDialogShow");
    params=nvl(params,[]);
    if (gbi("load-rule-btn").isEnabled() || params["selectedRuleID"]!=null){
      if (graphRedactor.changeList.length==0 || (graphRedactor.changeList.length>0 && showConfirm(getResourceBundle("JS_RULEEDITOR_RULENODES_1")))){
      }else{
        return;
      }
      graphRedactor.changeList=[];
      graphRedactor.slider.setValue(100);
      graphRedactor.set.remove();
      delete graphRedactor.set;
      graphRedactor.set=graphRedactor.r.set();
      testDatasetDialog.dialogHide();
      toggleLeftPanel(false);
      toggleDatasetPanel(false);
      ruleNodeDialog.selectedRuleID=nvl (params["selectedRuleID"],ruleDialog.selectedRuleID);
      ruleNodeDialog.selectedRuleName=ruleDialog.selectedRuleName;
      setValue(EI["WLabel12"],getResourceBundle("JS_RULEEDITOR_RULENODES_2"));
      ruleNodeDialog.loadwindow.show(ruleNodeDialog.loadwindow);
      showElement(EI["loadRuleNodesPanel"]);
      ruleNodeDialog.LoadedRuleNodes=[];
      ruleNodeDialog.getRuleNodesByParams({"RULEID":ruleNodeDialog.selectedRuleID},"ruleNodeDialog.loadingRuleNodes");   
    }
  }
  ////////////////////////////////////////////////////////////////////
  ruleNodeDialog.loadingRuleNodes=function(p){
    lgr("ruleNodeDialog.loadingRuleNodes");
    if (p["Status"]=="OK"){
      var p=p["Result"];
      if (p!=null && p!==""){
        var dd=p.length;
        ruleNodeDialog.RuleNodes=p;
        ruleNodeDialog.curLoadNodeIndex=0;
        if (dd>0){
          var ruleNodeID=p[0]["RULENODEID"];        
          ruleNodeDialog.getRuleNodeByID({"RULENODEID":ruleNodeID},"ruleNodeDialog.loadRuleNode");
        }else{
          setValue(EI["loadNodesProgress"],formatAmount(80,2));
          ruleDialog.getRulesByParams({"RULEID":ruleDialog.selectedRuleID},"ruleNodeDialog.onAfterLoadRule");
        }
      }
    }else{
      showAlert(getResourceBundle("JS_RULEEDITOR_RULENODES_3"));
    }
  }
  ////////////////////////////////////////////////////////////////////
  ruleNodeDialog.getRuleNodeByID=function(params,callback){
    params= params!=null ? params : getNewMap();    
    dsCall("[dmsws]","ruleNodeGetById",params,callback)
  }
  ////////////////////////////////////////////////////////////////////
  ruleNodeDialog.loadRuleNode=function(p){
    lgr("ruleNodeDialog.loadRuleNode");
    if (p["Status"]=="OK"){
      p=p["Result"];
      //lgr(p);
      ruleNodeDialog.LoadedRuleNodes.push(p);
      if ((ruleNodeDialog.curLoadNodeIndex+1)<ruleNodeDialog.RuleNodes.length){
        setValue(EI["loadNodesProgress"],formatAmount(ruleNodeDialog.curLoadNodeIndex/(ruleNodeDialog.RuleNodes.length)*80,2));
        ruleNodeDialog.curLoadNodeIndex=ruleNodeDialog.curLoadNodeIndex+1;
        ruleNodeDialog.getRuleNodeByID({"RULENODEID":ruleNodeDialog.RuleNodes[ruleNodeDialog.curLoadNodeIndex]["RULENODEID"]},"ruleNodeDialog.loadRuleNode");
      }else{
        setValue(EI["loadNodesProgress"],formatAmount(80,2));
        ruleDialog.getRulesByParams({"RULEID":ruleDialog.selectedRuleID},"ruleNodeDialog.onAfterLoadRule");
      }
    }else{
      showError(getResourceBundle("JS_RULEEDITOR_RULENODES_4"));
    }
  }
  ////////////////////////////////////////////////////////////////////
  ruleNodeDialog.onAfterLoadRule =function(p){
    lgr("ruleNodeDialog.onAfterLoadRule");
    if (p["Status"]=="OK"){
      p=p["Result"];
      p=p[0];
      graphRedactor.loadedRuleData=p;
      setValue(EI["loadNodesProgress"],formatAmount(90,2));
      datasetParamDialog.getDatasetParamByParams ({"DATASETID":graphRedactor.loadedRuleData["DATASETID"]},"ruleNodeDialog.onAfterLoadRuleDataset"); 
    }else{
      showError(getResourceBundle("JS_RULEEDITOR_RULENODES_5"));
    }
  }
  ////////////////////////////////////////////////////////////////////
  ruleNodeDialog.onAfterLoadRuleDataset=function(p){
    lgr("ruleNodeDialog.onAfterLoadRuleDataset");
    if (p["Status"]=="OK"){
      p=p["Result"];
      graphRedactor.loadedRuleDatasetParams=p;
      
      var dd=p.length;
      clearComboOptions(EI["cmMatrixParamType"]);
      for (var i=0;i<dd;i++){
        addComboOption(EI["cmMatrixParamType"],p[i]["DATASETPARAMID"],p[i]["SYSNAME"])
      }

      var RULEIDS=getNewList();
      dd=ruleNodeDialog.LoadedRuleNodes.length;
      for (var i=0;i<dd;i++){
        var ruleNode=ruleNodeDialog.LoadedRuleNodes[i];
        if (graphRedactor.nodeTypes[ruleNode["NODETYPE"]]=="Rule"){
          RULEIDS.push(ruleNode["VALUEID"]);
        }
      }
      ruleDialog.getRulesByParams({"DATASETID":graphRedactor.loadedRuleData["DATASETID"]},"ruleNodeDialog.onAfterLoadRules");
    }else{
      showError(getResourceBundle("JS_RULEEDITOR_RULENODES_6"));
    }
  }
  ////////////////////////////////////////////////////////////////////
  ruleNodeDialog.generateGraph=function(){
    ruleNodeDialog.RuleNodes=null;
    ruleNodeDialog.curLoadNodeIndex=null;
    ruleNodeDialog.loadwindow.hide(ruleNodeDialog.loadwindow); 
    setValue(EI["loadNodesProgress"],formatAmount(0,2));
    graphRedactor.generateGraph(); 
  }
  ////////////////////////////////////////////////////////////////////
  ruleNodeDialog.onAfterLoadRules=function(p){
    lgr("ruleNodeDialog.onAfterLoadRules");
    if (p["Status"]=="OK"){
      p=p["Result"];
      graphRedactor.loadedSubRules=p;
      setValue(EI["loadNodesProgress"],formatAmount(100,2));
      ruleNodeDialog.loadRuleCoord();
    }else{
      showError(getResourceBundle("JS_RULEEDITOR_RULENODES_7"));
    }
  }
  ////////////////////////////////////////////////////////////////////
  ruleNodeDialog.loadRuleCoord=function(){
      ruleNodeDialog.settingsGetByParams({"SYSNAMETYPE":"DTRedactorCoord",
                                          "SYSNAMECONSTANT":graphRedactor.loadedRuleData["RULEGROUPSYSNAME"]+"#"+graphRedactor.loadedRuleData["SYSNAME"]},
                                          "ruleNodeDialog.onAfterGetRuleCoord");   
  }
  //////////////////////////////////////////////////////////////////
  ruleNodeDialog.settingsGetByParams=function(params,callback){
    params= params!=null ? params : getNewMap();    
    dsCall("[frontws2]","settingsGetByParams",params,callback);
  }
  //////////////////////////////////////////////////////////////////
  ruleNodeDialog.onAfterGetRuleCoord=function(p){
    lgr("ruleNodeDialog.onAfterGetRuleCoord");
    if (p["Status"]=="OK"){
      p=p["Result"];
      lgr(p);
      var PARAMS=nvl(p["PARAMS"],[]);
      lgr(PARAMS);
      graphRedactor.loadedNodeCoordList=PARAMS["nodeCoordList"];
      lgr(graphRedactor.loadedNodeCoordList);
    }
    ruleNodeDialog.generateGraph();
  }
  ////////////////////////////////////////////////////////////////////
  ruleNodeDialog.add=function(prms,callback){
    lgr("ruleNodeDialog.add");
    prms=nvl(prms,getNewMap());
    callback=nvl(callback,"ruleNodeDialog.onAfterAddRuleNode")
    dsCall("[dmsws]","ruleNodeCreate",prms,callback);
  }
  ////////////////////////////////////////////////////////////////////
  ruleNodeDialog.edit=function(prms,callback){
    lgr("ruleNodeDialog.edit");
    prms=nvl(prms,getNewMap());
    callback=nvl(callback,"ruleNodeDialog.onAfterEditRuleNode");
    dsCall("[dmsws]","ruleNodeModify",prms,callback);
  }
  //////////////////////////////////////////////////////////////////////
  ruleNodeDialog.del=function(prms,callback){
    lgr("ruleNodeDialog.delete");
    prms=nvl(prms,getNewMap());
    lgr(prms);
    callback=nvl(callback,"ruleNodeDialog.onAfterDeleteRuleNode");
    dsCall("[dmsws]","ruleNodeDelete",prms,callback);    
  }


  return ruleNodeDialog;
}

ruleNodeDialog=RuleNodeDialogConstructor();