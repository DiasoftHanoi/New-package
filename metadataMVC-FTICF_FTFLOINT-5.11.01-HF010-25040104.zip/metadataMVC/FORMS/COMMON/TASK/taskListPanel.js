/*DSMETA version = "5.11.01-HF010-25040104" hash = "9d3d59a4749be51459e32fa664bc4fe5223c7134"*/
function registerMethod(initService){
    var service={};
    for (var ar in initService){
        if (initService.hasOwnProperty(ar)){
            if (ar.indexOf('Service')>-1 || typeof (initService[ar]) != 'function'){
                service[ar]=initService[ar];
            }else{
                var fn=initService[ar].toString();
                var sIdx=fn.search(/\(/)+1;
                var eIdx=fn.search(/\)\{/);
                var args=fn.substring(sIdx,eIdx);
                eval("service."+ar+"=function("+args+")"+fn.substring(eIdx+1,fn.length));
            }
        }
    }
    return service
}
service=registerMethod(service);

var inputParams = form.inputParams || {};
var outputParams = form.outputParams || {};
form.searchParams = inputParams.searchParams || {};

var lgr = service.lgr;
var nvl = service.nvl;
var gRB = function(key){
    return service.nvl(form.localize[key],key);
};

form.onShow = function () {
    var requiredElements = ["cbTaskResponsible"];
    if (inputParams.rightOrgStructure) {
        requiredElements.push("cbOrgNode");
    }
    form.params.requiredElements = requiredElements;
    form.searchParams.TaskTypeBrief = undefined;
    form.searchParams.CurrentUserID = undefined;
    form.searchParams.clientExtObjID = undefined;
    form.searchParams.STATESYSNAME = "ALL";
    form.searchParams.PerformerKind = 3;
    form.onChangeShowOnly(true);
};

form.cbOrgNodeParams={};
form.periodItems = [
    {value:"today", text:gRB("list.calendar.today")},
    {value:"today_yesterday", text:gRB("list.calendar.todayYesterday")},
    {value:"last_week", text:gRB("list.calendar.lastWeek")},
    {value:"last_month", text:gRB("list.calendar.lastMonth")},
    {value:"period", text:gRB("list.calendar.period")},
    {value:"date", text:gRB("list.calendar.date")}
];

form.onChangePeriod = function (item){
    var dateStart = utils.curDateJS();
    var dateEnd = utils.curDateJS();
    switch (item.value){
        case "today":
            dateEnd.setDate(dateEnd.getDate()+1);
            break;
        case "today_yesterday":
            dateStart.setDate(dateStart.getDate()-1);
            dateEnd.setDate(dateEnd.getDate()+1);
            break;
        case "last_week":
            dateStart.setDate(dateStart.getDate()-7);
            dateEnd.setDate(dateEnd.getDate()+1);
            break;
        case "last_month":
            dateStart.setMonth(dateStart.getMonth()-1);
            dateEnd.setDate(dateEnd.getDate()+1);
            break;
    }

    form.searchParams.MINDATE = (form.searchParams.PERIOD) ? utils.jsDateToJsonDate(dateStart) : "";
    form.searchParams.MAXDATE = (form.searchParams.PERIOD) ? utils.jsDateToJsonDate(dateEnd) : "";

    form.searchParams.StartDate = (form.searchParams.PERIOD) ? dateStart : "";
    form.searchParams.EndDate = (form.searchParams.PERIOD) ? dateEnd : "";

    lgr(form.searchParams);
};

form.params = {
    taskCurrentUser: {
        lkpParams: {
            ROLEID: form.searchParams.PerformerID,
            DepartmentIDList: [form.searchParams.DepartmentID],
            EmployeeStatus: 'ACTIVE'
        }
    },
    roleList : [],
    departmentDef: (!Boolean(form.searchParams.isCommonTasksGroupFlag)) ? angular.copy(form.searchParams.DepartmentID) : undefined
};

form.onSearch = function () {
    if (!inputParams.rightOrgStructure && !form.cbOrgNode.getValue()) {
        form.showErrorDialog(gRB("rightOrganizationErrMsg"), function () {}, [{
            caption: gRB('dialog.ok')
        }]);
        return;
    }
    var params = angular.copy(form.searchParams);
    if (params.PERIOD === 'period') {
        params.StartDate = service.convertToDate(nvl(form.startDate.getValue(), params.StartDate));
        params.EndDate = service.convertToDate(nvl(form.endDate.getValue(), params.EndDate));
        params.EndDate = moment(params.EndDate).second(0).minute(59).hour(23).milliseconds(0).toDate();
    }
    if (params.PERIOD === 'date') {
        params.StartDate = service.convertToDate(nvl(form.nowDate.getValue(), params.StartDate));
        params.EndDate = moment(params.StartDate).second(0).minute(59).hour(23).milliseconds(0).toDate();
    }

    var TaskStatusBriefList = [];
    if (params.STATESYSNAME) {
        TaskStatusBriefList.push(params.STATESYSNAME);
    }
    params['TaskStatusBriefList'] = TaskStatusBriefList;
    if (params.TaskTypeBrief == 'ALL') {
        delete params.TaskTypeBrief;
    }
    params["PerformerID"] = form.searchParams.PerformerID;
    params["clientExtObjID"] =  form.searchParams.clientExtObjID;

    form.command({
        event: 'SEARCH',
        params: params
    });

};

form.onClearSearchParams = function(){
    form.searchParams.TaskTypeBrief = undefined;
    form.searchParams.PerformerID = undefined;
    orm.searchParams.clientExtObjID = undefined;
    form.searchParams.STATESYSNAME = "ALL";
    form.searchParams.PERIOD = 'last_week';
    form.searchParams.CurrentUserID = (!Boolean(form.searchParams.isCommonTasksGroupFlag)) ? inputParams.USERID : undefined;
    form.searchParams.showOnly     = 'subordinate';
    if (!inputParams.rightOrgStructure) {
        form.cbOrgNode.items = [];
        form.cbOrgNode.value = undefined;
    }
    form.searchParams.DepartmentID = (!Boolean(form.searchParams.isCommonTasksGroupFlag)) ? form.params.departmentDef : undefined;
};

form.showOnlyItems = [
    {value:"assigned",    text:"${showOnlyAssigned}"},
    {value:"subordinate", text:"${showOnlySubordinate}"}
];

form.onChangeShowOnly = function (flag){
    form.cbTaskResponsible.clearItems();
    form.cbTaskResponsible.setValue();
    form.searchParams.CurrentUserID = inputParams.USERID;
    if (inputParams.isTaskAdmin && !inputParams.isSuperUser) {
        if(form.cbShowOnly && form.cbShowOnly.getValue() == 'subordinate'){
            form.params.roleList = inputParams.userListTaskAdmSub;
            form.searchParams.CurrentUserID = undefined;
        } else{
            form.params.roleList = inputParams.userListTaskAdmAssign;
        }
    } else {
        form.params.roleList = inputParams.roleList;
    }
    if (form.params.roleList.length == 1) {
        form.searchParams.PerformerID = form.params.roleList[0]["ROLEID"];
    }
    if (!inputParams.rightOrgStructure) {
        form.cbOrgNode.items = [];
        form.cbOrgNode.value = undefined;
    }
    form.cbTaskResponsible.setItems(form.params.roleList);
    form.searchParams.DepartmentID = (!Boolean(form.searchParams.isCommonTasksGroupFlag)) ? form.params.departmentDef : form.searchParams.DepartmentID; //2377081	TPBANK Форма Task LIst
    //form.searchParams.DepartmentID = (!Boolean(form.searchParams.isCommonTasksGroupFlag)) ? form.params.departmentDef : undefined;
    if (!flag) {
        form.onSearch();
    }
};

form.assigneeTypeItems = [
    {value : 3, text : "${assigneeTypeRole}"},
    {value : 2, text : "${assigneeTypeGroup}"}
];

form.onChangecbTaskResponsible=function (){
    form.params.taskCurrentUser.lkpParams.ROLEID = form.cbTaskResponsible.getValue();
    form['cbTaskCurrentUser'] ? form['cbTaskCurrentUser'].refresh() : undefined;
};

form.onChangecbOrgNode = function() {
    form.params.taskCurrentUser.lkpParams.DepartmentIDList = form.searchParams.DepartmentID != null ? [form.searchParams.DepartmentID] : [];
    if (form.cbTaskCurrentUser && form.cbTaskCurrentUser.isEnabled()) { // Переначитываем, если активен
        form['cbTaskCurrentUser'].refresh();
    }
};