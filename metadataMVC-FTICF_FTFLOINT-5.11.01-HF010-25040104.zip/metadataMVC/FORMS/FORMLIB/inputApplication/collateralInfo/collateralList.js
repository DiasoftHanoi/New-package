/*DSMETA version = "5.11.01-HF010-25040104" hash = "c8b888785da0619f111c4dff56257e1cde829faf"*/
/* global form, service */

function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
service = registerMethod(service);

var inputParams = form.inputParams || {};
form.formParams = inputParams.formParams;

var outputParams = form.outputParams || {};
outputParams.formParams = form.formParams;

var lgr = service.lgr;
var nvl = service.nvl;
var gRB = service.gRB;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);

form.isFormEditMode = form.inputParams.EDITMODE || false;

var linkedAppParams = inputParams.PARAMS || {};
linkedAppParams.DOCUMENTTYPEID = inputParams.DOCUMENTTYPEID;
linkedAppParams.MAINAPPLICATIONID = inputParams.APPLICATIONID;
linkedAppParams.EDITMODE = form.isFormEditMode;

form.data = {
    actionAdd           : Boolean(linkedAppParams.actionAdd),
    actionEdit          : Boolean(linkedAppParams.actionEdit),
    actionDelete        : Boolean(linkedAppParams.actionDelete),
    actionView          : Boolean(linkedAppParams.actionView),
    isCollateralAddFlag : Boolean(linkedAppParams.isCollateralAddFlag),
    collateralList      : inputParams.collateralList
};

form.onShow = function () {
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });

    if (!form.isFormEditMode) {
        if (form.btnNext) {
            form.btnNext.setFocus();
        }
        else if (form.btnSave) {
            form.btnSave.setFocus();
        }
        else {
            form.btnCancel.setFocus();
        }
    }
};

form.executeCommand = function (msg) {
    switch (msg.event) {
        case 'FAB_NAVIGATOR_NAVIGATE':
            outputParams.NEXTPAGE = msg.params.step;
            form.action('DIRECT');
        break;
        default:
        break;
    }
};

var sendMessage = function (message) {
    var PROCESS_RIGHT_LIST = getInputParams("PROCESS_RIGHT_LIST");
    if (PROCESS_RIGHT_LIST) {
        for (var ar in PROCESS_RIGHT_LIST) {
            form.commandRight(ar, message);
        }
    }
};

form.action = function (tag) {
    outputParams.TRANSTYPE = tag;
    if (tag === 'CLOSE') {
        if(form.isFormEditMode !== false) {
            if(!form.data.isCollateralAddFlag) {
                service.showDialogCancelConfirm(
                    form,
                    form.yesFunc
                )
            } else{
                form.sendForm('GO', false);
            }

        } else{
            form.sendForm('GO', false);
        }
    } else {
        form.outputParams.VERIFIED = true;
        if (form.isFormEditMode === false && form.isLastWizForm) {
            if (tag == 'NEXT') {
                outputParams.TRANSTYPE="CLOSE";
            }
        }
        form.sendForm("GO", false);
    }
};

form.getMainCollateralType = function (list, row) {
    if (list) {
        for (var i = 0, countI = list.length; i < countI; i++) {
            if (list[i].sysnameTypeCollateral == "main") {
                if (row != undefined) {
                    if (list[i].LinkID == row.LinkID) {
                        continue;
                    }
                }
                return true;
            }
        }
    }
    return false;
};

form.tblCollateralListObj = (function (grId) {
    var gridId = grId;
    var options = {
        edit: function () {
            form.btnCollateralListAdd.disable();
            var selectedRow = form.tblCollateralListTable.getSelectedRow()[0];
            linkedAppParams.EDITMODE = true;
            var params = {
                COLLATERALMODE   : "EDIT",
                formParams  : selectedRow,
                extraParams : linkedAppParams,
                MAINAPPLICATIONID : inputParams.APPLICATIONID,
                APPLICATIONID : (selectedRow) ? selectedRow.DOCUMENTID : "",
                mainCollateralTypeFlag : form.getMainCollateralType(inputParams.collateralList, selectedRow),
                STAGESYSNAME : inputParams.STAGESYSNAME
            };
            form.actionEditCollateralApp(params);
        },
        delete: function () {
            form.actionDeleteCollateral();
        },
        view: function () {
            var selectedRow = form.tblCollateralListTable.getSelectedRow()[0];
            if (form.btnCollateralListAdd)
                form.btnCollateralListAdd.disable();
            var params = {
                COLLATERALMODE   : "VIEW",
                formParams  : selectedRow,
                extraParams : linkedAppParams,
                MAINAPPLICATIONID : inputParams.APPLICATIONID,
                APPLICATIONID : (selectedRow) ? selectedRow.DOCUMENTID : "",
                STAGESYSNAME : inputParams.STAGESYSNAME
            };
            form.actionEditCollateralApp(params);
        }
    };
    var obj = {
        gridId: grId,
        refresh: function () {
            form[gridId].refresh();
        },
        onChangeItems: function () {
        },
        addNewRow: function () {
            var collateralInfoParam = {
                subjectList : inputParams.subjectList,
                APPLICATIONID : inputParams.APPLICATIONID
            };
            form.startModalPageFlowProcess(form.getCurrentProjectSysname() + "/FORMLIB/inputApplication/collateralInfo/addCollateral", collateralInfoParam).then(function (response) {
                if (!response || response.COLLATERALMODE != 'ADD') {
                    return;
                }
                var params = {
                    formParams  : response.formParams,
                    COLLATERALMODE   : response.COLLATERALMODE,
                    extraParams : linkedAppParams,
                    MAINAPPLICATIONID : inputParams.APPLICATIONID,
                    mainCollateralTypeFlag : form.getMainCollateralType(inputParams.collateralList),
                    STAGESYSNAME : inputParams.STAGESYSNAME
                };
                form.actionEditCollateralApp(params);
            });
        },
        setItems: function (items) {
            form[gridId].setItems(items);
        },
        getItems: function () {
            return form[gridId].getItems();
        },
        onSelectRow: function () {
            options.items = [];
            var selectedRow = form.tblCollateralListTable.getSelectedRow()[0];
            if (form.data.actionEdit) {
                options.items.push({caption: gRB('edit'), click: form.tblCollateralListTable.options.edit});
            }
            if (form.data.actionDelete) {
                options.items.push({caption: gRB('delete'), click: form.tblCollateralListTable.options.delete});
            }
            if (form.data.actionView) {
               options.items.push({caption: gRB('view'), click: form.tblCollateralListTable.options.view});
            }
        }
    };
    obj.options = options;
    return obj;
})('tblCollateralList');

form.actionEditCollateralApp = function(params) {
    if (form.btnCollateralListAdd)
        form.btnCollateralListAdd.disable();
    form.startNewPageFlowProcess("${collateral}",  form.getCurrentProjectSysname() + '/' + 'FORMLIB/inputCollateralApp/inputCollateralInformation', params, true, null, function(p){
        if (form.tblCollateralListTable) {
            form.startProcess(
                form.getCurrentProjectSysname() + "/FORMLIB/inputApplication/collateralInfo/getCollateralList",
                params,
                function (p) {
                    form.getCollateralList();
                }
            );
        }
    });
};

form.actionDeleteCollateral = function () {
    form.btnCollateralListAdd.disable();
    form.showQuestionDialog(gRB("dialog.confirmDelete"),
        function (response){
            switch (response.buttonIndex){
                case 0:
                    var selectedRow = form.tblCollateralListTable.getSelectedRow()[0];
                    var params = {
                        APPLICATIONID : selectedRow.DOCUMENTID,
                        deleteCollateral : selectedRow,
                        transSysName : linkedAppParams.transSysName,
                        STAGESYSNAME : inputParams.STAGESYSNAME
                    };
                    form.startProcess(
                        form.getCurrentProjectSysname() + "/FORMLIB/inputApplication/collateralInfo/deleteCollateral",
                        params,
                        function (p) {
                            form.getCollateralList();
                        }
                    );
                    break;
                case 1:
                    break;
            }
        },
        [
            {caption: gRB('dialog.yes')},
            {caption: gRB('dialog.no')}
        ]
    )
};

form.getCollateralList = function () {
    var params = {
        LINKTYPENAMES : inputParams.LINKTYPENAMES,
        APPLICATIONID : inputParams.APPLICATIONID,
        appMap        : inputParams.appMap
    };
    form.startProcess(
        form.getCurrentProjectSysname() + "/FORMLIB/inputApplication/collateralInfo/getCollateralList",
        params,
        function (p) {
            var collateralList = p.collateralList || [];
            if (collateralList) {
                form.tblCollateralListTable.setItems(collateralList);
                form.tblCollateralListTable.setSelectedRow(undefined);
                form.btnCollateralListAdd.enable();
                inputParams.subjectList = p.subjectList;
                inputParams.collateralList = p.collateralList;
            }
        }
    );
};