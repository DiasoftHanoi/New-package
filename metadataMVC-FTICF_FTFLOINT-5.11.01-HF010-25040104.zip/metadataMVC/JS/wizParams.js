/*DSMETA version = "5.11.01-HF010-25040104" hash = "18806d508b53271f89b5ba02ecdddd7796313309"*/
/* состав мап в wizard params*/

var wizardParamsRef = {
    appMap:[
        "DOCTYPENAME",                  //Тип заявки
        "STATE",                        //Состояние заявки
        "CREATIONDATE",                 //Дата создания заявки
        "DOCUMENTNUMBER",               //Номер заявки
        "DOCUMENTID",                   //Идентификатор заявки
        "TYPESYSNAME",                  //Тип заявки
        "bankProductId",                //ID банковского продукта
		"bankProductSysName",           //Сиснейм банковского продукта
        "bankProductName",              //Наименование банковского продукта
        "bankProductBrief",             //Крат наим банковского продукта
        "bankProductGroupId",           //Идентификатор группы банковских продуктов
        "bankProductGroupName",         //Наименование группы банковских продуктов
        "EmploymentList",               // Employment List
        "employmentOccupation",
        "NumberDependentsChild",        //Number Dependents Child
        "NumberDependentsOther",        //Number Dependents Other
        "LivingStandard",               //Living Standard
        "LivingEnvironment",            //LivingEnvironment
        "MaritalStatusText",            //MaritalStatusText
        "EducationTypeBriefText",       //EducationTypeBriefText
        "typeOfPropertyPermanentAddress",
        "typeOfPropertyCurrentAddress",
        "typeOfPropertyPermanentAddressText",
        "typeOfPropertyCurrentAddressText",
        "typeOfPropertyOtherPermanentAddress",
        "typeOfPropertyOtherCurrentAddress",
        "clientPostAddressIsSameAs",
        "clientRegisterAddressIsSameAs",
        "clientPermanentAddressIsSameAs",
        "clientFactAddressIsSameAs",
        "clientWorkAddressIsSameAs",
        "clientTemporaryRegisterAddressIsSameAs",
        "clientAge",
        "clientExtObj",               // CIF
        "leadSource",
        "leadID",
        "overdueDebtGroup2AndAbove",
        "smsInformingSysName",          //additionalInfo
        "smsInforming",
        "checkProductPolicy",
        "promotionProgramCode",
        "selectedNumber",
        "emailInformingSysName",
        "emailInforming",
        "selectedAddress",
        "comment",
        "spouseCoborrower",
        "clientGender", //пол клиента в дополнительный параметр заявки
        "clientCitizenship",//гражданство клиента
        "clientIsResident",//резидентность клиента
        "clientFactLiveAddressRegion", //регион адреса фактического проживания клиента
        "clientPermLiveAddressRegion", //регион адреса постоянного проживания клиента
        "channelSales",
        "channelSalesSysName",
        "DETAILS",
        "REFSYSNAME",
		"loanSubproduct",
        "loanSubproductName",
        //////////////////////Product Information(Mortgage)//////
        "loanPurposeSysName", //Product Information(Mortgage), Product Information(AUTO), Product Information (Unsecured Consumer Loan)
        "loanPurpose", //Product Information(Mortgage), Product Information (Unsecured Consumer Loan), Product Information(AUTO)
        "loanPurposeDetail", //Product Information(AUTO)
        "loanPurposeForCapital",
        "loanPurposeForCapitalSysName",
        "ownerSysName",
        "objectOwner",
        "ownerRelative",
        "withdrawalTerm", //Product Information(AUTO)
        "paymentDate", //Product Information(AUTO)
        "principalRepaymentMethodSysName", //Product Information(AUTO), Product Information(CreditCard)
        "principalRepaymentMethod", //Product Information(AUTO), Product Information(CreditCard)
        "interestRepaymentMethodSysName", //Product Information(AUTO), Product Information(CreditCard)
        "interestRepaymentMethod", //Product Information(AUTO), Product Information(CreditCard)
        "costOfObject", //Product Information(AUTO)
        "firstPayment", //Product Information(AUTO)
        "loanCurrency",
        "loanAmount", //Product Information(AUTO), Product Information (Unsecured Consumer Loan)
        "loanTerm", //Product Information(AUTO), Product Information(CreditCard), Product Information (Unsecured Consumer Loan)
        "interestRate", //Product Information(AUTO), Product Information(CreditCard), Product Information (Unsecured Consumer Loan)
        "gracePeriod",
        "subproductList",
        "feeList",
        "disbursmentMethod", //Product Information(AUTO)
        "disbursmentMethodOther", //Product Information(AUTO)
        "commission", //Product Information(AUTO)
        "conditionsBeforeDisbursement", //Condition Information
        "conditionsAfterDisbursement", //Condition Information
        "checksConditionsAfterDisbursement", //Condition Information
        "otherConditions", //Condition Information
        "exceptions", //Condition Information
        //////////////////////END Product Information(Mortgage)//////
        "referencePersonList", //было + используется в Reference Person (Unsecured Consumer Loan)
        "RelationshiWithBorrowerSysName",
        "RelationshiWithBorrower",
        "relationshiWithBorrowerOther",
        "assetsList",
        "incomeList",
        "revenueList",
        "expenseList",
        "CreditHistoryLoans",
        "loansNumberCreditHistory",
        "CreditHistoryOverdraft",
        "overdraftCardsNumberCreditHistory",
        "CreditHistoryCreditCard",
        "creditCardsNumberCreditHistory",
        "generalCommentFinancInfo",
        /////////Household information///////
        "householdName",
        "taxCode",
        "dateOfEstablishment",
        "dateOfEstablishmentText",
        "householdAddress",
        "householdAddressText",
        "householdBusinessLine",
        "householdProducts",
        "householdStaffNumber",
        "householdQualifiedemployees",
        "householdRegisteredCapital",
        "householdAverageIncome",
        "householdBusinessRegistrationCertificate",
        "householdBusinessRegistrationCertificatPlaceOfIssue",
        "householdBusinessRegistrationCertificatDateOfIssue",
        "householdBusinessRegistrationCertificatDateOfIssueText",
        "businessesList",
        ///////////////////////End Household information///////
        "costOfGoodsList",
        "revenueListHousehold",
        "expensesList",
        "totalProfit",
        //////////////////////Product Information(AUTO)//////
        "requstFor",
        "carClassSysName",
        "carClass",
        "vehicleConditionSysName",
        "vehicleCondition",
        "carYear",
        "creditCurrencySysName", //Product Information (Unsecured Consumer Loan)
        "creditCurrencyName", //Product Information (Unsecured Consumer Loan)
        "loanRatio",
        "interestRateOptionSysName",
        "interestRateOption",
        "disbursmentMethodSysName",
        //////////////////////END Product Information(AUTO)//////
        //////////////////////Product Information(CreditCard)////
        "classOfCustomer",
        "classOfCustomerSysName",
        "creditLimit",
        "creditCurrency",
        "requestedLimit",
        "onlineLimit",
        "onlineLimitTransaction",
        "overdueInterestRate",
        "maxFreeInterestPeriod",
        "sendCardAndPIN",
        "sendCardAndPINSysName",
        "passwordCreditCard",
        "passwordType",
        "passwordTypeSysName",
        "issueType",
        "issueTypeSysName",
        "paymentAccountNumber",
        "paymentMethodCard",
        "paymentMethodCardSysName",
        "methodReceivingMonthlyStatement",
        "methodReceivingMonthlyStatementSysName",
        "exceptionConditionsCard",
        //////////////////////END Product Information(CreditCard)//////
        /////////////Risk and Method of Control///////////////
        "riskToPayBackLoan",
        "riskToPayBackLoanSysName",
        "riskToPayBackLoanComment",
        "riskOfCollateral",
        "riskOfCollateralSysName",
        "riskOfCollateralComment",
        "otherRisks",
        "otherRisksSysName",
        "otherRisksComment",

        "checkPurpose",
        "businessActivities",
        "creditPractice",
        "collateralCheck",
        "collateralRevaluation",

        "legalProceedings",
        "levelOfCooperation",
        "righteousCharacteristic",
        "generalCommentAboutCustomer",
        "legalAndRelativStatus",
        "CreditHistoryCreditCardCIC",
        "CreditHistoryLoanCIC",
        "loansNumberCIC",
        "creditCardsNumberCIC",
        "CreditHistoryReportCICDate",
        "numberBanksIsLoans",
        "collectionRequestCardCoun",
        "averageUtilizationRateCards6Months",
        "collectionRequestCardCoun12Month",
        "collectionRequestLoanCoun12Month",
		"numberOfDebtInGroupOD2",
        "overdueDebtsFor12Months",
        "cardUsageRatioAtAllInstitutions1Month",
        "monthlyAmountPaidLoanWithoutCollateral",
        "totalIncome",
        "unemployed",
        ////////////END Risk and Method of Control//////////
        "hasCurrentAccountBank",
        "currentAccountNumberBank",
        "currentAccountBranchName",
        "accountHolderName",
        "salesApplicationNumber",
        "salesInternalCode",
        "salesRemark",
        //////////Product Information (Unsecured Consumer Loan)/////////
        "clientMapDefault",
        "PRODUCTBRIEFNAME",
        "loanPurposeOther",
        "cardNumber",
        "salesAgentCode",
        "leadDetails",
        "availabilityInsurance",
        "insuranceProductText",
        "insuranceTerm",
        "insurancePremiumRate",
        //////////END Product Information (Unsecured Consumer Loan)/////////
        "clientInAppMap",  //было + Income and Employment Info (Unsecured Consumer Loan)
        "houseOwnershipSysName",
        "houseOwnershipName",
        "monthlyRentalOrMortgagePaymentCost",
        "transportationOwnershipSysName",
        "transportationOwnershipName",
        "customerMobileDeviceSysName",
        "customerMobileDeviceName",
        "insuranceLifeCompanyName",
        "insuranceLifeContractNumber",
        "insuranceLifeMonthlyFee",
        "Liabilities",
        "parentFullName", //Reference Person (Unsecured Consumer Loan)
        "parentRelationshipWithBorrower", //Reference Person (Unsecured Consumer Loan)
        "parentRelationshipWithBorrowerText", //Reference Person (Unsecured Consumer Loan)
        "parentPermanentAddress", //Reference Person (Unsecured Consumer Loan)
        "parentPermanentAddressText", //Reference Person (Unsecured Consumer Loan)
        "parentMobilePhone", //Reference Person (Unsecured Consumer Loan)
        "parentMobilePhoneText", //Reference Person (Unsecured Consumer Loan)
        "parentFixLine", //Reference Person (Unsecured Consumer Loan)
        "parentFixLineText", //Reference Person (Unsecured Consumer Loan)
        "clientSocialStatus", //Income and Employment Info (Unsecured Consumer Loan)
        "clientSocialStatusName", //Income and Employment Info (Unsecured Consumer Loan)
        "clientJobSphereOfActivityName", //Income and Employment Info (Unsecured Consumer Loan)
        "clientMainJobStaffNumberName", //Income and Employment Info (Unsecured Consumer Loan)
        "methodOfPaymentName", //Income and Employment Info (Unsecured Consumer Loan)
        "clientJobSphereOfActivity", //Income and Employment Info (Unsecured Consumer Loan)
        "clientMainJobStaffNumber", //Income and Employment Info (Unsecured Consumer Loan)
        "clientJobFactAddress", //Income and Employment Info (Unsecured Consumer Loan)
        "clientJobFactAddressText", //Income and Employment Info (Unsecured Consumer Loan)
        "clientJobLegalAddress", //Income and Employment Info (Unsecured Consumer Loan)
        "clientJobLegalAddressText", //Income and Employment Info (Unsecured Consumer Loan)
        "clientJobPhoneNumber", //Income and Employment Info (Unsecured Consumer Loan)
        "clientJobPhoneNumberText", //Income and Employment Info (Unsecured Consumer Loan)
        "clientJobContactAddition", //Income and Employment Info (Unsecured Consumer Loan)
        "employesDepartment", //Income and Employment Info (Unsecured Consumer Loan)
        "clientCurrentServiceLengthMonths", //Income and Employment Info (Unsecured Consumer Loan)
        "clientProfileServiceLengthYears", //Income and Employment Info (Unsecured Consumer Loan)
        "methodOfPayment", //Income and Employment Info (Unsecured Consumer Loan)
        "dayOfSalaryPayment", //Income and Employment Info (Unsecured Consumer Loan)
        "incomeBankName", //Income and Employment Info (Unsecured Consumer Loan)
        "incomeAmount", //Income and Employment Info (Unsecured Consumer Loan)
        "otherMonthlyIncome", //Income and Employment Info (Unsecured Consumer Loan)
        "totalHouseholdIncome", //Income and Employment Info (Unsecured Consumer Loan)
        "clientEmployerTaxNumber", //Income and Employment Info (Unsecured Consumer Loan)
        "spouseFirstName", //Spouse Information (Unsecured Consumer Loan)
		"spouseDocumentType", //Spouse Information (Unsecured Consumer Loan)
		"spouseDocumentTypeName", //Spouse Information (Unsecured Consumer Loan)
		"spouseDocumentNumber", //Spouse Information (Unsecured Consumer Loan)
		"spousePhoneNumber", //Spouse Information (Unsecured Consumer Loan)
		"spousePhoneNumberText", //Spouse Information (Unsecured Consumer Loan)
		"spousePermanentAddress", //Spouse Information (Unsecured Consumer Loan)
		"spousePermanentAddressText", //Spouse Information (Unsecured Consumer Loan)
		"spouseJobCompanyName", //Spouse Information (Unsecured Consumer Loan)
		"spouseJobLegalAddress", //Spouse Information (Unsecured Consumer Loan)
		"spouseJobLegalAddressText", //Spouse Information (Unsecured Consumer Loan)
		"spouseJobPhoneNumber", //Spouse Information (Unsecured Consumer Loan)
		"spouseJobPhoneNumberText", //Spouse Information (Unsecured Consumer Loan)
        "approvedProductName", //Final Approval
        "approvedProductId", //Final Approval
        "approvedProductBrief", //Final Approval
        "approvedLoanPurposeSysName", //Final Approval
        "approvedLoanPurposeOther", //Final Approval
        "approvedLoanPurpose", //Final Approval
        "approvedLoanAmount", //Final Approval
        "approvedCurrencySysName", //Final Approval
        "approvedCurrencyName", //Final Approval
        "approvedLoanTerm", //Final Approval
        "approvedInterestRate", //Final Approval
        "approvedCardNumber", //Final Approval
        "currentAccNumber", //Disbursement
        "loanAccNumber", //Disbursement
        "disbursementBranchCode", //Disbursement
        "accountHolder", //Disbursement
        "cifFlagINT", //Disbursement
        "cifNumberINT", //Disbursement
        "disbursementErrorCode", //Disbursement
        "currentAddress", //Client Personal Info
        "additionalContactsList", //Additional Contacts
        "realEstateDescription",
        "interestRepaymentScheduleSysName",
        "interestRepaymentSchedule",
        "interestRepaymentScheduleOther",
        "principalRepaymentScheduleSysName",
        "principalRepaymentSchedule",
        "principalRepaymentScheduleOther",
        "principalRepaymentMethodOther",
        "promoInterestRate",
        "amplitudeInterestRate",
        "insuranceFee",
        "otherFees",
        "isCertificateOwnership",
        "realtyTypeSysName",
        "realtyType",
        "realtyTypeOther",
        "subProductName",
        "withdrawTerm",
        "periodList",
        "firstSupplementatyCard",
        "secondSupplementatyCard",
        "serviceInfo",
        "salesHistory",
        "blacklistTable",
        "customerGroupInfo",
        "nameInCard",
        "mainKNDLMember",
        "cardUsageRatioAverage9months",
        "cardUsageRatioAverageBeforeRequest",
	"hasSupplementaryCard",
        "monthsFromLastSearch",
        "loanType",
        "requiredCapital",
        "ownedCapital",
        "loanValueRatio",
        "totalCreditLimit",
        "totalCreditLimitDetail",
        "creditLimitPeriod",
        "indebtednessCertifPeriod",
        "disbursmentMethodDetailed",
        "fees",
        "crossUpProduct",
        "loanTypeText",
        "creditExtensionMethodSysName",
        "creditExtensionMethod",
        "MISCode",
        "flowSysName",
        "flow",
        "approverLevelSysName",
        "approverLevel",
        "productCustomerGroupSysName",
        "productCustomerGroup",
        "ReportInfo"
    ],

    clientMap:[
        "legalName",
        "legalAddressList",
        "CLIENTID",
        "clientFirstName",              // Name
        "clientGender",                 // Sex
        "clientBirthDate",              // BirthDay
        "clientAge",
        "clientCitizenshipCode",
        "clientCitizenship",            // Citizenship
        "clientCitizenshipName",
        "clientExtObjID",               // CIF
        "clientIsResident",             // Resident
        "clientBusinessmanFlag",        // Household member
        "clientAdditionalDocsTable",    // Add document List
        "MaritalStatus",                // Marital status
        "contactTableList",             // Contact List
        "addressTableList",             // Address List
        "EducationTypeBrief",           // Education
        "clientMainDocNumber",          // Main Document Number
        "clientDocType",                // Type of Document
        "searchParams",                 //S-31.1. Search Parameters по умолчанию
        "searchParamsFlag",
        "contactToDeleteList",          //Лист для удаления (Недействительности)
        "addressToDeleteList",          //Лист для удаления (Недействительности)
        "docToDeleteList",               //Лист для удаления (Недействительности)
        "FIOBankEmployee",               // FIO Bank Employee
        "applicationBranch"              // Branch Name
    ],
    excludeMap:[
        "DOCTYPENAME",
        "STATE",
        "CREATIONDATE",
        "DOCUMENTNUMBER",
        "DOCUMENTID",
        "TYPESYSNAME",
        "personType",
        "clientGender",
        "clientCitizenship",
        "clientIsResident"
        //если сюда потребуется добавить еще параметры по клиенту, их нужно чистить в процессе applicationDataEntry,
        //так как для заявки может быть выбиран новый клиент
    ]
};

function transformerWizardParam(wizardParams){
    if (arguments.length > 1){
        for(var i = 1; i < arguments.length; i++) {
            var nextMapName = arguments[i];
            var mapKeys = wizardParamsRef[nextMapName];
            logger.info("#### "+getNewList(mapKeys));
            var clearMap = new java.util.HashMap();
            // если мапа уже есть, добавлять в нее.
            if (wizardParams.get(nextMapName) != undefined && wizardParams.get(nextMapName) != null){
                clearMap = wizardParams.get(nextMapName);
            }
            // перекладываем из визарда в нужную мапу
            for (var j = 0; j < mapKeys.length; j++) {
                if (wizardParams.containsKey(mapKeys[j])) {
                    if (wizardParams.get(mapKeys[j]) != undefined && wizardParams.get(mapKeys[j]) != null) {
                        clearMap.put(mapKeys[j], wizardParams.get(mapKeys[j]));
                    } else {
                        clearMap.put(mapKeys[j], "");
                    }
                    wizardParams.put(nextMapName, clearMap);
                }
                if (wizardParamsRef['excludeMap'].indexOf(mapKeys[j]) == -1){
                    wizardParams.remove(mapKeys[j]);
                }
            }
        }
        return wizardParams;
    }
    else {
        if(arguments.length == 1){
            return wizardParams;
        }
    }
}

// берет значение из мапы если такое значится в списках мапы
// иначе берет значение из wizardParam
// например getWizardParamValue(wizardParams, "clientLastName", "clientMap") будет искать в clientMap внутри визарда
// или getWizardParamValue(wizardParams, "applicationSaleChannel", "appMap", "clientMap") будет искать в appMap и clientMap

function getWizardParamValue(wizardParams, valueName){
    if (arguments.length > 2){
        var mapName = "";
        for(var i = 2; i < arguments.length; i++) {
            var nextMapName = arguments[i];
            var mapKeys = wizardParamsRef[nextMapName];
            if(mapKeys!=null) {
                for (var j = 0; j < mapKeys.length; j++) {
                    if (mapKeys[j] == valueName) {
                        mapName = nextMapName;
                        break;
                    }
                }
            }
        }
        if (mapName!="" && wizardParams.get(mapName) != null){
            return wizardParams.get(mapName).get(valueName);
        }
        else {
            return wizardParams.get(valueName);
        }
    }
    else if(arguments.length == 2){
        return wizardParams.get(valueName);
    }
    else{
        return null;
    }
}
// параметры залога, которые добавляются в объект собственности в assetsMap
var collateralMap = [
    "sysnameTypeCollateral",
    "sysnameTypeAssets",
    "infoSalesTransferOwnershipSalesContract",
    "apartmentDetailInfo",
    "landNo",
    "mapNo",
    "area",
    "unit",
    "usagePurpose",
    "usageForm",
    "usageTerm",
    "usageSource",
    "assetAttachLandInfo",
    "numberPlate",
    "colourCar",
    "ownerNameVehicleRegistration",
    "issuedOfficeVehicleRegistration",
    "addressIssuedOfficeVehicleRegistration",
    "documentsProvingUsageRight",
    "documentsProvingOwnershipRight",
    "collateralCurrency",
    "liquidityFactor",
    "standardCreditFactor",
    "realCollateralValue",
    "controlMethodCollateral",
    "nameEvaluationReport",
    "currentUsageState",
    "ownershipTransferAbility",
    "classification",
    "collateralDescription"
];
// при удалении залога очищает мапу собственности assetsMap от параметров залога
function clearAssetMapAfterDeleteCollateral(assetMap){
    for (var j = 0, countJ = collateralMap.length; j < countJ; j++) {
        if (assetMap.get(collateralMap[j]) != undefined && assetMap.get(collateralMap[j]) != null) {
            assetMap.remove(collateralMap[j]);
        }
    }
}