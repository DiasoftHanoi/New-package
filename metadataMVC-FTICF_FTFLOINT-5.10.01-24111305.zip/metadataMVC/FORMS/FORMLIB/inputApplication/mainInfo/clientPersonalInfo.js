/*DSMETA version = "5.10.01-24111305" hash = "fc3a15970a6464ded1bd6714941d97cd44beb3b3"*/
/* global form */

function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
service = registerMethod(service);

var convertDate = service.convertDate;
var getTableContent = service.getTableContent;
var gRB = service.gRB;
var nvl = service.nvl;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);

form.isFormEditMode = form.inputParams.EDITMODE || false;

var inputParams = form.inputParams;
var outputParams = form.outputParams;

form.formParams = inputParams.formParams || {};
outputParams.formParams = form.formParams;

form.requiredElements = [
    "edFirstName",
    "cmSex",
    "clBirthDate",
    "cmCitizenship",
    "cmRelationshiWithBorrower",
    "edRelationshiWithBorrowerOther",
    "type",
    "additionalDocNumber",
    "additionalDocIssueDate",
    "additionalDocIssuedBy",
    "tblAdditionalDocs",
    "addressType",
    "addressBlock",
    "cbHousingOwnership",
    "cbHousingOwnershipOther",
    "clPeriodOfResidence",
    "tblClientAddress",
    "contactType",
    "contactValue",
    "tblClientContact",
    //These are not required, but need to be verified:
    "edCIF",
    "contactComment"
];

form.BorrowerLevel = {
    ReferenceGroupName: 'Distribution Reference Tables',
    ReferenceSysName: 'relashionshiptype'
};

form.ChannelSales = {
    ReferenceGroupName: 'General',
    ReferenceSysName: 'channelSalesLOS'
};

form.contactTableList = form.formParams.contactTableList || [];
form.documentList = form.formParams.clientAdditionalDocsTable || [];
form.addressTableList = form.formParams.addressTableList || [];
form.deleteContactList = form.formParams.contactToDeleteList || [];
form.deleteAddressList = form.formParams.addressToDeleteList || [];
form.deleteDocsList = form.formParams.docToDeleteList || [];
form.flagLead = (form.formParams.leadSource != undefined);

form.templateData={
    templateKind:"small" ,
    address:{},
    addressText:"",    
}
form.onShow = function () {
    form.getAge();
    service.wizFormNavigatorCommand({
       context: form,
       event: 'CURPAGE_MSG'
    });
    form.checkClientContactInfo('show');
    form.checkClientDocumentInfo('show');
    form.checkClientAddress('show');

    form.tblAdditionalDocsObj.setItems(form.formParams.clientAdditionalDocsTable || []);

    form.tblClientAddressObj.setItems(form.formParams.addressTableList || []);
    
    var addressTableList = form.formParams.addressTableList || [];
    if(addressTableList) {
        for (var i = 0; i < addressTableList.length; i++) {
            var addressType = addressTableList[i].addressType;
            if (addressType == "FactAddress") {
                form.clientFactLiveAddressRegion = addressTableList[i].blockAddress.Region;
            }
            if (addressType == "PermanentAddress") {
                form.clientPermLiveAddressRegion = addressTableList[i].blockAddress.Region;
            }
        }
    }

    var contactTableList = form.formParams.contactTableList || [];
    var contactTypeList  = form.inputParams.contactTypeList || [];
    var contactTypeMap   = {};
    for (var i = 0; i < contactTypeList.length; i++) {
        var contactType = contactTypeList[i];
        contactTypeMap[contactType.ContactTypeBrief] = contactType.ContactTypeMaskCode + contactType.ContactTypeMaskNumber;
    }
    for (var i = 0; i < contactTableList.length; i++) {
        var contactType = contactTableList[i].contactType;
        if (contactTypeMap[contactType] != undefined) {
            contactTableList[i].contactText = service.setMask(contactTableList[i].contactValue, contactTypeMap[contactType], true);
        }
    }
    form.tblClientContactObj.setItems(contactTableList);

    var searchParamsFlag =  form.formParams.searchParamsFlag;
    if(searchParamsFlag == true) {
        setTimeout(function() { form.addRowDefault() }, 10);
    }

    if (!form.isFormEditMode) {
        if (form.btnNext) {
            form.btnNext.setFocus();
        }
        else if (form.btnSave) {
            form.btnSave.setFocus();
        }
        else {
            form.btnCancel.setFocus();
        }
    }
};

form.addRowDefault = function() {
    var searchParams =  form.formParams.searchParams;
        if(searchParams != undefined) {
        var SearchingStrategy = searchParams["SearchingStrategy"];
        if(SearchingStrategy!=undefined) {
            if(SearchingStrategy == 'By document') {
                form.tblAdditionalDocsObj.addNewRow();
            }
            if(SearchingStrategy == 'By phone number') {
                form.tblClientContactObj.addNewRow();
            }
        }else{
             //If action PROCESS_RIGHT_LIST search
             form.tblAdditionalDocsObj.addNewRow();
             form.tblClientContactObj.addNewRow();
        }
        setTimeout(function() { form.setDefaultParams() }, 10);
    }
};

form.setDefaultParams = function() {
    var searchParams =  form.formParams.searchParams;
     if(searchParams != undefined) {
        var SearchingStrategy = searchParams["SearchingStrategy"];
        if(SearchingStrategy!=undefined) {
            if(SearchingStrategy == 'By document') {
                var IdentityCardTypeBrief = searchParams["IdentityCardTypeBrief"];
                form.type.setValue(IdentityCardTypeBrief);

                if(IdentityCardTypeBrief.toLowerCase() == 'nationalid') {
                    form.BaseIdentityCardFlag.setChecked(true);
                }
                var IdentityCardNumber = searchParams["IdentityCardNumber"];
                form.additionalDocNumber.setValue(IdentityCardNumber);
            }

            if(SearchingStrategy == 'By phone number') {
               var ContactValue = searchParams["ContactValue"];
               form.contactValue.setValue(ContactValue);
            }

            var CurrentName = searchParams["CurrentName"];
            var BirthDay = searchParams["BirthDay"];

            form.formParams.clientFirstName = CurrentName;
            form.formParams.clientBirthDate = BirthDay;

        }else{
             //If action PROCESS_RIGHT_LIST search
             //Document Type
             var IdentityCardTypeBrief = searchParams["IdentityCardTypeBrief"];
             form.type.setValue(IdentityCardTypeBrief);

             //Main Document
             if(IdentityCardTypeBrief.toLowerCase() == 'nationalid') {
                 form.BaseIdentityCardFlag.setChecked(true);
             }
             //Document Number
             var IdentityCardNumber = searchParams["IdentityCardNumber"];
             form.additionalDocNumber.setValue(IdentityCardNumber);

             //Phone Number
             var ContactValue = searchParams["ContactValue"];
             form.contactValue.setValue(ContactValue);
             //Customer Name
             var CurrentName = searchParams["CurrentName"];
             //Date of Birth
             var BirthDay = searchParams["BirthDay"];

             form.formParams.clientFirstName = CurrentName;
             form.formParams.clientBirthDate = BirthDay;
        }
    }
};

form.settings = {
    cmSex_items: [{
        value: 'Male',
        text: gRB('Male')
    }, {
        value: 'Female',
        text: gRB('Female')
    }
    ]
};

form.getMinBirthDate = function () {
    var now = new Date();
    return service.convertDate(new Date(now.setFullYear(now.getFullYear() - 18)));
};

form.formParams.clientAge = form.formParams.clientAge != null ? form.formParams.clientAge : '';

form.getAge = function () {
    var bDate = (form.formParams.clientBirthDate) ? service.convertDate(form.formParams.clientBirthDate) : '';
    if (bDate) {
        form.formParams.clientAge = parseInt(service.diffDate(bDate, form.curDate, 'year'));
    }else{
        form.formParams.clientAge = undefined;
    }
};

if (form.clBirthDate && form.formParams.clientAge == null) {
    form.formParams.clientAge = parseInt(service.diffDate(convertDate(new Date(form.clBirthDate)), convertDate(new Date()), 'year'));
}

var sendMessage = function (message) {
    var PROCESS_RIGHT_LIST = getInputParams("PROCESS_RIGHT_LIST");
    if (PROCESS_RIGHT_LIST) {
        for (var ar in PROCESS_RIGHT_LIST) {
            form.commandRight(ar, message);
        }
    }
};

form.curDate = service.convertDate(new Date());


form.action = function (tag) {
    outputParams.TRANSTYPE = tag;
    if(form.inputParams.EDITMODE === true) {
        outputParams.clientAdditionalDocsTable = form.tblAdditionalDocsObj.getItems();
        outputParams.addressTableList = form.tblClientAddressObj.getItems();
        outputParams.contactTableList = form.tblClientContactObj.getItems();
        form.formParams.clientCitizenship = (form.cmCitizenship) ? form.cmCitizenship.getText() : "";
        form.formParams.clientExtObj = (form.edCIF) ? form.edCIF.getText() : "";
        form.formParams.channelSales = (form.cmbChannelSales) ? form.cmbChannelSales.getText() : "";
        if (form.formParams.thirdParty == 'thirdParty') {
            form.formParams.RelationshiWithBorrower = form.cmRelationshiWithBorrower.getText();
            form.formParams.RelationshiWithBorrowerSysName = form.cmRelationshiWithBorrower.getValue();
        }
        if(form.clientFactLiveAddressRegion != undefined) {
             form.formParams.clientFactLiveAddressRegion = form.clientFactLiveAddressRegion;
        }
        if(form.clientPermLiveAddressRegion != undefined) {
             form.formParams.clientPermLiveAddressRegion = form.clientPermLiveAddressRegion;
        }
        outputParams.deleteContactList = form.deleteContactList;
        outputParams.deleteAddressList = form.deleteAddressList;
        outputParams.deleteDocsList = form.deleteDocsList;
    }
    if (tag === 'CLOSE') {
        if(form.inputParams.EDITMODE === false){
            form.sendForm('GO',false);
        }
        else {
            service.showDialogCancelConfirm(
                form,
                form.yesFunc,
                form.noFunc
            )
        }
    }
    else {
        if (tag === 'NEXT' && !form.verifyForm(true)) {
            return;
        } else {
            form.verifyForm(false);
        }
        if (tag === 'NEXT')
            form.setSearchParamsFlag('', false);
        form.sendForm('GO', false);
    }
};

form.yesFunc = function() {
    var tag = outputParams.TRANSTYPE;
    outputParams.TRANSTYPE = 'SAVEDRAFT';
    if(form.verifyForm(true, tag)) {
        form.sendForm('GO', false);
    }
};
form.noFunc = function(){
    form.outputParams.TRANSTYPE = 'CLOSE';
    form.sendForm('GO',false);
};

form.verifyForm = function (showFlag, tag) {
    var verified = true;
    var buttonNextSave = (form.isLastWizForm) ? "btnSave" : "btnNext";
    if (tag === 'CLOSE') {
        buttonNextSave = "btnCancel";
    }
    try {
        if ((form.validateControlsByIds(form.requiredElements.join(','), showFlag === true ? buttonNextSave : undefined).isShowFormErrors)) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    form.outputParams.VERIFIED = verified;
    return verified;
};

form.executeCommand = function (message) {
    if (message.event == "FAB_NAVIGATOR_NAVIGATE") {
        form.outputParams.NEXTPAGE = message.params.step;
        form.action("DIRECT");
    }
};

/////////////////////////////////////////////////////////////////////////////////////
form.getMapFromList = function (list, key, val) {
    for (var i = 0; i < list.length; i++) {
        if (list[i][key] + '' === val + '') {
            return list[i];
        }
    }
};
////Документы
form.tblAdditionalDocsObj = (function (grId) {
    var gridId = grId;
    var setDocMasks = function (docTypeSysName, docTypeList, maskObj) {
        var docType = undefined;
        if (!docTypeSysName || !(docType = form.getMapFromList(docTypeList, 'IdentityCardTypeBrief', docTypeSysName))) {
            maskObj.number = undefined;
            return;
        }
        maskObj.number = docType.NumberMask;
        return maskObj;
    };
    var person= {};
    var personDocMask = {
        number: person.IdentityCardNumberMask || undefined
    };
    var options = {
        requiredElements : [
            "type",
            "additionalDocNumber",
            "additionalDocIssueDate",
            "additionalDocIssuedBy"
        ],
        cardTypeList: form.inputParams.cardTypeList,
        data: {},
        cancel: function () {
            form[gridId].hideEditor();
            form.btnDocAdd.enable();
        },
        save: function () {
            if (form.checkDuplicateDocument(options.data.type)) {
                return;
            }
            var documentList = getTableContent(form.tblAdditionalDocs);
            if ((form.addDocMode == "edit" && documentList instanceof Object && Object.keys(documentList).length > 1) || (form.addDocMode == "add")) {
                form.changeBaseIdentityCardFlag(options.data.BaseIdentityCardFlag, grId);
            }
            if (!form.mainDocFlag) {
                form.saveCallBack(grId);
            }
            form.checkClientDocumentInfo();
            form.setSearchParamsFlag('By document', false);
            for (var i = 0; i < form.deleteDocsList.length; i++) {
                if (form.deleteDocsList[i].documentNumber == form.additionalDocNumber.getValue()) {
                    form.deleteDocsList.splice(i, 1);
                    i--;
                }
            }
        },
        clearFields: function () {
            delete options.data.type;
            options.data.typeName = null;
            delete options.data.additionalDocNumber;
            delete options.data.additionalDocIssueDate;
            delete options.data.additionalDocIssuedBy;
            delete options.data.BaseIdentityCardFlag;
        },
        edit: function () {
            form.addDocMode = 'edit';
            options.clearFields();
            var selectedRow = form.tblAdditionalDocs.getSelectedRow()[0];
            form[gridId].showEditor('edit');
            form.tblAdditionalDocsObj.options.data = {
                type                   : selectedRow["documentType"],
                typeName               : selectedRow["documentTypeName"],
                additionalDocNumber    : selectedRow['documentNumber'],
                additionalDocIssueDate : selectedRow['documentIssueDate'],
                additionalDocIssuedBy  : selectedRow['documentIssuedBy'],
                BaseIdentityCardFlag   : (selectedRow["BaseIdentityCardFlag"] == "" || selectedRow["BaseIdentityCardFlag"] == "0" || selectedRow["BaseIdentityCardFlag"] + '' == "false") ? false : true
            };
            form.checkClientDocumentInfo();
            options.onChangeDocType(selectedRow["documentType"], false);
            form.btnDocAdd.disable();
        },
        delete: function () {
            var row = form.tblAdditionalDocs.getSelectedRow()[0];
            if (row) {
                form.tblAdditionalDocs.deleteRow(obj.selectedId);
                form[gridId].refresh();
                form.deleteDocsList.push(row);
            }
            form.checkClientDocumentInfo();
            form.btnDocAdd.enable();
        },
        onChangeDocType : function (value, checkFlag) {
            form.tblAdditionalDocsObj.options.personMaskObj = setDocMasks(value, form.inputParams.cardTypeList, personDocMask);
            if (!checkFlag) {
                return;
            }
            var baseIdentityCardFlagTemp = false;
            if (this.data.type && this.data.type.toLowerCase() == "nationalid") {
                baseIdentityCardFlagTemp = true;
            }
            this.data.BaseIdentityCardFlag = baseIdentityCardFlagTemp;
        }
    };

    var obj = {
        gridId: grId,
        refresh: function () {
            form[gridId].refresh();
        },
        onChangeItems: function () {
        },
        addNewRow: function () {
            form.addDocMode = 'add';
            form[gridId].showEditor('add');
            options.clearFields();
            form.btnDocAdd.disable();
        },
        setItems: function (items) {
            form[gridId].setItems(items);
        },
        getItems: function () {
            return form[gridId].getItems();
        },
        onSelectRow: function () {
            options.items = [];
            if (form.isFormEditMode == true && form.formParams.restrictionAccessRightEdit) {
                var selRow = form[gridId].getSelectedRow()[0] || {};
                options.items = [
                    {caption: gRB('edit'),   click: form.tblAdditionalDocs.options.edit},
                    {caption: gRB('delete'), click: form.tblAdditionalDocs.options.delete}
                ];
            }
        }
    };
    obj.options = options;
    return obj;
})('tblAdditionalDocs');
/////Адрес
form.tblClientAddressObj = (function (grId) {
    var gridId = grId;
    var options = {
        templateData:form.templateData,        
        disableAddressIsSameAsFlag : false,
        requiredElements : [
            "addressType",
            "addressBlock",
            "cbHousingOwnership",
            "cbHousingOwnershipOther",
            "clPeriodOfResidence"
        ],
        addressTypeComboBoxParams_ITEMS: form.inputParams.addressTypeList || {},
        housingOwnershipComboBoxParams: {
            ReferenceSysName: 'housingOwnership',
            ORDERBY: 'ReferenceItemID'
        },
        data: {},
        cancel: function () {
            options.clearFields();
            form[gridId].hideEditor();
            form.btnAddressAdd.enable();
        },
        save: function () {
            var selectedRow = form.tblClientAddress.getSelectedRow()[0];
            if (form.checkDuplicateAddress(options.data.addressType, selectedRow.addressType)) {
                return;
            }
            var selectedAddressValue = form.addressType.getValue();
            if(selectedAddressValue == "FactAddress") {
                form.clientFactLiveAddressRegion = form.addressBlock.data.address.Region;
            } else if (selectedAddressValue == "PermanentAddress") {
                form.clientPermLiveAddressRegion = form.addressBlock.data.address.Region;
            }

            var newRow = {
                addressType                 : form.addressType.getValue(),
                addressTypeText             : form.addressType.getText(),
                addressIsSameAs             : (form.addressIsSameAs.getValue()) ? form.addressIsSameAs.getValue() : '',
                addressIsSameAsText         : (form.addressIsSameAs.getText()) ? form.addressIsSameAs.getText() : '',
                blockAddress                : form.addressBlock.data.address,
                addressString               : form.addressBlock.data.address.addressText,
                cbHousingOwnership          : (form.cbHousingOwnership) ? form.cbHousingOwnership.getValue() : '',
                cbHousingOwnershipName      : (form.cbHousingOwnership) ? form.cbHousingOwnership.getText() : '',
                cbHousingOwnershipOther     : (form.cbHousingOwnershipOther) ? form.cbHousingOwnershipOther.getValue() : '',
                registerStartDate           : form.clPeriodOfResidence.getValue(),
                registerStartTextDate       : form.clPeriodOfResidence.getText()
            };
            angular.extend(newRow, form.addressBlock.data.address);
            options.clearFields();
            if (selectedRow['id']) {
                newRow['id'] = selectedRow['id'];
                form[gridId].hideEditor();
                form[gridId].updateRow(obj.selectedId, newRow);

            } else {
                newRow['id'] = new Date().getTime();
                form[gridId].hideEditor();
                form[gridId].addRow(newRow);
            }
            form.checkClientAddress();
            form.btnAddressAdd.enable();
        },
        clearFields: function () {
            delete options.data.addressType;
            if (form.addressType)
               form.addressType.clearValue();
            delete options.data.addressIsSameAs;
            if(form.addressBlock) {
                form.addressBlock.data.address={};
                form.addressBlock.data.addressText="";
            }
            delete options.data.addressString;
            delete options.data.isSameAddressFlag;
            delete options.data.cbHousingOwnership;
            if (form.cbHousingOwnership)
               form.cbHousingOwnership.clearValue();
            delete options.data.cbHousingOwnershipOther;
            delete options.data.registerStartDate;
        },
        edit: function () {
            form.addAddrMode = 'edit';
            form[gridId].showEditor('edit');
            options.clearFields();
            var selectedRow = form.tblClientAddress.getSelectedRow()[0];
            form.fillComboAddressIsSameAs(selectedRow.addressType);
            form.tblClientAddressObj.options.data = {
                addressType             : selectedRow["addressType"],
                addressIsSameAs         : selectedRow["addressIsSameAs"],
                blockAddress            : selectedRow['blockAddress'],
                cbHousingOwnership      : selectedRow['cbHousingOwnership'],
                cbHousingOwnershipOther : selectedRow['cbHousingOwnershipOther'],
                registerStartDate       : selectedRow['registerStartDate'],
                addressString           : selectedRow["addressString"],
                isSameAddressFlag       : (nvl(selectedRow["addressIsSameAs"], '') != '')
            };
            form.tblClientAddressObj.options.templateData.address=selectedRow["blockAddress"];
            form.tblClientAddressObj.options.templateData.addressText=selectedRow["addressString"];               
            form.checkClientAddress();
            form.btnAddressAdd.disable();
        },
        delete: function () {
            var row = form.tblClientAddress.getSelectedRow()[0];
            if (row) {
                var addressList = getTableContent(form.tblClientAddress);
                if (addressList instanceof Object && Object.keys(addressList).length > 1) {
                    for (var i = 0, count = addressList.length; i < count; i++) {
                        var addressIsSameAsCur = nvl(addressList[i].addressIsSameAs, '');
                        if (addressIsSameAsCur.toLowerCase() == row.addressType.toLowerCase()) {
                            addressList[i].addressIsSameAs = null;
                            delete addressList[i].addressIsSameAsText;
                        }
                    }
                    form.tblClientAddressObj.setItems(addressList);
                }
                form.tblClientAddress.deleteRow(obj.selectedId);
                form[gridId].refresh();
                form.deleteAddressList.push(row);
            }
            form.checkClientAddress();
            form.btnAddressAdd.enable();
        },
        fillAddressIsSameAs : function (item) {
            if (nvl(item.value, '') != '') {
                var addressList = getTableContent(form.tblClientAddress);
                if (addressList instanceof Object && Object.keys(addressList).length > 0) {
                    for (var i = 0, count = addressList.length; i < count; i++) {
                        if (addressList[i].addressType && item.value.toLowerCase() == addressList[i].addressType.toLowerCase()) {
                            this.templateData.address      = addressList[i].blockAddress;
                            this.templateData.address.addressText      = addressList[i].addressString;
                            this.data.addressString     = addressList[i].addressString;
                            this.data.isSameAddressFlag = true;
                            break;
                        }
                    }
                }
            }
            else 
                this.data.isSameAddressFlag = false;
        },
        onChangeAddressType : function (item) {
            var selectedRow = form.tblClientAddress.getSelectedRow()[0];
            form.fillComboAddressIsSameAs(item.AddressTypeBrief, selectedRow.addressType);
        }
    };

    var obj = {
        gridId: grId,
        refresh: function () {
            form[gridId].refresh();
        },
        onChangeItems: function () {
        },
        addNewRow: function () {
            form.addAddrMode = 'add';
            form[gridId].showEditor('add');
            options.clearFields();
            form.fillComboAddressIsSameAs();
            form.btnAddressAdd.disable();
        },
        setItems: function (items) {
            form[gridId].setItems(items);
        },
        getItems: function () {
            return form[gridId].getItems();
        },
        onSelectRow: function () {
            options.items = [];
            if (form.isFormEditMode == true) {
                var selRow = form[gridId].getSelectedRow()[0] || {};
                options.items = [
                    {caption: gRB('edit'),   click: form.tblClientAddress.options.edit},
                    {caption: gRB('delete'), click: form.tblClientAddress.options.delete}
                ];
            }
        }
    };
    obj.options = options;
    return obj;
})('tblClientAddress');
/////Контакт
form.tblClientContactObj = (function (grId) {
    var gridId = grId;
    var options = {
        addressIsSameAs_ITEMS : [],
        requiredElements : [
            "contactType",
            "contactValue",
            "contactComment"
        ],
        contactTypeComboBoxParams_ITEMS: form.inputParams.contactTypeList || {},
        data: {},
        cancel: function () {
            form[gridId].hideEditor();
            form.btnContactAdd.enable();
        },
        save: function () {
            var selectedRow = form.tblClientContact.getSelectedRow()[0];
            var newRow = {
                contactType     : form.contactType.getValue(),
                contactTypeText : form.contactType.getText(),
                contactValue    : form.contactValue.getValue(),
                contactText     : form.contactValue.getText(),
                contactComment  : form.contactComment.getValue()
            };
            if (selectedRow['id']) {
                newRow['id'] = selectedRow['id'];
                form[gridId].hideEditor();
                form[gridId].updateRow(obj.selectedId, newRow);

            } else {
                newRow['id'] = new Date().getTime();
                form[gridId].hideEditor();
                form[gridId].addRow(newRow);

            }
            form.checkClientContactInfo();
            form.btnContactAdd.enable();
            form.setSearchParamsFlag('By phone number', false);
        },
        clearFields: function () {
            delete options.data.contactType;
            delete options.data.contactValue;
            delete options.data.contactComment;
        },
        edit: function () {
            options.clearFields();

            var selectedRow = form.tblClientContact.getSelectedRow()[0];

            form[gridId].showEditor('edit');
            form.tblClientContactObj.options.data = {
                contactType    : selectedRow["contactType"],
                contactValue   : selectedRow["contactValue"],
                contactComment : selectedRow['contactComment']
            };
            for (var i = 0, count = options.contactTypeComboBoxParams_ITEMS.length; i < count; i++) {
                if (options.data.contactType == options.contactTypeComboBoxParams_ITEMS[i].ContactTypeBrief) {
                    options.onChangeContactType(options.contactTypeComboBoxParams_ITEMS[i]);
                    break;
                }
            }
            form.btnContactAdd.disable();

        },
        delete: function () {
            var row = form.tblClientContact.getSelectedRow()[0];
            if (row) {
                if (form.formParams.selectedNumber == form.tblClientContact.getSelectedRow()[0].contactValue && form.formParams.smsInformingSysName == form.tblClientContact.getSelectedRow()[0].contactType) {
                    form.formParams.smsInformingSysName = "";
                    form.formParams.smsInforming = "";
                    form.formParams.selectedNumber = "";
                }
                if (form.formParams.selectedAddress == form.tblClientContact.getSelectedRow()[0].contactValue && form.formParams.emailInformingSysName == form.tblClientContact.getSelectedRow()[0].contactType) {
                    form.formParams.emailInformingSysName = "";
                    form.formParams.emailInforming = "";
                    form.formParams.selectedAddress = "";
                }
                form.deleteContactList.push(row);
                form.tblClientContact.deleteRow(obj.selectedId);
                form[gridId].refresh();
                form.checkClientContactInfo();
                form.btnContactAdd.enable();
            }
        },

        onChangeContactType : function (item, clearValue) {
            options.emailCheckValueRX = '';
            options.emailFilterRX = '';
            options.numberMask = '';
            if (clearValue) {
                form.contactValue.setValue("")
            }
            if (item && item.ContactTypeBrief != undefined){
                options.numberMask = item.ContactTypeMaskCode+item.ContactTypeMaskNumber;
                if (item.ContactTypeBrief.indexOf("Email") > 0) {
                    options.emailCheckValueRX = '^([a-zA-Z0-9_-]+\\.)*[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\\.[a-zA-Z0-9_-]+)*\\.[a-z]{2,}$';
                    options.emailFilterRX = '[.@a-zA-Z0-9_-]';
                }
            }
        },
        onChangeContactTypeReq: function(items) {
           options.emailCheckValueRX = '';
           options.emailFilterRX = '';
           if(items) {
              items.forEach(function(row) {
                 if(row.ContactTypeBrief === options.data.contactType) options.numberMask = row.ContactTypeMaskCode + row.ContactTypeMaskNumber
              }, this);
           }
        }
	
    };

    var obj = {
        gridId: grId,
        refresh: function () {
            form[gridId].refresh();
        },
        onChangeItems: function () {
        },
        addNewRow: function () {
            form[gridId].showEditor('add');
            options.clearFields();
            options.onChangeContactType(form.tblClientContact.getSelectedRow()[0]['contactType']);
            form.btnContactAdd.disable();
        },
        setItems: function (items) {
            form[gridId].setItems(items);
        },
        getItems: function () {
            return form[gridId].getItems();
        },
        onSelectRow: function () {
            options.items = [];
            if (form.isFormEditMode == true) {
                var selRow = form[gridId].getSelectedRow()[0] || {};
                options.items = [
                    {caption: gRB('edit'),   click: form.tblClientContact.options.edit},
                    {caption: gRB('delete'), click: form.tblClientContact.options.delete}
                ];
            }
        }
    };
    obj.options = options;
    return obj;
})('tblClientContact');

form.addClientContact = function (item) {
    form.tblClientContactObj.options.clearFields();
    form.btnContactAdd.disable();
    form.tblClientContactObj.options.data.contactType = item.ContactTypeBrief;
    form.tblClientContactObj.options.onChangeContactType(item['ContactTypeBrief']);
};

form.addOneAddress = function(item) {
    form.tblClientAddressObj.options.clearFields();
    form.btnAddressAdd.disable();
};
///Установка флажка на Main Document
form.addMainDoc = function (item) {
    form.tblAdditionalDocsObj.options.clearFields();
    form.tblAdditionalDocsObj.options.data.BaseIdentityCardFlag=true;
    form.addDocMode = "add";
    form.btnDocAdd.disable();
};

form.fillComboAddressIsSameAs = function (curAddrType, oldAddressType) {
    curAddrType    = nvl(curAddrType, '');
    oldAddressType = nvl(oldAddressType, '');
    form.tblClientAddressObj.options.disableAddressIsSameAsFlag = true;
    form.tblClientAddressObj.options.addressIsSameAs_ITEMS = [];
    var addressList = getTableContent(form.tblClientAddress);
    if (addressList instanceof Object && Object.keys(addressList).length > 0) {
        for (var i = 0, count = addressList.length; i < count; i++) {
            var addressType = addressList[i].addressType;
            if (addressType && curAddrType != addressType && oldAddressType != addressType)
                form.tblClientAddressObj.options.addressIsSameAs_ITEMS.push({value : addressType, text : gRB("addressCoincidesWith") + " " + addressList[i].addressTypeText.toLowerCase()});
        }
        if (form.addAddrMode == 'edit' && addressList.length == 1)
            form.tblClientAddressObj.options.disableAddressIsSameAsFlag = false;
    }
    else {
        form.tblClientAddressObj.options.disableAddressIsSameAsFlag = false;
    }
};

form.checkDuplicateAddress = function (addressType, oldAddressType) {
    oldAddressType = nvl(oldAddressType, '');
    var addressList = getTableContent(form.tblClientAddress);
    if (addressList instanceof Object && Object.keys(addressList).length > 0) {
        for (var i = 0, count = addressList.length; i < count; i++) {
            if (addressType == addressList[i].addressType && addressType != oldAddressType) {
                form.showErrorDialog(gRB("duplicateAddressErrMsg"), function () {}, [{
                    caption: gRB('dialog.ok')
                }]);
                return true;
            }
        }
    }
    return false;
};
// проверка дубликата документа
form.checkDuplicateDocument = function (type) {
    var documentList = getTableContent(form.tblAdditionalDocs);
    if ((form.addDocMode == "edit" && documentList instanceof Object && Object.keys(documentList).length > 1) || (form.addDocMode == "add")) {
        for (var i = 0, count = documentList.length; i < count; i++) {
            var documentMap = documentList[i];
            if (type == documentMap.documentType && form.tblAdditionalDocsObj.selectedId != documentMap.id) {
                form.showErrorDialog(gRB("duplicateDocumentErrMsg"), function () {}, [{
                    caption: gRB('dialog.ok')
                }]);
                return true;
            }
        }
    }
    return false;
};
// изменяет признак Основной документ при добавлении второго основного документа
form.changeBaseIdentityCardFlag = function (BaseIdentityCardFlag, gridId) {
    var documentList = getTableContent(form.tblAdditionalDocs);
    form.mainDocFlag = false;
    if (documentList instanceof Object && Object.keys(documentList).length > 0) {
        for (var i = 0, count = documentList.length; i < count; i++) {
            var documentMap = documentList[i];
            if (BaseIdentityCardFlag && BaseIdentityCardFlag == documentMap.BaseIdentityCardFlag  && form.tblAdditionalDocsObj.selectedId != documentMap.id) {
                var indexDoc = i;
                form.mainDocFlag = true;
                form.showInformationDialog(gRB("changeMainDocument"), function(response){
                    switch (response.buttonIndex){
                        case 0:
                            form.BaseIdentityCardFlag.value = true;
                            form.saveCallBack(gridId);
                            documentList[indexDoc].BaseIdentityCardFlag = false;
                            //form.tblAdditionalDocs.setItems(documentList);
                            form.tblAdditionalDocs.updateRow(documentMap.id, documentList[indexDoc]);
                            form.checkClientDocumentInfo();
                            break;
                        case 1:
                            form.BaseIdentityCardFlag.value = false;
                            form.saveCallBack(gridId);
                            break;
                    }
                }, [{caption: gRB("dialog.ok"), kind:"info small"}, {caption: gRB("dialog.cancel"), kind:"info small"}]);
                break;
            }
        }
    }
};

form.saveCallBack = function (gridId) {
    var selectedRow = form.tblAdditionalDocs.getSelectedRow()[0];
    var newRow = {
        documentType: form.type ? form.type.getValue():null,
        documentTypeName: form.type ?form.type.getText():null,
        documentNumber: form.additionalDocNumber.getValue() != '' ? form.additionalDocNumber.getText() : null,
        documentIssueDate: form.additionalDocIssueDate ? form.additionalDocIssueDate.getValue():null,
        documentIssueTextDate: form.additionalDocIssueDate ?form.additionalDocIssueDate.getText():null,
        documentIssuedBy:form.additionalDocIssuedBy? form.additionalDocIssuedBy.getValue():null,
        BaseIdentityCardFlag: form.BaseIdentityCardFlag ? (form.BaseIdentityCardFlag.getValue() == true ? true : false):null,
    };

    if (selectedRow['id']) {
        newRow['id'] = selectedRow['id'];
        form[gridId].hideEditor();
        form[gridId].updateRow(form.tblAdditionalDocsObj.selectedId, newRow);

    } else {
        newRow['id'] = new Date().getTime();
        form[gridId].hideEditor();
        form[gridId].addRow(newRow);

    }
    form.btnDocAdd.enable();
};

///функция для отмены показа requiredItems для контактов
form.checkClientContactInfo = function(mode) {
    form.clientContactRequiredItems = [
        {
            caption: "${mobile}",
            ContactTypeBrief: "MobilePhone"
        }
    ];

    var contactTableList = (mode == 'show') ? form.contactTableList || [] : getTableContent(form.tblClientContact);
    var contactTypeMap = form.getMapFromList(contactTableList,"contactType", "MobilePhone") || {};
    if (contactTypeMap instanceof Object && Object.keys(contactTypeMap).length > 0) {
        form.clientContactRequiredItems = [];
    }

};

///функция для отмены показа requiredItems для документов
form.checkClientDocumentInfo = function(mode) {
    form.clientDocRequiredItems = [
        {
            caption: "${BaseIdentityCardFlag.caption}"
        }
    ];
    var documentList = (mode == 'show') ? form.documentList || [] : getTableContent(form.tblAdditionalDocs);
    var docContactTypeMap = form.getMapFromList(documentList,"BaseIdentityCardFlag", "true") || {};
    if (docContactTypeMap instanceof Object && Object.keys(docContactTypeMap).length > 0) {
        form.clientDocRequiredItems = [];
    }
};
form.checkClientAddress = function (mode){
    form.clientAddressRequiredItems = [
        {
            caption: "${oneAddress}"
        }
    ];
    var addressTableList = (mode == 'show') ? form.addressTableList || [] : getTableContent(form.tblClientAddress);
    if (addressTableList instanceof Object && Object.keys(addressTableList).length > 0) {
        form.clientAddressRequiredItems = [];
    }
};

form.setSearchParamsFlag = function (strategy, value) {
    strategy = nvl(strategy, '');
    if (nvl(strategy, '') != '') {
        var searchParams = form.formParams.searchParams;
        if (searchParams != undefined) {
            var SearchingStrategy = searchParams["SearchingStrategy"];
            if (SearchingStrategy == strategy) 
                form.formParams.searchParamsFlag = value;
        }
    }
    else
        form.formParams.searchParamsFlag = value;
};
