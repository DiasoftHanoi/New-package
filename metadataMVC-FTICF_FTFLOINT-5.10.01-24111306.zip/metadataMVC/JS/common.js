/*DSMETA version = "5.10.01-24111306" hash = "4e8b38d33e03f32e2b84af2650fa32edbdb3a4e3"*/
service.nvl = nvl;
service.convertDate = convertDate;
service.diffDate = diffDate;
service.strToNum = strToNum;

function nvl(v,d){
    return (v!=null && v!=undefined && v!=="") ? v : d;
}

function convertDate(str){
	var dateRazd = String('d.m.y').replace('y', '').replace('m', '').replace('d', '').substr(0, 1);
	var datePor = String('d.m.y').split(dateRazd).join('');
	var timeRazd = ':';
	var timePor = 'HMS';
    var str2 = (str + '').replace(/ [^ ]{3,} (\d{4})$/g, " $1");
    if (!(/^([1-9]|0[1-9]|[12][0-9]|3[01])[\.]?([1-9]|0[1-9]|1[012])[\.]?[1-9]{1}[0-9]{3}$/i).test(str2)) {
        var tmp = new Date(str2);
        var d = new Array();
        d['y'] = tmp.getFullYear();
        var tMon = tmp.getMonth();
        d['m'] = (tMon + 1) < 10 ? "0" + (tMon + 1) : (tMon + 1);
        var tDay = tmp.getDate();
        d['d'] = tDay < 10 ? "0" + tDay : tDay;
        var tHour = tmp.getHours();
        d['H'] = tHour < 10 ? "0" + tHour : tHour;
        var tMin = tmp.getMinutes();
        d['M'] = tMin < 10 ? "0" + tMin : tMin;
        var tSec = tmp.getSeconds();
        d['S'] = tSec < 10 ? "0" + tSec : tSec;
        str = '' + d[datePor.substr(0, 1)] + dateRazd + d[datePor.substr(1, 1)] + dateRazd + d[datePor.substr(2, 1)];
        if (arguments.length > 1 && arguments[1] === true) {
            str += ' ' + d[timePor.substr(0, 1)] + timeRazd + d[timePor.substr(1, 1)] + timeRazd + '00';
        }
    }
    return str;
}

function diffDate(d1, d2, r){
    var diff = false;
    var re = /^([1-9]|0[1-9]|[12][0-9]|3[01])[\.]?([1-9]|0[1-9]|1[012])[\.]?[1-9]{1}[0-9]{3}$/i;
    if (re.test(d1))
        if (re.test(d2)) {
            if ((r == 'week') || (r == 'day')) {
                var date1 = changeDateAsDate(d1, 0, 0, 0);
                var date2 = changeDateAsDate(d2, 0, 0, 0);
                diff = date2 - date1;
                diff = diff / (3600000 * 24);
                if (r == 'week')
                    diff = diff / 7;
            } else {
                d1 = d1.split('.');
                d2 = d2.split('.');
                var d3 = new Array();
                for (var i = 0; i < 3; i++) {
                    d3[i] = Math.abs(d2[i] - d1[i]);
                    d1[i] = d2[i] - d1[i];
                }
                diff = d1[2] * 12 + d1[1];
                if (d1[0] < 0) {
                    if (diff > 0)
                        diff--;
                } else {
                    if (diff < 0)
                        diff++;
                }
                if (r == 'year')
                    diff = diff / 12;
            }
        }
    return diff;
}

function strToNum(str){
    str+="";
    var n=parseFloat(str.replace(/[^\d,\.-]/g,"").replace(/,/g,"."))+"";
    n=n.replace("NaN","0");
    n=parseFloat(n);
    return n;
}

/* получает текст из выбранного радиобаттона*/
service.getRadioText = function(id){
    var ret = undefined;
    if(id.value){
        for(var i = 0; i < id.items.length; i++) {
            if (id.items[i].value==id.value){
                ret = id.items[i].text;
                break;
            }
        }
    }
    return ret;
};

service.formatAmount = function(p, fix){
    if (p==null || p==undefined || isNaN(parseFloat(p))) return 0;
    if (!fix) fix = 0;
    var f = Math.pow(10, fix);
    p = (Math.floor(p*f)/f)+ "";
    var a = p.replace(",",".").split(".");
    return (new Array(4 - a[0].length % 3).join("U")+a[0]).replace(/([0-9U]{3})/g, "$1 ").replace(/U/g, "").trim() + (a[1] ? "."+a[1] : "");
};

service.getAge = getAge;

function getAge(dateString){
    return moment(dateString,"DD.MM.YYYY").diff(new Date(),"year")*-1;
}

service.lgr = lgr;

function lgr(s){
    if (window.console){
        window.console.log(s);
    }
}
service.pageflowCall=function (a, b, c, d){
	fabPageFlowService.startPageflowWithoutDisplay('/webmvc/api/pageflow/' +a+'/'+b, c).then(function(p){
		p = service.nvl(p['data'],{});
		p = service.nvl(p['item'],{});
		p = service.nvl(p['inputParams'],{});
		d(p);
	})['catch'](function (result){
		service.lgr("catch",result);
		d({Status:'ERROR'});
	});
};

service.showModalWindow = function (form, process, params, callback){
    form.startModalPageFlowProcess(form.getCurrentProjectSysname() + '/' + process, params).then(
        function (p){
            if (callback) {
                callback(p);
            }
        });
};

service.checkINN = function(INN){
    var arrayWeights = INN.length === 10 ? [2, 4, 10, 3, 5, 9, 4, 6, 8, 0] : [3, 7, 2, 4, 10, 3, 5, 9, 4, 6, 8, 0];
    var controlAmount = 0;
    var count = INN.length == 10 ? 10 : 11;

    for (var i = 0; i < count; i++) {
        var weight = INN.length === 10 ? arrayWeights[i] : arrayWeights[i + 1];
        controlAmount += parseInt(INN[i]) * weight;
    }

    var controlNumber = controlAmount % 11;
    controlNumber = controlNumber > 9 ? controlNumber % 10 : controlNumber;

    if (INN.length === 10) {
        return Boolean(parseInt(controlNumber) === parseInt(INN[9]));
    } else {
        if (parseInt(controlNumber) !== parseInt(INN[10])) {
            return false
        }
        controlAmount = 0;

        for (var i = 0; i < INN.length; i++) {
            controlAmount += parseInt(INN[i]) * arrayWeights[i];
        }

        controlNumber = controlAmount % 11;
        controlNumber = controlNumber > 9 ? controlNumber % 10 : controlNumber;

        return Boolean(parseInt(controlNumber) === parseInt(INN[11]));
    }
};

service.setMask = function(srcString,mask,explodeNumber){
    var srcString = srcString+"";
    var mask = mask+"";
    var maskResult = mask;

    var positionMask = function(mask){
        if(explodeNumber)
            return mask.search(/[\d#]/);
        return mask.indexOf('#');
    };

    if(mask=='' || positionMask(mask)==-1)
        return srcString;

    while(positionMask(mask) >= 0){
        var pos = positionMask(mask);
        if(pos == -1)
            break;
        if(pos == mask.length-1){
            mask = mask.substring(0,pos)+'z';
            maskResult = maskResult.substring(0,pos)+srcString[0];
        }
        else{
            mask = mask.substring(0,pos)+'z'+mask.substring(pos+1);
            maskResult = maskResult.substring(0,pos)+srcString[0]+ mask.substring(pos+1);
        }
        srcString = srcString.substring(1);
    }
    return maskResult;
};
