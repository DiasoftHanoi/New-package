/*DSMETA version = "5.10.01-24111306" hash = "fea4ff73f6556b35af844f9de6e303af274c5f06"*/
/* global form */

function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
service = registerMethod(service);

var convertDate = service.convertDate;
var getTableContent = service.getTableContent;
var gRB = service.gRB;
var nvl = service.nvl;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);

form.isFormEditMode = form.inputParams.EDITMODE || false;

var inputParams = form.inputParams;
var outputParams = form.outputParams;

form.formParams = inputParams.formParams || {};
outputParams.formParams = form.formParams;

form.requiredElements = [
    "edFirstName",
    "cmSex",
    "clBirthDate",
    "edRelationshiWithBorrowerOther",
    "addressType",
    "addressBlock",
    "cmRelationshiWithBorrower",
    "contactComment",
    "contactType",
    "contactValue",
    "tblClientAddress",
    "tblClientContact"
];

form.requiredItems = [
    {
        caption: "${mobile}",
        ContactTypeBrief: "MobilePhone"
    }
];

form.requiredItemsAddress = [
    {
        caption: "${oneAddress}",
        AddressTypeBrief: "OneAddress"
    }
];

form.BorrowerLevel = {
    ReferenceGroupName: 'Distribution Reference Tables',
    ReferenceSysName: 'relashionshiptype'
};

form.RelationshipWithBorrowerOther = function () {
    if(form.cmRelationshiWithBorrower.getText() == "Other") {
         form.isBorrowerOther = true;
    }else{
         form.isBorrowerOther = false;
    }
};

form.templateData={
    templateKind:"small" ,
    address:{},
    addressText:"",    
}
form.onShow = function () {
    if (!form.isFormEditMode) {
        form.getAge();
    }

    var contactList = form.formParams.contactList || [];
    var addressList = form.formParams.addressList || [];

    var contactTypeMap = form.getMapFromList(contactList, "contactType", "MobilePhone") || {};
    if (contactTypeMap instanceof Object && Object.keys(contactTypeMap).length > 0) {
        form.requiredItems = [];
    }
    if (contactList && contactList.length > 0) {
        form.requiredItemsAddress = [];
    }

    form.checkClientAddress('show');
    form.checkClientContactInfo('show');
    form.tblClientAddressObj.setItems(form.formParams.addressList || []);

    var contactTypeList = form.inputParams.contactTypeList || [];
    contactTypeMap      = {};
    for (var i = 0; i < contactTypeList.length; i++) {
        var contactType = contactTypeList[i];
        contactTypeMap[contactType.ContactTypeBrief] = contactType.ContactTypeMaskCode + contactType.ContactTypeMaskNumber;
    }
    for (var i = 0; i < contactList.length; i++) {
        var contactType = contactList[i].contactType;
        if (contactTypeMap[contactType] != undefined) {
            contactList[i].contactText = service.setMask(contactList[i].contactValue, contactTypeMap[contactType], true);
        }
    }
    form.tblClientContactObj.setItems(contactList || []);
    if (!form.isFormEditMode) {
        if (form.btnNext) {
            form.btnNext.setFocus();
        }
        else if (form.btnSave) {
            form.btnSave.setFocus();
        }
        else {
            form.btnCancel.setFocus();
        }
    }
};

form.settings = {
    cmSex_items: [{
        value: 'Male',
        text: gRB('Male')
    }, {
        value: 'Female',
        text: gRB('Female')
    }
    ]
};

form.getMinBirthDate = function () {
    var now = new Date();
    return service.convertDate(new Date(now.setFullYear(now.getFullYear() - 18)));
};

form.formParams.clientAge = form.formParams.clientAge != null ? form.formParams.clientAge : '';

form.getAge = function () {
    var bDate = (form.isFormEditMode) ? form.clBirthDate.getText() : utils.jsDateToString(form.formParams.clientBirthDate);
    if (!form.isFormEditMode || form.clBirthDate.isValid()) {
        form.formParams.clientAge = parseInt(service.diffDate(bDate, form.curDate, 'year'));
    }
};

if (form.clBirthDate && form.formParams.clientAge == null) {
    form.formParams.clientAge = parseInt(service.diffDate(convertDate(new Date(form.clBirthDate)), convertDate(new Date()), 'year'));
}

var sendMessage = function (message) {
    var PROCESS_RIGHT_LIST = getInputParams("PROCESS_RIGHT_LIST");
    if (PROCESS_RIGHT_LIST) {
        for (var ar in PROCESS_RIGHT_LIST) {
            form.commandRight(ar, message);
        }
    }
}

form.curDate = service.convertDate(new Date());

form.yesFunc = function() {
    form.outputParams.TRANSTYPE = 'SAVEDRAFT';
    if (form.verifyForm()) {
        form.sendForm('GO', false);
    }
};

form.nextSave = function() {
    var clientAge = form.formParams.clientAge;
        var clientFirstName = form.formParams.clientFirstName;
        var clientGender = form.formParams.clientGender;
        var clientBirthDate = form.formParams.clientBirthDate;
        var RelationshiWithBorrower = form.formParams.RelationshiWithBorrower;
        if(form.isFormEditMode == true)
            var relationshiWithBorrowerBrief = form.cmRelationshiWithBorrower.getText();
        var relationshiWithBorrowerOther = form.formParams.relationshiWithBorrowerOther;
        var addressList = form.tblClientAddressObj.getItems();
        var contactList = form.tblClientContactObj.getItems();
        var referencePersonListID = form.formParams.referencePersonListID;
        var LinkID = form.formParams.LinkID;
        var applicationListFormEditMod = false;

        if(form.formParams.referencePersonList == null) {
            form.formParams.referencePersonList = [];
        }
        if (LinkID) {
            applicationListFormEditMod = true;
        } else {
            LinkID = new Date().getTime();
        }
        if(form.isFormEditMode == true) {
             if (applicationListFormEditMod) {
                 for (var i = 0; i < form.formParams.referencePersonList.length; i++) {
                     if (form.formParams.referencePersonList[i].LinkID == LinkID) {
                         form.formParams.referencePersonList[i].RelationshiWithBorrower = RelationshiWithBorrower;
                         form.formParams.referencePersonList[i].relationshiWithBorrowerBrief = relationshiWithBorrowerBrief;
                         form.formParams.referencePersonList[i].clientAge = clientAge;
                         form.formParams.referencePersonList[i].clientBirthDate = clientBirthDate;
                         form.formParams.referencePersonList[i].clientFirstName = clientFirstName;
                         form.formParams.referencePersonList[i].clientGender = clientGender;
                         form.formParams.referencePersonList[i].contactList = contactList;
                         form.formParams.referencePersonList[i].relationshiWithBorrowerOther = relationshiWithBorrowerOther;
                         form.formParams.referencePersonList[i].addressList = addressList;
                         break;
                     }
                 }
             } else {
                 form.formParams.referencePersonList.push({clientAge: clientAge,clientFirstName: clientFirstName, clientGender: clientGender, clientBirthDate: clientBirthDate, RelationshiWithBorrower: RelationshiWithBorrower, relationshiWithBorrowerBrief: relationshiWithBorrowerBrief, relationshiWithBorrowerOther: relationshiWithBorrowerOther, LinkID : LinkID, addressList: addressList, contactList: contactList});
             }
        }
        form.commandAll({event: "REFRESH_PERSON_LIST", params: {referencePersonList: form.formParams.referencePersonList}});
}

form.action = function (tagName) {
    if (tagName === 'CLOSE') {
        if(form.inputParams.EDITMODE === false){
            form.sendForm('GO',false);
        }
        else {
            if (form.verifyForm(false)) {
                form.outputParams.TRANSTYPE = 'SAVEDRAFT';
                form.nextSave();
            }
            form.sendForm('GO', false);
            /*service.showDialogCancelConfirm(
                form,
                function (){
                    form.outputParams.TRANSTYPE = 'SAVEDRAFT';
                    if (form.verifyForm(true)) {
                        form.nextSave();
                        form.sendForm('GO', false);
                    }
                }
            )*/
        }
    } else {

        if (tagName === 'NEXT' && !form.verifyForm(true)) {
            return;
        } else {
            form.verifyForm(false);
        }
        form.nextSave();
        form.sendForm('GO', false);
    }
};

form.verifyForm = function (showFlag) {
    var verified = true;
    var buttonNextSave = "btnNext";
    try {
        console.log('verifyForm')
        if ((form.validateControlsByIds(form.requiredElements.join(','), showFlag === true ? buttonNextSave : undefined).isShowFormErrors)) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    form.outputParams.VERIFIED = verified;
    return verified;
};

form.executeCommand = function (message) {
    if (message.event == "FAB_NAVIGATOR_NAVIGATE") {
        form.outputParams.NEXTPAGE = message.params.step;
        form.action("DIRECT");
    }
};


form.getMapFromList = function (list, key, val) {
    for (var i = 0; i < list.length; i++) {
        if (list[i][key] + '' === val + '') {
            return list[i];
        }
    }
};

form.tblClientAddressObj = (function (grId) {
    var gridId = grId;
    var options = {
        templateData:form.templateData,
        disableAddressIsSameAsFlag : false,
        requiredElements : [
            "addressType",
            "addressBlock",
        ],
        addressTypeComboBoxParams_ITEMS: form.inputParams.addressTypeList || {},
        data: {},
        cancel: function () {
            options.clearFields();
            form[gridId].hideEditor();
            form.btnAddressAdd.enable();
        },
        save: function () {
            var selectedRow = form.tblClientAddress.getSelectedRow()[0];
            if (form.checkDuplicateAddress(options.data.addressType, selectedRow.addressType)) {
                return;
            }

            var newRow = {
                addressType                 : form.addressType.getValue(),
                addressTypeText             : form.addressType.getText(),
                addressIsSameAs             : (form.addressIsSameAs.getValue()) ? form.addressIsSameAs.getValue() : '',
                addressIsSameAsText         : (form.addressIsSameAs.getText()) ? form.addressIsSameAs.getText() : '',
                blockAddress                : form.addressBlock.data.address,
                addressString               : form.addressBlock.data.address.addressText,
            };
            angular.extend(newRow, form.addressBlock.data.address);
            options.clearFields();
            if (selectedRow['id']) {
                newRow['id'] = selectedRow['id'];
                form[gridId].hideEditor();
                form[gridId].updateRow(obj.selectedId, newRow);

            } else {
                newRow['id'] = new Date().getTime();
                form[gridId].hideEditor();
                form[gridId].addRow(newRow);
            }
            form.checkClientAddress();
            form.btnAddressAdd.enable();
        },
        clearFields: function () {
            delete options.data.addressType;
            if (form.addressType)
               form.addressType.clearValue();
            delete options.data.addressIsSameAs;
            if(form.addressBlock) {
                form.addressBlock.data.address={};
                form.addressBlock.data.addressText="";
            }
            delete options.data.addressString;
            delete options.data.isSameAddressFlag;
        },
        edit: function () {
            form.addAddrMode = 'edit';
            form[gridId].showEditor('edit');
            options.clearFields();
            var selectedRow = form.tblClientAddress.getSelectedRow()[0];
            form.fillComboAddressIsSameAs(selectedRow.addressType);
            form.tblClientAddressObj.options.data = {
                addressType             : selectedRow["addressType"],
                addressIsSameAs         : selectedRow["addressIsSameAs"],
                blockAddress            : selectedRow['blockAddress'],
                addressString           : selectedRow["addressString"],
                isSameAddressFlag       : (nvl(selectedRow["addressIsSameAs"], '') != '')
            };
            form.tblClientAddressObj.options.templateData.address=selectedRow["blockAddress"];
            form.tblClientAddressObj.options.templateData.addressText=selectedRow["addressString"];
            form.checkClientAddress();
            form.btnAddressAdd.disable();
        },
        delete: function () {
            var row = form.tblClientAddress.getSelectedRow()[0];
            if (row) {
                var addressList = getTableContent(form.tblClientAddress);
                if (addressList instanceof Object && Object.keys(addressList).length > 1) {
                    for (var i = 0, count = addressList.length; i < count; i++) {
                        var addressIsSameAsCur = nvl(addressList[i].addressIsSameAs, '');
                        if (addressIsSameAsCur.toLowerCase() == row.addressType.toLowerCase()) {
                            addressList[i].addressIsSameAs = null;
                            delete addressList[i].addressIsSameAsText;
                        }
                    }
                    form.tblClientAddressObj.setItems(addressList);
                }
                form.tblClientAddress.deleteRow(obj.selectedId);
                form[gridId].refresh();
            }
            form.checkClientAddress();
            form.btnAddressAdd.enable();
        },
        fillAddressIsSameAs : function (item) {
            if (nvl(item.value, '') != '') {
                var addressList = getTableContent(form.tblClientAddress);
                if (addressList instanceof Object && Object.keys(addressList).length > 0) {
                    for (var i = 0, count = addressList.length; i < count; i++) {
                        if (addressList[i].addressType && item.value.toLowerCase() == addressList[i].addressType.toLowerCase()) {
                            this.templateData.address      = addressList[i].blockAddress;
                            this.templateData.address.addressText      = addressList[i].addressString;
                            this.data.addressString     = addressList[i].addressString;
                            this.data.isSameAddressFlag = true;
                            break;
                        }
                    }
                }
            }
            else 
                this.data.isSameAddressFlag = false;
        },
        onChangeAddressType : function (item) {
            var selectedRow = form.tblClientAddress.getSelectedRow()[0];
            form.fillComboAddressIsSameAs(item.AddressTypeBrief, selectedRow.addressType);
        }
    };

    var obj = {
        gridId: grId,
        refresh: function () {
            form[gridId].refresh();
        },
        onChangeItems: function () {
        },
        addNewRow: function () {
            form.addAddrMode = 'add';
            form[gridId].showEditor('add');
            options.clearFields();
            form.fillComboAddressIsSameAs();
            form.btnAddressAdd.disable();
        },
        setItems: function (items) {
            form[gridId].setItems(items);
        },
        getItems: function () {
            return form[gridId].getItems();
        },
        onSelectRow: function () {
            options.items = [];
            if (form.isFormEditMode == true) {
                var selRow = form[gridId].getSelectedRow()[0] || {};
                options.items = [
                    {caption: gRB('edit'),   click: form.tblClientAddress.options.edit},
                    {caption: gRB('delete'), click: form.tblClientAddress.options.delete}
                ];
            }
        }
    };
    obj.options = options;
    return obj;
})('tblClientAddress');

form.fillComboAddressIsSameAs = function (curAddrType, oldAddressType) {
    curAddrType    = nvl(curAddrType, '');
    oldAddressType = nvl(oldAddressType, '');
    form.tblClientAddressObj.options.disableAddressIsSameAsFlag = true;
    form.tblClientAddressObj.options.addressIsSameAs_ITEMS = [];
    var addressList = getTableContent(form.tblClientAddress);
    if (addressList instanceof Object && Object.keys(addressList).length > 0) {
        for (var i = 0, count = addressList.length; i < count; i++) {
            var addressType = addressList[i].addressType;
            if (curAddrType != addressType && oldAddressType != addressType)
                form.tblClientAddressObj.options.addressIsSameAs_ITEMS.push({value : addressType, text : gRB("addressCoincidesWith") + " " + addressList[i].addressTypeText.toLowerCase()});
        }
        if (form.addAddrMode == 'edit' && addressList.length == 1)
            form.tblClientAddressObj.options.disableAddressIsSameAsFlag = false;
    }
    else {
        form.tblClientAddressObj.options.disableAddressIsSameAsFlag = false;
    }
};

form.tblClientContactObj = (function (grId) {
    var gridId = grId;
    var options = {
        addressIsSameAs_ITEMS : [],
        requiredElements : [
            "contactType",
            "contactValue",
            "contactComment"
        ],
        contactTypeComboBoxParams_ITEMS: form.inputParams.contactTypeList || {},
        data: {},
        cancel: function () {
            form[gridId].hideEditor();
            form.btnContactAdd.enable();
        },
        save: function () {
            var selectedRow = form.tblClientContact.getSelectedRow()[0];
            var newRow = {
                contactType     : form.contactType.getValue(),
                contactTypeText : form.contactType.getText(),
                contactValue    : form.contactValue.getValue(),
                contactText     : form.contactValue.getText(),
                contactComment  : form.contactComment.getValue()
            };
            if (selectedRow['id']) {
                newRow['id'] = selectedRow['id'];
                form[gridId].hideEditor();
                form[gridId].updateRow(obj.selectedId, newRow);

            } else {
                newRow['id'] = new Date().getTime();
                form[gridId].hideEditor();
                form[gridId].addRow(newRow);

            }
            form.checkClientContactInfo();
            form.btnContactAdd.enable();
        },
        clearFields: function () {
            delete options.data.contactType;
            if (form.contactType)
               form.contactType.clearValue();
            delete options.data.contactValue;
            delete options.data.contactComment;
        },
        edit: function () {
            options.clearFields();

            var selectedRow = form.tblClientContact.getSelectedRow()[0];

            form[gridId].showEditor('edit');
            form.tblClientContactObj.options.data = {
                contactType    : selectedRow["contactType"],
                contactValue   : selectedRow["contactValue"],
                contactComment : selectedRow['contactComment']
            };
            options.onChangeContactType(selectedRow['contactType']);
            form.btnContactAdd.disable();

        },
        delete: function () {
            if (form.tblClientContact.getSelectedRow()[0]) {
                form.tblClientContact.deleteRow(obj.selectedId);
                form[gridId].refresh();
                form.requiredItems = [
                    {
                        caption: "${mobile}",
                        ContactTypeBrief: "MobilePhone"
                    }
                ];
                var contactTableList = form.tblClientContact.getItems() || [];
                if (contactTableList && contactTableList.length > 0) {
                    for (var i = 0, count = contactTableList.length; i < count; i++) {
                        if (contactTableList[i].contactType.toLowerCase() == 'mobilephone') {
                            form.requiredItems = [];
                        }
                    }
                }
            }
            form.checkClientContactInfo();
            form.btnContactAdd.enable();
        },

        onChangeContactType : function (item) {
            options.emailCheckValueRX = '';
            options.emailFilterRX = '';
            if (item && item.ContactTypeBrief != undefined){
               options.numberMask = item.ContactTypeMaskCode+item.ContactTypeMaskNumber;
               if (item.ContactTypeBrief.indexOf("Email") > 0) {
                   options.emailCheckValueRX = '^([a-zA-Z0-9_-]+\\.)*[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\\.[a-zA-Z0-9_-]+)*\\.[a-z]{2,}$';
                   options.emailFilterRX = '[.@a-zA-Z0-9_-]';
                }
            } 
        },

        onChangeContactTypeReq: function(items) {
           options.emailCheckValueRX = '';
           options.emailFilterRX = '';
           if(items) {
              items.forEach(function(row) {
                 if(row.ContactTypeBrief === options.data.contactType) options.numberMask = row.ContactTypeMaskCode + row.ContactTypeMaskNumber
              }, this);
           }

        }
    };

    var obj = {
        gridId: grId,
        refresh: function () {
            form[gridId].refresh();
        },
        onChangeItems: function () {
        },
        addNewRow: function () {
            form[gridId].showEditor('add');
            options.clearFields();
            options.onChangeContactType(form.tblClientContact.getSelectedRow()[0]['contactType']);
            form.btnContactAdd.disable();
        },
        setItems: function (items) {
            form[gridId].setItems(items);
        },
        getItems: function () {
            return form[gridId].getItems();
        },
        onSelectRow: function () {
            options.items = [];
            if (form.isFormEditMode == true) {
                var selRow = form[gridId].getSelectedRow()[0] || {};
                options.items = [
                    {caption: gRB('edit'),   click: form.tblClientContact.options.edit},
                    {caption: gRB('delete'), click: form.tblClientContact.options.delete}
                ];
            }
        }
    };
    obj.options = options;
    return obj;
})('tblClientContact');

form.addClientContact = function (item) {
    form.tblClientContactObj.options.clearFields();
    form.btnContactAdd.disable();
    form.tblClientContactObj.options.data.contactType = item.ContactTypeBrief;
    form.tblClientContactObj.options.onChangeContactType(item['ContactTypeBrief']);
};

form.checkClientAddress = function (mode){
    if (form.isFormEditMode == true)
        form.clientAddressRequiredItems = [
            {
                caption: "${oneAddress}"
            }
        ];
    else
        form.clientAddressRequiredItems = [];

    var addressTableList = (mode == 'show') ? form.formParams.addressList || [] : getTableContent(form.tblClientAddress);
    if (addressTableList instanceof Object && Object.keys(addressTableList).length > 0) {
        form.clientAddressRequiredItems = [];
    }
};

form.checkDuplicateAddress = function (addressType, oldAddressType) {
    oldAddressType = nvl(oldAddressType, '');
    var addressList = getTableContent(form.tblClientAddress);
    if (addressList instanceof Object && Object.keys(addressList).length > 0) {
        for (var i = 0, count = addressList.length; i < count; i++) {
            if (addressType == addressList[i].addressType && addressType != oldAddressType) {
                form.showErrorDialog(gRB("duplicateAddressErrMsg"), function () {}, [{
                    caption: gRB('dialog.ok')
                }]);
                return true;
            }
        }
    }
    return false;
};

form.checkClientContactInfo = function(mode) {
    if (form.isFormEditMode == true)
        form.clientContactRequiredItems = [
            {
                caption: "${mobile}",
                ContactTypeBrief: "MobilePhone"
            }
        ];
    else 
        form.clientContactRequiredItems = [];

    var contactTableList = (mode == 'show') ? form.formParams.contactList || [] : getTableContent(form.tblClientContact);
    var contactTypeMap = form.getMapFromList(contactTableList,"contactType", "MobilePhone") || {};
    if (contactTypeMap instanceof Object && Object.keys(contactTypeMap).length > 0) {
        form.clientContactRequiredItems = [];
    }
};

form.addOneAddress = function(item) {
    form.tblClientAddressObj.options.clearFields();
    form.btnAddressAdd.disable();
};

