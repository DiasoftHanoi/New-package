/*DSMETA version = "5.10.01-24111306" hash = "3a3aebd8979a399ee20b90de1b43c0d717feeee8"*/
/* global form */

function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
service = registerMethod(service);

var convertDate = service.convertDate;
var getTableContent = service.getTableContent;
var gRB = service.gRB;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);

form.isFormEditMode = form.inputParams.EDITMODE || false;

var inputParams = form.inputParams;
var outputParams = form.outputParams;

form.formParams = inputParams.formParams || {};
form.formParams.incomeList  = form.inputParams.incomeList ? form.inputParams.incomeList:[];
outputParams.formParams = form.formParams;

form.requiredElements = [
    "tblJobInfo"
];

form.onShow = function () {
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });
    form.tblJobInfoObj.setItems(form.inputParams.EmploymentList || []);
    form.checkJobInfoRequiredItem('show');

    if (!form.isFormEditMode) {
        if (form.btnNext) {
            form.btnNext.setFocus();
        }
        else if (form.btnSave) {
            form.btnSave.setFocus();
        }
        else {
            form.btnCancel.setFocus();
        }
    }
};

var sendMessage = function (message) {
    var PROCESS_RIGHT_LIST = getInputParams("PROCESS_RIGHT_LIST");
    if (PROCESS_RIGHT_LIST) {
        for (var ar in PROCESS_RIGHT_LIST) {
            form.commandRight(ar, message);
        }
    }
};

form.curDate = service.convertDate(new Date());

form.yesFunc = function() {
    form.outputParams.TRANSTYPE = 'SAVEDRAFT';
    form.sendForm('GO', false);
};

form.action = function (tag) {
    outputParams.TRANSTYPE = tag;
    outputParams.EmploymentList = form.tblJobInfoObj.getItems();
    outputParams.formParams.incomeList=form.formParams.incomeList;

    if (tag === 'CLOSE') {
        if(form.inputParams.EDITMODE === false){
            form.sendForm('GO',false);
        }else {
            form.verifyForm(true, tag);
            service.showDialogCancelConfirm(
                form,
                form.yesFunc
            )
        }
    }
    else {
        if (tag === 'NEXT' && !form.verifyForm(true)) {
            return;
        } else {
            form.verifyForm(false);
        }
        form.sendForm('GO', false);
    }
};

form.verifyForm = function (showFlag, tag) {
    var verified = true;
    var buttonNextSave = (form.isLastWizForm) ? "btnSave" : "btnNext";
    if (tag === 'CLOSE') {
        buttonNextSave = "btnCancel";
    }
    try {
        if ((form.validateControlsByIds(form.requiredElements.join(','), showFlag === true ? buttonNextSave : undefined).isShowFormErrors)) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    form.outputParams.VERIFIED = verified;
    return verified;
};

form.executeCommand = function (message) {
    if (message.event == "FAB_NAVIGATOR_NAVIGATE") {
        form.outputParams.NEXTPAGE = message.params.step;
        form.action("DIRECT");
    }
};

/////////////////////////////////////////////////////////////////////////////////////
form.getMapFromList = function (list, key, val) {
    for (var i = 0; i < list.length; i++) {
        if (list[i][key] + '' === val + '') {
            return list[i];
        }
    }
};
form.showRemoveDialog =function(form, yesFunc, noFunc){
    var gRB = form.getResourceBundle;

    form.showQuestionDialog(gRB('dialog.RemoveEmploymentAndIncomeLists'),
        function (response){
            switch (response.buttonIndex){
                case 0:
                    if (yesFunc){
                        yesFunc();
                    } else {
                        form.outputParams.TRANSTYPE = 'SAVE';
                        form.sendForm('GO',false);
                    }
                    break;
            }
        },
        [
            {caption: gRB('dialog.yes')},
            {caption: gRB('dialog.no')}
        ]
    )
};
form.tblJobInfoObj = (function (grId) {
    var gridId = grId;
    var options = {
        delete: function () {
            var  index=-1;
            var isFind=false;
            for (var i=0;i<form.formParams.incomeList.length;i++){
                var item = form.formParams.incomeList[i];
                if(item["LinkID"]===obj.selectedId){
                    index=i;
                    isFind=true;
                    break;
                }
            }
            if(isFind){
                form.showRemoveDialog(form,
                    function(){
                        form.formParams.incomeList.splice( index, 1);

                        if (form.tblJobInfo.getSelectedRow()[0]) {
                            form.tblJobInfo.deleteRow(obj.selectedId);
                            form[gridId].refresh();
                            form.checkJobInfoRequiredItem();
                        }
                    });
            }else{
                if (form.tblJobInfo.getSelectedRow()[0]) {
                    form.tblJobInfo.deleteRow(obj.selectedId);
                    form[gridId].refresh();
                    form.checkJobInfoRequiredItem();
                }
            }


        },
        editJobInfoItem : function (pageHeader, isFormEditMode) {
            var selectedRow = form.tblJobInfo.getSelectedRow()[0] || {};
            var pageHeaderTemp = (form.isFormEditMode) ? gRB("edit") : gRB("view");
            var isFormEditModeTemp = (form.isFormEditMode) ? "edit" : "view";
            var jobInfoParam = {
                newRow  : (isFormEditMode == "add") ? {} : selectedRow,
                PAGEHEADER  : (isFormEditMode) ? pageHeader : pageHeaderTemp + " " + "${jobInfo}",
                EDITMODE    : (isFormEditMode) ? isFormEditMode : isFormEditModeTemp
            };
            form.startModalPageFlowProcess(form.getCurrentProjectSysname() + "/FORMLIB/inputApplication/jobInfo/clientJobInfo", jobInfoParam).then(function (response) {
                if (!response) {
                   form.tblJobInfo.hideEditor();
                   return;
                }
                var newRow = response.newRow || {};
                if (jobInfoParam.EDITMODE == "view") return;
                if (selectedRow['LinkID'] && jobInfoParam.EDITMODE != "add") {
                    form.tblJobInfo.hideEditor();
                    if (newRow instanceof Object && Object.keys(newRow).length > 0) {
                        form.tblJobInfo.updateRow(selectedRow['LinkID'], newRow);
                    }
                }
                else {
                    //form.tblJobInfo.hideEditor();
                    if (newRow instanceof Object && Object.keys(newRow).length > 0) {
                        newRow['LinkID'] = new Date().getTime();
                        form.tblJobInfo.addRow(newRow);
                    }
                }
                var clientJobInfoList = getTableContent(form.tblJobInfo);
                form.checkJobInfoRequiredItem();
            });
        }
    };

    var obj = {
        gridId: grId,
        refresh: function () {
            form[gridId].refresh();
        },
        onChangeItems: function () {
        },
        addNewRow: function (element) {
            if (element == 'grid') {
                form.tblJobInfo.hideEditor();
            }
            this.options.editJobInfoItem(gRB("add") + " " + "${jobInfo}", "add");
        },
        setItems: function (items) {
            form[gridId].setItems(items);
        },
        getItems: function () {
            return form[gridId].getItems();
        },
        onSelectRow: function () {
            options.items = [];
            var selectedRow = form.tblJobInfo.getSelectedRow()[0];
            if (form.isFormEditMode == true) {
                options.items = [
                    {caption: gRB('edit'), click: form.tblJobInfo.options.editJobInfoItem},
                    {caption: gRB('delete'), click: form.tblJobInfo.options.delete}
                ];
            }
            else {
                options.items = [
                    {caption: gRB('view'), click: form.tblJobInfo.options.editJobInfoItem}
                ];
            }
        }
    };
    obj.options = options;
    return obj;
})('tblJobInfo');

form.addJobInfo = function () {
    form.tblJobInfoObj.options.editJobInfoItem(gRB("add") + " " + "${jobInfo}", "add");
};

form.checkJobInfoRequiredItem = function (mode) {
    form.requiredItems = [
        {
            caption: "${mainPlaceOfWork}",
            employmentType: "${mainPlaceOfWork}"
        }
    ];
    var jobInfoTableList = (mode == 'show') ? form.inputParams.EmploymentList || [] : getTableContent(form.tblJobInfo);
    var jobInfoTableMap = form.getMapFromList(jobInfoTableList, "employmentType", "${mainPlaceOfWork}") || {};
    if ((jobInfoTableMap instanceof Object && Object.keys(jobInfoTableMap).length > 0) || !form.isFormEditMode || !!form.formParams.unemployed) {
        form.requiredItems = [];
    }
};