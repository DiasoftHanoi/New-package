/*DSMETA version = "5.10.01-24111306" hash = "5fb43dc6c2d3437b330392b8144ecadf4220a427"*/
/* global form, service */

var inputParams = form.inputParams || {};
form.formParams = inputParams.formParams;

var outputParams = form.outputParams || {}
outputParams.formParams = form.formParams;

var lgr = service.lgr;
var nvl = service.nvl;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);
form.isFormEditMode = form.inputParams.EDITMODE || false;

form.isSpouseCoborrower = true;
if(form.inputParams.TYPESYSNAME == "issueCardAppINT"){
   form.isSpouseCoborrower = false;
}
form.formParams.spouseCoborrowerText = "No";
if(form.formParams.spouseCoborrower + "" == 'true') form.formParams.spouseCoborrowerText = "Yes";

form.onShow = function () {
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });
};

form.executeCommand = function(msg){
    if (msg.event === 'FAB_NAVIGATOR_NAVIGATE'){
        outputParams.NEXTPAGE = msg.params.step;
        form.action('DIRECT');
    }
};

form.EducationLevel = {
    ReferenceGroupName: 'General',
    ReferenceSysName: 'Education'
};

form.MarriageStatus = {
    ReferenceGroupName: 'General',
    ReferenceSysName: 'marriageStatusBorrower'
};

form.verifyForm = function (showFlag, tag) {
    var verified = true;
    try {
        var btnNext =  form['btnNext'] ? 'btnNext' : 'btnSave';
        if (tag === 'CLOSE') {
            btnNext = "btnCancel";
        }
        if (form.validateControlsByIds('*', showFlag === true ? btnNext : undefined).isShowFormErrors) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {lgr(e);
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    form.outputParams.VERIFIED = verified;
    return verified;
};

form.action = function (tagName) {
    outputParams.TRANSTYPE = tagName;
     if(form["educationTypeBrief"])
            outputParams.formParams.EducationTypeBriefText = form.educationTypeBrief.getText();
     if(form["marriageStatus"])
            outputParams.formParams.MaritalStatusText = form.marriageStatus.getText();

    if (tagName === 'CLOSE') {
        if(form.inputParams.EDITMODE === false){
            form.sendForm('GO',false);
        }else {
            form.verifyForm(true, tagName);
            service.showDialogCancelConfirm(
                form,
                function () {
                    form.outputParams.TRANSTYPE = 'SAVEDRAFT';
                    form.sendForm('GO', false);
                }
            )
        }
    } else {

        if (tagName === 'NEXT' && !form.verifyForm(true)) {
            return;
        } else {
            form.verifyForm(false);
        }
        form.sendForm('GO', false);
    }
}