/*DSMETA version = "5.10.01-24111306" hash = "c2dd51d2dd7ed8040fdd7a801d0436c145561779"*/
var inputParams = form.inputParams || {};
form.formParams = inputParams.formParams || {};

var outputParams = form.outputParams || {};
outputParams.formParams = form.formParams || {};

var lgr = service.lgr;
var nvl = service.nvl;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);

form.onShow = function () {

};

form.executeCommand = function(msg){
    if (msg.event === 'FAB_NAVIGATOR_NAVIGATE'){
        outputParams.NEXTPAGE = msg.params.step;
        form.action('DIRECT');
    }
};

form.verifyForm = function (showFlag) {
    var verified = true;
    try {
        var btnNext =  form['btnNext'] ? 'btnNext' : 'btnSave';
        if (form.validateControlsByIds('*', showFlag === true ? btnNext : undefined).isShowFormErrors) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {lgr(e);
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    form.outputParams.VERIFIED = verified;
    return verified;
};

form.action = function (tagName) {
    outputParams.STAGEDETAILS = form.formParams.STAGEDETAILS;
    outputParams.TRANSTYPE = tagName;

    if (tagName === 'CLOSE' || tagName === 'PREV') {
        form.sendForm('CLOSE', false);
    } else {

        if (tagName === 'NEXT' && !form.verifyForm(true)) {
            return;
        } else {
            form.verifyForm(false);
        }
        form.sendForm('GO', false);
    }
};