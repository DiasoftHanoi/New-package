/*DSMETA version = "5.10.01-24112501" hash = "f4fa7fb09cfd5f5d707421ffe1767f9d3b1489dc"*/
/* global form, service */

var inputParams = form.inputParams || {};
form.formParams = inputParams.formParams;

var outputParams = form.outputParams || {};
outputParams.formParams = form.formParams;

function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}

service = registerMethod(service);
var getTableContent = service.getTableContent;

var lgr = service.lgr;
var nvl = service.nvl;
var gRB = service.gRB;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);

form.isFormEditMode = form.inputParams.EDITMODE || false;

form.onShow = function () {
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });
    form.tblLoanObj.setItems(form.inputParams.CreditHistoryLoanCIC || []);
    form.tblCreditCardObj.setItems(form.inputParams.CreditHistoryCreditCardCIC || []);
    if (!form.isFormEditMode) {
        if (form.btnNext) {
            form.btnNext.setFocus();
        }
        else if (form.btnSave) {
            form.btnSave.setFocus();
        }
        else {
            form.btnCancel.setFocus();
        }
    }
};

form.executeCommand = function(msg){
    if (msg.event === 'FAB_NAVIGATOR_NAVIGATE'){
        outputParams.NEXTPAGE = msg.params.step;
        form.action('DIRECT');
    }
};

//CreditCard
form.tblCreditCardObj = (function (grId) {
    var gridId = grId;
    var options = {
        delete: function () {
            if (form.tblCreditCard.getSelectedRow()[0]) {
                form.showDeleteDialog(gRB("dialog.confirmDelete"),
                function (idxData) {
                    if (idxData.buttonIndex == 0) {
                        form.tblCreditCard.deleteRow(obj.selectedId);
                        form[gridId].refresh();
                    }
                },
                [{caption: gRB('dialog.yes')}, {caption: gRB('dialog.cancel')}])
            }
        },
        editCreditCardItem : function (pageHeader, isFormEditMode) {
            var selectedRow = form.tblCreditCard.getSelectedRow()[0] || {};
            var pageHeaderTemp = (form.isFormEditMode) ? gRB("edit") : gRB("view");
            var isFormEditModeTemp = (form.isFormEditMode) ? "edit" : "view";
            var CreditCardParam = {
                newRow  : (isFormEditMode == "add") ? {} : selectedRow,
                PAGEHEADER  : (isFormEditMode) ? pageHeader : pageHeaderTemp + " " + "${pnlCreditCard.caption}",
                EDITMODE    : (isFormEditMode) ? isFormEditMode : isFormEditModeTemp,
                addPanel    : "${pnlCreditCardAdd.caption}"
            };
            CreditCardParam.newRow["creditCurrencySysName"] = form.formParams.creditCurrencySysName;
            form.startModalPageFlowProcess(form.getCurrentProjectSysname() + "/FORMLIB/inputApplication/CICReport/CICReportAdd", CreditCardParam).then(function (response) {
                if (!response) return;
                var newRow = response.newRow || {};
                if (CreditCardParam.EDITMODE == "view") return;
                if (selectedRow['id'] && CreditCardParam.EDITMODE != "add") {
                    //form.tblCreditCard.hideEditor();
                    if (newRow instanceof Object && Object.keys(newRow).length > 0) {
                        form.tblCreditCard.updateRow(selectedRow['id'], newRow);
                    }
                }
                else {
                    //form.tblCreditCard.hideEditor();
                    if (newRow instanceof Object && Object.keys(newRow).length > 0) {
                        newRow['id'] = new Date().getTime();
                        form.tblCreditCard.addRow(newRow);
                    }
                }
                var clientCreditCardList = getTableContent(form.tblCreditCard);
            });
        }
    };

    var obj = {
        gridId: grId,
        creditCardPanelIsCollapsed: !inputParams.CreditHistoryCreditCardCIC || inputParams.CreditHistoryCreditCardCIC.length == 0,
        refresh: function () {
            form[gridId].refresh();
        },
        onChangeItems: function () {
        },
        addNewRow: function () {
            obj.creditCardPanelIsCollapsed = false;
            this.options.editCreditCardItem(gRB("add") + " " + "${pnlCreditCard.caption}", "add");
        },
        setItems: function (items) {
            form[gridId].setItems(items);
        },
        getItems: function () {
            return form[gridId].getItems();
        },
        onSelectRow: function () {
            options.items = [];
            var selectedRow = form.tblCreditCard.getSelectedRow()[0];
            if (form.isFormEditMode == true) {
                options.items = [
                    {caption: gRB('edit'), click: form.tblCreditCard.options.editCreditCardItem},
                    {caption: gRB('delete'), click: form.tblCreditCard.options.delete}
                ];
            }
            else {
                options.items = [
                    {caption: gRB('view'), click: form.tblCreditCard.options.editCreditCardItem}
                ];
            }
        }
    };
    obj.options = options;
    return obj;
})('tblCreditCard');
//Loan
form.tblLoanObj = (function (grId) {
    var gridId = grId;
    var options = {
        delete: function () {
            if (form.tblLoan.getSelectedRow()[0]) {
                form.showDeleteDialog(gRB("dialog.confirmDelete"),
                function (idxData) {
                    if (idxData.buttonIndex == 0) {
                        form.tblLoan.deleteRow(obj.selectedId);
                        form[gridId].refresh();
                    }
                },
                [{caption: gRB('dialog.yes')}, {caption: gRB('dialog.cancel')}])
            }
        },
        editLoanItem : function (pageHeader, isFormEditMode) {
            var selectedRow = form.tblLoan.getSelectedRow()[0] || {};
            var pageHeaderTemp = (form.isFormEditMode) ? gRB("edit") : gRB("view");
            var isFormEditModeTemp = (form.isFormEditMode) ? "edit" : "view";
            var LoanParam = {
                newRow  : (isFormEditMode == "add") ? {} : selectedRow,
                PAGEHEADER  : (isFormEditMode) ? pageHeader : pageHeaderTemp + " " + "${pnlClientLoan.caption}",
                EDITMODE    : (isFormEditMode) ? isFormEditMode : isFormEditModeTemp,
                addPanel    : "${pnlClientLoanAdd.caption}",
                timeOfOverdueDebt : form.formParams.timeOfOverdueDebt
            };
            form.startModalPageFlowProcess(form.getCurrentProjectSysname() + "/FORMLIB/inputApplication/CICReport/CICReportAdd", LoanParam).then(function (response) {
                if (!response) return;
                var newRow = response.newRow || {};
                if (LoanParam.EDITMODE == "view") return;
                //form.tblLoan.hideEditor();
                if (selectedRow['id'] && LoanParam.EDITMODE != "add") {
                    if (newRow instanceof Object && Object.keys(newRow).length > 0) {
                        form.tblLoan.updateRow(selectedRow['id'], newRow);
                    }
                }
                else {
                    if (newRow instanceof Object && Object.keys(newRow).length > 0) {
                        newRow['id'] = new Date().getTime();
                        form.tblLoan.addRow(newRow);
                    }
                }
            });
        }
    };

    var obj = {
        gridId: grId,

        cols : [
             {
                value: 'bankName',
                type: 'text',
                caption: ('${tblLoan.bankName}'),
                width: 55
             },
             {
                 value: 'overdueGroup',
                 type: 'text',
                 caption: ('${tblLoan.overdueGroup}'),
                 width: 15
             },
             {
                value: 'overdueNumber',
                type: 'text',
                caption: ('${tblLoan.overdueNumber}'),
                width: 15
             },
             {
                value: 'item.debtPaidOff ? "${yes}" : "${no}"',
                type: 'expression',
                caption: ('${tblLoan.debtPaidOff}'),
                width: 45
             }
               ],
        loanPanelIsCollapsed: !inputParams.CreditHistoryLoanCIC || inputParams.CreditHistoryLoanCIC.length == 0,
        refresh: function () {
            form[gridId].refresh();
        },
        onChangeItems: function () {
        },
        addNewRow: function () {
            obj.loanPanelIsCollapsed = false;
            this.options.editLoanItem(gRB("add") + " " + "${pnlClientLoan.caption}", "add");
        },
        setItems: function (items) {
            form[gridId].setItems(items);
        },
        getItems: function () {
            return form[gridId].getItems();
        },
        onSelectRow: function () {
            options.items = [];
            var selectedRow = form.tblLoan.getSelectedRow()[0];
            if (form.isFormEditMode == true) {
                options.items = [
                    {caption: gRB('edit'), click: form.tblLoan.options.editLoanItem},
                    {caption: gRB('delete'), click: form.tblLoan.options.delete}
                ];
            }
            else {
                options.items = [
                    {caption: gRB('view'), click: form.tblLoan.options.editLoanItem}
                ];
            }
        }
    };
    obj.options = options;
    return obj;
})('tblLoan');

form.verifyForm = function (showFlag) {
    var verified = true;
    try {
        var btnNext =  form['btnNext'] ? 'btnNext' : 'btnSave';
        if (form.validateControlsByIds('*', showFlag === true ? btnNext : undefined).isShowFormErrors) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {lgr(e);
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    form.outputParams.VERIFIED = verified;
    return verified;
};

form.action = function (tagName) {
    outputParams.TRANSTYPE = tagName;
    outputParams.VERIFIED = true;
    var creditCardCICList = outputParams.CreditHistoryCreditCardCIC = form.tblCreditCardObj.getItems() || [];
    var loanCICList = outputParams.CreditHistoryLoanCIC = form.tblLoanObj.getItems() || [];
    outputParams.formParams.loansNumberCIC = loanCICList.length;
    outputParams.formParams.creditCardsNumberCIC = creditCardCICList.length;
    outputParams.formParams.overdueDebtGroup2AndAbove = false;
    if ( loanCICList instanceof Object && Object.keys(loanCICList).length > 0) {
        for (var i = 0; i < loanCICList.length; i++) {
            if (loanCICList[i].overdueGroupCICName > "2" && loanCICList[i].overdueNumber > "0") {
                outputParams.formParams.overdueDebtGroup2AndAbove = true;
                break;
            }
        }
    }

    if (tagName === 'CLOSE') {
        if(form.isFormEditMode == false){
            form.sendForm('GO',false);
        } else {
            service.showDialogCancelConfirm(
                form,
                function (){
                    form.outputParams.TRANSTYPE = 'SAVEDRAFT';
                    form.verifyForm(false);
                    form.sendForm('GO', false);
                }
            )
        }
    } else {

        if (tagName === 'NEXT' && !form.verifyForm(true)) {
            return;
        } else {
            form.verifyForm(false);
        }
        form.sendForm('GO', false);
    }
};