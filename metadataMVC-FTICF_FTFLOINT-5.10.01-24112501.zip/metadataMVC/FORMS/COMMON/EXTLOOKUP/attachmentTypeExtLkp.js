/*DSMETA version = "5.10.01-24112501" hash = "fd8d1a4d3e7bf6cd729cf7eddc950d2105409f9e"*/
form.formParams = {};
form.outputParams = form.formParams;
var formParams = form.formParams;

form.trAttachmentTypeOnSelect = function (v) {
    service.lgr(formParams.selectedNode);
    service.lgr(v);
};

form.trAttachmentTypeOnClick = function () {
    var selectedNode = formParams.selectedNode || [];

    if (selectedNode.length != 0) {
        var ACCESSMODE = selectedNode[0].ACCESSMODE || 'no';
        var STATEACCESSMODE = form.inputParams.STATEACCESSMODE;
        if ((ACCESSMODE === 'no' || ACCESSMODE === 'readonly' || ACCESSMODE === 'filter') && (STATEACCESSMODE === 'full' || STATEACCESSMODE === 'edit')) {
            form.showWarningDialog(form.getResourceBundle('AttachmentList.noRightDocType')+' «'+selectedNode[0].NAME+'»', function(){} ,[{caption: form.getResourceBundle("dialog.ok")}]);
            return;
        }
        if ((STATEACCESSMODE === 'no') || (STATEACCESSMODE === 'readonly')) {
            form.showWarningDialog(form.getResourceBundle('AttachmentList.noRightDocType')+' «'+selectedNode[0].NAME+'» ' + form.getResourceBundle('AttachmentList.noRightState'), function(){} ,[{caption: form.getResourceBundle("dialog.ok")}]);
            return;
        }
        formParams.KEY = selectedNode[0].SYSNAME;
        formParams.VALUE = selectedNode[0].name;
    }

    service.lgr(formParams);

    if (formParams.KEY) {
        formParams.LOOKUP_RESULT = "OK";
    } else {
        delete formParams.LOOKUP_RESULT
    }
    form.sendForm('NEXT');
};

form.cancel = function () {
    delete formParams.KEY;
    delete formParams.VALUE;
    delete formParams.LOOKUP_RESULT;
    form.sendForm("CANCEL");
};